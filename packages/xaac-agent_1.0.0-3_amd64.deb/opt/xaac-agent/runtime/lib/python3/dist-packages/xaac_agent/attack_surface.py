from __future__ import annotations

import argparse
import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable


@dataclass(frozen=True, slots=True)
class SurfaceFinding:
    code: str
    severity: str
    component: str
    message: str


@dataclass(frozen=True, slots=True)
class SurfaceReport:
    version: int
    passed: bool
    findings: tuple[SurfaceFinding, ...]
    reviewed_components: tuple[str, ...]

    def to_dict(self) -> dict[str, object]:
        return {
            "version": self.version,
            "passed": self.passed,
            "reviewed_components": list(self.reviewed_components),
            "findings": [asdict(item) for item in self.findings],
        }


def _directives(path: Path, section: str) -> dict[str, str]:
    current = ""
    values: dict[str, str] = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or line.startswith(";"):
            continue
        if line.startswith("[") and line.endswith("]"):
            current = line[1:-1]
            continue
        if current == section and "=" in line:
            key, value = line.split("=", 1)
            values[key] = value
    return values


def review_attack_surface(project_root: Path) -> SurfaceReport:
    findings: list[SurfaceFinding] = []
    agent_path = project_root / "debian/systemd/xaac-agent.service"
    helper_path = project_root / "debian/systemd/xaac-privileged-helper.service"
    socket_path = project_root / "debian/systemd/xaac-privileged-helper.socket"
    pyproject_path = project_root / "pyproject.toml"

    required = (agent_path, helper_path, socket_path, pyproject_path)
    for path in required:
        if not path.is_file():
            findings.append(SurfaceFinding("missing_artifact", "critical", str(path.relative_to(project_root)), "Required security artifact is missing"))
    if findings:
        return SurfaceReport(1, False, tuple(findings), tuple(str(p.relative_to(project_root)) for p in required))

    agent = _directives(agent_path, "Service")
    helper = _directives(helper_path, "Service")
    sock = _directives(socket_path, "Socket")

    _expect(findings, agent.get("User") == "xaac-agent", "agent_runs_as_root", "critical", "xaac-agent.service", "Main agent must run as xaac-agent")
    _expect(findings, agent.get("NoNewPrivileges") == "true", "agent_new_privileges", "critical", "xaac-agent.service", "NoNewPrivileges must be enabled")
    _expect(findings, agent.get("CapabilityBoundingSet") == "", "agent_capabilities", "critical", "xaac-agent.service", "Main agent capability bounding set must be empty")
    _expect(findings, agent.get("ProtectSystem") == "strict", "agent_filesystem_write", "high", "xaac-agent.service", "ProtectSystem must be strict")
    families = set(agent.get("RestrictAddressFamilies", "").split())
    _expect(findings, families <= {"AF_UNIX", "AF_INET", "AF_INET6", "AF_NETLINK"} and bool(families), "agent_socket_family", "high", "xaac-agent.service", "Unexpected socket family exposed")
    _expect(findings, "AF_PACKET" not in families, "raw_packet_access", "critical", "xaac-agent.service", "AF_PACKET must not be available")

    _expect(findings, helper.get("RestrictAddressFamilies") == "AF_UNIX", "helper_network_access", "critical", "xaac-privileged-helper.service", "Privileged helper must only use AF_UNIX")
    _expect(findings, helper.get("NoNewPrivileges") == "true", "helper_new_privileges", "high", "xaac-privileged-helper.service", "Privileged helper must not gain additional privileges")
    capabilities = set(helper.get("CapabilityBoundingSet", "").split())
    _expect(findings, capabilities == {"CAP_SYS_BOOT"}, "helper_capabilities", "critical", "xaac-privileged-helper.service", "Privileged helper must expose only CAP_SYS_BOOT")

    _expect(findings, sock.get("ListenStream") == "/run/xaac-agent/privileged.sock", "helper_socket_path", "high", "xaac-privileged-helper.socket", "Privileged socket path is not the approved path")
    _expect(findings, sock.get("SocketMode") == "0660", "helper_socket_mode", "critical", "xaac-privileged-helper.socket", "Privileged socket must use mode 0660")
    _expect(findings, sock.get("SocketGroup") == "xaac-command", "helper_socket_group", "critical", "xaac-privileged-helper.socket", "Privileged socket must use xaac-command group")

    pyproject = pyproject_path.read_text(encoding="utf-8")
    scripts = tuple(line.strip() for line in pyproject.splitlines() if line.strip().startswith("xaac-") and "=" in line)
    approved = {"xaac-agent", "xaac-privileged-helper", "xaac-xms-simulator", "xaac-attack-surface-audit", "xaac-network-diagnostics", "xaac-service-diagnostics", "xaac-system-diagnostics", "xaac-thin-client-rdp-diagnostics", "xaac-support-bundle", "xaac-redact-diagnostics", "xaac-upload-support-bundle", "xaac-retention-cleanup", "xaac-soak-test", "xaac-production-profile-validate", "xaac-local-recovery", "xaac-chaos-test", "xaac-config-migrate"}
    exposed = {line.split("=", 1)[0].strip() for line in scripts}
    _expect(findings, exposed <= approved, "unexpected_entry_point", "high", "pyproject.toml", "Unexpected executable entry point exposed")

    reviewed = tuple(str(p.relative_to(project_root)) for p in required)
    return SurfaceReport(1, not any(item.severity in {"critical", "high"} for item in findings), tuple(findings), reviewed)


def _expect(findings: list[SurfaceFinding], condition: bool, code: str, severity: str, component: str, message: str) -> None:
    if not condition:
        findings.append(SurfaceFinding(code, severity, component, message))


def main(argv: Iterable[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Audit the static XAAC Agent attack surface")
    parser.add_argument("--project-root", type=Path, default=Path.cwd())
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(list(argv) if argv is not None else None)
    report = review_attack_surface(args.project_root.resolve())
    if args.json:
        print(json.dumps(report.to_dict(), sort_keys=True, separators=(",", ":")))
    else:
        print("PASS" if report.passed else "FAIL")
        for finding in report.findings:
            print(f"{finding.severity.upper()} {finding.code} {finding.component}: {finding.message}")
    return 0 if report.passed else 1


if __name__ == "__main__":
    raise SystemExit(main())

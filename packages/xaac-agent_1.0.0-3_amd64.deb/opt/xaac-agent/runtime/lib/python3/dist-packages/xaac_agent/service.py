from __future__ import annotations

import logging
import signal
from datetime import datetime, timezone
from pathlib import Path
from types import FrameType

from xaac_agent.device_keys import DeviceKeyStore
from xaac_agent.authentication import authenticate_payload
from xaac_agent.command_ack import CommandJournal, CommandJournalError
from xaac_agent.command_audit import CommandAuditJournal, CommandAuditError
from xaac_agent.command_authorization import CommandAuthorizationPolicy
from xaac_agent.command_model import Command, CommandResult, CommandState, CommandType, CommandValidationError
from xaac_agent.power_commands import PowerCommandExecutor
from xaac_agent.service_commands import ServiceCommandExecutor
from xaac_agent.task_commands import TaskCommandExecutor
from xaac_agent.file_transfer_commands import FileTransferCommandExecutor, parse_file_targets
from xaac_agent.log_collection_commands import LogCollectionCommandExecutor
from xaac_agent.signed_script_commands import SignedScriptCommandExecutor, parse_signed_scripts, parse_trusted_script_keys
from xaac_agent.config import (
    AgentConfigurationError,
    AgentSettings,
    ConfigurationReloadResult,
    reload_settings,
)
from xaac_agent.enrollment import (
    DeviceCredentials,
    CredentialRenewalRequest,
    DeviceCredentialsStore,
    EnrollmentError,
    EnrollmentRequest,
    UnenrollmentRequest,
)
from xaac_agent.health import HealthStateStore, LastFailureStore
from xaac_agent.heartbeat_state import HeartbeatSequenceStore, HeartbeatStateError, read_uptime_seconds
from xaac_agent.identity import DeviceIdentityStore
from xaac_agent.inventory import InventoryCollector
from xaac_agent.inventory_incremental import InventoryStateError, InventoryStateStore
from xaac_agent.process_lock import ProcessLock
from xaac_agent.outbox import PersistentOutbox, OutboxError, OutboxMessage
from xaac_agent.offline import OfflineStateError, OfflineStateStore
from xaac_agent.protocol import Heartbeat
from xaac_agent.registration import RegistrationStateError, RegistrationStateStore
from xaac_agent.retry import RetryController
from xaac_agent.resource_monitoring import MonitoringThresholds, ResourceMonitor
from xaac_agent.memory_pressure import MemoryPressureMonitor, MemoryPressurePolicy
from xaac_agent.cpu_sampling import CpuSamplingMonitor, CpuSamplingPolicy
from xaac_agent.emmc_monitoring import EmmcMonitor, EmmcPolicy
from xaac_agent.hardware_profile import HardwareProfileDetector
from xaac_agent.production_profile import resolve_production_profile, ProductionProfileError
from xaac_agent.disk_monitoring import DiskMonitor, FilesystemThresholds
from xaac_agent.thermal_monitoring import ThermalMonitor, ThermalPolicy, ThermalThresholds
from xaac_agent.process_service_monitoring import ProcessServiceMonitor
from xaac_agent.network_monitoring import NetworkMonitor, NetworkOptimizationPolicy, NetworkThresholds
from xaac_agent.startup_monitoring import StartupMonitor, StartupPolicy
from xaac_agent.connectivity_monitoring import ConnectivityMonitor, ConnectivityThresholds
from xaac_agent.certificate_monitoring import CertificateCredentialMonitor, ExpiryThresholds
from xaac_agent.monitoring_aggregation import MonitoringAggregator
from xaac_agent.adaptive_delivery import AdaptiveDeliveryController, AdaptiveDeliveryPolicy
from xaac_agent.local_alerts import LocalAlertManager, LocalAlertStateError
from xaac_agent.secrets import SecretFile
from xaac_agent.scheduler import ScheduledTask, TaskScheduler
from xaac_agent.systemd_notify import SystemdNotifier
from xaac_agent.transport import AgentTransportError, XmpTransport
from xaac_agent.tpm import TpmError, TpmMonitor, TpmPolicy
from xaac_agent.boot_security import BootSecurityError, BootSecurityMonitor, BootSecurityPolicy
from xaac_agent.file_integrity import FileIntegrityError, FileIntegrityMonitor, FileIntegrityPolicy
from xaac_agent.compromise_response import CompromiseResponseManager, CompromiseResponsePolicy
from xaac_agent.watchdog import WatchdogMonitor
from xaac_agent.recovery import RecoveryStateError, RecoveryStateStore
from xaac_agent.xms_address import XmsAddressStore, XmsAddressError
from xaac_agent.xms_failover import XmsFailoverStore, XmsFailoverError
from xaac_agent.safe_mode import SafeModeStore, SafeModeError

logger = logging.getLogger(__name__)


class AgentService:
    def __init__(
        self,
        settings: AgentSettings,
        *,
        config_path: Path | None = None,
        transport: XmpTransport | None = None,
        collector: InventoryCollector | None = None,
        scheduler: TaskScheduler | None = None,
        notifier: SystemdNotifier | None = None,
        resource_monitor: ResourceMonitor | None = None,
        memory_pressure_monitor: MemoryPressureMonitor | None = None,
        cpu_sampling_monitor: CpuSamplingMonitor | None = None,
        emmc_monitor: EmmcMonitor | None = None,
        disk_monitor: DiskMonitor | None = None,
        thermal_monitor: ThermalMonitor | None = None,
        process_service_monitor: ProcessServiceMonitor | None = None,
        network_monitor: NetworkMonitor | None = None,
        startup_monitor: StartupMonitor | None = None,
        connectivity_monitor: ConnectivityMonitor | None = None,
        certificate_monitor: CertificateCredentialMonitor | None = None,
        monitoring_aggregator: MonitoringAggregator | None = None,
        local_alert_manager: LocalAlertManager | None = None,
        adaptive_delivery_controller: AdaptiveDeliveryController | None = None,
        power_command_executor: PowerCommandExecutor | None = None,
        service_command_executor: ServiceCommandExecutor | None = None,
        task_command_executor: TaskCommandExecutor | None = None,
        file_transfer_command_executor: FileTransferCommandExecutor | None = None,
        log_collection_command_executor: LogCollectionCommandExecutor | None = None,
        signed_script_command_executor: SignedScriptCommandExecutor | None = None,
        command_audit_journal: CommandAuditJournal | None = None,
        tpm_monitor: TpmMonitor | None = None,
        boot_security_monitor: BootSecurityMonitor | None = None,
        file_integrity_monitor: FileIntegrityMonitor | None = None,
        compromise_response_manager: CompromiseResponseManager | None = None,
        recovery_state_store: RecoveryStateStore | None = None,
    ) -> None:
        try:
            effective_url = XmsAddressStore(settings.xms_address_state_file, require_https=settings.xms_address_require_https and not settings.allow_http).resolve(settings.server_url)
        except XmsAddressError as error:
            raise AgentConfigurationError(str(error)) from error
        settings = __import__("dataclasses").replace(settings, server_url=effective_url)
        self._xms_failover = None
        if effective_url:
            try:
                self._xms_failover = XmsFailoverStore(
                    settings.xms_failover_state_file,
                    primary_url=effective_url,
                    alternate_urls=settings.xms_authorized_alternate_urls,
                    failure_threshold=settings.xms_failover_failure_threshold,
                    require_https=settings.xms_address_require_https and not settings.allow_http,
                )
                failover_state = self._xms_failover.load()
            except XmsFailoverError as error:
                raise AgentConfigurationError(str(error)) from error
            settings = __import__("dataclasses").replace(settings, server_url=failover_state.active_url)
        self._settings = settings
        self._hardware_profile = HardwareProfileDetector().detect()
        try:
            self._production_profile = resolve_production_profile(self._hardware_profile, settings.production_profile_mode)
        except ProductionProfileError as error:
            raise AgentConfigurationError(str(error)) from error
        self._config_path = config_path
        self._transport = transport or XmpTransport()
        self._collector = collector or InventoryCollector(configuration_summary=self._inventory_configuration_summary(settings))
        self._scheduler = scheduler or TaskScheduler()
        self._health = HealthStateStore(self._settings.health_file)
        self._failure_store = LastFailureStore(self._settings.last_failure_file)
        self._recovery = recovery_state_store or RecoveryStateStore(self._settings.recovery_state_file)
        self._safe_mode = SafeModeStore(self._settings.safe_mode_state_file)
        self._registration_store = RegistrationStateStore(self._settings.registration_state_file)
        self._heartbeat_sequences = HeartbeatSequenceStore(self._settings.heartbeat_state_file)
        self._inventory_state = InventoryStateStore(
            self._settings.inventory_state_file,
            full_interval_heartbeats=self._settings.inventory_full_interval_heartbeats,
        )
        self._command_authorization = CommandAuthorizationPolicy.from_strings(
            allowed_types=self._settings.command_allowed_types,
            local_capabilities=self._settings.command_local_capabilities,
            allowed_issuer_kinds=self._settings.command_allowed_issuer_kinds,
            agent_user=self._settings.command_agent_user,
            privileged_helper_user=self._settings.command_privileged_helper_user,
            allowed_services=self._settings.command_allowed_services,
            allowed_tasks=self._settings.command_allowed_tasks,
            allowed_file_targets=tuple(value.partition("=")[0].strip() for value in self._settings.command_allowed_file_targets),
            allowed_log_sources=self._settings.command_allowed_log_sources,
            allowed_signed_scripts=tuple(value.partition("=")[0].strip() for value in self._settings.command_allowed_signed_scripts),
            trusted_script_keys=tuple(value.partition("=")[0].strip() for value in self._settings.command_trusted_script_keys),
            max_script_bytes=self._settings.command_max_script_bytes,
            max_log_lines=self._settings.command_max_log_lines, max_log_bytes=self._settings.command_max_log_bytes,
            max_log_since_seconds=self._settings.command_max_log_since_seconds,
            max_file_bytes=self._settings.command_max_file_bytes,
            max_delay_seconds=self._settings.command_max_delay_seconds,
            max_timeout_seconds=self._settings.command_max_timeout_seconds,
        )
        self._power_command_executor = power_command_executor or PowerCommandExecutor.system_default()
        self._service_command_executor = service_command_executor or ServiceCommandExecutor.system_default()
        self._task_command_executor = task_command_executor or TaskCommandExecutor.system_default()
        self._file_transfer_command_executor = file_transfer_command_executor or FileTransferCommandExecutor.system_default(
            targets=parse_file_targets(self._settings.command_allowed_file_targets),
            max_file_bytes=self._settings.command_max_file_bytes,
        )
        self._log_collection_command_executor = log_collection_command_executor or LogCollectionCommandExecutor.system_default(
            max_lines=self._settings.command_max_log_lines, max_bytes=self._settings.command_max_log_bytes,
            max_since_seconds=self._settings.command_max_log_since_seconds,
        )
        self._signed_script_command_executor = signed_script_command_executor or SignedScriptCommandExecutor.system_default(
            scripts=parse_signed_scripts(self._settings.command_allowed_signed_scripts),
            trusted_keys=parse_trusted_script_keys(self._settings.command_trusted_script_keys),
            max_script_bytes=self._settings.command_max_script_bytes,
        )
        self._command_audit = command_audit_journal or CommandAuditJournal(
            self._settings.command_audit_file, max_records=self._settings.command_audit_max_records
        )
        self._command_journal = CommandJournal(
            self._settings.command_journal_file,
            authorization_policy=self._command_authorization,
            max_lifetime_seconds=self._settings.command_max_lifetime_seconds,
            replay_window_seconds=self._settings.command_replay_window_seconds,
            clock_skew_seconds=self._settings.command_clock_skew_seconds,
            require_nonce=self._settings.command_require_nonce,
            reject_command_id_reuse=self._settings.command_reject_id_reuse,
        )
        self._offline = OfflineStateStore(
            self._settings.offline_state_file,
            prolonged_threshold_seconds=self._settings.offline_prolonged_threshold_seconds,
        )
        self._outbox = PersistentOutbox(
            self._settings.outbox_file,
            max_messages=self._settings.outbox_max_messages,
            max_bytes=self._settings.outbox_max_bytes,
        )
        self._resource_monitor = resource_monitor or self._build_resource_monitor(self._settings)
        self._memory_pressure_monitor = memory_pressure_monitor or self._build_memory_pressure_monitor()
        self._cpu_sampling_monitor = cpu_sampling_monitor or self._build_cpu_sampling_monitor()
        self._emmc_monitor = emmc_monitor or self._build_emmc_monitor()
        self._disk_monitor = disk_monitor or self._build_disk_monitor(self._settings)
        self._thermal_monitor = thermal_monitor or self._build_thermal_monitor(self._settings)
        self._process_service_monitor = process_service_monitor or self._build_process_service_monitor(self._settings)
        self._network_monitor = network_monitor or self._build_network_monitor(self._settings)
        self._startup_monitor = startup_monitor or self._build_startup_monitor()
        self._connectivity_monitor = connectivity_monitor or self._build_connectivity_monitor(self._settings)
        self._certificate_monitor = certificate_monitor or self._build_certificate_monitor(self._settings)
        self._tpm_monitor = tpm_monitor or TpmMonitor(TpmPolicy(enabled=settings.tpm_enabled, required=settings.tpm_required, device_path=settings.tpm_device_path, pcr_bank=settings.tpm_pcr_bank, pcrs=settings.tpm_pcrs, command_timeout_seconds=settings.tpm_command_timeout_seconds))
        self._boot_security_monitor = boot_security_monitor or BootSecurityMonitor(BootSecurityPolicy(enabled=settings.boot_security_enabled, require_uefi=settings.boot_require_uefi, require_secure_boot=settings.boot_require_secure_boot, efi_variables_path=settings.boot_efi_variables_path, kernel_lockdown_path=settings.boot_kernel_lockdown_path))
        self._file_integrity_monitor = file_integrity_monitor or FileIntegrityMonitor(FileIntegrityPolicy(enabled=settings.file_integrity_enabled, required=settings.file_integrity_required, manifest_path=settings.file_integrity_manifest_path, max_manifest_bytes=settings.file_integrity_max_manifest_bytes, max_files=settings.file_integrity_max_files, max_file_bytes=settings.file_integrity_max_file_bytes))
        self._compromise_response = compromise_response_manager or CompromiseResponseManager(CompromiseResponsePolicy(enabled=settings.compromise_response_enabled, automatic_quarantine=settings.compromise_automatic_quarantine, state_file=settings.compromise_state_file, block_remote_commands=settings.compromise_block_remote_commands, block_updates=settings.compromise_block_updates, allow_heartbeat=settings.compromise_allow_heartbeat, max_state_bytes=settings.compromise_max_state_bytes))
        self._monitoring_aggregator = monitoring_aggregator or MonitoringAggregator(
            window_samples=self._settings.monitoring_aggregation_window_samples
        )
        self._local_alert_manager = local_alert_manager or LocalAlertManager(
            self._settings.local_alert_state_file,
            recovery_enabled=self._settings.local_alert_recovery_enabled,
        )
        self._adaptive_delivery = adaptive_delivery_controller or self._build_adaptive_delivery(self._settings)
        self._negotiated_heartbeat_interval = self._settings.heartbeat_interval_seconds
        self._retry = RetryController(
            base_delay_seconds=self._settings.retry_base_delay_seconds,
            max_delay_seconds=self._settings.retry_max_delay_seconds,
            jitter_ratio=self._settings.retry_jitter_ratio,
            circuit_failure_threshold=self._settings.circuit_failure_threshold,
            circuit_open_seconds=self._settings.circuit_open_seconds,
        )
        try:
            persisted_offline = self._offline.load()
            if persisted_offline.offline:
                self._retry.restore(
                    consecutive_failures=persisted_offline.consecutive_failures,
                    delay_seconds=persisted_offline.remaining_retry_seconds(),
                )
        except OfflineStateError as error:
            logger.error("offline_state_restore_failed error=%s", error)
        self._watchdog = WatchdogMonitor(
            notifier or SystemdNotifier.from_environment(),
            on_stall=self._on_watchdog_stall,
        )
        self._stopping = False
        self._restart_required_fields: frozenset[str] = frozenset()

    @staticmethod
    def _build_resource_monitor(settings: AgentSettings) -> ResourceMonitor:
        return ResourceMonitor(
            window_samples=settings.monitoring_window_samples,
            thresholds=MonitoringThresholds(
                cpu_warning_percent=settings.cpu_warning_percent,
                cpu_critical_percent=settings.cpu_critical_percent,
                memory_warning_percent=settings.memory_warning_percent,
                memory_critical_percent=settings.memory_critical_percent,
                load_warning_per_cpu=settings.load_warning_per_cpu,
                load_critical_per_cpu=settings.load_critical_per_cpu,
                hysteresis_percent=settings.monitoring_hysteresis_percent,
            ),
        )

    @staticmethod
    def _build_memory_pressure_monitor() -> MemoryPressureMonitor:
        profile = HardwareProfileDetector().detect()
        return MemoryPressureMonitor(MemoryPressurePolicy.for_profile(profile))

    @staticmethod
    def _build_cpu_sampling_monitor() -> CpuSamplingMonitor:
        profile = HardwareProfileDetector().detect()
        return CpuSamplingMonitor(CpuSamplingPolicy.for_profile(profile))

    @staticmethod
    def _build_emmc_monitor() -> EmmcMonitor:
        profile = HardwareProfileDetector().detect()
        return EmmcMonitor(EmmcPolicy.for_profile(profile))

    @staticmethod
    def _build_disk_monitor(settings: AgentSettings) -> DiskMonitor:
        return DiskMonitor(
            thresholds=FilesystemThresholds(
                warning_percent=settings.disk_warning_percent,
                critical_percent=settings.disk_critical_percent,
                hysteresis_percent=settings.monitoring_hysteresis_percent,
            )
        )

    @staticmethod
    def _build_thermal_monitor(settings: AgentSettings) -> ThermalMonitor:
        profile = HardwareProfileDetector().detect()
        configured = ThermalThresholds(
            warning_celsius=settings.temperature_warning_celsius,
            critical_celsius=settings.temperature_critical_celsius,
            hysteresis_celsius=settings.temperature_hysteresis_celsius,
        )
        return ThermalMonitor(policy=ThermalPolicy.for_profile(profile, configured))

    @staticmethod
    def _build_process_service_monitor(settings: AgentSettings) -> ProcessServiceMonitor:
        return ProcessServiceMonitor(
            process_names=settings.critical_processes,
            service_names=settings.critical_services,
            service_timeout_seconds=settings.service_check_timeout_seconds,
        )

    @staticmethod
    def _build_startup_monitor() -> StartupMonitor:
        profile = HardwareProfileDetector().detect()
        return StartupMonitor(StartupPolicy.for_profile(profile))

    @staticmethod
    def _build_network_monitor(settings: AgentSettings) -> NetworkMonitor:
        profile = HardwareProfileDetector().detect()
        return NetworkMonitor(
            policy=NetworkOptimizationPolicy.for_profile(profile),
            thresholds=NetworkThresholds(
                warning_error_percent=settings.network_warning_error_percent,
                critical_error_percent=settings.network_critical_error_percent,
                hysteresis_percent=settings.network_hysteresis_percent,
            )
        )

    @staticmethod
    def _build_connectivity_monitor(settings: AgentSettings) -> ConnectivityMonitor:
        return ConnectivityMonitor(
            settings.server_url,
            timeout_seconds=settings.connectivity_timeout_seconds,
            thresholds=ConnectivityThresholds(
                warning_latency_ms=settings.connectivity_warning_latency_ms,
                critical_latency_ms=settings.connectivity_critical_latency_ms,
                hysteresis_ms=settings.connectivity_hysteresis_ms,
            ),
            tls_ca_file=settings.tls_ca_file,
            tls_minimum_version=settings.tls_minimum_version,
            tls_maximum_version=settings.tls_maximum_version,
            tls_ciphers=settings.tls_ciphers,
            tls_certificate_pins=settings.tls_certificate_pins,
        )

    @staticmethod
    def _build_certificate_monitor(settings: AgentSettings) -> CertificateCredentialMonitor:
        return CertificateCredentialMonitor(
            settings.server_url,
            settings.device_credentials_file,
            timeout_seconds=settings.certificate_check_timeout_seconds,
            thresholds=ExpiryThresholds(
                warning_days=settings.certificate_warning_days,
                critical_days=settings.certificate_critical_days,
            ),
            tls_ca_file=settings.tls_ca_file,
        )


    @staticmethod
    def _build_adaptive_delivery(settings: AgentSettings) -> AdaptiveDeliveryController:
        return AdaptiveDeliveryController(AdaptiveDeliveryPolicy(
            enabled=settings.adaptive_delivery_enabled,
            warning_interval_seconds=settings.adaptive_warning_interval_seconds,
            critical_interval_seconds=settings.adaptive_critical_interval_seconds,
            normal_relax_after_samples=settings.adaptive_normal_relax_after_samples,
            normal_interval_multiplier=settings.adaptive_normal_interval_multiplier,
            reduced_outbox_batch_size=settings.adaptive_reduced_outbox_batch_size,
            offline_outbox_batch_size=settings.adaptive_offline_outbox_batch_size,
        ))

    @staticmethod
    def _inventory_configuration_summary(settings: AgentSettings) -> dict[str, object]:
        return {
            "enabled": settings.enabled,
            "transport": "https" if settings.server_url.startswith("https://") else ("http" if settings.server_url else "unconfigured"),
            "heartbeat_interval_seconds": settings.heartbeat_interval_seconds,
            "compression_enabled": settings.compression_enabled,
            "proxy_configured": bool(settings.proxy_url),
            "custom_ca_configured": settings.tls_ca_file is not None,
        }

    @property
    def settings(self) -> AgentSettings:
        return self._settings

    @property
    def stopping(self) -> bool:
        return self._stopping

    @property
    def restart_required_fields(self) -> frozenset[str]:
        return self._restart_required_fields

    def run_once(self) -> bool:
        with ProcessLock(self._settings.process_lock_file):
            return self._run_once_unlocked()

    def _run_once_unlocked(self) -> bool:
        if not self._settings.enabled:
            logger.info("agent_disabled")
            return True
        try:
            registration = self._registration_store.load()
        except RegistrationStateError as error:
            logger.error("registration_state_invalid error=%s", error)
            return False
        if registration.blocks_enrollment:
            logger.warning("device_management_blocked status=%s reason=%s", registration.status, registration.reason or "unspecified")
            self._health.update(status=registration.status)
            return False
        identity = DeviceIdentityStore(self._settings.device_identity_file).load_or_create()
        key_pair = DeviceKeyStore(self._settings.device_private_key_file).load_or_create()
        inventory = self._collector.collect()
        try:
            credentials = self._load_or_enroll(
                identity, key_pair, inventory.to_payload().get("hardware", {})
            )
            credentials = self._renew_credentials_if_needed(credentials, key_pair)
            if registration.status != "active":
                self._registration_store.mark_active()
                logger.info("device_reenrolled device_id=%s", identity.device_id)
        except (EnrollmentError, AgentTransportError) as error:
            logger.warning("enrollment_failed error=%s", error)
            self._health.mark_heartbeat(False)
            return False
        try:
            heartbeat_sequence = self._heartbeat_sequences.next()
        except HeartbeatStateError as error:
            logger.error("heartbeat_state_invalid error=%s", error)
            self._health.mark_heartbeat(False)
            return False
        try:
            inventory_transmission = self._inventory_state.prepare(
                inventory.to_payload(), heartbeat_sequence=heartbeat_sequence.sequence
            )
        except InventoryStateError as error:
            logger.error("inventory_state_invalid error=%s", error)
            self._health.mark_heartbeat(False)
            return False
        try:
            pending_acks = self._command_journal.pending()
        except CommandJournalError as error:
            logger.error('command_journal_invalid error=%s', error)
            self._health.mark_heartbeat(False)
            return False
        monitoring = self._resource_monitor.sample() if self._settings.monitoring_enabled else {}
        monitoring["production_profile"] = self._production_profile.to_payload()
        monitoring["recovery"] = self._recovery.telemetry()
        if self._settings.monitoring_enabled:
            monitoring["memory_pressure"] = self._memory_pressure_monitor.sample()
            monitoring["cpu_sampling"] = self._cpu_sampling_monitor.sample(
                resource_severity=str(monitoring.get("severity", "normal"))
            )
            monitoring["emmc"] = self._emmc_monitor.sample()
            monitoring["storage"] = self._disk_monitor.sample()
            monitoring["thermal"] = self._thermal_monitor.sample()
            monitoring["processes_services"] = self._process_service_monitor.sample()
            monitoring["network"] = self._network_monitor.sample()
            monitoring["startup"] = self._startup_monitor.sample()
            if self._settings.connectivity_check_enabled:
                monitoring["xms_connectivity"] = self._connectivity_monitor.sample()
            if self._settings.certificate_monitoring_enabled:
                monitoring["certificates_credentials"] = self._certificate_monitor.sample()
            if self._settings.boot_security_enabled:
                try:
                    monitoring["boot_security"] = self._boot_security_monitor.sample()
                except BootSecurityError as error:
                    logger.error("boot_security_requirement_failed error=%s", error)
                    self._health.mark_heartbeat(False)
                    return False
            if self._settings.file_integrity_enabled:
                try:
                    monitoring["file_integrity"] = self._file_integrity_monitor.sample()
                except FileIntegrityError as error:
                    logger.error("file_integrity_requirement_failed error=%s", error)
                    self._health.mark_heartbeat(False)
                    return False
            if self._settings.compromise_response_enabled:
                monitoring["compromise_response"] = self._compromise_response.telemetry()
            if self._settings.tpm_enabled:
                try:
                    monitoring["tpm"] = self._tpm_monitor.sample()
                except TpmError as error:
                    logger.error("tpm_required_unavailable error=%s", error)
                    self._health.mark_heartbeat(False)
                    return False
            component_severities = (
                monitoring["memory_pressure"].get("severity"),
                monitoring["cpu_sampling"].get("severity"),
                monitoring["emmc"].get("severity"),
                monitoring["storage"].get("severity"),
                monitoring["thermal"].get("severity"),
                monitoring["processes_services"].get("severity"),
                monitoring["network"].get("severity"),
                monitoring["startup"].get("severity"),
                monitoring.get("xms_connectivity", {}).get("severity"),
                monitoring.get("certificates_credentials", {}).get("severity"),
                monitoring.get("tpm", {}).get("severity"),
                monitoring.get("boot_security", {}).get("severity"),
                monitoring.get("file_integrity", {}).get("severity"),
                monitoring.get("compromise_response", {}).get("severity"),
            )
            if "critical" in component_severities:
                monitoring["severity"] = "critical"
            elif "warning" in component_severities and monitoring.get("severity") == "normal":
                monitoring["severity"] = "warning"
            monitoring["aggregation"] = self._monitoring_aggregator.add(monitoring)
            if self._settings.local_alerts_enabled:
                try:
                    alerts = self._local_alert_manager.evaluate(monitoring)
                    for alert in alerts:
                        priority = (
                            self._settings.local_alert_critical_priority
                            if alert.current_state == "critical"
                            else self._settings.local_alert_warning_priority
                        )
                        self.queue_message(
                            "monitoring-alert",
                            alert.to_payload(),
                            priority=priority,
                            message_id=alert.alert_id,
                            ttl_seconds=self._settings.local_alert_ttl_seconds,
                        )
                    if alerts:
                        monitoring["local_alerts"] = {
                            "generated": len(alerts),
                            "events": [alert.to_payload() for alert in alerts],
                        }
                except (LocalAlertStateError, OutboxError) as error:
                    logger.error("local_alert_processing_failed error=%s", error)
        try:
            offline_before_attempt = self._offline.load().offline
        except OfflineStateError as error:
            logger.error("offline_state_invalid error=%s", error)
            offline_before_attempt = False
        delivery_decision = self._adaptive_delivery.decide(
            severity=str(monitoring.get("severity", "normal")),
            offline=offline_before_attempt,
            base_interval_seconds=self._negotiated_heartbeat_interval,
            min_interval_seconds=self._settings.heartbeat_min_interval_seconds,
            max_interval_seconds=self._settings.heartbeat_max_interval_seconds,
            configured_outbox_batch_size=self._settings.outbox_batch_size,
        )
        if monitoring:
            monitoring["adaptive_delivery"] = delivery_decision.to_payload()
            monitoring = self._adaptive_delivery.shape_monitoring(
                monitoring, delivery_decision.telemetry_profile
            )
        try:
            self._scheduler.update_task_interval("heartbeat", delivery_decision.interval_seconds)
        except KeyError:
            pass
        outbox_delivery_id: str | None = None
        try:
            outbox_delivery_id, pending_outbox, outbox_recovery = self._outbox.reserve_batch(
                limit=delivery_decision.outbox_batch_size,
                minimum_priority=(
                    self._settings.critical_message_priority
                    if delivery_decision.critical_only
                    else None
                ),
            )
            monitoring["outbox_recovery"] = outbox_recovery.to_payload()
            try:
                monitoring["safe_mode"] = self._safe_mode.load().to_payload()
            except SafeModeError as error:
                monitoring["safe_mode"] = {"schema_version": 1, "active": True, "reason": "safe_mode_state_invalid"}
                logger.error("safe_mode_state_invalid error=%s", error)
        except OutboxError as error:
            logger.error('outbox_invalid error=%s', error)
            self._health.mark_heartbeat(False)
            return False
        heartbeat = Heartbeat.create(
            identity,
            inventory,
            boot_id=heartbeat_sequence.boot_id,
            uptime_seconds=read_uptime_seconds(),
            heartbeat_sequence=heartbeat_sequence.sequence,
            agent_state=self._health.state.status,
            enrollment_state=registration.status,
            health={
                "connectivity": self._offline_payload(),
                "configuration_valid": True,
                "credential_valid": True,
                "watchdog_active": self._watchdog.enabled,
                "consecutive_heartbeat_failures": self._health.state.consecutive_heartbeat_failures,
                "restart_required": bool(self._restart_required_fields),
                "safe_mode": bool(monitoring.get("safe_mode", {}).get("active", False)),
            },
            command_acknowledgements=tuple(ack.to_payload() for ack in pending_acks),
            outbox_messages=tuple(message.to_payload() for message in pending_outbox),
            inventory_payload=inventory_transmission.payload,
            inventory_mode=inventory_transmission.mode,
            inventory_fingerprint=inventory_transmission.fingerprint,
            inventory_base_fingerprint=inventory_transmission.base_fingerprint,
            inventory_removed_paths=inventory_transmission.removed_paths,
            monitoring=monitoring,
            capabilities=tuple(sorted(set(getattr(self._collector, "capabilities", ())) | {
                "enrollment", "credential-renewal", "authenticated-heartbeat", "revocation",
                "unenrollment", "command-acknowledgements", "persistent-outbox",
                "inventory-incremental", "outbox-state-recovery", "prolonged-network-loss-recovery", "authorized-xms-failover", "safe-mode", "monitoring-cpu-memory-load", "monitoring-filesystems",
                "monitoring-thermal-sensors", "monitoring-processes-services",
                "monitoring-network", "monitoring-xms-connectivity",
                "monitoring-certificates-credentials", "monitoring-aggregation",
                "monitoring-local-alerts", "monitoring-adaptive-delivery",
            })),
        )
        retry_decision = self._retry.before_attempt()
        if not retry_decision.allowed:
            logger.warning(
                "heartbeat_deferred retry_in_seconds=%.3f circuit_open=%s failures=%s",
                retry_decision.delay_seconds,
                retry_decision.circuit_open,
                retry_decision.consecutive_failures,
            )
            self._apply_retry_interval(retry_decision.delay_seconds)
            self._mark_offline("circuit_open", retry_decision.delay_seconds)
            if outbox_delivery_id:
                try:
                    self._outbox.release_delivery(outbox_delivery_id)
                except OutboxError as release_error:
                    logger.error("outbox_release_failed error=%s", release_error)
            self._health.mark_heartbeat(False)
            return False
        try:
            response = self._transport.send_heartbeat(
                authenticate_payload(heartbeat.to_payload(), credentials, key_pair), self._settings, credentials.credential
            )
        except AgentTransportError as error:
            if error.credential_revoked:
                self._handle_revocation(credentials, reason=error.error_code or "credential_revoked")
                logger.error("device_revoked device_id=%s", credentials.device_id)
            else:
                decision = self._retry.record_failure(
                    retryable=error.retryable,
                    retry_after_seconds=error.retry_after_seconds,
                )
                if error.retryable:
                    self._apply_retry_interval(decision.delay_seconds)
                    self._mark_offline(error.error_code or "transport_failure", decision.delay_seconds)
                if error.retryable:
                    try:
                        if self._xms_failover is None:
                            raise XmsFailoverError("xms_failover_not_configured")
                        failover_state = self._xms_failover.record_failure(
                            active_url=self._settings.server_url,
                            reason=error.error_code or "transport_failure",
                        )
                        if failover_state.active_url != self._settings.server_url:
                            logger.warning("xms_failover_selected server=%s", failover_state.active_url)
                            self._settings = __import__("dataclasses").replace(
                                self._settings, server_url=failover_state.active_url
                            )
                    except XmsFailoverError as failover_error:
                        logger.error("xms_failover_state_invalid error=%s", failover_error)
                logger.warning(
                    "heartbeat_failed error=%s retryable=%s retry_in_seconds=%.3f circuit_open=%s",
                    error, error.retryable, decision.delay_seconds, decision.circuit_open,
                )
            if outbox_delivery_id:
                try:
                    self._outbox.release_delivery(outbox_delivery_id)
                except OutboxError as release_error:
                    logger.error("outbox_release_failed error=%s", release_error)
            self._health.mark_heartbeat(False)
            return False
        self._command_journal.mark_delivered([ack.command_id for ack in pending_acks])
        if outbox_delivery_id:
            self._outbox.acknowledge_delivery(outbox_delivery_id)
        self._inventory_state.commit(inventory_transmission)
        self._retry.record_success()
        try:
            if self._xms_failover is not None:
                self._xms_failover.record_success(active_url=self._settings.server_url)
        except XmsFailoverError as error:
            logger.error("xms_failover_state_invalid error=%s", error)
        self._mark_online()
        self._process_server_commands(response.payload)
        self._apply_server_heartbeat_interval(response.payload)
        logger.info("heartbeat_sent status=%s sequence=%s", response.status, heartbeat_sequence.sequence)
        self._health.mark_heartbeat(True)
        return True


    def queue_message(
        self,
        message_type: str,
        payload: dict[str, object],
        *,
        priority: int = 50,
        message_id: str | None = None,
        ttl_seconds: int | None = None,
    ) -> OutboxMessage:
        """Afig un missatge idempotent a la cua persistent de sortida."""
        return self._outbox.enqueue(
            message_type,
            payload,
            priority=priority,
            message_id=message_id,
            ttl_seconds=(
                self._settings.outbox_default_ttl_seconds
                if ttl_seconds is None
                else ttl_seconds
            ),
        )

    def run_forever(self) -> int:
        with ProcessLock(self._settings.process_lock_file):
            self._install_signal_handlers()
            try:
                recovery_event = self._recovery.begin_startup()
            except RecoveryStateError as error:
                self._failure_store.record("recovery_state_invalid", str(error))
                try:
                    self._safe_mode.enter("recovery_state_invalid", str(error))
                except SafeModeError as safe_mode_error:
                    self._health.update(status="failed")
                    logger.error("safe_mode_activation_failed error=%s", safe_mode_error)
                    return 1
                recovery_event = None
                self._health.update(status="safe-mode")
                logger.error("safe_mode_entered reason=recovery_state_invalid error=%s", error)
            if recovery_event is not None and recovery_event.unexpected:
                logger.warning(
                    "unexpected_startup_detected event=%s previous_boot_id=%s recovery_count=%s",
                    recovery_event.event,
                    recovery_event.previous_boot_id or "none",
                    recovery_event.recovery_count,
                )
            self._configure_watchdog_integration()
            self._scheduler.add_task(
                ScheduledTask(
                    name="heartbeat",
                    interval_seconds=self._settings.heartbeat_interval_seconds,
                    callback=self._run_once_unlocked,
                    run_immediately=True,
                )
            )
            try:
                safe_mode_active = self._safe_mode.load().active
            except SafeModeError:
                safe_mode_active = True
            self._health.update(status="safe-mode" if safe_mode_active else "running")
            self._watchdog.start()
            try:
                self._scheduler.run()
            except Exception as error:
                self._failure_store.record("service_loop_failure", repr(error))
                self._health.update(status="failed")
                raise
            finally:
                self._watchdog.stop()
            try:
                self._recovery.mark_clean_shutdown()
            except RecoveryStateError as error:
                self._failure_store.record("recovery_shutdown_state_invalid", str(error))
                self._health.update(status="failed")
                logger.error("recovery_shutdown_state_invalid error=%s", error)
                return 1
            self._health.update(status="stopped")
            logger.info("agent_stopped")
            return 0

    def stop(
        self,
        signum: int | None = None,
        frame: FrameType | None = None,
    ) -> None:
        del frame
        if not self._stopping:
            logger.info("agent_stop_requested signal=%s", signum)
        self._stopping = True
        self._health.update(status="stopping")
        self._scheduler.stop()

    def request_reload(
        self,
        signum: int | None = None,
        frame: FrameType | None = None,
    ) -> None:
        del frame
        logger.info("configuration_reload_requested signal=%s", signum)
        self._scheduler.call_soon(self.reload_configuration)

    def reload_configuration(self) -> ConfigurationReloadResult | None:
        if self._config_path is None:
            logger.warning("configuration_reload_ignored reason=no_config_path")
            return None
        try:
            result = reload_settings(self._config_path, self._settings)
        except AgentConfigurationError as error:
            logger.error("configuration_reload_failed error=%s", error)
            return None
        if not result.changed:
            logger.info("configuration_reload_unchanged")
            return result

        previous_interval = self._settings.heartbeat_interval_seconds
        monitoring_fields = {
            "monitoring_window_samples", "monitoring_aggregation_window_samples", "adaptive_delivery_enabled",
            "adaptive_warning_interval_seconds", "adaptive_critical_interval_seconds",
            "adaptive_normal_relax_after_samples", "adaptive_normal_interval_multiplier",
            "adaptive_reduced_outbox_batch_size", "adaptive_offline_outbox_batch_size",
            "cpu_warning_percent", "cpu_critical_percent",
            "memory_warning_percent", "memory_critical_percent", "load_warning_per_cpu",
            "load_critical_per_cpu", "monitoring_hysteresis_percent",
            "disk_warning_percent", "disk_critical_percent",
            "temperature_warning_celsius", "temperature_critical_celsius",
            "temperature_hysteresis_celsius",
            "critical_processes", "critical_services", "service_check_timeout_seconds",
            "network_warning_error_percent", "network_critical_error_percent",
            "network_hysteresis_percent", "connectivity_check_enabled",
            "connectivity_timeout_seconds", "connectivity_warning_latency_ms",
            "connectivity_critical_latency_ms", "connectivity_hysteresis_ms",
            "certificate_monitoring_enabled", "certificate_check_timeout_seconds",
            "certificate_warning_days", "certificate_critical_days",
            "local_alerts_enabled", "local_alert_recovery_enabled",
            "local_alert_ttl_seconds", "local_alert_warning_priority",
            "local_alert_critical_priority",
        }
        rebuild_monitor = bool(result.applied_fields & monitoring_fields)
        self._settings = result.settings
        if rebuild_monitor:
            self._resource_monitor = self._build_resource_monitor(self._settings)
            self._disk_monitor = self._build_disk_monitor(self._settings)
            self._thermal_monitor = self._build_thermal_monitor(self._settings)
            self._process_service_monitor = self._build_process_service_monitor(self._settings)
            self._network_monitor = self._build_network_monitor(self._settings)
            self._connectivity_monitor = self._build_connectivity_monitor(self._settings)
            self._certificate_monitor = self._build_certificate_monitor(self._settings)
            self._monitoring_aggregator = MonitoringAggregator(
                window_samples=self._settings.monitoring_aggregation_window_samples
            )
            self._adaptive_delivery = self._build_adaptive_delivery(self._settings)
            self._local_alert_manager = LocalAlertManager(
                self._settings.local_alert_state_file,
                recovery_enabled=self._settings.local_alert_recovery_enabled,
            )
        self._restart_required_fields = result.restart_required_fields
        self._health.update(
            restart_required_fields=tuple(sorted(result.restart_required_fields))
        )

        if self._settings.heartbeat_interval_seconds != previous_interval:
            self._scheduler.update_task_interval(
                "heartbeat", self._settings.heartbeat_interval_seconds
            )

        logger.info(
            "configuration_reloaded applied=%s restart_required=%s",
            ",".join(sorted(result.applied_fields)) or "none",
            ",".join(sorted(result.restart_required_fields)) or "none",
        )
        return result




    def _offline_payload(self) -> dict[str, object]:
        try:
            return self._offline.load().to_payload()
        except OfflineStateError as error:
            logger.error("offline_state_invalid error=%s", error)
            return {"status": "unknown", "reason": "state_invalid"}

    def _mark_offline(self, reason: str, retry_seconds: float) -> None:
        try:
            state = self._offline.mark_offline(reason, retry_seconds=retry_seconds)
            self._health.update(status="offline")
            logger.info(
                "agent_offline failures=%s retry_in_seconds=%.3f reason=%s",
                state.consecutive_failures, retry_seconds, reason,
            )
        except OfflineStateError as error:
            logger.error("offline_state_update_failed error=%s", error)

    def _mark_online(self) -> None:
        try:
            previous = self._offline.load()
            self._offline.mark_online()
            if previous.offline:
                logger.info(
                    "agent_online_recovered previous_failures=%s outage_seconds=%.3f prolonged=%s",
                    previous.consecutive_failures, previous.outage_seconds(), previous.prolonged,
                )
            try:
                safe_mode_active = self._safe_mode.load().active
            except SafeModeError:
                safe_mode_active = True
            self._health.update(status="safe-mode" if safe_mode_active else "running")
        except OfflineStateError as error:
            logger.error("offline_state_update_failed error=%s", error)

    def _process_server_commands(self, payload: dict[str, object]) -> None:
        try:
            if self._safe_mode.load().active:
                logger.warning("commands_rejected reason=safe_mode")
                return
        except SafeModeError as error:
            logger.error("commands_rejected reason=safe_mode_state_invalid error=%s", error)
            return
        if self._settings.compromise_response_enabled and not self._compromise_response.capabilities()["remote_commands"]:
            logger.warning("commands_rejected reason=device_quarantined")
            return
        commands = payload.get("commands")
        if commands is None:
            return
        if not isinstance(commands, list):
            logger.warning("commands_rejected reason=not_a_list")
            return
        if len(commands) > self._settings.command_max_per_response:
            logger.warning("commands_limited received=%s limit=%s", len(commands), self._settings.command_max_per_response)
            commands = commands[:self._settings.command_max_per_response]
        for command in commands:
            if not isinstance(command, dict):
                logger.warning("command_rejected reason=not_an_object")
                continue
            try:
                acknowledgement = self._command_journal.record_received(command)
            except CommandJournalError as error:
                logger.error("command_journal_invalid error=%s", error)
                return
            if acknowledgement is None:
                logger.warning("command_rejected reason=missing_command_id")
                continue
            logger.info(
                "command_acknowledgement_queued command_id=%s status=%s duplicate=%s",
                acknowledgement.command_id,
                acknowledgement.status,
                acknowledgement.duplicate,
            )
            try:
                self._command_audit.append(
                    "received", acknowledgement.command_id,
                    command_type=str(command.get("type")) if command.get("type") is not None else None,
                    issuer_id=(command.get("issuer", {}).get("id") if isinstance(command.get("issuer"), dict) else str(command.get("issuer")) if command.get("issuer") else None),
                    state=acknowledgement.status, code=acknowledgement.detail,
                    data={"duplicate": acknowledgement.duplicate},
                )
            except CommandAuditError as error:
                logger.error("command_audit_invalid error=%s", error)
                return
            if acknowledgement.status != "accepted" or acknowledgement.duplicate:
                continue
            try:
                parsed_command = Command.from_payload(command)
            except CommandValidationError:
                continue
            if parsed_command.is_expired():
                self._command_journal.mark_result(parsed_command.command_id, "expired", "command_expired_before_execution")
                result = CommandResult(
                    command_id=parsed_command.command_id, state=CommandState.EXPIRED,
                    finished_at=datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
                    code="command_expired_before_execution",
                )
            elif parsed_command.command_type is CommandType.CANCEL:
                target = str(parsed_command.parameters["target_command_id"])
                cancelled, code = self._command_journal.cancel(target, reason=parsed_command.parameters.get("reason"))
                result = CommandResult(
                    command_id=parsed_command.command_id,
                    state=CommandState.SUCCEEDED if cancelled else CommandState.FAILED,
                    finished_at=datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
                    code=code, data={"target_command_id": target},
                )
            elif parsed_command.command_type in {CommandType.REBOOT, CommandType.POWEROFF}:
                result = self._power_command_executor.execute(parsed_command)
            elif parsed_command.command_type is CommandType.SERVICE:
                result = self._service_command_executor.execute(parsed_command)
            elif parsed_command.command_type is CommandType.TASK:
                result = self._task_command_executor.execute(parsed_command)
            elif parsed_command.command_type is CommandType.FILE_TRANSFER:
                result = self._file_transfer_command_executor.execute(parsed_command)
            elif parsed_command.command_type is CommandType.COLLECT_LOGS:
                result = self._log_collection_command_executor.execute(parsed_command)
            elif parsed_command.command_type is CommandType.SIGNED_SCRIPT:
                result = self._signed_script_command_executor.execute(parsed_command)
            else:
                continue
            self._command_journal.mark_result(result.command_id, result.state.value, result.code)
            try:
                self._command_audit.append(
                    "completed", result.command_id, command_type=parsed_command.command_type.value,
                    issuer_id=parsed_command.issuer.issuer_id, state=result.state.value, code=result.code,
                    data={"terminal": result.terminal},
                )
            except CommandAuditError as error:
                logger.error("command_audit_invalid error=%s", error)
            logger.info(
                "command_completed command_id=%s type=%s state=%s code=%s",
                result.command_id,
                parsed_command.command_type.value,
                result.state.value,
                result.code or "unspecified",
            )
            try:
                self.queue_message(
                    "command-result",
                    result.to_payload(),
                    priority=self._settings.critical_message_priority,
                    message_id=f"command-result:{result.command_id}",
                    ttl_seconds=self._settings.outbox_default_ttl_seconds,
                )
            except OutboxError as error:
                logger.error("command_result_queue_failed command_id=%s error=%s", result.command_id, error)

    def _apply_retry_interval(self, delay_seconds: float) -> None:
        bounded = max(
            self._settings.heartbeat_min_interval_seconds,
            min(int(max(1.0, delay_seconds)), self._settings.heartbeat_max_interval_seconds),
        )
        try:
            self._scheduler.update_task_interval("heartbeat", bounded)
        except KeyError:
            pass

    def _apply_server_heartbeat_interval(self, payload: dict[str, object]) -> None:
        value = payload.get("next_heartbeat_seconds", payload.get("nextHeartbeat"))
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            return
        requested = int(value)
        bounded = max(
            self._settings.heartbeat_min_interval_seconds,
            min(requested, self._settings.heartbeat_max_interval_seconds),
        )
        if bounded == self._negotiated_heartbeat_interval:
            return
        self._negotiated_heartbeat_interval = bounded
        try:
            self._scheduler.update_task_interval("heartbeat", bounded)
        except KeyError:
            pass
        logger.info("heartbeat_interval_negotiated requested=%s applied=%s", requested, bounded)

    def _load_or_enroll(self, identity, key_pair, hardware) -> DeviceCredentials:
        store = DeviceCredentialsStore(self._settings.device_credentials_file)
        try:
            credentials = store.load()
        except FileNotFoundError:
            try:
                token = SecretFile.from_systemd_credential(
                    "xaac-enrollment-token", fallback=self._settings.enrollment_token_file
                ).read()
            except FileNotFoundError:
                token = None
            if not token:
                raise EnrollmentError("enrollment token is required")
            request = EnrollmentRequest.create(identity, key_pair, hardware)
            response = self._transport.send_enrollment(
                request.to_payload(), self._settings, token
            )
            credentials = DeviceCredentials.from_response(
                response.payload, expected_device_id=identity.device_id
            )
            store.save(credentials)
            logger.info(
                "device_enrolled device_id=%s key_id=%s status=%s",
                identity.device_id,
                key_pair.key_id,
                response.status,
            )
        if credentials.device_id != identity.device_id:
            raise EnrollmentError("persisted credential belongs to another device")
        return credentials

    def _renew_credentials_if_needed(
        self, credentials: DeviceCredentials, key_pair
    ) -> DeviceCredentials:
        renew_before = self._settings.credential_renew_before_seconds
        skew = self._settings.credential_clock_skew_tolerance_seconds
        if not credentials.renewal_due(
            renew_before_seconds=renew_before,
            clock_skew_tolerance_seconds=skew,
        ):
            if credentials.is_expired(clock_skew_tolerance_seconds=skew):
                raise EnrollmentError("device credential has expired")
            return credentials

        request = CredentialRenewalRequest.create(credentials, key_pair)
        try:
            response = self._transport.renew_credentials(
                authenticate_payload(request.to_payload(), credentials, key_pair), self._settings, credentials.credential
            )
            renewed = DeviceCredentials.from_response(
                response.payload, expected_device_id=credentials.device_id
            )
            DeviceCredentialsStore(self._settings.device_credentials_file).save(renewed)
            logger.info(
                "device_credentials_renewed device_id=%s status=%s expires_at=%s",
                credentials.device_id,
                response.status,
                renewed.expires_at or "unspecified",
            )
            return renewed
        except (AgentTransportError, EnrollmentError) as error:
            if credentials.is_expired(clock_skew_tolerance_seconds=skew):
                raise EnrollmentError("expired device credential could not be renewed") from error
            logger.warning(
                "device_credentials_renewal_deferred device_id=%s error=%s",
                credentials.device_id,
                error,
            )
            return credentials

    def unenroll(self, *, reason: str = "administrator_request") -> bool:
        """Request an authenticated disenrollment and remove local credentials."""
        with ProcessLock(self._settings.process_lock_file):
            return self._unenroll_unlocked(reason=reason)

    def _unenroll_unlocked(self, *, reason: str) -> bool:
        identity = DeviceIdentityStore(self._settings.device_identity_file).load_or_create()
        key_pair = DeviceKeyStore(self._settings.device_private_key_file).load_or_create()
        store = DeviceCredentialsStore(self._settings.device_credentials_file)
        try:
            credentials = store.load()
        except FileNotFoundError:
            self._registration_store.mark_unenrolled(reason)
            return True
        if credentials.device_id != identity.device_id:
            raise EnrollmentError("persisted credential belongs to another device")
        request = UnenrollmentRequest.create(credentials, key_pair, reason=reason)
        response = self._transport.send_unenrollment(
            authenticate_payload(request.to_payload(), credentials, key_pair), self._settings, credentials.credential
        )
        if response.payload.get("status") != "unenrolled":
            raise EnrollmentError("XMS did not confirm unenrollment")
        store.delete()
        self._registration_store.mark_unenrolled(reason)
        self._health.update(status="unenrolled")
        logger.info("device_unenrolled device_id=%s reason=%s", identity.device_id, reason)
        return True

    def authorize_reenrollment(self) -> None:
        """Explicit local administrative action permitting one reenrollment attempt."""
        with ProcessLock(self._settings.process_lock_file):
            self._registration_store.authorize_reenrollment()
            logger.info("device_reenrollment_authorized")

    def _handle_revocation(self, credentials: DeviceCredentials, *, reason: str) -> None:
        store = DeviceCredentialsStore(self._settings.device_credentials_file)
        try:
            store.delete()
        except FileNotFoundError:
            pass
        self._registration_store.mark_revoked(reason)
        self._health.update(status="revoked")
        self._failure_store.record("device_revoked", f"device_id={credentials.device_id} reason={reason}")

    def _configure_watchdog_integration(self) -> None:
        set_progress = getattr(self._scheduler, "set_progress_callback", None)
        if callable(set_progress):
            set_progress(self._mark_scheduler_progress)
        if self._watchdog.enabled:
            set_max_wait = getattr(self._scheduler, "set_max_wait_seconds", None)
            if callable(set_max_wait):
                set_max_wait(max(1.0, self._watchdog.poll_interval_seconds / 2.0))

    def _mark_scheduler_progress(self) -> None:
        self._watchdog.mark_progress()
        self._health.mark_progress()

    def _on_watchdog_stall(self, age_seconds: float) -> None:
        detail = f"scheduler_without_progress_seconds={age_seconds:.3f}"
        self._failure_store.record("watchdog_stall", detail)
        self._health.update(status="stalled")

    def _install_signal_handlers(self) -> None:
        signal.signal(signal.SIGTERM, self.stop)
        signal.signal(signal.SIGINT, self.stop)
        if hasattr(signal, "SIGHUP"):
            signal.signal(signal.SIGHUP, self.request_reload)

    @staticmethod
    def _read_token(path: Path) -> str | None:
        try:
            token = path.read_text(encoding="utf-8").strip()
        except FileNotFoundError:
            return None
        return token or None

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any


class DebianInitialInstallError(ValueError):
    """Raised when the initial-install policy is unsafe or inconsistent."""


@dataclass(frozen=True, slots=True)
class DebianInitialInstallPolicy:
    package: str
    runtime_python: Path
    minimum_version: str
    config_path: Path
    enrollment_token: Path
    preserve_existing: bool
    default_enabled: bool
    socket_units: tuple[str, ...]
    service_units: tuple[str, ...]
    enable_on_install: bool
    start_service_when_disabled: bool
    commands: tuple[Path, ...]

    @classmethod
    def load(cls, path: Path) -> "DebianInitialInstallPolicy":
        try:
            raw: Any = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise DebianInitialInstallError("debian_initial_install_invalid") from exc
        if not isinstance(raw, dict) or raw.get("schema_version") != 1:
            raise DebianInitialInstallError("debian_initial_install_schema_invalid")
        runtime = raw.get("runtime")
        config = raw.get("configuration")
        activation = raw.get("activation")
        commands = raw.get("commands")
        if not all(isinstance(item, dict) for item in (runtime, config, activation, commands)):
            raise DebianInitialInstallError("debian_initial_install_sections_invalid")
        socket_units = activation.get("socket_units")
        service_units = activation.get("service_units")
        if not isinstance(socket_units, list) or not isinstance(service_units, list):
            raise DebianInitialInstallError("debian_initial_install_units_invalid")
        command_paths = tuple(Path(str(value)) for value in commands.values())
        return cls(
            package=str(raw.get("package", "")),
            runtime_python=Path(str(runtime.get("python", ""))),
            minimum_version=str(runtime.get("minimum_version", "")),
            config_path=Path(str(config.get("path", ""))),
            enrollment_token=Path(str(config.get("enrollment_token", ""))),
            preserve_existing=config.get("preserve_existing") is True,
            default_enabled=config.get("default_enabled") is True,
            socket_units=tuple(str(item) for item in socket_units),
            service_units=tuple(str(item) for item in service_units),
            enable_on_install=activation.get("enable_on_install") is True,
            start_service_when_disabled=activation.get("start_service_when_disabled") is True,
            commands=command_paths,
        )

    def validate(self) -> None:
        if self.package != "xaac-agent":
            raise DebianInitialInstallError("debian_initial_install_package_invalid")
        if self.runtime_python != Path("/opt/xaac-agent/runtime/bin/python3.13"):
            raise DebianInitialInstallError("debian_initial_install_runtime_invalid")
        if self.minimum_version != "3.13":
            raise DebianInitialInstallError("debian_initial_install_version_invalid")
        if self.config_path != Path("/etc/xaac-agent/agent.ini") or not self.preserve_existing:
            raise DebianInitialInstallError("debian_initial_install_config_invalid")
        if self.enrollment_token != Path("/etc/xaac-agent/enrollment.token"):
            raise DebianInitialInstallError("debian_initial_install_token_invalid")
        if self.default_enabled or self.start_service_when_disabled:
            raise DebianInitialInstallError("debian_initial_install_unsafe_activation")
        if not self.enable_on_install:
            raise DebianInitialInstallError("debian_initial_install_activation_invalid")
        if self.socket_units != ("xaac-privileged-helper.socket",):
            raise DebianInitialInstallError("debian_initial_install_socket_units_invalid")
        if self.service_units != ("xaac-agent.service",):
            raise DebianInitialInstallError("debian_initial_install_service_units_invalid")
        allowed_commands = {
            Path("/usr/bin/systemd-sysusers"),
            Path("/usr/bin/systemd-tmpfiles"),
            Path("/usr/bin/systemctl"),
        }
        if set(self.commands) != allowed_commands or len(self.commands) != len(allowed_commands):
            raise DebianInitialInstallError("debian_initial_install_commands_invalid")
        for command in self.commands:
            if not command.is_absolute() or ".." in command.parts:
                raise DebianInitialInstallError("debian_initial_install_command_unsafe")

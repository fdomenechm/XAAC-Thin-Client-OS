from __future__ import annotations

import json
import os
import stat
import uuid
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Mapping

from xaac_agent.state_recovery import KnownGoodState, StateRecoveryError


class OutboxError(RuntimeError):
    """La cua persistent de sortida és invàlida o insegura."""


class OutboxFullError(OutboxError):
    """La cua ha arribat als límits configurats."""


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


@dataclass(frozen=True, slots=True)
class OutboxMessage:
    message_id: str
    message_type: str
    payload: dict[str, object]
    priority: int
    created_at: str
    expires_at: str | None = None

    def to_payload(self) -> dict[str, object]:
        return {
            'message_id': self.message_id,
            'type': self.message_type,
            'priority': self.priority,
            'created_at': self.created_at,
            'payload': dict(self.payload),
            **({'expires_at': self.expires_at} if self.expires_at is not None else {}),
        }


@dataclass(frozen=True, slots=True)
class OutboxRecoveryReport:
    recovered_messages: int
    delivery_id: str | None

    def to_payload(self) -> dict[str, object]:
        return {
            "schema_version": 1,
            "recovered_messages": self.recovered_messages,
            "delivery_id": self.delivery_id,
        }


class PersistentOutbox:
    SCHEMA_VERSION = 1

    def __init__(
        self,
        path: Path,
        *,
        max_messages: int = 512,
        max_bytes: int = 4 * 1024 * 1024,
    ) -> None:
        self.path = path
        self.max_messages = max(1, int(max_messages))
        self.max_bytes = max(4096, int(max_bytes))
        self._known_good = KnownGoodState(path)

    def enqueue(
        self,
        message_type: str,
        payload: Mapping[str, object],
        *,
        priority: int = 50,
        message_id: str | None = None,
        ttl_seconds: int | None = None,
    ) -> OutboxMessage:
        message_type = str(message_type).strip()
        if not message_type:
            raise OutboxError('message_type no pot ser buit')
        if isinstance(priority, bool) or not 0 <= int(priority) <= 100:
            raise OutboxError('priority fora de rang')
        if not isinstance(payload, Mapping):
            raise OutboxError('payload ha de ser un objecte')
        state = self._load()
        identifier = (message_id or str(uuid.uuid4())).strip()
        existing = next((item for item in state['messages'] if item.get('message_id') == identifier), None)
        if existing is not None:
            return self._from_record(existing)
        created_at = _utc_now()
        expires_at = None
        if ttl_seconds is not None:
            if isinstance(ttl_seconds, bool) or int(ttl_seconds) <= 0:
                raise OutboxError('ttl_seconds ha de ser positiu')
            expires_at = (datetime.now(timezone.utc) + timedelta(seconds=int(ttl_seconds))).isoformat().replace('+00:00', 'Z')
        message = OutboxMessage(identifier, message_type, dict(payload), int(priority), created_at, expires_at)
        candidate = dict(state)
        candidate['messages'] = [*state['messages'], message.to_payload()]
        if len(candidate['messages']) > self.max_messages:
            raise OutboxFullError('s’ha superat el nombre màxim de missatges')
        if len(self._serialize(candidate).encode('utf-8')) > self.max_bytes:
            raise OutboxFullError('s’ha superat la mida màxima de la cua')
        self._write(candidate)
        return message

    def pending(self, *, limit: int | None = None) -> list[OutboxMessage]:
        state = self._load()
        active = self._remove_expired(state)
        records = [item for item in active if item.get("delivery_id") is None]
        records = self._sort_records(records)
        if limit is not None:
            records = records[: max(0, int(limit))]
        return [self._from_record(record) for record in records]

    def reserve_batch(
        self,
        *,
        limit: int,
        minimum_priority: int | None = None,
        delivery_id: str | None = None,
    ) -> tuple[str, list[OutboxMessage], OutboxRecoveryReport]:
        if isinstance(limit, bool) or int(limit) < 0:
            raise OutboxError("limit invàlid")
        if minimum_priority is not None and (
            isinstance(minimum_priority, bool) or not 0 <= int(minimum_priority) <= 100
        ):
            raise OutboxError("minimum_priority fora de rang")
        state = self._load()
        active = self._remove_expired(state, write=False)
        recovered_ids = {
            str(item.get("delivery_id"))
            for item in active
            if isinstance(item.get("delivery_id"), str)
        }
        recovered_delivery = next(iter(recovered_ids)) if len(recovered_ids) == 1 else None
        recovered_count = 0
        for item in active:
            if item.get("delivery_id") is not None:
                item.pop("delivery_id", None)
                item.pop("delivery_started_at", None)
                recovered_count += 1
        candidates = [
            item for item in active
            if minimum_priority is None or int(item.get("priority", 0)) >= int(minimum_priority)
        ]
        selected = self._sort_records(candidates)[: int(limit)]
        identifier = (delivery_id or str(uuid.uuid4())).strip() if selected else ""
        if selected and (not identifier or len(identifier) > 128):
            raise OutboxError("delivery_id invàlid")
        selected_ids = {str(item.get("message_id")) for item in selected}
        started_at = _utc_now()
        for item in active:
            if item.get("message_id") in selected_ids:
                item["delivery_id"] = identifier
                item["delivery_started_at"] = started_at
        state["messages"] = active
        state["last_recovery"] = {
            "recovered_messages": recovered_count,
            "delivery_id": recovered_delivery,
            "recovered_at": started_at,
        }
        self._write(state)
        return identifier, [self._from_record(record) for record in selected], OutboxRecoveryReport(
            recovered_messages=recovered_count,
            delivery_id=recovered_delivery,
        )

    def acknowledge_delivery(self, delivery_id: str) -> None:
        identifier = str(delivery_id).strip()
        if not identifier:
            raise OutboxError("delivery_id invàlid")
        state = self._load()
        remaining = [item for item in state["messages"] if item.get("delivery_id") != identifier]
        if len(remaining) == len(state["messages"]):
            raise OutboxError("delivery_id desconegut")
        state["messages"] = remaining
        self._write(state)

    def release_delivery(self, delivery_id: str) -> None:
        identifier = str(delivery_id).strip()
        if not identifier:
            raise OutboxError("delivery_id invàlid")
        state = self._load()
        changed = False
        for item in state["messages"]:
            if item.get("delivery_id") == identifier:
                item.pop("delivery_id", None)
                item.pop("delivery_started_at", None)
                changed = True
        if changed:
            self._write(state)

    def mark_delivered(self, message_ids: list[str]) -> None:
        if not message_ids:
            return
        identifiers = set(message_ids)
        state = self._load()
        remaining = [item for item in state['messages'] if item.get('message_id') not in identifiers]
        if len(remaining) != len(state['messages']):
            state['messages'] = remaining
            self._write(state)

    def recovery_telemetry(self) -> dict[str, object]:
        state = self._load()
        recovery = state.get("last_recovery")
        if not isinstance(recovery, dict):
            return OutboxRecoveryReport(0, None).to_payload()
        count = recovery.get("recovered_messages", 0)
        delivery_id = recovery.get("delivery_id")
        return OutboxRecoveryReport(
            int(count) if isinstance(count, int) and not isinstance(count, bool) and count >= 0 else 0,
            delivery_id if isinstance(delivery_id, str) else None,
        ).to_payload()

    def count(self) -> int:
        return len(self._load()['messages'])

    def _remove_expired(self, state: dict[str, Any], *, write: bool = True) -> list[dict[str, Any]]:
        active = [item for item in state["messages"] if not self._is_expired(item)]
        if write and len(active) != len(state["messages"]):
            state["messages"] = active
            self._write(state)
        return active

    @staticmethod
    def _sort_records(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
        return sorted(
            records,
            key=lambda item: (-int(item.get("priority", 0)), str(item.get("created_at", "")), str(item.get("message_id", ""))),
        )

    def _load(self) -> dict[str, Any]:
        if not self.path.exists():
            return {'schema_version': self.SCHEMA_VERSION, 'messages': []}
        try:
            mode = self.path.lstat().st_mode
        except OSError as error:
            raise OutboxError(f'no es pot inspeccionar la cua: {error}') from error
        if stat.S_ISLNK(mode) or not stat.S_ISREG(mode):
            raise OutboxError('la cua ha de ser un fitxer regular')
        try:
            payload = json.loads(self.path.read_text(encoding='utf-8'))
        except (OSError, json.JSONDecodeError) as error:
            try:
                self._known_good.restore()
                payload = json.loads(self.path.read_text(encoding='utf-8'))
            except (StateRecoveryError, OSError, json.JSONDecodeError) as recovery_error:
                raise OutboxError('cua no llegible o JSON invàlid i sense còpia recuperable') from recovery_error
        if not isinstance(payload, dict) or payload.get('schema_version') != self.SCHEMA_VERSION:
            raise OutboxError('esquema de cua no compatible')
        messages = payload.get('messages')
        if not isinstance(messages, list) or any(not isinstance(item, dict) for item in messages):
            raise OutboxError('missatges de cua invàlids')
        for item in messages:
            self._from_record(item)
        return payload

    def _write(self, payload: dict[str, Any]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_name(f'.{self.path.name}.{os.getpid()}.tmp')
        data = self._serialize(payload)
        try:
            fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, 'w', encoding='utf-8') as stream:
                stream.write(data)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.path)
            os.chmod(self.path, 0o600)
            self._known_good.snapshot()
        finally:
            try:
                temporary.unlink()
            except FileNotFoundError:
                pass

    @staticmethod
    def _serialize(payload: dict[str, Any]) -> str:
        return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':')) + '\n'

    @staticmethod
    def _from_record(record: Mapping[str, Any]) -> OutboxMessage:
        message_id = record.get('message_id')
        message_type = record.get('type')
        payload = record.get('payload')
        priority = record.get('priority')
        created_at = record.get('created_at')
        expires_at = record.get('expires_at')
        if not isinstance(message_id, str) or not message_id.strip():
            raise OutboxError('message_id invàlid')
        if not isinstance(message_type, str) or not message_type.strip():
            raise OutboxError('type invàlid')
        if not isinstance(payload, dict):
            raise OutboxError('payload invàlid')
        if isinstance(priority, bool) or not isinstance(priority, int) or not 0 <= priority <= 100:
            raise OutboxError('priority invàlida')
        if not isinstance(created_at, str) or not created_at.strip():
            raise OutboxError('created_at invàlid')
        if expires_at is not None and (not isinstance(expires_at, str) or not expires_at.strip()):
            raise OutboxError('expires_at invàlid')
        delivery_id = record.get('delivery_id')
        delivery_started_at = record.get('delivery_started_at')
        if delivery_id is not None and (not isinstance(delivery_id, str) or not delivery_id.strip() or len(delivery_id) > 128):
            raise OutboxError('delivery_id invàlid')
        if delivery_started_at is not None and (not isinstance(delivery_started_at, str) or not delivery_started_at.strip()):
            raise OutboxError('delivery_started_at invàlid')
        if (delivery_id is None) != (delivery_started_at is None):
            raise OutboxError('estat de lliurament incomplet')
        return OutboxMessage(message_id.strip(), message_type.strip(), dict(payload), priority, created_at.strip(), expires_at.strip() if isinstance(expires_at, str) else None)

    @staticmethod
    def _is_expired(record: Mapping[str, Any]) -> bool:
        expires_at = record.get('expires_at')
        if expires_at is None:
            return False
        try:
            value = str(expires_at).replace('Z', '+00:00')
            expiration = datetime.fromisoformat(value)
            if expiration.tzinfo is None:
                expiration = expiration.replace(tzinfo=timezone.utc)
        except ValueError as error:
            raise OutboxError('expires_at invàlid') from error
        return expiration <= datetime.now(timezone.utc)

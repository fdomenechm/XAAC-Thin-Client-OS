from __future__ import annotations

import re
from dataclasses import dataclass
from functools import total_ordering
from typing import Any, Mapping

from xaac_agent import __version__
from xaac_agent.policy_model import Policy, PolicyResult, PolicyState
from xaac_agent.protocol import XMP_PROTOCOL_VERSION

_VERSION_PATTERN = re.compile(
    r"^(?P<major>0|[1-9][0-9]*)\."
    r"(?P<minor>0|[1-9][0-9]*)\."
    r"(?P<patch>0|[1-9][0-9]*)"
    r"(?:-(?P<prerelease>[0-9A-Za-z.-]+))?"
    r"(?:\+[0-9A-Za-z.-]+)?$"
)
_PROTOCOL_PATTERN = re.compile(r"^[0-9]+\.[0-9]+$")
_MAX_PROTOCOL_VERSIONS = 16


class PolicyCompatibilityError(ValueError):
    """La política no és compatible amb les capacitats o versions locals."""

    def __init__(self, code: str, *, detail: str | None = None) -> None:
        super().__init__(code)
        self.code = code
        self.detail = detail


@total_ordering
@dataclass(frozen=True, slots=True)
class SemanticVersion:
    major: int
    minor: int
    patch: int
    prerelease: tuple[int | str, ...] = ()

    @classmethod
    def parse(cls, value: object, *, code: str = "invalid_semantic_version") -> "SemanticVersion":
        if not isinstance(value, str):
            raise PolicyCompatibilityError(code)
        match = _VERSION_PATTERN.fullmatch(value.strip())
        if match is None:
            raise PolicyCompatibilityError(code)
        prerelease: tuple[int | str, ...] = ()
        raw_prerelease = match.group("prerelease")
        if raw_prerelease:
            identifiers: list[int | str] = []
            for identifier in raw_prerelease.split("."):
                if not identifier:
                    raise PolicyCompatibilityError(code)
                if identifier.isdigit():
                    if len(identifier) > 1 and identifier.startswith("0"):
                        raise PolicyCompatibilityError(code)
                    identifiers.append(int(identifier))
                else:
                    identifiers.append(identifier)
            prerelease = tuple(identifiers)
        return cls(
            major=int(match.group("major")),
            minor=int(match.group("minor")),
            patch=int(match.group("patch")),
            prerelease=prerelease,
        )

    def __lt__(self, other: object) -> bool:
        if not isinstance(other, SemanticVersion):
            return NotImplemented
        own_core = (self.major, self.minor, self.patch)
        other_core = (other.major, other.minor, other.patch)
        if own_core != other_core:
            return own_core < other_core
        if not self.prerelease:
            return bool(other.prerelease)
        if not other.prerelease:
            return True
        for left, right in zip(self.prerelease, other.prerelease):
            if left == right:
                continue
            if isinstance(left, int) and isinstance(right, str):
                return True
            if isinstance(left, str) and isinstance(right, int):
                return False
            return left < right
        return len(self.prerelease) < len(other.prerelease)


@dataclass(frozen=True, slots=True)
class PolicyCompatibility:
    min_agent_version: SemanticVersion | None = None
    max_agent_version: SemanticVersion | None = None
    protocol_versions: tuple[str, ...] = ()

    @classmethod
    def from_policy(cls, policy: Policy) -> "PolicyCompatibility":
        raw = policy.metadata.get("compatibility")
        if raw is None:
            return cls()
        if not isinstance(raw, Mapping):
            raise PolicyCompatibilityError("invalid_policy_compatibility")
        unknown = set(raw) - {"min_agent_version", "max_agent_version", "protocol_versions"}
        if unknown:
            raise PolicyCompatibilityError("unknown_policy_compatibility_field", detail=sorted(unknown)[0])

        minimum = raw.get("min_agent_version")
        maximum = raw.get("max_agent_version")
        parsed_minimum = None if minimum is None else SemanticVersion.parse(
            minimum, code="invalid_min_agent_version"
        )
        parsed_maximum = None if maximum is None else SemanticVersion.parse(
            maximum, code="invalid_max_agent_version"
        )
        if parsed_minimum is not None and parsed_maximum is not None and parsed_minimum > parsed_maximum:
            raise PolicyCompatibilityError("invalid_agent_version_range")

        raw_protocols = raw.get("protocol_versions", [])
        if not isinstance(raw_protocols, list):
            raise PolicyCompatibilityError("invalid_policy_protocol_versions")
        if len(raw_protocols) > _MAX_PROTOCOL_VERSIONS:
            raise PolicyCompatibilityError("too_many_policy_protocol_versions")
        protocols: set[str] = set()
        for protocol in raw_protocols:
            if not isinstance(protocol, str) or not _PROTOCOL_PATTERN.fullmatch(protocol.strip()):
                raise PolicyCompatibilityError("invalid_policy_protocol_version")
            protocols.add(protocol.strip())
        return cls(
            min_agent_version=parsed_minimum,
            max_agent_version=parsed_maximum,
            protocol_versions=tuple(sorted(protocols)),
        )


@dataclass(frozen=True, slots=True)
class CompatiblePolicy:
    policy: Policy
    agent_version: str
    protocol_version: str
    available_capabilities: tuple[str, ...]

    def to_result(self) -> PolicyResult:
        return PolicyResult(
            self.policy.policy_id,
            self.policy.revision,
            PolicyState.VALIDATED,
            code="policy_compatible",
            data={
                "agent_version": self.agent_version,
                "protocol_version": self.protocol_version,
                "required_capabilities": list(self.policy.required_capabilities),
            },
        )


@dataclass(frozen=True, slots=True)
class PolicyCompatibilityChecker:
    agent_version: str = __version__
    protocol_version: str = XMP_PROTOCOL_VERSION
    local_capabilities: tuple[str, ...] = ()

    def check(self, policy: Policy) -> CompatiblePolicy:
        local_version = SemanticVersion.parse(self.agent_version, code="invalid_local_agent_version")
        if not _PROTOCOL_PATTERN.fullmatch(self.protocol_version):
            raise PolicyCompatibilityError("invalid_local_protocol_version")
        requirements = PolicyCompatibility.from_policy(policy)

        if requirements.min_agent_version is not None and local_version < requirements.min_agent_version:
            raise PolicyCompatibilityError("agent_version_too_old", detail=self.agent_version)
        if requirements.max_agent_version is not None and local_version > requirements.max_agent_version:
            raise PolicyCompatibilityError("agent_version_too_new", detail=self.agent_version)
        if requirements.protocol_versions and self.protocol_version not in requirements.protocol_versions:
            raise PolicyCompatibilityError("policy_protocol_incompatible", detail=self.protocol_version)

        available = frozenset(item.strip() for item in self.local_capabilities if item.strip())
        missing = sorted(set(policy.required_capabilities) - available)
        if missing:
            raise PolicyCompatibilityError("policy_capability_unavailable", detail=missing[0])

        return CompatiblePolicy(
            policy=policy,
            agent_version=self.agent_version,
            protocol_version=self.protocol_version,
            available_capabilities=tuple(sorted(available)),
        )

    def check_result(self, policy: Policy) -> PolicyResult:
        try:
            return self.check(policy).to_result()
        except PolicyCompatibilityError as error:
            data: dict[str, Any] = {}
            if error.detail is not None:
                data["detail"] = error.detail
            return PolicyResult(
                policy.policy_id,
                policy.revision,
                PolicyState.REJECTED,
                code=error.code,
                data=data,
            )

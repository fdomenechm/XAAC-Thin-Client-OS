from __future__ import annotations

import base64
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Mapping

from xaac_agent.device_keys import DeviceKeyPair
from xaac_agent.enrollment import DeviceCredentials, canonical_json

AUTH_SCHEMA_VERSION = 1


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


@dataclass(frozen=True, slots=True)
class RequestAuthentication:
    request_id: str
    nonce: str
    sent_at: str
    device_id: str
    key_id: str
    signature: str
    schema_version: int = AUTH_SCHEMA_VERSION

    @classmethod
    def create(
        cls,
        payload: Mapping[str, Any],
        credentials: DeviceCredentials,
        key_pair: DeviceKeyPair,
        *,
        request_id: str | None = None,
        nonce: str | None = None,
        sent_at: str | None = None,
    ) -> 'RequestAuthentication':
        metadata = {
            'schema_version': AUTH_SCHEMA_VERSION,
            'request_id': request_id or str(uuid.uuid4()),
            'nonce': nonce or str(uuid.uuid4()),
            'sent_at': sent_at or utc_now(),
            'device_id': credentials.device_id,
            'key_id': key_pair.key_id,
        }
        signed = {'authentication': metadata, 'payload': dict(payload)}
        signature = base64.b64encode(key_pair.sign(canonical_json(signed))).decode('ascii')
        return cls(signature=signature, **metadata)

    def to_payload(self) -> dict[str, Any]:
        return {
            'schema_version': self.schema_version,
            'request_id': self.request_id,
            'nonce': self.nonce,
            'sent_at': self.sent_at,
            'device_id': self.device_id,
            'key_id': self.key_id,
            'signature': self.signature,
        }


def authenticate_payload(
    payload: Mapping[str, Any],
    credentials: DeviceCredentials,
    key_pair: DeviceKeyPair,
    **overrides: str,
) -> dict[str, Any]:
    auth = RequestAuthentication.create(payload, credentials, key_pair, **overrides)
    return {**dict(payload), 'xmp_authentication': auth.to_payload()}

from __future__ import annotations

import hashlib
import os
import stat
import tempfile
import urllib.error
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import BinaryIO, Mapping, Protocol

from xaac_agent.command_model import Command, CommandResult, CommandState, CommandType


class FileDownloadBackend(Protocol):
    def open(self, url: str, *, timeout_seconds: int) -> BinaryIO: ...


class HttpsDownloadBackend:
    """Descàrrega HTTPS directa; no interpreta ordres ni rutes remotes."""

    def open(self, url: str, *, timeout_seconds: int) -> BinaryIO:
        request = urllib.request.Request(url, headers={"User-Agent": "XAAC-Agent/0.6.6"})
        response = urllib.request.urlopen(request, timeout=timeout_seconds)
        final_url = response.geturl()
        if not isinstance(final_url, str) or not final_url.lower().startswith("https://"):
            response.close()
            raise ValueError("insecure_redirect")
        return response


@dataclass(frozen=True, slots=True)
class FileTarget:
    target_id: str
    path: Path
    mode: int = 0o600


@dataclass(frozen=True, slots=True)
class FileTransferCommandExecutor:
    backend: FileDownloadBackend
    targets: Mapping[str, FileTarget]
    max_file_bytes: int = 16 * 1024 * 1024

    @classmethod
    def system_default(
        cls,
        *,
        targets: Mapping[str, FileTarget] | None = None,
        max_file_bytes: int = 16 * 1024 * 1024,
    ) -> "FileTransferCommandExecutor":
        return cls(backend=HttpsDownloadBackend(), targets=targets or {}, max_file_bytes=max_file_bytes)

    def execute(self, command: Command) -> CommandResult:
        if command.command_type is not CommandType.FILE_TRANSFER:
            raise ValueError("unsupported_file_transfer_command")
        started_at = _utc_now()
        parameters = command.parameters
        target_id = str(parameters["target_id"])
        target = self.targets.get(target_id)
        if target is None:
            return self._failed(command, started_at, "file_target_unavailable", target_id)

        source_url = str(parameters["source_url"])
        expected_sha256 = str(parameters["sha256"]).lower()
        expected_size = int(parameters["size_bytes"])
        timeout = int(parameters.get("timeout_seconds", 300))
        overwrite = bool(parameters.get("overwrite", False))
        if expected_size > self.max_file_bytes:
            return self._failed(command, started_at, "file_too_large", target_id)

        destination = target.path
        try:
            self._validate_destination(destination, overwrite=overwrite)
            destination.parent.mkdir(mode=0o750, parents=True, exist_ok=True)
            with self.backend.open(source_url, timeout_seconds=timeout) as source:
                digest, written, temporary = self._write_temporary(
                    source,
                    destination,
                    expected_size=expected_size,
                    mode=target.mode,
                )
            try:
                if written != expected_size:
                    raise ValueError("file_size_mismatch")
                if digest != expected_sha256:
                    raise ValueError("file_digest_mismatch")
                self._validate_destination(destination, overwrite=overwrite)
                os.replace(temporary, destination)
                _fsync_directory(destination.parent)
            except Exception:
                temporary.unlink(missing_ok=True)
                raise
        except TimeoutError:
            return self._failed(command, started_at, "file_transfer_timeout", target_id)
        except (urllib.error.URLError, OSError) as error:
            return self._failed(command, started_at, "file_transfer_backend_error", target_id, str(error))
        except ValueError as error:
            return self._failed(command, started_at, str(error), target_id)

        return CommandResult(
            command_id=command.command_id,
            state=CommandState.SUCCEEDED,
            started_at=started_at,
            finished_at=_utc_now(),
            code="file_transferred",
            data={
                "target_id": target_id,
                "size_bytes": expected_size,
                "sha256": expected_sha256,
            },
        )

    def _write_temporary(
        self,
        source: BinaryIO,
        destination: Path,
        *,
        expected_size: int,
        mode: int,
    ) -> tuple[str, int, Path]:
        digest = hashlib.sha256()
        written = 0
        fd, raw_path = tempfile.mkstemp(prefix=f".{destination.name}.", suffix=".part", dir=destination.parent)
        temporary = Path(raw_path)
        try:
            os.fchmod(fd, mode)
            with os.fdopen(fd, "wb") as output:
                while True:
                    chunk = source.read(64 * 1024)
                    if not chunk:
                        break
                    if not isinstance(chunk, bytes):
                        raise ValueError("invalid_download_stream")
                    written += len(chunk)
                    if written > expected_size or written > self.max_file_bytes:
                        raise ValueError("file_size_exceeded")
                    digest.update(chunk)
                    output.write(chunk)
                output.flush()
                os.fsync(output.fileno())
        except Exception:
            try:
                os.close(fd)
            except OSError:
                pass
            temporary.unlink(missing_ok=True)
            raise
        return digest.hexdigest(), written, temporary

    @staticmethod
    def _validate_destination(destination: Path, *, overwrite: bool) -> None:
        try:
            info = destination.lstat()
        except FileNotFoundError:
            return
        if stat.S_ISLNK(info.st_mode):
            raise ValueError("file_target_symlink")
        if not stat.S_ISREG(info.st_mode):
            raise ValueError("file_target_not_regular")
        if not overwrite:
            raise ValueError("file_target_exists")

    @staticmethod
    def _failed(
        command: Command,
        started_at: str,
        code: str,
        target_id: str,
        detail: str | None = None,
    ) -> CommandResult:
        return CommandResult(
            command_id=command.command_id,
            state=CommandState.FAILED,
            started_at=started_at,
            finished_at=_utc_now(),
            code=code,
            message=_safe_detail(detail),
            data={"target_id": target_id},
        )


def parse_file_targets(values: tuple[str, ...]) -> dict[str, FileTarget]:
    targets: dict[str, FileTarget] = {}
    for value in values:
        target_id, separator, raw_path = value.partition("=")
        target_id, raw_path = target_id.strip(), raw_path.strip()
        if not separator or not target_id or not raw_path:
            raise ValueError(f"invalid_file_target:{value}")
        path = Path(raw_path)
        if not path.is_absolute() or ".." in path.parts:
            raise ValueError(f"invalid_file_target_path:{target_id}")
        if target_id in targets:
            raise ValueError(f"duplicate_file_target:{target_id}")
        targets[target_id] = FileTarget(target_id=target_id, path=path)
    return targets


def _fsync_directory(path: Path) -> None:
    descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _safe_detail(value: str | None) -> str | None:
    if not value:
        return None
    return " ".join(value.split())[:512] or None

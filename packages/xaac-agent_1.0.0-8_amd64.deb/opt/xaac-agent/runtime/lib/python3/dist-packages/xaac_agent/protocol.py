from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from xaac_agent import __version__
from xaac_agent.identity import DeviceIdentity
from xaac_agent.inventory import DeviceInventory

XMP_PROTOCOL_VERSION = '1.0'
DEFAULT_CAPABILITIES = (
    'enrollment',
    'credential-renewal',
    'authenticated-heartbeat',
    'revocation',
    'unenrollment',
    'inventory-basic',
    'inventory-operating-system',
    'command-acknowledgements',
    'persistent-outbox',
    'inventory-incremental',
)


@dataclass(frozen=True, slots=True)
class Heartbeat:
    device_id: str
    sent_at: str
    agent_version: str
    boot_id: str
    uptime_seconds: int
    heartbeat_sequence: int
    agent_state: str
    enrollment_state: str
    health: dict[str, object]
    capabilities: tuple[str, ...]
    platform: dict[str, object]
    inventory: dict[str, object]
    monitoring: dict[str, object]
    inventory_mode: str = "full"
    inventory_fingerprint: str = ""
    inventory_base_fingerprint: str | None = None
    inventory_removed_paths: tuple[str, ...] = ()
    command_acknowledgements: tuple[dict[str, object], ...] = ()
    outbox_messages: tuple[dict[str, object], ...] = ()
    protocol_version: str = XMP_PROTOCOL_VERSION
    schema_version: int = 2

    @classmethod
    def create(
        cls,
        identity: DeviceIdentity,
        inventory: DeviceInventory,
        *,
        boot_id: str = 'unknown',
        uptime_seconds: int = 0,
        heartbeat_sequence: int = 1,
        agent_state: str = 'running',
        enrollment_state: str = 'active',
        health: dict[str, object] | None = None,
        capabilities: tuple[str, ...] = DEFAULT_CAPABILITIES,
        command_acknowledgements: tuple[dict[str, object], ...] = (),
        outbox_messages: tuple[dict[str, object], ...] = (),
        inventory_payload: dict[str, object] | None = None,
        inventory_mode: str = "full",
        inventory_fingerprint: str = "",
        inventory_base_fingerprint: str | None = None,
        inventory_removed_paths: tuple[str, ...] = (),
        monitoring: dict[str, object] | None = None,
    ) -> 'Heartbeat':
        payload = inventory.to_payload()
        return cls(
            device_id=identity.device_id,
            sent_at=datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
            agent_version=__version__,
            boot_id=boot_id,
            uptime_seconds=max(0, int(uptime_seconds)),
            heartbeat_sequence=max(1, int(heartbeat_sequence)),
            agent_state=agent_state,
            enrollment_state=enrollment_state,
            health=dict(health or {}),
            capabilities=tuple(sorted(set(capabilities))),
            platform={
                'hostname': payload.get('hostname'),
                'architecture': payload.get('architecture'),
                'kernel': payload.get('kernel'),
                'operating_system': payload.get('operating_system'),
            },
            inventory=dict(payload if inventory_payload is None else inventory_payload),
            monitoring=dict(monitoring or {}),
            inventory_mode=inventory_mode,
            inventory_fingerprint=inventory_fingerprint,
            inventory_base_fingerprint=inventory_base_fingerprint,
            inventory_removed_paths=tuple(inventory_removed_paths),
            command_acknowledgements=tuple(dict(item) for item in command_acknowledgements),
            outbox_messages=tuple(dict(item) for item in outbox_messages),
        )

    def to_payload(self) -> dict[str, Any]:
        return {
            'schema_version': self.schema_version,
            'type': 'heartbeat',
            'protocol_version': self.protocol_version,
            'device_id': self.device_id,
            'sent_at': self.sent_at,
            'agent_version': self.agent_version,
            'boot_id': self.boot_id,
            'uptime_seconds': self.uptime_seconds,
            'heartbeat_sequence': self.heartbeat_sequence,
            'agent_state': self.agent_state,
            'enrollment_state': self.enrollment_state,
            'capabilities': list(self.capabilities),
            'health': self.health,
            'platform': self.platform,
            'inventory_mode': self.inventory_mode,
            'inventory_fingerprint': self.inventory_fingerprint,
            'inventory_base_fingerprint': self.inventory_base_fingerprint,
            'inventory_removed_paths': list(self.inventory_removed_paths),
            'inventory': self.inventory,
            'monitoring': self.monitoring,
            'command_acknowledgements': [dict(item) for item in self.command_acknowledgements],
            'outbox_messages': [dict(item) for item in self.outbox_messages],
        }

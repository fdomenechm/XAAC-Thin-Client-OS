from __future__ import annotations

import hashlib
import json
import re
import stat
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Mapping

from xaac_agent.update_model import UpdateComponent, UpdateResult, UpdateState
from xaac_agent.update_trust import VerifiedUpdateArtifact

_PACKAGE = re.compile(r"^[a-z0-9][a-z0-9+.-]{0,127}(?::[a-z0-9][a-z0-9-]{0,31})?$")
_VERSION = re.compile(r"^[0-9A-Za-z][0-9A-Za-z.+:~_-]{0,127}$")


class DebianUpdateError(RuntimeError):
    def __init__(self, code: str, *, data: Mapping[str, object] | None = None) -> None:
        super().__init__(code)
        self.code = code
        self.data = dict(data or {})


@dataclass(frozen=True, slots=True)
class DebianPackageRequest:
    name: str
    version: str | None = None

    @property
    def apt_spec(self) -> str:
        return f"{self.name}={self.version}" if self.version else self.name


Runner = Callable[..., subprocess.CompletedProcess[str]]


@dataclass(frozen=True, slots=True)
class DebianPackageUpdater:
    allowed_packages: tuple[str, ...] = ()
    apt_get_path: Path = Path("/usr/bin/apt-get")
    dpkg_query_path: Path = Path("/usr/bin/dpkg-query")
    timeout_seconds: int = 900
    max_packages: int = 32
    allow_new_packages: bool = False
    allow_removals: bool = False
    runner: Runner = subprocess.run

    def __post_init__(self) -> None:
        if not self.apt_get_path.is_absolute() or not self.dpkg_query_path.is_absolute():
            raise ValueError("debian_update_tool_path_not_absolute")
        if not 1 <= self.timeout_seconds <= 7200:
            raise ValueError("invalid_debian_update_timeout")
        if not 1 <= self.max_packages <= 256:
            raise ValueError("invalid_debian_update_max_packages")
        for package in self.allowed_packages:
            if not _PACKAGE.fullmatch(package):
                raise ValueError("invalid_debian_update_allowed_package")

    def install(self, verified: VerifiedUpdateArtifact) -> UpdateResult:
        plan = verified.plan
        if plan.component is not UpdateComponent.DEBIAN_PACKAGES:
            raise DebianUpdateError("debian_update_component_mismatch")
        if plan.artifact.media_type not in {"application/json", "application/vnd.xaac.debian-update+json"}:
            raise DebianUpdateError("debian_update_media_type_invalid")
        self._verify_artifact(verified)
        requests = self._read_manifest(verified.path)
        self._authorize(requests)
        before = self._installed_versions(requests)
        args = [str(self.apt_get_path), "--simulate", "--no-remove", "--only-upgrade", "install", *[item.apt_spec for item in requests]]
        simulation = self._run(args, timeout=min(self.timeout_seconds, 120), timeout_code="debian_update_simulation_timeout")
        if simulation.returncode != 0:
            raise DebianUpdateError("debian_update_simulation_failed", data={"error": self._clean(simulation.stderr)})
        self._validate_simulation(simulation.stdout)
        install_args = [str(self.apt_get_path), "-y", "--no-remove", "--only-upgrade", "install", *[item.apt_spec for item in requests]]
        completed = self._run(install_args, timeout=self.timeout_seconds, timeout_code="debian_update_timeout")
        if completed.returncode != 0:
            raise DebianUpdateError("debian_update_install_failed", data={"return_code": completed.returncode, "error": self._clean(completed.stderr)})
        after = self._installed_versions(requests)
        state = UpdateState.REBOOT_PENDING if plan.reboot_required else UpdateState.INSTALLED
        return UpdateResult(plan.update_id, plan.component, plan.target_version, state, code="debian_packages_updated", data={
            "packages": [{"name": item.name, "requested_version": item.version, "before": before.get(item.name), "after": after.get(item.name)} for item in requests],
            "reboot_required": plan.reboot_required,
        })

    def _verify_artifact(self, verified: VerifiedUpdateArtifact) -> None:
        try:
            info = verified.path.lstat()
        except OSError as error:
            raise DebianUpdateError("debian_update_manifest_unavailable") from error
        if stat.S_ISLNK(info.st_mode):
            raise DebianUpdateError("debian_update_manifest_symlink")
        if not stat.S_ISREG(info.st_mode):
            raise DebianUpdateError("debian_update_manifest_not_regular")
        digest = hashlib.sha256(); size = 0
        try:
            with verified.path.open("rb") as stream:
                for chunk in iter(lambda: stream.read(65536), b""):
                    size += len(chunk); digest.update(chunk)
        except OSError as error:
            raise DebianUpdateError("debian_update_manifest_read_error") from error
        if size != verified.size_bytes:
            raise DebianUpdateError("debian_update_manifest_size_mismatch")
        if digest.hexdigest() != verified.artifact_sha256:
            raise DebianUpdateError("debian_update_manifest_digest_mismatch")

    def _read_manifest(self, path: Path) -> tuple[DebianPackageRequest, ...]:
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError) as error:
            raise DebianUpdateError("debian_update_manifest_invalid") from error
        if not isinstance(payload, dict) or set(payload) - {"schema_version", "packages"} or payload.get("schema_version") != 1:
            raise DebianUpdateError("debian_update_manifest_invalid")
        packages = payload.get("packages")
        if not isinstance(packages, list) or not packages or len(packages) > self.max_packages:
            raise DebianUpdateError("debian_update_package_count_invalid")
        result: list[DebianPackageRequest] = []
        seen: set[str] = set()
        for raw in packages:
            if not isinstance(raw, dict) or set(raw) - {"name", "version"}:
                raise DebianUpdateError("debian_update_package_entry_invalid")
            name, version = raw.get("name"), raw.get("version")
            if not isinstance(name, str) or not _PACKAGE.fullmatch(name):
                raise DebianUpdateError("debian_update_package_name_invalid")
            if version is not None and (not isinstance(version, str) or not _VERSION.fullmatch(version)):
                raise DebianUpdateError("debian_update_package_version_invalid")
            if name in seen:
                raise DebianUpdateError("debian_update_package_duplicate")
            seen.add(name); result.append(DebianPackageRequest(name, version))
        return tuple(result)

    def _authorize(self, requests: tuple[DebianPackageRequest, ...]) -> None:
        allowed = set(self.allowed_packages)
        denied = [item.name for item in requests if item.name not in allowed]
        if denied:
            raise DebianUpdateError("debian_update_package_not_allowed", data={"packages": denied})

    def _installed_versions(self, requests: tuple[DebianPackageRequest, ...]) -> dict[str, str | None]:
        result: dict[str, str | None] = {}
        for item in requests:
            completed = self._run([str(self.dpkg_query_path), "-W", "-f=${Status}\t${Version}", item.name], timeout=30, timeout_code="debian_update_query_timeout")
            if completed.returncode != 0:
                if not self.allow_new_packages:
                    raise DebianUpdateError("debian_update_package_not_installed", data={"package": item.name})
                result[item.name] = None
                continue
            parts = completed.stdout.strip().split("\t", 1)
            if len(parts) != 2 or parts[0] != "install ok installed":
                raise DebianUpdateError("debian_update_package_state_invalid", data={"package": item.name})
            result[item.name] = parts[1]
        return result

    def _validate_simulation(self, output: str) -> None:
        text = output or ""
        if not self.allow_removals and ("The following packages will be REMOVED:" in text or re.search(r"^Remv\s", text, re.MULTILINE)):
            raise DebianUpdateError("debian_update_would_remove_packages")
        if not self.allow_new_packages and "The following NEW packages will be installed:" in text:
            raise DebianUpdateError("debian_update_would_install_new_packages")

    def _run(self, args: list[str], *, timeout: int, timeout_code: str) -> subprocess.CompletedProcess[str]:
        try:
            return self.runner(args, check=False, capture_output=True, text=True, timeout=timeout, env={"LC_ALL": "C", "DEBIAN_FRONTEND": "noninteractive"})
        except subprocess.TimeoutExpired as error:
            raise DebianUpdateError(timeout_code) from error
        except OSError as error:
            raise DebianUpdateError("debian_update_backend_error") from error

    @staticmethod
    def _clean(value: str) -> str:
        return " ".join((value or "").replace("\x00", "").split())[:512]

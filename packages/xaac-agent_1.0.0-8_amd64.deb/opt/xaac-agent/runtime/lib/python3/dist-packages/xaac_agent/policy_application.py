from __future__ import annotations

import hashlib
import json
import os
import stat
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .policy_compatibility import CompatiblePolicy
from .policy_model import PolicyResult, PolicyState
from .policy_schema import ValidatedPolicy
from .policy_trust import VerifiedPolicy


class PolicyApplicationError(ValueError):
    """La política no es pot preparar o activar transaccionalment."""

    def __init__(self, code: str) -> None:
        super().__init__(code)
        self.code = code


@dataclass(frozen=True, slots=True)
class AppliedPolicy:
    policy_id: str
    revision: int
    path: Path
    sha256: str
    previous_preserved: bool

    def to_result(self) -> PolicyResult:
        return PolicyResult(
            self.policy_id,
            self.revision,
            PolicyState.APPLIED,
            code="policy_applied_transactionally",
            data={
                "sha256": self.sha256,
                "previous_preserved": self.previous_preserved,
            },
        )


@dataclass(slots=True)
class PolicyTransactionApplier:
    directory: Path
    active_name: str = "active-policy.json"
    previous_name: str = "previous-policy.json"

    def apply(
        self,
        validated: ValidatedPolicy,
        verified: VerifiedPolicy,
        compatible: CompatiblePolicy,
        *,
        now: datetime | None = None,
    ) -> AppliedPolicy:
        policy = validated.policy
        identities = {policy.identity, verified.policy.identity, compatible.policy.identity}
        if len(identities) != 1:
            raise PolicyApplicationError("policy_evidence_mismatch")
        if policy.is_expired(now=now):
            raise PolicyApplicationError("policy_expired_before_application")

        self._prepare_directory()
        active = self.directory / self.active_name
        previous = self.directory / self.previous_name
        self._validate_destination(active)
        self._validate_destination(previous)

        document: dict[str, Any] = policy.to_payload()
        document["sections"] = validated.normalized_sections
        document["application"] = {
            "applied_at": (now or datetime.now(timezone.utc)).astimezone(timezone.utc).isoformat().replace("+00:00", "Z"),
            "schema_id": validated.schema_id,
            "schema_revision": validated.schema_revision,
            "signature_key_id": verified.key_id,
            "signature_algorithm": verified.algorithm,
            "canonical_sha256": verified.canonical_sha256,
            "agent_version": compatible.agent_version,
            "protocol_version": compatible.protocol_version,
        }
        raw = json.dumps(document, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8") + b"\n"
        digest = hashlib.sha256(raw).hexdigest()

        staged = self._write_temp(raw, prefix=".policy-stage-")
        previous_preserved = False
        try:
            if active.exists():
                current = active.read_bytes()
                backup = self._write_temp(current, prefix=".policy-previous-")
                os.replace(backup, previous)
                previous_preserved = True
            os.replace(staged, active)
            self._fsync_directory()
        except OSError as error:
            try:
                staged.unlink(missing_ok=True)
            except OSError:
                pass
            raise PolicyApplicationError("policy_activation_failed") from error

        return AppliedPolicy(policy.policy_id, policy.revision, active, digest, previous_preserved)

    def load_active(self) -> dict[str, Any] | None:
        path = self.directory / self.active_name
        if not path.exists():
            return None
        self._validate_destination(path)
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
            raise PolicyApplicationError("active_policy_unreadable") from error
        if not isinstance(value, dict):
            raise PolicyApplicationError("active_policy_invalid")
        return value

    def _prepare_directory(self) -> None:
        if self.directory.is_symlink():
            raise PolicyApplicationError("policy_application_directory_symlink")
        try:
            self.directory.mkdir(parents=True, exist_ok=True, mode=0o700)
            mode = self.directory.stat().st_mode
        except OSError as error:
            raise PolicyApplicationError("policy_application_directory_unavailable") from error
        if not stat.S_ISDIR(mode):
            raise PolicyApplicationError("policy_application_directory_invalid")
        os.chmod(self.directory, 0o700)

    @staticmethod
    def _validate_destination(path: Path) -> None:
        if path.is_symlink():
            raise PolicyApplicationError("policy_application_target_symlink")
        if path.exists() and not stat.S_ISREG(path.stat().st_mode):
            raise PolicyApplicationError("policy_application_target_not_regular")

    def _write_temp(self, data: bytes, *, prefix: str) -> Path:
        try:
            descriptor, name = tempfile.mkstemp(prefix=prefix, dir=self.directory)
            path = Path(name)
            with os.fdopen(descriptor, "wb") as stream:
                os.fchmod(stream.fileno(), 0o600)
                stream.write(data)
                stream.flush()
                os.fsync(stream.fileno())
            return path
        except OSError as error:
            raise PolicyApplicationError("policy_staging_failed") from error

    def _fsync_directory(self) -> None:
        descriptor = os.open(self.directory, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)

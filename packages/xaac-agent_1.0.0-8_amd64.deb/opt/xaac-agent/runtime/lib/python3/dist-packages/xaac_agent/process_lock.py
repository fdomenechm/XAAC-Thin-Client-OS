from __future__ import annotations

import errno
import fcntl
import logging
import os
import stat
from pathlib import Path
from types import TracebackType

logger = logging.getLogger(__name__)


class ProcessLockError(RuntimeError):
    """Error base relacionat amb el bloqueig del procés de l'agent."""


class AgentAlreadyRunningError(ProcessLockError):
    """Ja hi ha una altra instància de XAAC Agent en execució."""

    def __init__(self, lock_file: Path, pid: int | None = None) -> None:
        self.lock_file = lock_file
        self.pid = pid
        detail = f" (PID {pid})" if pid is not None else ""
        super().__init__(f"XAAC Agent ja està en execució{detail}: {lock_file}")


class InvalidLockFileError(ProcessLockError):
    """El fitxer de bloqueig no es pot utilitzar de manera segura."""


class ProcessLock:
    """Bloqueig exclusiu no bloquejant basat en ``flock``.

    El PID s'emmagatzema per facilitar el diagnòstic, però l'autoritat real és
    el bloqueig mantingut pel kernel. Per això un fitxer deixat després d'una
    finalització inesperada es recupera automàticament.
    """

    def __init__(self, lock_file: Path, *, pid: int | None = None) -> None:
        self._lock_file = lock_file
        self._pid = os.getpid() if pid is None else pid
        self._fd: int | None = None

    @property
    def lock_file(self) -> Path:
        return self._lock_file

    @property
    def acquired(self) -> bool:
        return self._fd is not None

    def acquire(self) -> None:
        if self.acquired:
            return

        self._prepare_parent_directory()
        fd = self._open_safely()
        try:
            self._validate_open_file(fd)
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError as error:
                running_pid = self._read_pid(fd)
                raise AgentAlreadyRunningError(self._lock_file, running_pid) from error

            self._write_pid(fd)
        except Exception:
            os.close(fd)
            raise

        self._fd = fd
        logger.info("process_lock_acquired path=%s pid=%s", self._lock_file, self._pid)

    def release(self) -> None:
        fd = self._fd
        if fd is None:
            return

        self._fd = None
        try:
            # S'elimina mentre encara mantenim el bloqueig per evitar que una
            # altra instància reutilitze el mateix inode entre unlock i unlink.
            try:
                self._lock_file.unlink()
            except FileNotFoundError:
                pass
            fcntl.flock(fd, fcntl.LOCK_UN)
        finally:
            os.close(fd)
        logger.info("process_lock_released path=%s pid=%s", self._lock_file, self._pid)

    def __enter__(self) -> "ProcessLock":
        self.acquire()
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        self.release()

    def _prepare_parent_directory(self) -> None:
        parent = self._lock_file.parent
        try:
            parent.mkdir(parents=True, exist_ok=True, mode=0o755)
        except OSError as error:
            raise InvalidLockFileError(
                f"No es pot preparar el directori de runtime {parent}: {error}"
            ) from error
        if not parent.is_dir():
            raise InvalidLockFileError(f"El directori de runtime no és un directori: {parent}")

    def _open_safely(self) -> int:
        flags = os.O_RDWR | os.O_CREAT
        if hasattr(os, "O_CLOEXEC"):
            flags |= os.O_CLOEXEC
        if hasattr(os, "O_NOFOLLOW"):
            flags |= os.O_NOFOLLOW
        try:
            return os.open(self._lock_file, flags, 0o600)
        except OSError as error:
            if error.errno == errno.ELOOP:
                raise InvalidLockFileError(
                    f"El fitxer de bloqueig no pot ser un enllaç simbòlic: {self._lock_file}"
                ) from error
            raise InvalidLockFileError(
                f"No es pot obrir el fitxer de bloqueig {self._lock_file}: {error}"
            ) from error

    def _validate_open_file(self, fd: int) -> None:
        metadata = os.fstat(fd)
        if not stat.S_ISREG(metadata.st_mode):
            raise InvalidLockFileError(
                f"El fitxer de bloqueig no és un fitxer regular: {self._lock_file}"
            )

    def _write_pid(self, fd: int) -> None:
        payload = f"{self._pid}\n".encode("ascii")
        os.lseek(fd, 0, os.SEEK_SET)
        os.ftruncate(fd, 0)
        os.write(fd, payload)
        os.fsync(fd)
        os.fchmod(fd, 0o600)

    @staticmethod
    def _read_pid(fd: int) -> int | None:
        try:
            os.lseek(fd, 0, os.SEEK_SET)
            raw = os.read(fd, 64).decode("ascii", errors="strict").strip()
            pid = int(raw)
        except (OSError, UnicodeError, ValueError):
            return None
        return pid if pid > 0 else None

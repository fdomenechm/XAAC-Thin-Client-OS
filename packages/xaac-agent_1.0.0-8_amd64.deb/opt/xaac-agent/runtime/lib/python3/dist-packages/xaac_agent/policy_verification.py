from __future__ import annotations

import hashlib
import json
import stat
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from .policy_application import AppliedPolicy
from .policy_model import PolicyResult, PolicyState


class PolicyPostVerificationError(ValueError):
    """La política activada no supera la verificació posterior local."""

    def __init__(self, code: str, *, data: Mapping[str, Any] | None = None) -> None:
        super().__init__(code)
        self.code = code
        self.data = dict(data or {})


@dataclass(frozen=True, slots=True)
class PolicyProbeResult:
    name: str
    passed: bool
    code: str = "ok"
    data: Mapping[str, Any] | None = None


PolicyProbe = Callable[[Mapping[str, Any]], PolicyProbeResult]


@dataclass(frozen=True, slots=True)
class VerifiedActivePolicy:
    policy_id: str
    revision: int
    path: Path
    sha256: str
    verified_at: datetime
    probes: tuple[PolicyProbeResult, ...] = ()

    def to_result(self) -> PolicyResult:
        return PolicyResult(
            self.policy_id,
            self.revision,
            PolicyState.APPLIED,
            code="policy_post_verification_passed",
            data={
                "sha256": self.sha256,
                "verified_at": self.verified_at.astimezone(timezone.utc).isoformat().replace("+00:00", "Z"),
                "probes": [
                    {"name": probe.name, "code": probe.code, "data": dict(probe.data or {})}
                    for probe in self.probes
                ],
            },
        )


@dataclass(slots=True)
class PolicyPostVerifier:
    probes: Sequence[PolicyProbe] = ()
    max_bytes: int = 2 * 1024 * 1024

    def verify(
        self,
        applied: AppliedPolicy,
        *,
        now: datetime | None = None,
    ) -> VerifiedActivePolicy:
        path = applied.path
        if path.is_symlink():
            raise PolicyPostVerificationError("active_policy_symlink")
        try:
            metadata = path.stat()
        except OSError as error:
            raise PolicyPostVerificationError("active_policy_unavailable") from error
        if not stat.S_ISREG(metadata.st_mode):
            raise PolicyPostVerificationError("active_policy_not_regular")
        if metadata.st_size <= 0 or metadata.st_size > self.max_bytes:
            raise PolicyPostVerificationError("active_policy_size_invalid")

        try:
            raw = path.read_bytes()
        except OSError as error:
            raise PolicyPostVerificationError("active_policy_unreadable") from error
        digest = hashlib.sha256(raw).hexdigest()
        if digest != applied.sha256:
            raise PolicyPostVerificationError(
                "active_policy_digest_mismatch",
                data={"expected_sha256": applied.sha256, "actual_sha256": digest},
            )

        try:
            document = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise PolicyPostVerificationError("active_policy_invalid_json") from error
        if not isinstance(document, dict):
            raise PolicyPostVerificationError("active_policy_invalid_document")
        if document.get("policy_id") != applied.policy_id or document.get("revision") != applied.revision:
            raise PolicyPostVerificationError("active_policy_identity_mismatch")
        if not isinstance(document.get("sections"), dict):
            raise PolicyPostVerificationError("active_policy_sections_invalid")

        application = document.get("application")
        if not isinstance(application, dict):
            raise PolicyPostVerificationError("active_policy_application_evidence_missing")
        required_evidence = {
            "applied_at",
            "schema_id",
            "schema_revision",
            "signature_key_id",
            "signature_algorithm",
            "canonical_sha256",
            "agent_version",
            "protocol_version",
        }
        if any(key not in application for key in required_evidence):
            raise PolicyPostVerificationError("active_policy_application_evidence_incomplete")

        results: list[PolicyProbeResult] = []
        for probe in self.probes:
            try:
                result = probe(document)
            except Exception as error:  # probes are an isolation boundary
                raise PolicyPostVerificationError(
                    "policy_probe_error", data={"probe": getattr(probe, "__name__", "unknown")}
                ) from error
            if not isinstance(result, PolicyProbeResult):
                raise PolicyPostVerificationError("policy_probe_invalid_result")
            results.append(result)
            if not result.passed:
                raise PolicyPostVerificationError(
                    "policy_probe_failed",
                    data={"probe": result.name, "code": result.code, **dict(result.data or {})},
                )

        instant = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
        return VerifiedActivePolicy(
            policy_id=applied.policy_id,
            revision=applied.revision,
            path=path,
            sha256=digest,
            verified_at=instant,
            probes=tuple(results),
        )

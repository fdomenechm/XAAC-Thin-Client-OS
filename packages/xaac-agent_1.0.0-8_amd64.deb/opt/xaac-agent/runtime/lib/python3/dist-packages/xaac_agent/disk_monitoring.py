from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable


_EPHEMERAL_FILESYSTEMS = frozenset({
    "proc", "sysfs", "devtmpfs", "devpts", "tmpfs", "cgroup", "cgroup2",
    "securityfs", "pstore", "debugfs", "tracefs", "configfs", "fusectl",
    "mqueue", "hugetlbfs", "rpc_pipefs", "autofs", "binfmt_misc", "overlay",
})


def _decode_mount_field(value: str) -> str:
    return value.replace("\\040", " ").replace("\\011", "\t").replace("\\012", "\n").replace("\\134", "\\")


@dataclass(frozen=True, slots=True)
class FilesystemThresholds:
    warning_percent: float = 80.0
    critical_percent: float = 95.0
    hysteresis_percent: float = 5.0


@dataclass(frozen=True, slots=True)
class MountRecord:
    mount_point: Path
    filesystem_type: str
    source: str
    read_only: bool


class DiskThresholdTracker:
    def __init__(self, thresholds: FilesystemThresholds) -> None:
        self._thresholds = thresholds
        self._states: dict[str, str] = {}

    def evaluate(self, key: str, used_percent: float) -> str:
        previous = self._states.get(key, "normal")
        warning = self._thresholds.warning_percent
        critical = self._thresholds.critical_percent
        hysteresis = self._thresholds.hysteresis_percent
        if previous == "critical":
            state = "critical" if used_percent >= critical - hysteresis else ("warning" if used_percent >= warning - hysteresis else "normal")
        elif previous == "warning":
            state = "critical" if used_percent >= critical else ("warning" if used_percent >= warning - hysteresis else "normal")
        else:
            state = "critical" if used_percent >= critical else ("warning" if used_percent >= warning else "normal")
        self._states[key] = state
        return state


class DiskMonitor:
    """Monitorització lleugera dels sistemes de fitxers muntats."""

    def __init__(
        self,
        *,
        mountinfo_path: Path = Path("/proc/self/mountinfo"),
        thresholds: FilesystemThresholds | None = None,
        statvfs: Callable[[str | bytes | os.PathLike[str] | os.PathLike[bytes]], os.statvfs_result] = os.statvfs,
    ) -> None:
        self._mountinfo_path = mountinfo_path
        self._tracker = DiskThresholdTracker(thresholds or FilesystemThresholds())
        self._statvfs = statvfs

    def sample(self) -> dict[str, object]:
        filesystems: list[dict[str, object]] = []
        for mount in self._read_mounts():
            try:
                stats = self._statvfs(mount.mount_point)
            except (OSError, ValueError):
                continue
            block_size = stats.f_frsize or stats.f_bsize
            total = int(stats.f_blocks * block_size)
            available = int(stats.f_bavail * block_size)
            free = int(stats.f_bfree * block_size)
            if total <= 0:
                continue
            used = max(0, total - free)
            used_percent = round(min(100.0, used * 100.0 / total), 2)
            state = self._tracker.evaluate(str(mount.mount_point), used_percent)
            entry: dict[str, object] = {
                "mount_point": str(mount.mount_point),
                "filesystem_type": mount.filesystem_type,
                "source": mount.source,
                "read_only": mount.read_only,
                "total_bytes": total,
                "used_bytes": used,
                "free_bytes": free,
                "available_bytes": available,
                "used_percent": used_percent,
                "state": state,
            }
            filesystems.append(entry)
        severity = "critical" if any(item["state"] == "critical" for item in filesystems) else (
            "warning" if any(item["state"] == "warning" for item in filesystems) else "normal"
        )
        return {
            "filesystems": filesystems,
            "filesystem_count": len(filesystems),
            "read_only_count": sum(1 for item in filesystems if item["read_only"]),
            "severity": severity,
        }

    def _read_mounts(self) -> tuple[MountRecord, ...]:
        try:
            if self._mountinfo_path.is_symlink() or not self._mountinfo_path.is_file():
                return ()
            text = self._mountinfo_path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return ()
        mounts: dict[str, MountRecord] = {}
        for line in text.splitlines():
            parts = line.split()
            try:
                separator = parts.index("-")
                mount_point = _decode_mount_field(parts[4])
                options = parts[5].split(",")
                filesystem_type = parts[separator + 1]
                source = _decode_mount_field(parts[separator + 2])
            except (ValueError, IndexError):
                continue
            if filesystem_type in _EPHEMERAL_FILESYSTEMS or not mount_point.startswith("/"):
                continue
            mounts[mount_point] = MountRecord(
                mount_point=Path(mount_point),
                filesystem_type=filesystem_type,
                source=source,
                read_only="ro" in options,
            )
        return tuple(mounts[key] for key in sorted(mounts))

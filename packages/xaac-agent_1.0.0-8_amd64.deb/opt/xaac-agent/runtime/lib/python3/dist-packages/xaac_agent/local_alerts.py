from __future__ import annotations

import json
import os
import stat
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Mapping


class LocalAlertStateError(RuntimeError):
    """L'estat persistent de les alertes locals és invàlid o insegur."""


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


@dataclass(frozen=True, slots=True)
class LocalAlert:
    alert_id: str
    component: str
    previous_state: str
    current_state: str
    event: str
    occurred_at: str

    def to_payload(self) -> dict[str, object]:
        return {
            'alert_id': self.alert_id,
            'component': self.component,
            'previous_state': self.previous_state,
            'current_state': self.current_state,
            'event': self.event,
            'occurred_at': self.occurred_at,
        }


class LocalAlertManager:
    """Genera alertes només quan canvia l'estat d'un component monitoritzat."""

    SCHEMA_VERSION = 1
    VALID_STATES = frozenset({'normal', 'warning', 'critical'})

    def __init__(self, path: Path, *, recovery_enabled: bool = True) -> None:
        self.path = path
        self.recovery_enabled = bool(recovery_enabled)

    def evaluate(self, monitoring: Mapping[str, object]) -> list[LocalAlert]:
        previous = self._load()
        current = self._extract_states(monitoring)
        alerts: list[LocalAlert] = []
        now = _utc_now()
        for component in sorted(current):
            state = current[component]
            old = previous.get(component, 'normal')
            if state == old:
                continue
            if state == 'normal':
                if self.recovery_enabled and old in {'warning', 'critical'}:
                    alerts.append(self._build(component, old, state, 'recovery', now))
            else:
                event = 'raised' if old == 'normal' else 'severity_changed'
                alerts.append(self._build(component, old, state, event, now))
        self._write(current)
        return alerts

    @classmethod
    def _extract_states(cls, monitoring: Mapping[str, object]) -> dict[str, str]:
        result: dict[str, str] = {}
        thresholds = monitoring.get('thresholds')
        if isinstance(thresholds, Mapping):
            for name, value in thresholds.items():
                state = str(value)
                if state in cls.VALID_STATES:
                    result[f'resources.{name}'] = state
        for name, value in monitoring.items():
            if name in {'thresholds', 'aggregate', 'aggregation', 'sample', 'severity', 'sample_count'}:
                continue
            if isinstance(value, Mapping):
                state = value.get('severity')
                if isinstance(state, str) and state in cls.VALID_STATES:
                    result[name] = state
        return result

    @staticmethod
    def _build(component: str, old: str, state: str, event: str, now: str) -> LocalAlert:
        safe_component = component.replace('/', '_').replace(' ', '_')
        return LocalAlert(
            alert_id=f'monitoring:{safe_component}:{state}:{now}',
            component=component,
            previous_state=old,
            current_state=state,
            event=event,
            occurred_at=now,
        )

    def _load(self) -> dict[str, str]:
        if not self.path.exists():
            return {}
        try:
            mode = self.path.lstat().st_mode
        except OSError as error:
            raise LocalAlertStateError(f'no es pot inspeccionar l’estat d’alertes: {error}') from error
        if stat.S_ISLNK(mode) or not stat.S_ISREG(mode):
            raise LocalAlertStateError('l’estat d’alertes ha de ser un fitxer regular')
        try:
            payload = json.loads(self.path.read_text(encoding='utf-8'))
        except (OSError, json.JSONDecodeError) as error:
            raise LocalAlertStateError('estat d’alertes no llegible o JSON invàlid') from error
        if not isinstance(payload, dict) or payload.get('schema_version') != self.SCHEMA_VERSION:
            raise LocalAlertStateError('esquema d’alertes no compatible')
        states = payload.get('states')
        if not isinstance(states, dict):
            raise LocalAlertStateError('estats d’alertes invàlids')
        result: dict[str, str] = {}
        for key, value in states.items():
            if not isinstance(key, str) or not isinstance(value, str) or value not in self.VALID_STATES:
                raise LocalAlertStateError('estat de component invàlid')
            result[key] = value
        return result

    def _write(self, states: Mapping[str, str]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {'schema_version': self.SCHEMA_VERSION, 'states': dict(states), 'updated_at': _utc_now()}
        temporary = self.path.with_name(f'.{self.path.name}.{os.getpid()}.tmp')
        data = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':')) + '\n'
        try:
            fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, 'w', encoding='utf-8') as stream:
                stream.write(data)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.path)
            os.chmod(self.path, 0o600)
        finally:
            try:
                temporary.unlink()
            except FileNotFoundError:
                pass

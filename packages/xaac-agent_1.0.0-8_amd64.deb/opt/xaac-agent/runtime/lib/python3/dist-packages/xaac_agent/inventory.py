from __future__ import annotations

import os
import socket
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping

from xaac_agent.bios_inventory import FirmwareInventoryCollector
from xaac_agent.hardware_cpu_memory import CpuMemoryInventoryCollector
from xaac_agent.hardware_identity import HardwareIdentityCollector
from xaac_agent.hardware_profile import HardwareProfileDetector
from xaac_agent.graphics_audio_inventory import GraphicsAudioInventoryCollector
from xaac_agent.inventory_providers import InventoryCollectionResult, InventoryRegistry
from xaac_agent.os_inventory import OperatingSystemInventoryCollector
from xaac_agent.network_inventory import NetworkInventoryCollector
from xaac_agent.storage_inventory import StorageInventoryCollector
from xaac_agent.usb_peripherals_inventory import UsbPeripheralsInventoryCollector
from xaac_agent.software_inventory import SoftwareInventoryCollector


@dataclass(slots=True)
class OperatingSystemProvider:
    collector: OperatingSystemInventoryCollector
    name: str = "operating-system"
    version: str = "1"
    order: int = 10
    capabilities: tuple[str, ...] = ("inventory-operating-system",)

    def collect(self) -> Mapping[str, object]:
        details = self.collector.collect()
        return {
            "hostname": socket.gethostname(),
            "architecture": details.architecture,
            "kernel": details.kernel_release,
            "operating_system": details.pretty_name,
            "machine_id_present": Path("/etc/machine-id").is_file(),
            "xaac_thinclient_installed": InventoryCollector._thinclient_installed(),
            "operating_system_details": details.to_payload(),
        }


@dataclass(slots=True)
class HardwareIdentityProvider:
    collector: HardwareIdentityCollector
    name: str = "hardware-identity"
    version: str = "1"
    order: int = 20
    capabilities: tuple[str, ...] = ("inventory-hardware-identity",)

    def collect(self) -> Mapping[str, object]:
        return {"hardware": self.collector.collect().to_payload()}


@dataclass(slots=True)
class HardwareProfileProvider:
    detector: HardwareProfileDetector
    name: str = "hardware-profile"
    version: str = "1"
    order: int = 25
    capabilities: tuple[str, ...] = ("inventory-hardware-profile",)

    def collect(self) -> Mapping[str, object]:
        return {"hardware_profile": self.detector.detect().to_payload()}


@dataclass(slots=True)
class CpuMemoryProvider:
    collector: CpuMemoryInventoryCollector
    name: str = "cpu-memory"
    version: str = "1"
    order: int = 30
    capabilities: tuple[str, ...] = ("inventory-cpu-memory",)

    def collect(self) -> Mapping[str, object]:
        return self.collector.collect().to_payload()


@dataclass(slots=True)
class FirmwareProvider:
    collector: FirmwareInventoryCollector
    name: str = "firmware"
    version: str = "1"
    order: int = 40
    capabilities: tuple[str, ...] = ("inventory-firmware",)

    def collect(self) -> Mapping[str, object]:
        return {"firmware": self.collector.collect().to_payload()}


@dataclass(slots=True)
class StorageProvider:
    collector: StorageInventoryCollector
    name: str = "storage"
    version: str = "1"
    order: int = 50
    capabilities: tuple[str, ...] = ("inventory-storage",)

    def collect(self) -> Mapping[str, object]:
        return {"storage": self.collector.collect().to_payload()}


@dataclass(slots=True)
class NetworkProvider:
    collector: NetworkInventoryCollector
    name: str = "network"
    version: str = "1"
    order: int = 60
    capabilities: tuple[str, ...] = ("inventory-network",)

    def collect(self) -> Mapping[str, object]:
        return {"network": self.collector.collect().to_payload()}


@dataclass(slots=True)
class GraphicsAudioProvider:
    collector: GraphicsAudioInventoryCollector
    name: str = "graphics-audio"
    version: str = "1"
    order: int = 70
    capabilities: tuple[str, ...] = ("inventory-graphics-audio",)

    def collect(self) -> Mapping[str, object]:
        return self.collector.collect().to_payload()


@dataclass(slots=True)
class UsbPeripheralsProvider:
    collector: UsbPeripheralsInventoryCollector
    name: str = "usb-peripherals"
    version: str = "1"
    order: int = 80
    capabilities: tuple[str, ...] = ("inventory-usb-peripherals",)

    def collect(self) -> Mapping[str, object]:
        return {"usb_peripherals": self.collector.collect().to_payload()}


@dataclass(slots=True)
class SoftwareProvider:
    collector: SoftwareInventoryCollector
    name: str = "software"
    version: str = "1"
    order: int = 90
    capabilities: tuple[str, ...] = ("inventory-software",)

    def collect(self) -> Mapping[str, object]:
        return {"software": self.collector.collect().to_payload()}


@dataclass(frozen=True, slots=True)
class DeviceInventory:
    hostname: str
    architecture: str
    kernel: str
    operating_system: str
    machine_id_present: bool
    xaac_thinclient_installed: bool
    hardware: object = None
    os_details: object = None
    cpu: object = None
    memory: object = None
    storage: object = None
    firmware: object = None
    network: object = None
    graphics: object = None
    audio: object = None
    usb_peripherals: object = None
    software: object = None
    provider_errors: Mapping[str, str] | None = None

    def to_payload(self) -> dict[str, object]:
        hardware = self.hardware.to_payload() if hasattr(self.hardware, "to_payload") else (self.hardware or {})
        os_details = self.os_details.to_payload() if hasattr(self.os_details, "to_payload") else (self.os_details or {})
        cpu = self.cpu.to_payload() if hasattr(self.cpu, "to_payload") else (self.cpu or {})
        memory = self.memory.to_payload() if hasattr(self.memory, "to_payload") else (self.memory or {})
        storage = self.storage.to_payload() if hasattr(self.storage, "to_payload") else (self.storage or {})
        firmware = self.firmware.to_payload() if hasattr(self.firmware, "to_payload") else (self.firmware or {})
        network = self.network.to_payload() if hasattr(self.network, "to_payload") else (self.network or {})
        graphics = self.graphics.to_payload() if hasattr(self.graphics, "to_payload") else (self.graphics or {})
        audio = self.audio.to_payload() if hasattr(self.audio, "to_payload") else (self.audio or {})
        usb_peripherals = self.usb_peripherals.to_payload() if hasattr(self.usb_peripherals, "to_payload") else (self.usb_peripherals or {})
        software = self.software.to_payload() if hasattr(self.software, "to_payload") else (self.software or {})
        return {
            "hostname": self.hostname,
            "architecture": self.architecture,
            "kernel": self.kernel,
            "operating_system": self.operating_system,
            "machine_id_present": self.machine_id_present,
            "xaac_thinclient_installed": self.xaac_thinclient_installed,
            "hardware": hardware,
            "operating_system_details": os_details,
            "cpu": cpu,
            "memory": memory,
            "storage": storage,
            "firmware": firmware,
            "network": network,
            "graphics": graphics,
            "audio": audio,
            "usb_peripherals": usb_peripherals,
            "software": software,
        }


class InventoryCollector:
    def __init__(
        self,
        hardware_collector: HardwareIdentityCollector | None = None,
        os_collector: OperatingSystemInventoryCollector | None = None,
        cpu_memory_collector: CpuMemoryInventoryCollector | None = None,
        storage_collector: StorageInventoryCollector | None = None,
        firmware_collector: FirmwareInventoryCollector | None = None,
        network_collector: NetworkInventoryCollector | None = None,
        graphics_audio_collector: GraphicsAudioInventoryCollector | None = None,
        usb_peripherals_collector: UsbPeripheralsInventoryCollector | None = None,
        software_collector: SoftwareInventoryCollector | None = None,
        configuration_summary: Mapping[str, object] | None = None,
        registry: InventoryRegistry | None = None,
    ) -> None:
        self._registry = registry or InventoryRegistry((
            OperatingSystemProvider(os_collector or OperatingSystemInventoryCollector()),
            HardwareIdentityProvider(hardware_collector or HardwareIdentityCollector()),
            HardwareProfileProvider(HardwareProfileDetector()),
            CpuMemoryProvider(cpu_memory_collector or CpuMemoryInventoryCollector()),
            FirmwareProvider(firmware_collector or FirmwareInventoryCollector()),
            StorageProvider(storage_collector or StorageInventoryCollector()),
            NetworkProvider(network_collector or NetworkInventoryCollector()),
            GraphicsAudioProvider(graphics_audio_collector or GraphicsAudioInventoryCollector()),
            UsbPeripheralsProvider(usb_peripherals_collector or UsbPeripheralsInventoryCollector()),
            SoftwareProvider(software_collector or SoftwareInventoryCollector(configuration_summary=configuration_summary)),
        ))
        self._last_result: InventoryCollectionResult | None = None

    @property
    def capabilities(self) -> tuple[str, ...]:
        result = self._last_result or self._registry.collect()
        self._last_result = result
        return result.capabilities

    def collect(self) -> DeviceInventory:
        result = self._registry.collect()
        self._last_result = result
        p = result.payload
        return DeviceInventory(
            hostname=str(p.get("hostname", "unknown")),
            architecture=str(p.get("architecture", "unknown")),
            kernel=str(p.get("kernel", "unknown")),
            operating_system=str(p.get("operating_system", "unknown")),
            machine_id_present=bool(p.get("machine_id_present", False)),
            xaac_thinclient_installed=bool(p.get("xaac_thinclient_installed", False)),
            hardware=self._provider_object("hardware-identity"),
            os_details=self._provider_object("operating-system"),
            cpu=self._provider_cpu_memory("cpu"),
            memory=self._provider_cpu_memory("memory"),
            storage=self._provider_storage(),
            firmware=self._provider_firmware(),
            network=self._provider_network(),
            graphics=self._provider_graphics_audio("graphics"),
            audio=self._provider_graphics_audio("audio"),
            usb_peripherals=self._provider_usb_peripherals(),
            software=self._provider_software(),
            provider_errors=result.errors,
        )

    def _provider_object(self, name: str) -> object:
        for provider in self._registry.providers:
            if provider.name == name and hasattr(provider, "collector"):
                # Recollecting is avoided below by using the last provider value where practical;
                # legacy object attributes are retained for API compatibility.
                return provider.collector.collect()
        return {}

    def _provider_cpu_memory(self, part: str) -> object:
        for provider in self._registry.providers:
            if provider.name == "cpu-memory" and hasattr(provider, "collector"):
                value = provider.collector.collect()
                return getattr(value, part)
        return {}

    def _provider_firmware(self) -> object:
        for provider in self._registry.providers:
            if provider.name == "firmware" and hasattr(provider, "collector"):
                return provider.collector.collect()
        return {}

    def _provider_network(self) -> object:
        for provider in self._registry.providers:
            if provider.name == "network" and hasattr(provider, "collector"):
                return provider.collector.collect()
        return {}

    def _provider_graphics_audio(self, part: str) -> object:
        for provider in self._registry.providers:
            if provider.name == "graphics-audio" and hasattr(provider, "collector"):
                value = provider.collector.collect()
                return getattr(value, part)
        return {}

    def _provider_usb_peripherals(self) -> object:
        for provider in self._registry.providers:
            if provider.name == "usb-peripherals" and hasattr(provider, "collector"):
                return provider.collector.collect()
        return {}

    def _provider_software(self) -> object:
        for provider in self._registry.providers:
            if provider.name == "software" and hasattr(provider, "collector"):
                return provider.collector.collect()
        return {}

    def _provider_storage(self) -> object:
        for provider in self._registry.providers:
            if provider.name == "storage" and hasattr(provider, "collector"):
                return provider.collector.collect()
        return {}

    @staticmethod
    def _thinclient_installed() -> bool:
        executable = Path("/usr/bin/xaac-thinclient")
        package_dir = Path("/usr/lib/python3/dist-packages/xaac_thinclient")
        return executable.exists() or package_dir.exists() or bool(os.environ.get("XAAC_THINCLIENT_PRESENT"))

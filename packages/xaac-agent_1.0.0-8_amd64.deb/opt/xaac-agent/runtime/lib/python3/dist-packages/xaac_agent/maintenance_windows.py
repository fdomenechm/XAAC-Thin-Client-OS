from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime, time, timedelta, timezone
from typing import Iterable
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from xaac_agent.update_model import UpdatePlan, UpdateResult, UpdateState

_DAY_NAMES = {"mon": 0, "tue": 1, "wed": 2, "thu": 3, "fri": 4, "sat": 5, "sun": 6}
_TIME_RE = re.compile(r"^(?:[01][0-9]|2[0-3]):[0-5][0-9]$")


class MaintenanceWindowError(ValueError):
    def __init__(self, code: str) -> None:
        super().__init__(code)
        self.code = code


@dataclass(frozen=True, slots=True)
class MaintenanceWindow:
    weekdays: tuple[int, ...]
    start: time
    end: time

    @classmethod
    def parse(cls, value: str) -> "MaintenanceWindow":
        if not isinstance(value, str) or "@" not in value:
            raise MaintenanceWindowError("invalid_maintenance_window")
        raw_days, raw_hours = (part.strip().lower() for part in value.split("@", 1))
        if "-" not in raw_hours:
            raise MaintenanceWindowError("invalid_maintenance_window")
        raw_start, raw_end = (part.strip() for part in raw_hours.split("-", 1))
        if not _TIME_RE.fullmatch(raw_start) or not _TIME_RE.fullmatch(raw_end):
            raise MaintenanceWindowError("invalid_maintenance_window_time")
        weekdays = cls._parse_days(raw_days)
        start = time.fromisoformat(raw_start)
        end = time.fromisoformat(raw_end)
        if start == end:
            raise MaintenanceWindowError("empty_maintenance_window")
        return cls(weekdays=weekdays, start=start, end=end)

    @staticmethod
    def _parse_days(value: str) -> tuple[int, ...]:
        if value == "daily":
            return tuple(range(7))
        days: set[int] = set()
        for item in value.split(","):
            item = item.strip()
            if not item:
                raise MaintenanceWindowError("invalid_maintenance_window_day")
            if "-" in item:
                first, last = (part.strip() for part in item.split("-", 1))
                if first not in _DAY_NAMES or last not in _DAY_NAMES:
                    raise MaintenanceWindowError("invalid_maintenance_window_day")
                current = _DAY_NAMES[first]
                days.add(current)
                while current != _DAY_NAMES[last]:
                    current = (current + 1) % 7
                    days.add(current)
            else:
                if item not in _DAY_NAMES:
                    raise MaintenanceWindowError("invalid_maintenance_window_day")
                days.add(_DAY_NAMES[item])
        if not days:
            raise MaintenanceWindowError("invalid_maintenance_window_day")
        return tuple(sorted(days))

    def contains(self, local_time: datetime) -> bool:
        current = local_time.timetz().replace(tzinfo=None)
        weekday = local_time.weekday()
        if self.start < self.end:
            return weekday in self.weekdays and self.start <= current < self.end
        # Finestra nocturna: el tram posterior a mitjanit pertany al dia anterior.
        if weekday in self.weekdays and current >= self.start:
            return True
        return ((weekday - 1) % 7) in self.weekdays and current < self.end

    def next_start(self, local_time: datetime) -> datetime:
        for offset in range(0, 9):
            day = (local_time + timedelta(days=offset)).date()
            candidate = datetime.combine(day, self.start, tzinfo=local_time.tzinfo)
            if candidate.weekday() in self.weekdays and candidate > local_time:
                return candidate
        raise MaintenanceWindowError("maintenance_window_unreachable")


@dataclass(frozen=True, slots=True)
class MaintenanceDecision:
    allowed: bool
    code: str
    evaluated_at: datetime
    timezone_name: str
    next_window_at: datetime | None = None
    window_index: int | None = None

    def to_result(self, plan: UpdatePlan) -> UpdateResult:
        data: dict[str, object] = {
            "evaluated_at": self.evaluated_at.astimezone(timezone.utc).isoformat().replace("+00:00", "Z"),
            "timezone": self.timezone_name,
        }
        if self.next_window_at is not None:
            data["next_window_at"] = self.next_window_at.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
        if self.window_index is not None:
            data["window_index"] = self.window_index
        return UpdateResult(
            plan.update_id,
            plan.component,
            plan.target_version,
            UpdateState.VALIDATED if self.allowed else UpdateState.SCHEDULED,
            code=self.code,
            data=data,
        )


@dataclass(frozen=True, slots=True)
class MaintenanceWindowEvaluator:
    timezone_name: str = "UTC"
    windows: tuple[MaintenanceWindow, ...] = ()
    allow_when_unconfigured: bool = False
    max_schedule_ahead_seconds: int = 7 * 24 * 3600

    def __post_init__(self) -> None:
        try:
            ZoneInfo(self.timezone_name)
        except ZoneInfoNotFoundError as error:
            raise ValueError("invalid_maintenance_timezone") from error
        if not 60 <= self.max_schedule_ahead_seconds <= 31 * 24 * 3600:
            raise ValueError("invalid_maintenance_schedule_horizon")

    @classmethod
    def from_strings(
        cls,
        *,
        timezone_name: str,
        windows: Iterable[str],
        allow_when_unconfigured: bool = False,
        max_schedule_ahead_seconds: int = 7 * 24 * 3600,
    ) -> "MaintenanceWindowEvaluator":
        parsed = tuple(MaintenanceWindow.parse(value) for value in windows if value.strip())
        return cls(timezone_name, parsed, allow_when_unconfigured, max_schedule_ahead_seconds)

    def evaluate(self, plan: UpdatePlan, *, now: datetime | None = None) -> MaintenanceDecision:
        current = now or datetime.now(timezone.utc)
        if current.tzinfo is None:
            raise MaintenanceWindowError("maintenance_time_requires_timezone")
        current_utc = current.astimezone(timezone.utc)
        if plan.expires_at is not None and current_utc >= plan.expires_at:
            return MaintenanceDecision(False, "update_expired_before_maintenance", current_utc, self.timezone_name)
        local = current_utc.astimezone(ZoneInfo(self.timezone_name))
        if not self.windows:
            code = "maintenance_window_not_required" if self.allow_when_unconfigured else "maintenance_window_not_configured"
            return MaintenanceDecision(self.allow_when_unconfigured, code, current_utc, self.timezone_name)
        for index, window in enumerate(self.windows):
            if window.contains(local):
                return MaintenanceDecision(True, "maintenance_window_open", current_utc, self.timezone_name, window_index=index)
        next_candidates = [(window.next_start(local), index) for index, window in enumerate(self.windows)]
        next_local, index = min(next_candidates, key=lambda item: item[0])
        next_utc = next_local.astimezone(timezone.utc)
        if (next_utc - current_utc).total_seconds() > self.max_schedule_ahead_seconds:
            return MaintenanceDecision(False, "maintenance_window_too_far", current_utc, self.timezone_name)
        if plan.expires_at is not None and next_utc >= plan.expires_at:
            return MaintenanceDecision(False, "update_expires_before_next_window", current_utc, self.timezone_name)
        return MaintenanceDecision(False, "maintenance_window_closed", current_utc, self.timezone_name, next_utc, index)

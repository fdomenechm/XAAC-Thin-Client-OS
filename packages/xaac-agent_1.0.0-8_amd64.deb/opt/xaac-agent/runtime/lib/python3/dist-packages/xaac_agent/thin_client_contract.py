from __future__ import annotations

import os
import re
import stat
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Iterable


class ThinClientContractError(ValueError):
    """Contracte local XAAC Agent/Thin Client no vàlid o insegur."""


class ContractArea(str, Enum):
    RUNTIME = "runtime"
    STATE = "state"
    CONFIG = "config"
    COMMANDS = "commands"


class ContractOperation(str, Enum):
    READ_STATE = "read-state"
    PUBLISH_STATE = "publish-state"
    READ_CONFIG = "read-config"
    STAGE_CONFIG = "stage-config"
    ACK_CONFIG = "ack-config"
    SUBMIT_COMMAND = "submit-command"
    READ_COMMAND_RESULT = "read-command-result"
    QUERY_SERVICE = "query-service"
    CONTROL_SERVICE = "control-service"
    PUBLISH_HEARTBEAT = "publish-heartbeat"
    READ_HEARTBEAT = "read-heartbeat"
    PUBLISH_EVENT = "publish-event"
    READ_EVENTS = "read-events"
    COLLECT_DIAGNOSTICS = "collect-diagnostics"


_NAME_RE = re.compile(r"^[a-z][a-z0-9._-]{0,63}$")


@dataclass(frozen=True, slots=True)
class ContractPath:
    area: ContractArea
    path: Path
    owner: str
    group: str
    mode: int
    persistent: bool

    def to_payload(self) -> dict[str, object]:
        return {
            "area": self.area.value,
            "path": str(self.path),
            "owner": self.owner,
            "group": self.group,
            "mode": f"{self.mode:04o}",
            "persistent": self.persistent,
        }


@dataclass(frozen=True, slots=True)
class ThinClientIntegrationContract:
    contract_version: int
    agent_user: str
    thin_client_user: str
    shared_group: str
    runtime_root: Path
    state_root: Path
    config_root: Path
    command_root: Path
    allowed_operations: tuple[ContractOperation, ...]

    @classmethod
    def build(
        cls,
        *,
        runtime_root: Path,
        state_root: Path,
        config_root: Path,
        command_root: Path,
        agent_user: str = "xaac-agent",
        thin_client_user: str = "xaac-kiosk",
        shared_group: str = "xaac-ipc",
        allowed_operations: Iterable[str | ContractOperation] = (),
        contract_version: int = 1,
    ) -> "ThinClientIntegrationContract":
        if contract_version != 1:
            raise ThinClientContractError("unsupported_contract_version")
        for value in (agent_user, thin_client_user, shared_group):
            if not isinstance(value, str) or not _NAME_RE.fullmatch(value):
                raise ThinClientContractError("invalid_contract_identity")

        roots = tuple(Path(p) for p in (runtime_root, state_root, config_root, command_root))
        if len({str(p) for p in roots}) != 4:
            raise ThinClientContractError("contract_paths_must_be_distinct")
        for path in roots:
            if not path.is_absolute():
                raise ThinClientContractError("contract_path_must_be_absolute")
            if ".." in path.parts:
                raise ThinClientContractError("invalid_contract_path")

        operations: set[ContractOperation] = set()
        for operation in allowed_operations:
            try:
                operations.add(operation if isinstance(operation, ContractOperation) else ContractOperation(operation))
            except ValueError as error:
                raise ThinClientContractError("unsupported_contract_operation") from error

        return cls(
            contract_version=1,
            agent_user=agent_user,
            thin_client_user=thin_client_user,
            shared_group=shared_group,
            runtime_root=roots[0],
            state_root=roots[1],
            config_root=roots[2],
            command_root=roots[3],
            allowed_operations=tuple(sorted(operations, key=lambda item: item.value)),
        )

    @property
    def paths(self) -> tuple[ContractPath, ...]:
        return (
            ContractPath(ContractArea.RUNTIME, self.runtime_root, self.thin_client_user, self.shared_group, 0o2750, False),
            ContractPath(ContractArea.STATE, self.state_root, self.thin_client_user, self.shared_group, 0o2750, True),
            ContractPath(ContractArea.CONFIG, self.config_root, self.agent_user, self.shared_group, 0o2750, True),
            ContractPath(ContractArea.COMMANDS, self.command_root, self.agent_user, self.shared_group, 0o2750, False),
        )

    def is_operation_allowed(self, operation: str | ContractOperation) -> bool:
        try:
            parsed = operation if isinstance(operation, ContractOperation) else ContractOperation(operation)
        except ValueError:
            return False
        return parsed in self.allowed_operations

    def validate_layout(self, *, require_existing: bool = False) -> None:
        for entry in self.paths:
            path = entry.path
            if path.is_symlink():
                raise ThinClientContractError("contract_path_symlink")
            if not path.exists():
                if require_existing:
                    raise ThinClientContractError("contract_path_missing")
                continue
            try:
                mode = path.stat(follow_symlinks=False).st_mode
            except OSError as error:
                raise ThinClientContractError("contract_path_unreadable") from error
            if not stat.S_ISDIR(mode):
                raise ThinClientContractError("contract_path_not_directory")
            if mode & (stat.S_IWOTH | stat.S_IROTH):
                raise ThinClientContractError("contract_path_world_accessible")

    def create_layout(self) -> None:
        for entry in self.paths:
            path = entry.path
            parent = path.parent
            if parent.is_symlink() or path.is_symlink():
                raise ThinClientContractError("contract_path_symlink")
            try:
                path.mkdir(mode=entry.mode, parents=True, exist_ok=True)
                os.chmod(path, entry.mode, follow_symlinks=False)
            except OSError as error:
                raise ThinClientContractError("contract_layout_create_failed") from error
        self.validate_layout(require_existing=True)

    def to_payload(self) -> dict[str, object]:
        return {
            "contract": "xaac-local-integration",
            "contract_version": self.contract_version,
            "formats": {
                "state": "xaac-state/v2",
                "configuration": "xaac-configuration/v1",
                "configuration_ack": "xaac-configuration-ack/v1",
                "configuration_result": "xaac-configuration-result/v1",
                "command": "xaac-local-command/v1",
                "command_result": "xaac-local-command-result/v1",
                "event": "xaac-local-event/v1",
                "heartbeat": "xaac-local-heartbeat/v1",
                "diagnostic": "xaac-thin-client-diagnostic/v1",
            },
            "principals": {
                "agent_user": self.agent_user,
                "thin_client_user": self.thin_client_user,
                "shared_group": self.shared_group,
            },
            "paths": [entry.to_payload() for entry in self.paths],
            "allowed_operations": [operation.value for operation in self.allowed_operations],
            "separation": {
                "state": "thin-client-publishes-agent-reads",
                "events": "session-supervisor-publishes-agent-reads",
                "configuration": "agent-stages-thin-client-validates-and-activates",
                "commands": "agent-submits-thin-client-returns-structured-result",
            },
        }

from __future__ import annotations

import hashlib
import json
import os
import stat
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping


class CommandAuditError(RuntimeError):
    """El registre d'auditoria d'ordres és invàlid o insegur."""


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _canonical(value: Mapping[str, Any]) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


class CommandAuditJournal:
    SCHEMA_VERSION = 1
    GENESIS_HASH = "0" * 64

    def __init__(self, path: Path, *, max_records: int = 1024) -> None:
        self.path = path
        self.max_records = max(32, max_records)

    def append(
        self,
        event: str,
        command_id: str,
        *,
        command_type: str | None = None,
        issuer_id: str | None = None,
        state: str | None = None,
        code: str | None = None,
        data: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        payload = self._load()
        records = payload["records"]
        previous_hash = records[-1]["hash"] if records else self.GENESIS_HASH
        record: dict[str, Any] = {
            "sequence": (records[-1]["sequence"] + 1) if records else 1,
            "recorded_at": _utc_now(),
            "event": event,
            "command_id": command_id,
            "previous_hash": previous_hash,
        }
        for key, value in (("command_type", command_type), ("issuer_id", issuer_id), ("state", state), ("code", code)):
            if value is not None:
                record[key] = value
        if data:
            record["data"] = dict(data)
        record["hash"] = hashlib.sha256(_canonical(record)).hexdigest()
        records.append(record)
        if len(records) > self.max_records:
            records[:] = records[-self.max_records :]
            records[0]["previous_hash"] = self.GENESIS_HASH
            records[0]["hash"] = hashlib.sha256(_canonical({k: v for k, v in records[0].items() if k != "hash"})).hexdigest()
            for index in range(1, len(records)):
                records[index]["previous_hash"] = records[index - 1]["hash"]
                records[index]["hash"] = hashlib.sha256(_canonical({k: v for k, v in records[index].items() if k != "hash"})).hexdigest()
        self._write(payload)
        return dict(record)

    def records(self) -> list[dict[str, Any]]:
        return [dict(record) for record in self._load()["records"]]

    def verify(self) -> bool:
        records = self._load()["records"]
        previous = self.GENESIS_HASH
        for record in records:
            if record.get("previous_hash") != previous:
                return False
            claimed = record.get("hash")
            content = {key: value for key, value in record.items() if key != "hash"}
            if claimed != hashlib.sha256(_canonical(content)).hexdigest():
                return False
            previous = str(claimed)
        return True

    def _load(self) -> dict[str, Any]:
        if not self.path.exists():
            return {"schema_version": self.SCHEMA_VERSION, "records": []}
        mode = self.path.lstat().st_mode
        if stat.S_ISLNK(mode) or not stat.S_ISREG(mode):
            raise CommandAuditError("l'auditoria ha de ser un fitxer regular")
        try:
            payload = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as error:
            raise CommandAuditError("auditoria no llegible o JSON invàlid") from error
        if not isinstance(payload, dict) or payload.get("schema_version") != self.SCHEMA_VERSION:
            raise CommandAuditError("esquema d'auditoria no compatible")
        if not isinstance(payload.get("records"), list):
            raise CommandAuditError("registres d'auditoria invàlids")
        return payload

    def _write(self, payload: dict[str, Any]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_name(f".{self.path.name}.{os.getpid()}.tmp")
        data = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n"
        try:
            fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as stream:
                stream.write(data)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.path)
            os.chmod(self.path, 0o600)
        finally:
            temporary.unlink(missing_ok=True)

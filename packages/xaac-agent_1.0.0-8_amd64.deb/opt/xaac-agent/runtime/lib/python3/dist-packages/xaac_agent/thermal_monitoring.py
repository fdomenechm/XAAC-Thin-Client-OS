from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from xaac_agent.hardware_profile import HardwareProfile

_MAX_TEXT_BYTES = 4096
_MAX_THERMAL_ZONES = 32
_MAX_HWMON_DEVICES = 32
_MAX_HWMON_SENSORS_PER_DEVICE = 32


def _safe_iterdir(path: Path, *, limit: int) -> tuple[Path, ...]:
    try:
        if path.is_symlink() or not path.is_dir():
            return ()
        return tuple(sorted(path.iterdir(), key=lambda item: item.name)[:limit])
    except OSError:
        return ()


def _read_regular_text(path: Path) -> str | None:
    try:
        if path.is_symlink() or not path.is_file():
            return None
        with path.open("rb") as handle:
            raw = handle.read(_MAX_TEXT_BYTES + 1)
    except OSError:
        return None
    if len(raw) > _MAX_TEXT_BYTES:
        return None
    value = raw.decode("utf-8", errors="replace").strip()
    return value or None


def _temperature_celsius(raw: str | None) -> float | None:
    if raw is None:
        return None
    try:
        value = float(raw)
    except ValueError:
        return None
    absolute = abs(value)
    if absolute >= 1_000_000:
        value /= 1_000_000
    elif absolute >= 1_000:
        value /= 1_000
    if not -50.0 <= value <= 250.0:
        return None
    return round(value, 2)


@dataclass(frozen=True, slots=True)
class ThermalThresholds:
    warning_celsius: float = 75.0
    critical_celsius: float = 90.0
    hysteresis_celsius: float = 3.0


@dataclass(frozen=True, slots=True)
class ThermalPolicy:
    profile_id: str
    thresholds: ThermalThresholds
    fanless_device: bool
    recommend_unobstructed_airflow: bool

    @classmethod
    def for_profile(
        cls,
        profile: HardwareProfile,
        configured: ThermalThresholds | None = None,
    ) -> "ThermalPolicy":
        thresholds = configured or ThermalThresholds()
        if profile.profile_id == "dell-wyse-3040":
            # The Wyse 3040 is passively cooled. Never relax its profile above
            # the conservative defaults, while still allowing stricter local values.
            warning = min(thresholds.warning_celsius, 70.0)
            critical = min(thresholds.critical_celsius, 85.0)
            if warning >= critical:
                warning = critical - 1.0
            thresholds = ThermalThresholds(warning, critical, thresholds.hysteresis_celsius)
            return cls(profile.profile_id, thresholds, True, True)
        return cls(profile.profile_id, thresholds, False, False)


class ThermalThresholdTracker:
    def __init__(self, thresholds: ThermalThresholds) -> None:
        self._thresholds = thresholds
        self._states: dict[str, str] = {}

    def evaluate(self, sensor_id: str, temperature_celsius: float) -> str:
        previous = self._states.get(sensor_id, "normal")
        warning = self._thresholds.warning_celsius
        critical = self._thresholds.critical_celsius
        hysteresis = self._thresholds.hysteresis_celsius
        if previous == "critical":
            if temperature_celsius >= critical - hysteresis:
                state = "critical"
            elif temperature_celsius >= warning - hysteresis:
                state = "warning"
            else:
                state = "normal"
        elif previous == "warning":
            if temperature_celsius >= critical:
                state = "critical"
            elif temperature_celsius >= warning - hysteresis:
                state = "warning"
            else:
                state = "normal"
        else:
            state = "critical" if temperature_celsius >= critical else ("warning" if temperature_celsius >= warning else "normal")
        self._states[sensor_id] = state
        return state


class ThermalMonitor:
    """Bounded, read-only thermal telemetry from thermal sysfs and hwmon."""

    def __init__(
        self,
        *,
        thermal_root: Path = Path("/sys/class/thermal"),
        hwmon_root: Path = Path("/sys/class/hwmon"),
        thresholds: ThermalThresholds | None = None,
        policy: ThermalPolicy | None = None,
    ) -> None:
        self._thermal_root = thermal_root
        self._hwmon_root = hwmon_root
        self._policy = policy or ThermalPolicy("generic", thresholds or ThermalThresholds(), False, False)
        self._tracker = ThermalThresholdTracker(self._policy.thresholds)

    def sample(self) -> dict[str, object]:
        sensors = [*self._thermal_zone_sensors(), *self._hwmon_sensors()]
        unique: dict[str, dict[str, object]] = {str(sensor["sensor_id"]): sensor for sensor in sensors}
        ordered = [unique[key] for key in sorted(unique)]
        states = [str(sensor["state"]) for sensor in ordered]
        severity = "critical" if "critical" in states else ("warning" if "warning" in states else "normal")
        temperatures = [float(sensor["temperature_celsius"]) for sensor in ordered]
        payload: dict[str, object] = {
            "profile_id": self._policy.profile_id,
            "sensor_count": len(ordered),
            "sensors": ordered,
            "severity": severity,
            "availability": "available" if ordered else "unavailable",
            "thresholds": {
                "warning_celsius": self._policy.thresholds.warning_celsius,
                "critical_celsius": self._policy.thresholds.critical_celsius,
                "hysteresis_celsius": self._policy.thresholds.hysteresis_celsius,
            },
            "recommendations": {
                "fanless_device": self._policy.fanless_device,
                "keep_airflow_unobstructed": self._policy.recommend_unobstructed_airflow,
                "active_cooling_changes_performed": False,
            },
        }
        if temperatures:
            payload["maximum_temperature_celsius"] = round(max(temperatures), 2)
            payload["average_temperature_celsius"] = round(sum(temperatures) / len(temperatures), 2)
        return payload

    def _thermal_zone_sensors(self) -> list[dict[str, object]]:
        sensors: list[dict[str, object]] = []
        for zone in _safe_iterdir(self._thermal_root, limit=_MAX_THERMAL_ZONES):
            if not zone.name.startswith("thermal_zone") or zone.is_symlink() or not zone.is_dir():
                continue
            temperature = _temperature_celsius(_read_regular_text(zone / "temp"))
            if temperature is None:
                continue
            label = _read_regular_text(zone / "type") or zone.name
            sensor_id = f"thermal:{zone.name}"
            sensors.append(self._payload(sensor_id, label, temperature, "thermal_zone"))
        return sensors

    def _hwmon_sensors(self) -> list[dict[str, object]]:
        sensors: list[dict[str, object]] = []
        for hwmon in _safe_iterdir(self._hwmon_root, limit=_MAX_HWMON_DEVICES):
            if not hwmon.name.startswith("hwmon") or hwmon.is_symlink() or not hwmon.is_dir():
                continue
            chip = _read_regular_text(hwmon / "name") or hwmon.name
            found = 0
            for input_path in _safe_iterdir(hwmon, limit=256):
                name = input_path.name
                if not (name.startswith("temp") and name.endswith("_input")):
                    continue
                index = name[4:-6]
                if not index.isdigit():
                    continue
                temperature = _temperature_celsius(_read_regular_text(input_path))
                if temperature is None:
                    continue
                label = _read_regular_text(hwmon / f"temp{index}_label") or f"{chip} temp{index}"
                sensor_id = f"hwmon:{hwmon.name}:temp{index}"
                sensors.append(self._payload(sensor_id, label, temperature, "hwmon"))
                found += 1
                if found >= _MAX_HWMON_SENSORS_PER_DEVICE:
                    break
        return sensors

    def _payload(self, sensor_id: str, label: str, temperature: float, source: str) -> dict[str, object]:
        return {
            "sensor_id": sensor_id,
            "label": " ".join(label.split())[:128],
            "source": source,
            "temperature_celsius": temperature,
            "state": self._tracker.evaluate(sensor_id, temperature),
        }

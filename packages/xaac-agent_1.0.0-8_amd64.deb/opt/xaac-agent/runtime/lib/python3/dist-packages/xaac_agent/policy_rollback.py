from __future__ import annotations

import hashlib
import json
import os
import stat
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

from .policy_application import AppliedPolicy
from .policy_model import PolicyResult, PolicyState
from .policy_verification import PolicyPostVerificationError, PolicyPostVerifier, VerifiedActivePolicy


class PolicyRollbackError(ValueError):
    """No es pot completar o verificar el rollback de la política."""

    def __init__(self, code: str, *, data: Mapping[str, Any] | None = None) -> None:
        super().__init__(code)
        self.code = code
        self.data = dict(data or {})


@dataclass(frozen=True, slots=True)
class RolledBackPolicy:
    policy_id: str
    revision: int
    path: Path
    sha256: str
    replaced_policy_id: str
    replaced_revision: int
    verified: VerifiedActivePolicy

    def to_result(self) -> PolicyResult:
        return PolicyResult(
            self.policy_id,
            self.revision,
            PolicyState.ROLLED_BACK,
            code="policy_rolled_back_safely",
            data={
                "sha256": self.sha256,
                "replaced_policy_id": self.replaced_policy_id,
                "replaced_revision": self.replaced_revision,
                "verified_at": self.verified.verified_at.astimezone(timezone.utc)
                .isoformat()
                .replace("+00:00", "Z"),
            },
        )


@dataclass(slots=True)
class PolicyRollbackManager:
    directory: Path
    verifier: PolicyPostVerifier
    active_name: str = "active-policy.json"
    previous_name: str = "previous-policy.json"
    max_bytes: int = 2 * 1024 * 1024

    def rollback(
        self,
        *,
        expected_active_policy_id: str | None = None,
        expected_active_revision: int | None = None,
        now: datetime | None = None,
    ) -> RolledBackPolicy:
        self._validate_directory()
        active = self.directory / self.active_name
        previous = self.directory / self.previous_name
        active_raw, active_document = self._read_policy(active, "active")
        previous_raw, previous_document = self._read_policy(previous, "previous")

        active_id, active_revision = self._identity(active_document, "active")
        previous_id, previous_revision = self._identity(previous_document, "previous")
        if expected_active_policy_id is not None and active_id != expected_active_policy_id:
            raise PolicyRollbackError("rollback_active_policy_mismatch")
        if expected_active_revision is not None and active_revision != expected_active_revision:
            raise PolicyRollbackError("rollback_active_revision_mismatch")
        if (active_id, active_revision) == (previous_id, previous_revision):
            raise PolicyRollbackError("rollback_target_same_as_active")

        previous_digest = hashlib.sha256(previous_raw).hexdigest()
        rollback_applied = AppliedPolicy(
            previous_id,
            previous_revision,
            active,
            previous_digest,
            previous_preserved=True,
        )

        staged_target = self._write_temp(previous_raw, prefix=".policy-rollback-target-")
        staged_original = self._write_temp(active_raw, prefix=".policy-rollback-original-")
        activated = False
        try:
            os.replace(staged_target, active)
            activated = True
            self._fsync_directory()
            try:
                verified = self.verifier.verify(rollback_applied, now=now)
            except PolicyPostVerificationError as error:
                self._restore_original(staged_original, active)
                raise PolicyRollbackError(
                    "rollback_post_verification_failed",
                    data={"verification_code": error.code, **error.data},
                ) from error

            # Després d'un rollback satisfactori, l'antiga activa passa a ser la
            # candidata anterior. Això permet un rollback compensatori posterior.
            os.replace(staged_original, previous)
            self._fsync_directory()
            return RolledBackPolicy(
                previous_id,
                previous_revision,
                active,
                previous_digest,
                active_id,
                active_revision,
                verified,
            )
        except PolicyRollbackError:
            raise
        except OSError as error:
            if activated:
                try:
                    self._restore_original(staged_original, active)
                except PolicyRollbackError:
                    raise PolicyRollbackError("rollback_activation_and_restore_failed") from error
            raise PolicyRollbackError("rollback_activation_failed") from error
        finally:
            for path in (staged_target, staged_original):
                try:
                    path.unlink(missing_ok=True)
                except OSError:
                    pass

    def _restore_original(self, staged_original: Path, active: Path) -> None:
        try:
            os.replace(staged_original, active)
            self._fsync_directory()
        except OSError as error:
            raise PolicyRollbackError("rollback_restore_failed") from error

    def _validate_directory(self) -> None:
        if self.directory.is_symlink():
            raise PolicyRollbackError("rollback_directory_symlink")
        try:
            metadata = self.directory.stat()
        except OSError as error:
            raise PolicyRollbackError("rollback_directory_unavailable") from error
        if not stat.S_ISDIR(metadata.st_mode):
            raise PolicyRollbackError("rollback_directory_invalid")

    def _read_policy(self, path: Path, role: str) -> tuple[bytes, dict[str, Any]]:
        if path.is_symlink():
            raise PolicyRollbackError(f"rollback_{role}_policy_symlink")
        try:
            metadata = path.stat()
        except FileNotFoundError as error:
            raise PolicyRollbackError(f"rollback_{role}_policy_missing") from error
        except OSError as error:
            raise PolicyRollbackError(f"rollback_{role}_policy_unavailable") from error
        if not stat.S_ISREG(metadata.st_mode):
            raise PolicyRollbackError(f"rollback_{role}_policy_not_regular")
        if metadata.st_size <= 0 or metadata.st_size > self.max_bytes:
            raise PolicyRollbackError(f"rollback_{role}_policy_size_invalid")
        try:
            raw = path.read_bytes()
            document = json.loads(raw.decode("utf-8"))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
            raise PolicyRollbackError(f"rollback_{role}_policy_unreadable") from error
        if not isinstance(document, dict):
            raise PolicyRollbackError(f"rollback_{role}_policy_invalid")
        if not isinstance(document.get("sections"), dict):
            raise PolicyRollbackError(f"rollback_{role}_policy_sections_invalid")
        if not isinstance(document.get("application"), dict):
            raise PolicyRollbackError(f"rollback_{role}_policy_evidence_missing")
        return raw, document

    @staticmethod
    def _identity(document: Mapping[str, Any], role: str) -> tuple[str, int]:
        policy_id = document.get("policy_id")
        revision = document.get("revision")
        if not isinstance(policy_id, str) or not policy_id:
            raise PolicyRollbackError(f"rollback_{role}_policy_identity_invalid")
        if not isinstance(revision, int) or isinstance(revision, bool) or revision < 1:
            raise PolicyRollbackError(f"rollback_{role}_policy_identity_invalid")
        return policy_id, revision

    def _write_temp(self, data: bytes, *, prefix: str) -> Path:
        try:
            descriptor, name = tempfile.mkstemp(prefix=prefix, dir=self.directory)
            path = Path(name)
            with os.fdopen(descriptor, "wb") as stream:
                os.fchmod(stream.fileno(), 0o600)
                stream.write(data)
                stream.flush()
                os.fsync(stream.fileno())
            return path
        except OSError as error:
            raise PolicyRollbackError("rollback_staging_failed") from error

    def _fsync_directory(self) -> None:
        descriptor = os.open(self.directory, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)

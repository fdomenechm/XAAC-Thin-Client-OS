from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from xaac_agent.hardware_profile import HardwareProfile

_MAX_TEXT_BYTES = 4096
_MAX_DEVICES = 16
_SECTOR_BYTES = 512


def _read_text(path: Path) -> str | None:
    try:
        if path.is_symlink() or not path.is_file():
            return None
        with path.open("rb") as handle:
            raw = handle.read(_MAX_TEXT_BYTES + 1)
    except OSError:
        return None
    if len(raw) > _MAX_TEXT_BYTES:
        return None
    value = raw.decode("utf-8", errors="replace").strip()
    return value or None


def _read_non_negative_int(path: Path) -> int | None:
    value = _read_text(path)
    if value is None:
        return None
    try:
        parsed = int(value)
    except ValueError:
        return None
    return parsed if parsed >= 0 else None


@dataclass(frozen=True, slots=True)
class EmmcPolicy:
    profile_id: str
    write_warning_bytes_per_hour: int
    write_critical_bytes_per_hour: int
    recommend_volatile_runtime: bool
    recommend_batched_writes: bool

    @classmethod
    def for_profile(cls, profile: HardwareProfile) -> "EmmcPolicy":
        if profile.profile_id == "dell-wyse-3040":
            return cls(profile.profile_id, 256 * 1024 * 1024, 1024 * 1024 * 1024, True, True)
        return cls(profile.profile_id, 1024 * 1024 * 1024, 4 * 1024 * 1024 * 1024, False, False)


class EmmcMonitor:
    """Bounded eMMC telemetry with write-rate estimation.

    The monitor reads sysfs counters only. It never performs probe writes and it
    does not expose serial numbers, CID/CSD data or file-system contents.
    """

    def __init__(
        self,
        policy: EmmcPolicy,
        *,
        block_root: Path = Path("/sys/class/block"),
    ) -> None:
        self._policy = policy
        self._block_root = block_root
        self._previous: dict[str, tuple[int, float]] = {}

    def sample(self, *, monotonic_seconds: float | None = None) -> dict[str, object]:
        import time

        now = time.monotonic() if monotonic_seconds is None else float(monotonic_seconds)
        devices: list[dict[str, object]] = []
        highest = "normal"
        if self._block_root.is_dir() and not self._block_root.is_symlink():
            for path in sorted(self._block_root.glob("mmcblk*"), key=lambda item: item.name)[:_MAX_DEVICES]:
                if not path.name.removeprefix("mmcblk").isdigit() or path.is_symlink() or not path.is_dir():
                    continue
                device_type = (_read_text(path / "device" / "type") or "").lower()
                if device_type and device_type not in {"mmc", "sd"}:
                    continue
                sectors_written = self._written_sectors(path / "stat")
                entry: dict[str, object] = {"device": path.name, "kind": "emmc"}
                size_sectors = _read_non_negative_int(path / "size")
                if size_sectors is not None:
                    entry["capacity_bytes"] = size_sectors * _SECTOR_BYTES
                if sectors_written is not None:
                    total = sectors_written * _SECTOR_BYTES
                    entry["written_bytes_since_boot"] = total
                    previous = self._previous.get(path.name)
                    if previous is not None and now > previous[1] and total >= previous[0]:
                        rate = round((total - previous[0]) * 3600.0 / (now - previous[1]))
                        entry["estimated_write_bytes_per_hour"] = rate
                        severity = self._severity(rate)
                        entry["severity"] = severity
                        highest = self._max_severity(highest, severity)
                    self._previous[path.name] = (total, now)
                devices.append(entry)

        return {
            "profile_id": self._policy.profile_id,
            "severity": highest,
            "devices": devices,
            "device_count": len(devices),
            "recommendations": {
                "volatile_runtime_state": self._policy.recommend_volatile_runtime,
                "batched_persistent_writes": self._policy.recommend_batched_writes,
                "probe_writes_performed": False,
            },
        }

    @staticmethod
    def _written_sectors(path: Path) -> int | None:
        value = _read_text(path)
        if value is None:
            return None
        fields = value.split()
        if len(fields) < 7:
            return None
        try:
            sectors = int(fields[6])
        except ValueError:
            return None
        return sectors if sectors >= 0 else None

    def _severity(self, rate: int) -> str:
        if rate >= self._policy.write_critical_bytes_per_hour:
            return "critical"
        if rate >= self._policy.write_warning_bytes_per_hour:
            return "warning"
        return "normal"

    @staticmethod
    def _max_severity(left: str, right: str) -> str:
        rank = {"normal": 0, "warning": 1, "critical": 2}
        return right if rank[right] > rank[left] else left

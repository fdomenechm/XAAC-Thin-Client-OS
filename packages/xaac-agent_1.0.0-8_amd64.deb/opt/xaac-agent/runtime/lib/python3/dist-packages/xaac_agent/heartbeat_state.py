from __future__ import annotations

import json
import os
import tempfile
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Callable


class HeartbeatStateError(ValueError):
    """Persistent heartbeat state is invalid or unsafe."""


def read_boot_id(path: Path = Path('/proc/sys/kernel/random/boot_id')) -> str:
    try:
        value = path.read_text(encoding='ascii').strip()
        return str(uuid.UUID(value))
    except (OSError, ValueError):
        return 'unknown'


def read_uptime_seconds(path: Path = Path('/proc/uptime')) -> int:
    try:
        value = path.read_text(encoding='ascii').split()[0]
        return max(0, int(float(value)))
    except (OSError, ValueError, IndexError):
        return max(0, int(time.monotonic()))


@dataclass(frozen=True, slots=True)
class HeartbeatSequence:
    boot_id: str
    sequence: int


class HeartbeatSequenceStore:
    def __init__(self, path: Path, *, boot_id_provider: Callable[[], str] = read_boot_id) -> None:
        self.path = path
        self._boot_id_provider = boot_id_provider

    def next(self) -> HeartbeatSequence:
        boot_id = self._boot_id_provider()
        previous = self._load_optional()
        sequence = previous.sequence + 1 if previous and previous.boot_id == boot_id else 1
        current = HeartbeatSequence(boot_id=boot_id, sequence=sequence)
        self._save(current)
        return current

    def _load_optional(self) -> HeartbeatSequence | None:
        try:
            if self.path.is_symlink() or (self.path.exists() and not self.path.is_file()):
                raise HeartbeatStateError('heartbeat state path must be a regular file')
            raw = json.loads(self.path.read_text(encoding='utf-8'))
        except FileNotFoundError:
            return None
        except (OSError, json.JSONDecodeError) as error:
            raise HeartbeatStateError('heartbeat state is not readable JSON') from error
        if not isinstance(raw, dict) or raw.get('schema_version') != 1:
            raise HeartbeatStateError('unsupported heartbeat state schema')
        boot_id = raw.get('boot_id')
        sequence = raw.get('sequence')
        if not isinstance(boot_id, str) or not boot_id:
            raise HeartbeatStateError('invalid heartbeat boot_id')
        if not isinstance(sequence, int) or sequence < 1:
            raise HeartbeatStateError('invalid heartbeat sequence')
        return HeartbeatSequence(boot_id, sequence)

    def _save(self, state: HeartbeatSequence) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        descriptor, name = tempfile.mkstemp(prefix=f'.{self.path.name}.', dir=self.path.parent)
        temporary = Path(name)
        try:
            os.fchmod(descriptor, 0o600)
            with os.fdopen(descriptor, 'w', encoding='utf-8') as handle:
                json.dump({'schema_version': 1, 'boot_id': state.boot_id, 'sequence': state.sequence}, handle, sort_keys=True)
                handle.write('\n')
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, self.path)
        finally:
            temporary.unlink(missing_ok=True)

from __future__ import annotations

import hashlib
import os
import re
import stat
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable, Mapping

from xaac_agent.update_model import UpdateComponent, UpdateResult, UpdateState
from xaac_agent.update_trust import VerifiedUpdateArtifact

_PACKAGE_NAME = re.compile(r"^[a-z0-9][a-z0-9+.-]{0,127}$")
_VERSION = re.compile(r"^[0-9]+\.[0-9]+\.[0-9]+(?:[-+~][0-9A-Za-z.+:~-]+)?$")
_UNIT = re.compile(r"^[A-Za-z0-9_.@:-]{1,128}\.service$")


class ThinClientUpdateError(RuntimeError):
    def __init__(self, code: str, *, data: Mapping[str, object] | None = None) -> None:
        super().__init__(code)
        self.code = code
        self.data = dict(data or {})


@dataclass(frozen=True, slots=True)
class PackageMetadata:
    package: str
    version: str
    architecture: str


@dataclass(frozen=True, slots=True)
class ProtectedSnapshot:
    path: Path
    existed: bool
    content: bytes | None
    mode: int | None


Runner = Callable[..., subprocess.CompletedProcess[str]]


@dataclass(frozen=True, slots=True)
class ThinClientPackageInstaller:
    package_name: str = "xaac-thinclient"
    systemd_unit: str = "xaac-thin-client.service"
    dpkg_deb_path: Path = Path("/usr/bin/dpkg-deb")
    dpkg_path: Path = Path("/usr/bin/dpkg")
    systemctl_path: Path = Path("/usr/bin/systemctl")
    timeout_seconds: int = 180
    protected_paths: tuple[Path, ...] = ()
    runner: Runner = subprocess.run

    def __post_init__(self) -> None:
        if not _PACKAGE_NAME.fullmatch(self.package_name):
            raise ValueError("invalid_thin_client_package_name")
        if not _UNIT.fullmatch(self.systemd_unit):
            raise ValueError("invalid_thin_client_systemd_unit")
        if not 1 <= self.timeout_seconds <= 3600:
            raise ValueError("invalid_thin_client_update_timeout")
        for path in (self.dpkg_deb_path, self.dpkg_path, self.systemctl_path):
            if not path.is_absolute():
                raise ValueError("thin_client_update_tool_path_not_absolute")

    def install(self, verified: VerifiedUpdateArtifact) -> UpdateResult:
        plan = verified.plan
        if plan.component is not UpdateComponent.THIN_CLIENT:
            raise ThinClientUpdateError("thin_client_update_component_mismatch")
        if plan.artifact.media_type != "application/vnd.debian.binary-package":
            raise ThinClientUpdateError("thin_client_update_media_type_invalid")
        self._verify_artifact(verified)
        metadata = self._inspect(verified.path)
        if metadata.package != self.package_name:
            raise ThinClientUpdateError("thin_client_update_package_name_mismatch", data={"package": metadata.package})
        if metadata.version != plan.target_version:
            raise ThinClientUpdateError("thin_client_update_package_version_mismatch", data={"package_version": metadata.version})
        snapshots = tuple(self._snapshot(path) for path in self.protected_paths)
        was_active = self._is_active()
        stopped = False
        if was_active:
            self._service_action("stop")
            stopped = True
        try:
            completed = self.runner(
                [str(self.dpkg_path), "--install", "--force-confold", str(verified.path)],
                check=False, capture_output=True, text=True, timeout=self.timeout_seconds,
            )
        except subprocess.TimeoutExpired as error:
            self._restore_service(stopped)
            raise ThinClientUpdateError("thin_client_update_timeout") from error
        except OSError as error:
            self._restore_service(stopped)
            raise ThinClientUpdateError("thin_client_update_backend_error") from error
        if completed.returncode != 0:
            self._restore_service(stopped)
            raise ThinClientUpdateError("thin_client_update_install_failed", data={"return_code": completed.returncode, "error": self._clean_error(completed.stderr)})
        restored = self._restore_changed(snapshots)
        if was_active:
            self._service_action("start")
        state = UpdateState.REBOOT_PENDING if plan.reboot_required else UpdateState.INSTALLED
        return UpdateResult(plan.update_id, plan.component, plan.target_version, state, code="thin_client_update_installed", data={
            "package": metadata.package, "version": metadata.version, "architecture": metadata.architecture,
            "service_unit": self.systemd_unit, "service_was_active": was_active,
            "service_restarted": was_active, "reboot_required": plan.reboot_required,
            "protected_paths_restored": [str(path) for path in restored],
        })

    def _verify_artifact(self, verified: VerifiedUpdateArtifact) -> None:
        try:
            info = verified.path.lstat()
        except OSError as error:
            raise ThinClientUpdateError("thin_client_update_artifact_unavailable") from error
        if stat.S_ISLNK(info.st_mode):
            raise ThinClientUpdateError("thin_client_update_artifact_symlink")
        if not stat.S_ISREG(info.st_mode):
            raise ThinClientUpdateError("thin_client_update_artifact_not_regular")
        digest = hashlib.sha256(); size = 0
        try:
            with verified.path.open("rb") as stream:
                for chunk in iter(lambda: stream.read(65536), b""):
                    size += len(chunk); digest.update(chunk)
        except OSError as error:
            raise ThinClientUpdateError("thin_client_update_artifact_read_error") from error
        if size != verified.size_bytes:
            raise ThinClientUpdateError("thin_client_update_artifact_size_mismatch")
        if digest.hexdigest() != verified.artifact_sha256:
            raise ThinClientUpdateError("thin_client_update_artifact_digest_mismatch")

    def _inspect(self, path: Path) -> PackageMetadata:
        try:
            completed = self.runner([str(self.dpkg_deb_path), "--field", str(path), "Package", "Version", "Architecture"], check=False, capture_output=True, text=True, timeout=min(self.timeout_seconds, 30))
        except subprocess.TimeoutExpired as error:
            raise ThinClientUpdateError("thin_client_update_inspection_timeout") from error
        except OSError as error:
            raise ThinClientUpdateError("thin_client_update_backend_error") from error
        if completed.returncode != 0:
            raise ThinClientUpdateError("thin_client_update_package_invalid", data={"error": self._clean_error(completed.stderr)})
        values = [line.strip() for line in completed.stdout.splitlines() if line.strip()]
        if len(values) != 3 or not _PACKAGE_NAME.fullmatch(values[0]) or not _VERSION.fullmatch(values[1]) or len(values[2]) > 64:
            raise ThinClientUpdateError("thin_client_update_package_metadata_invalid")
        return PackageMetadata(*values)

    def _is_active(self) -> bool:
        try:
            completed = self.runner([str(self.systemctl_path), "is-active", "--quiet", self.systemd_unit], check=False, capture_output=True, text=True, timeout=min(self.timeout_seconds, 30))
        except subprocess.TimeoutExpired as error:
            raise ThinClientUpdateError("thin_client_update_service_status_timeout") from error
        except OSError as error:
            raise ThinClientUpdateError("thin_client_update_backend_error") from error
        return completed.returncode == 0

    def _service_action(self, action: str) -> None:
        try:
            completed = self.runner([str(self.systemctl_path), action, self.systemd_unit], check=False, capture_output=True, text=True, timeout=min(self.timeout_seconds, 60))
        except subprocess.TimeoutExpired as error:
            raise ThinClientUpdateError(f"thin_client_update_service_{action}_timeout") from error
        except OSError as error:
            raise ThinClientUpdateError("thin_client_update_backend_error") from error
        if completed.returncode != 0:
            raise ThinClientUpdateError(f"thin_client_update_service_{action}_failed", data={"error": self._clean_error(completed.stderr)})

    def _restore_service(self, stopped: bool) -> None:
        if stopped:
            try:
                self._service_action("start")
            except ThinClientUpdateError:
                pass

    @staticmethod
    def _snapshot(path: Path) -> ProtectedSnapshot:
        try:
            info = path.lstat()
        except FileNotFoundError:
            return ProtectedSnapshot(path, False, None, None)
        except OSError as error:
            raise ThinClientUpdateError("thin_client_update_protected_path_unavailable", data={"path": str(path)}) from error
        if stat.S_ISLNK(info.st_mode) or not stat.S_ISREG(info.st_mode):
            raise ThinClientUpdateError("thin_client_update_protected_path_unsafe", data={"path": str(path)})
        return ProtectedSnapshot(path, True, path.read_bytes(), stat.S_IMODE(info.st_mode))

    def _restore_changed(self, snapshots: Iterable[ProtectedSnapshot]) -> tuple[Path, ...]:
        restored: list[Path] = []
        for snapshot in snapshots:
            exists = snapshot.path.exists()
            current = snapshot.path.read_bytes() if exists and snapshot.path.is_file() else None
            if snapshot.existed and current != snapshot.content:
                self._atomic_write(snapshot.path, snapshot.content or b"", snapshot.mode or 0o600); restored.append(snapshot.path)
            elif not snapshot.existed and exists:
                if snapshot.path.is_symlink() or not snapshot.path.is_file():
                    raise ThinClientUpdateError("thin_client_update_protected_path_unsafe", data={"path": str(snapshot.path)})
                snapshot.path.unlink(); restored.append(snapshot.path)
        return tuple(restored)

    @staticmethod
    def _atomic_write(path: Path, content: bytes, mode: int) -> None:
        path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        descriptor, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
        try:
            os.fchmod(descriptor, mode)
            with os.fdopen(descriptor, "wb") as stream:
                stream.write(content); stream.flush(); os.fsync(stream.fileno())
            os.replace(temporary, path)
            fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
            try: os.fsync(fd)
            finally: os.close(fd)
        finally:
            if os.path.exists(temporary): os.unlink(temporary)

    @staticmethod
    def _clean_error(value: str) -> str:
        return " ".join((value or "").replace("\x00", "").split())[:512]

from __future__ import annotations

import json
import os
import tempfile
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _atomic_json_write(path: Path, payload: dict[str, Any], mode: int = 0o600) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temporary = Path(temporary_name)
    try:
        os.fchmod(descriptor, mode)
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=False, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


@dataclass(slots=True)
class HealthState:
    status: str
    pid: int
    started_at: str
    updated_at: str
    last_progress_at: str | None = None
    last_successful_heartbeat_at: str | None = None
    consecutive_heartbeat_failures: int = 0
    restart_required_fields: tuple[str, ...] = ()


class HealthStateStore:
    def __init__(self, path: Path, *, pid: int | None = None) -> None:
        now = _utc_now()
        self.path = path
        self.state = HealthState(
            status="starting",
            pid=os.getpid() if pid is None else pid,
            started_at=now,
            updated_at=now,
        )

    def update(self, **changes: Any) -> None:
        for name, value in changes.items():
            if not hasattr(self.state, name):
                raise AttributeError(name)
            setattr(self.state, name, value)
        self.state.updated_at = _utc_now()
        _atomic_json_write(self.path, asdict(self.state))

    def mark_progress(self) -> None:
        self.update(last_progress_at=_utc_now())

    def mark_heartbeat(self, success: bool) -> None:
        if success:
            self.update(
                last_successful_heartbeat_at=_utc_now(),
                consecutive_heartbeat_failures=0,
            )
        else:
            self.update(
                consecutive_heartbeat_failures=self.state.consecutive_heartbeat_failures + 1
            )


class LastFailureStore:
    def __init__(self, path: Path) -> None:
        self.path = path

    def record(self, reason: str, detail: str = "") -> None:
        _atomic_json_write(
            self.path,
            {
                "reason": reason,
                "detail": detail,
                "recorded_at": _utc_now(),
                "pid": os.getpid(),
            },
        )

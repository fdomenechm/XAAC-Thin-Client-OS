from __future__ import annotations

import base64
import hashlib
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from xaac_agent.update_cache import CachedUpdateArtifact
from xaac_agent.update_model import UpdateComponent, UpdatePlan, UpdateResult, UpdateState, UpdateValidationError

_KEY_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$")


class UpdateTrustError(ValueError):
    def __init__(self, code: str) -> None:
        super().__init__(code)
        self.code = code


@dataclass(frozen=True, slots=True)
class UpdateTrustAnchor:
    key_id: str
    public_key: Ed25519PublicKey
    issuer_id: str | None = None


def parse_trusted_update_keys(values: tuple[str, ...]) -> dict[str, UpdateTrustAnchor]:
    anchors: dict[str, UpdateTrustAnchor] = {}
    for value in values:
        subject, separator, encoded = value.partition("=")
        if not separator or not subject.strip() or not encoded.strip():
            raise ValueError(f"invalid_update_key_definition:{value}")
        key_id, issuer_separator, issuer_id = subject.strip().partition("@")
        if not _KEY_ID.fullmatch(key_id):
            raise ValueError(f"invalid_update_key_id:{key_id}")
        if issuer_separator and (not issuer_id.strip() or len(issuer_id.strip()) > 256):
            raise ValueError(f"invalid_update_key_issuer:{key_id}")
        if key_id in anchors:
            raise ValueError(f"duplicate_update_key_id:{key_id}")
        try:
            raw = base64.b64decode(encoded.strip(), validate=True)
            key = Ed25519PublicKey.from_public_bytes(raw)
        except (TypeError, ValueError) as error:
            raise ValueError(f"invalid_update_public_key:{key_id}") from error
        anchors[key_id] = UpdateTrustAnchor(key_id, key, issuer_id.strip() if issuer_separator else None)
    return anchors


def canonical_update_bytes(plan: UpdatePlan) -> bytes:
    return json.dumps(
        plan.to_payload(), sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False
    ).encode("utf-8")


@dataclass(frozen=True, slots=True)
class VerifiedUpdateArtifact:
    plan: UpdatePlan
    path: Path
    key_id: str
    algorithm: str
    plan_sha256: str
    artifact_sha256: str
    size_bytes: int

    @property
    def state(self) -> UpdateState:
        return UpdateState.VERIFIED

    def to_result(self) -> UpdateResult:
        return UpdateResult(
            self.plan.update_id,
            self.plan.component,
            self.plan.target_version,
            UpdateState.VERIFIED,
            code="update_signature_verified",
            data={
                "algorithm": self.algorithm,
                "key_id": self.key_id,
                "plan_sha256": self.plan_sha256,
                "artifact_sha256": self.artifact_sha256,
                "size_bytes": self.size_bytes,
                "filename": self.path.name,
            },
        )


@dataclass(frozen=True, slots=True)
class UpdateTrustVerifier:
    trusted_keys: Mapping[str, UpdateTrustAnchor]
    allowed_issuer_kinds: tuple[str, ...] = ("xms",)
    allowed_components: tuple[UpdateComponent, ...] = tuple(UpdateComponent)
    require_signature: bool = True

    def verify(self, document: Mapping[str, Any], cached: CachedUpdateArtifact) -> VerifiedUpdateArtifact:
        if not isinstance(document, Mapping):
            raise UpdateTrustError("invalid_update_document")
        try:
            plan = UpdatePlan.from_payload(document)
        except UpdateValidationError as error:
            raise UpdateTrustError(error.code) from error
        if plan.identity != cached.plan.identity:
            raise UpdateTrustError("cached_update_identity_mismatch")
        if plan.artifact.sha256 != cached.sha256 or plan.artifact.size != cached.size_bytes:
            raise UpdateTrustError("cached_update_artifact_mismatch")
        if plan.issuer.kind not in self.allowed_issuer_kinds:
            raise UpdateTrustError("update_issuer_kind_untrusted")
        if plan.component not in self.allowed_components:
            raise UpdateTrustError("update_component_untrusted")
        signature = document.get("signature")
        if signature is None and not self.require_signature:
            raise UpdateTrustError("unsigned_update_not_verifiable")
        if not isinstance(signature, Mapping):
            raise UpdateTrustError("missing_update_signature" if signature is None else "invalid_update_signature")
        if set(signature) - {"algorithm", "key_id", "value"}:
            raise UpdateTrustError("unknown_update_signature_field")
        algorithm, key_id, encoded = signature.get("algorithm"), signature.get("key_id"), signature.get("value")
        if algorithm != "Ed25519":
            raise UpdateTrustError("unsupported_update_signature_algorithm")
        if not isinstance(key_id, str) or not _KEY_ID.fullmatch(key_id.strip()):
            raise UpdateTrustError("invalid_update_signature_key_id")
        if not isinstance(encoded, str) or not encoded.strip():
            raise UpdateTrustError("invalid_update_signature_value")
        anchor = self.trusted_keys.get(key_id.strip())
        if anchor is None:
            raise UpdateTrustError("update_signing_key_untrusted")
        if anchor.issuer_id is not None and anchor.issuer_id != plan.issuer.issuer_id:
            raise UpdateTrustError("update_signing_key_issuer_mismatch")
        try:
            raw_signature = base64.b64decode(encoded.strip(), validate=True)
        except (TypeError, ValueError) as error:
            raise UpdateTrustError("invalid_update_signature_encoding") from error
        if len(raw_signature) != 64:
            raise UpdateTrustError("invalid_update_signature_length")
        canonical = canonical_update_bytes(plan)
        try:
            anchor.public_key.verify(raw_signature, canonical)
        except InvalidSignature as error:
            raise UpdateTrustError("update_signature_invalid") from error
        return VerifiedUpdateArtifact(
            plan, cached.path, anchor.key_id, "Ed25519", hashlib.sha256(canonical).hexdigest(), cached.sha256, cached.size_bytes
        )

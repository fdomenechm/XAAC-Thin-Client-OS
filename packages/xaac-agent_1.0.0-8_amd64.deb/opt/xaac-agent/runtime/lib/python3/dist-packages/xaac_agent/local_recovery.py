from __future__ import annotations

import argparse
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from xaac_agent.config import AgentConfigurationError, AgentSettings
from xaac_agent.local_audit import LocalAuditJournal
from xaac_agent.safe_mode import SafeModeError, SafeModeState, SafeModeStore
from xaac_agent.thin_client_configuration import (
    ThinClientConfigurationDistributor,
    ThinClientConfigurationError,
)
from xaac_agent.thin_client_contract import ContractOperation, ThinClientIntegrationContract


class LocalRecoveryError(RuntimeError):
    """A local recovery operation was denied or could not be completed safely."""


@dataclass(frozen=True, slots=True)
class LocalRecoveryStatus:
    safe_mode: SafeModeState
    known_good_configuration_available: bool
    active_configuration_available: bool

    def to_payload(self) -> dict[str, object]:
        return {
            "schema_version": 1,
            "safe_mode": self.safe_mode.to_payload(),
            "known_good_configuration_available": self.known_good_configuration_available,
            "active_configuration_available": self.active_configuration_available,
        }


class LocalRecoveryManager:
    """Root-only, offline recovery surface with a narrow auditable operation set."""

    def __init__(
        self,
        settings: AgentSettings,
        *,
        effective_uid: Callable[[], int] = os.geteuid,
    ) -> None:
        self.settings = settings
        self._effective_uid = effective_uid
        self.safe_mode = SafeModeStore(settings.safe_mode_state_file)
        self.audit = LocalAuditJournal(
            settings.local_audit_file,
            max_records=settings.local_audit_max_records,
            max_bytes=settings.local_audit_max_bytes,
        )
        contract = ThinClientIntegrationContract.build(
            runtime_root=settings.thin_client_runtime_directory,
            state_root=settings.thin_client_state_directory,
            config_root=settings.thin_client_config_directory,
            command_root=settings.thin_client_command_directory,
            agent_user=settings.command_agent_user,
            thin_client_user=settings.thin_client_user,
            shared_group=settings.thin_client_shared_group,
            allowed_operations=(
                ContractOperation.READ_CONFIG,
                ContractOperation.STAGE_CONFIG,
                ContractOperation.ACK_CONFIG,
            ),
        )
        self.configuration = ThinClientConfigurationDistributor(
            contract=contract,
            max_bytes=settings.thin_client_configuration_max_bytes,
        )

    def status(self) -> LocalRecoveryStatus:
        self._authorize()
        return LocalRecoveryStatus(
            safe_mode=self.safe_mode.load(),
            known_good_configuration_available=self._regular_file_exists(self.configuration.known_good_path),
            active_configuration_available=self._regular_file_exists(self.configuration.active_path),
        )

    def enter_safe_mode(self, *, reason: str, detail: str | None = None) -> SafeModeState:
        self._authorize()
        try:
            state = self.safe_mode.enter(reason, detail)
            self._audit("local_recovery_enter_safe_mode", subject=reason)
            return state
        except Exception:
            self._audit_failure("local_recovery_enter_safe_mode", subject=reason)
            raise

    def clear_safe_mode(self, *, expected_reason: str | None = None) -> SafeModeState:
        self._authorize()
        try:
            state = self.safe_mode.clear(expected_reason=expected_reason)
            self._audit("local_recovery_clear_safe_mode", subject=expected_reason or "any")
            return state
        except Exception:
            self._audit_failure("local_recovery_clear_safe_mode", subject=expected_reason or "any")
            raise

    def restore_known_good_configuration(
        self,
        *,
        expected_configuration_id: str | None = None,
        minimum_revision: int | None = None,
    ) -> dict[str, object]:
        self._authorize()
        try:
            result = self.configuration.restore_known_good(
                expected_configuration_id=expected_configuration_id,
                minimum_revision=minimum_revision,
            )
            payload = result.to_payload()
            self._audit(
                "local_recovery_restore_configuration",
                subject=result.configuration_id,
                fields={"revision": result.revision, "sha256": result.sha256},
            )
            return payload
        except Exception:
            self._audit_failure(
                "local_recovery_restore_configuration",
                subject=expected_configuration_id or "known-good",
            )
            raise

    def _authorize(self) -> None:
        if self._effective_uid() != 0:
            raise LocalRecoveryError("local recovery requires root privileges")

    @staticmethod
    def _regular_file_exists(path: Path) -> bool:
        return path.exists() and path.is_file() and not path.is_symlink()

    def _audit(self, event: str, *, subject: str, fields: dict[str, object] | None = None) -> None:
        if self.settings.local_audit_enabled:
            self.audit.append(event, actor="local-root", subject=subject, fields=fields)

    def _audit_failure(self, event: str, *, subject: str) -> None:
        if self.settings.local_audit_enabled:
            self.audit.append(event, actor="local-root", outcome="failure", subject=subject)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="XAAC Agent local recovery utility")
    parser.add_argument("--config", type=Path, default=Path("/etc/xaac-agent/agent.ini"))
    subparsers = parser.add_subparsers(dest="operation", required=True)

    subparsers.add_parser("status", help="show safe-mode and configuration recovery status")

    enter = subparsers.add_parser("enter-safe-mode", help="enter persistent safe mode")
    enter.add_argument("--reason", required=True)
    enter.add_argument("--detail")

    clear = subparsers.add_parser("clear-safe-mode", help="clear persistent safe mode")
    clear.add_argument("--expected-reason")

    restore = subparsers.add_parser("restore-configuration", help="restore last known-good Thin Client configuration")
    restore.add_argument("--expected-configuration-id")
    restore.add_argument("--minimum-revision", type=int)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    try:
        settings = AgentSettings.load(args.config)
        manager = LocalRecoveryManager(settings)
        if args.operation == "status":
            payload = manager.status().to_payload()
        elif args.operation == "enter-safe-mode":
            payload = manager.enter_safe_mode(reason=args.reason, detail=args.detail).to_payload()
        elif args.operation == "clear-safe-mode":
            payload = manager.clear_safe_mode(expected_reason=args.expected_reason).to_payload()
        else:
            payload = manager.restore_known_good_configuration(
                expected_configuration_id=args.expected_configuration_id,
                minimum_revision=args.minimum_revision,
            )
        print(json.dumps(payload, ensure_ascii=False, sort_keys=True))
        return 0
    except (AgentConfigurationError, LocalRecoveryError, SafeModeError, ThinClientConfigurationError) as error:
        print(json.dumps({"error": str(error)}, ensure_ascii=False, sort_keys=True))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

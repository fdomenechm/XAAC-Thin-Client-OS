from __future__ import annotations

import json
import os
import stat
import uuid
from dataclasses import dataclass
from pathlib import Path
from tempfile import NamedTemporaryFile


IDENTITY_SCHEMA_VERSION = 1


class DeviceIdentityError(RuntimeError):
    """Base error for persistent device identity operations."""


class InvalidDeviceIdentityError(DeviceIdentityError):
    """Raised when an existing identity cannot be trusted or parsed."""


@dataclass(frozen=True, slots=True)
class DeviceIdentity:
    """Logical identity assigned locally to this XAAC Agent installation."""

    device_id: str
    schema_version: int = IDENTITY_SCHEMA_VERSION

    def __post_init__(self) -> None:
        parsed = _parse_device_uuid(self.device_id)
        object.__setattr__(self, "device_id", str(parsed))
        if self.schema_version != IDENTITY_SCHEMA_VERSION:
            raise InvalidDeviceIdentityError(
                f"unsupported identity schema version: {self.schema_version}"
            )

    def to_payload(self) -> dict[str, object]:
        return {
            "schema_version": self.schema_version,
            "identity_kind": "logical",
            "device_id": self.device_id,
        }


class DeviceIdentityStore:
    """Load or atomically create the persistent logical device identity.

    Existing invalid identities are never silently replaced because doing so
    would make XMS see the same physical endpoint as a different device.
    """

    def __init__(self, path: Path) -> None:
        self._path = path

    def load_or_create(self) -> DeviceIdentity:
        try:
            return self.load()
        except FileNotFoundError:
            identity = DeviceIdentity(device_id=str(uuid.uuid4()))
            return self._create_exclusively(identity)

    def load(self) -> DeviceIdentity:
        self._validate_path()
        try:
            raw = self._path.read_text(encoding="utf-8")
        except FileNotFoundError:
            raise
        except OSError as error:
            raise InvalidDeviceIdentityError(
                f"cannot read identity file {self._path}: {error}"
            ) from error

        try:
            payload = json.loads(raw)
        except json.JSONDecodeError as error:
            raise InvalidDeviceIdentityError(
                f"identity file is not valid JSON: {self._path}"
            ) from error
        if not isinstance(payload, dict):
            raise InvalidDeviceIdentityError("identity payload must be an object")

        schema_version = payload.get("schema_version")
        if schema_version != IDENTITY_SCHEMA_VERSION:
            raise InvalidDeviceIdentityError(
                f"unsupported identity schema version: {schema_version!r}"
            )
        identity_kind = payload.get("identity_kind", "logical")
        if identity_kind != "logical":
            raise InvalidDeviceIdentityError(
                f"unsupported identity kind: {identity_kind!r}"
            )
        device_id = payload.get("device_id")
        if not isinstance(device_id, str):
            raise InvalidDeviceIdentityError("device_id must be a string")

        identity = DeviceIdentity(device_id=device_id, schema_version=schema_version)
        self._ensure_private_permissions()
        return identity

    def _create_exclusively(self, identity: DeviceIdentity) -> DeviceIdentity:
        self._prepare_parent_directory()
        temporary_name: str | None = None
        try:
            with NamedTemporaryFile(
                "w",
                encoding="utf-8",
                dir=self._path.parent,
                prefix=".identity-",
                suffix=".tmp",
                delete=False,
            ) as handle:
                temporary_name = handle.name
                json.dump(
                    identity.to_payload(),
                    handle,
                    sort_keys=True,
                    separators=(",", ":"),
                )
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.chmod(temporary_name, 0o600)

            try:
                os.link(temporary_name, self._path)
            except FileExistsError:
                # Another process won the creation race. Never overwrite it.
                return self.load()
            except OSError as error:
                raise InvalidDeviceIdentityError(
                    f"cannot create identity file {self._path}: {error}"
                ) from error

            self._fsync_directory(self._path.parent)
            self._ensure_private_permissions()
            return identity
        finally:
            if temporary_name and os.path.exists(temporary_name):
                os.unlink(temporary_name)

    def _validate_path(self) -> None:
        try:
            metadata = self._path.lstat()
        except FileNotFoundError:
            raise
        except OSError as error:
            raise InvalidDeviceIdentityError(
                f"cannot inspect identity file {self._path}: {error}"
            ) from error
        if stat.S_ISLNK(metadata.st_mode):
            raise InvalidDeviceIdentityError("identity file must not be a symbolic link")
        if not stat.S_ISREG(metadata.st_mode):
            raise InvalidDeviceIdentityError("identity path must be a regular file")

    def _prepare_parent_directory(self) -> None:
        try:
            self._path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            if self._path.parent.is_symlink():
                raise InvalidDeviceIdentityError(
                    "identity parent directory must not be a symbolic link"
                )
            if not self._path.parent.is_dir():
                raise InvalidDeviceIdentityError(
                    "identity parent path must be a directory"
                )
        except DeviceIdentityError:
            raise
        except OSError as error:
            raise InvalidDeviceIdentityError(
                f"cannot prepare identity directory {self._path.parent}: {error}"
            ) from error

    def _ensure_private_permissions(self) -> None:
        try:
            mode = stat.S_IMODE(self._path.stat().st_mode)
            if mode != 0o600:
                os.chmod(self._path, 0o600)
        except OSError as error:
            raise InvalidDeviceIdentityError(
                f"cannot enforce identity permissions on {self._path}: {error}"
            ) from error

    @staticmethod
    def _fsync_directory(path: Path) -> None:
        flags = os.O_RDONLY
        if hasattr(os, "O_DIRECTORY"):
            flags |= os.O_DIRECTORY
        descriptor = os.open(path, flags)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)


def _parse_device_uuid(value: str) -> uuid.UUID:
    try:
        parsed = uuid.UUID(value)
    except (ValueError, AttributeError) as error:
        raise InvalidDeviceIdentityError("device_id is not a valid UUID") from error
    if parsed.int == 0:
        raise InvalidDeviceIdentityError("device_id must not be the nil UUID")
    return parsed

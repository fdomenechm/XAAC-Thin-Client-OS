from __future__ import annotations

import copy
import json
import os
import re
import stat
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from .policy_model import PolicyResult, PolicyState
from .policy_schema import ValidatedPolicy


class PolicyConflictError(ValueError):
    """La política local no permet resoldre de manera segura els conflictes."""

    def __init__(self, code: str) -> None:
        super().__init__(code)
        self.code = code


_PATH_PART = re.compile(r"^[a-z][a-z0-9_-]{0,63}$")
_MAX_LOCAL_BYTES = 1024 * 1024


def parse_protected_paths(values: tuple[str, ...] | list[str]) -> tuple[str, ...]:
    paths: set[str] = set()
    for raw in values:
        if not isinstance(raw, str):
            raise PolicyConflictError("invalid_protected_policy_path")
        value = raw.strip().lower()
        parts = value.split(".")
        if len(parts) < 2 or any(not _PATH_PART.fullmatch(part) for part in parts):
            raise PolicyConflictError("invalid_protected_policy_path")
        paths.add(value)
    return tuple(sorted(paths))


def _validate_local_value(value: Any, *, depth: int = 0) -> None:
    if depth > 10:
        raise PolicyConflictError("local_policy_too_deep")
    if value is None or isinstance(value, (bool, int, str)):
        return
    if isinstance(value, float):
        if value != value or value in (float("inf"), float("-inf")):
            raise PolicyConflictError("invalid_local_policy_value")
        return
    if isinstance(value, list):
        if len(value) > 256:
            raise PolicyConflictError("local_policy_list_too_large")
        for item in value:
            _validate_local_value(item, depth=depth + 1)
        return
    if isinstance(value, dict):
        if len(value) > 128:
            raise PolicyConflictError("local_policy_mapping_too_large")
        for key, item in value.items():
            if not isinstance(key, str) or not _PATH_PART.fullmatch(key):
                raise PolicyConflictError("invalid_local_policy_key")
            _validate_local_value(item, depth=depth + 1)
        return
    raise PolicyConflictError("invalid_local_policy_value")


def load_local_policy_overlay(path: Path, *, max_bytes: int = _MAX_LOCAL_BYTES) -> dict[str, Any]:
    if path.is_symlink():
        raise PolicyConflictError("local_policy_symlink")
    if not path.exists():
        return {}
    try:
        info = path.stat()
        if not stat.S_ISREG(info.st_mode):
            raise PolicyConflictError("local_policy_not_regular")
        if info.st_size > max_bytes:
            raise PolicyConflictError("local_policy_too_large")
        raw = path.read_bytes()
        value = json.loads(raw.decode("utf-8"))
    except PolicyConflictError:
        raise
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
        raise PolicyConflictError("local_policy_unreadable") from error
    if not isinstance(value, dict):
        raise PolicyConflictError("invalid_local_policy")
    sections = value.get("sections", value)
    if not isinstance(sections, dict):
        raise PolicyConflictError("invalid_local_policy_sections")
    _validate_local_value(sections)
    return copy.deepcopy(sections)


def _lookup(root: Mapping[str, Any], parts: tuple[str, ...]) -> tuple[bool, Any]:
    current: Any = root
    for part in parts:
        if not isinstance(current, Mapping) or part not in current:
            return False, None
        current = current[part]
    return True, current


def _set(root: dict[str, Any], parts: tuple[str, ...], value: Any) -> None:
    current = root
    for part in parts[:-1]:
        child = current.get(part)
        if not isinstance(child, dict):
            child = {}
            current[part] = child
        current = child
    current[parts[-1]] = copy.deepcopy(value)


def _remove(root: dict[str, Any], parts: tuple[str, ...]) -> bool:
    current: Any = root
    parents: list[tuple[dict[str, Any], str]] = []
    for part in parts[:-1]:
        if not isinstance(current, dict) or part not in current:
            return False
        parents.append((current, part))
        current = current[part]
    if not isinstance(current, dict) or parts[-1] not in current:
        return False
    del current[parts[-1]]
    for parent, key in reversed(parents):
        child = parent.get(key)
        if isinstance(child, dict) and not child:
            del parent[key]
        else:
            break
    return True


@dataclass(frozen=True, slots=True)
class PolicyConflict:
    path: str
    resolution: str
    remote_present: bool
    local_present: bool

    def to_payload(self) -> dict[str, object]:
        return {
            "path": self.path,
            "resolution": self.resolution,
            "remote_present": self.remote_present,
            "local_present": self.local_present,
        }


@dataclass(frozen=True, slots=True)
class ConflictResolvedPolicy:
    policy: Any
    schema_id: str
    schema_revision: int
    normalized_sections: dict[str, Any]
    conflicts: tuple[PolicyConflict, ...]

    def to_result(self) -> PolicyResult:
        return PolicyResult(
            self.policy.policy_id,
            self.policy.revision,
            PolicyState.VALIDATED,
            code="policy_conflicts_resolved",
            data={
                "conflict_count": len(self.conflicts),
                "conflicts": [item.to_payload() for item in self.conflicts],
            },
        )


@dataclass(frozen=True, slots=True)
class PolicyConflictResolver:
    protected_paths: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(self, "protected_paths", parse_protected_paths(self.protected_paths))

    def resolve(
        self,
        validated: ValidatedPolicy,
        local_sections: Mapping[str, Any] | None = None,
    ) -> ConflictResolvedPolicy:
        local = dict(local_sections or {})
        _validate_local_value(local)
        resolved = copy.deepcopy(validated.normalized_sections)
        conflicts: list[PolicyConflict] = []

        for path in self.protected_paths:
            parts = tuple(path.split("."))
            remote_present, _ = _lookup(resolved, parts)
            local_present, local_value = _lookup(local, parts)
            if local_present:
                _set(resolved, parts, local_value)
                resolution = "local-value"
            else:
                _remove(resolved, parts)
                resolution = "remote-value-removed"
            if remote_present or local_present:
                conflicts.append(PolicyConflict(path, resolution, remote_present, local_present))

        return ConflictResolvedPolicy(
            policy=validated.policy,
            schema_id=validated.schema_id,
            schema_revision=validated.schema_revision,
            normalized_sections=resolved,
            conflicts=tuple(conflicts),
        )

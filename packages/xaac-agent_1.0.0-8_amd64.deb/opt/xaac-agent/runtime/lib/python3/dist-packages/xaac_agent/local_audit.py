from __future__ import annotations

import hashlib
import json
import os
import stat
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

from .secrets import redact_text


class LocalAuditError(RuntimeError):
    """El registre local d'auditoria és invàlid o insegur."""


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _canonical(value: Mapping[str, Any]) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _clean_text(value: str, field: str, *, maximum: int = 256) -> str:
    if not isinstance(value, str) or not value.strip():
        raise LocalAuditError(f"{field} és obligatori")
    cleaned = redact_text(value.strip())[:maximum]
    if any(ord(char) < 32 for char in cleaned):
        raise LocalAuditError(f"{field} conté caràcters de control")
    return cleaned


def _safe_fields(fields: Mapping[str, Any] | None) -> dict[str, Any]:
    if not fields:
        return {}
    if len(fields) > 16:
        raise LocalAuditError("massa camps d'auditoria")
    result: dict[str, Any] = {}
    for key, value in sorted(fields.items()):
        clean_key = _clean_text(str(key), "nom del camp", maximum=64)
        sensitive_key = any(token in clean_key.lower() for token in ("authorization", "password", "passwd", "secret", "token", "api_key", "apikey", "credential"))
        if sensitive_key:
            result[clean_key] = "[REDACTED]"
        elif isinstance(value, str):
            result[clean_key] = redact_text(value)[:512]
        elif isinstance(value, (int, float, bool)) or value is None:
            result[clean_key] = value
        else:
            result[clean_key] = redact_text(str(value))[:512]
    return result


class LocalAuditJournal:
    """Auditoria local acotada i encadenada amb una àncora de retenció."""

    SCHEMA_VERSION = 1
    GENESIS_HASH = "0" * 64

    def __init__(self, path: Path, *, max_records: int = 2048, max_bytes: int = 2 * 1024 * 1024) -> None:
        self.path = path
        self.max_records = max_records
        self.max_bytes = max_bytes
        if not 32 <= max_records <= 100000:
            raise LocalAuditError("max_records fora de rang")
        if not 65536 <= max_bytes <= 64 * 1024 * 1024:
            raise LocalAuditError("max_bytes fora de rang")

    def append(
        self,
        event: str,
        *,
        actor: str = "xaac-agent",
        outcome: str = "success",
        subject: str | None = None,
        fields: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        payload = self._load()
        records = payload["records"]
        previous = records[-1]["hash"] if records else payload["anchor_hash"]
        sequence = int(payload["last_sequence"]) + 1
        record: dict[str, Any] = {
            "sequence": sequence,
            "recorded_at": _utc_now(),
            "event": _clean_text(event, "event"),
            "actor": _clean_text(actor, "actor"),
            "outcome": _clean_text(outcome, "outcome", maximum=64),
            "previous_hash": previous,
        }
        if subject is not None:
            record["subject"] = _clean_text(subject, "subject", maximum=256)
        safe = _safe_fields(fields)
        if safe:
            record["fields"] = safe
        record["hash"] = hashlib.sha256(_canonical(record)).hexdigest()
        records.append(record)
        payload["last_sequence"] = sequence
        self._trim(payload)
        self._write(payload)
        return dict(record)

    def records(self) -> list[dict[str, Any]]:
        return [dict(record) for record in self._load()["records"]]

    def verify(self) -> bool:
        payload = self._load()
        previous = payload["anchor_hash"]
        last_sequence = 0
        for record in payload["records"]:
            if not isinstance(record, dict):
                return False
            sequence = record.get("sequence")
            if not isinstance(sequence, int) or sequence <= last_sequence:
                return False
            if record.get("previous_hash") != previous:
                return False
            claimed = record.get("hash")
            content = {key: value for key, value in record.items() if key != "hash"}
            if claimed != hashlib.sha256(_canonical(content)).hexdigest():
                return False
            previous = str(claimed)
            last_sequence = sequence
        return not payload["records"] or payload["last_sequence"] >= last_sequence

    def _empty(self) -> dict[str, Any]:
        return {"schema_version": self.SCHEMA_VERSION, "anchor_hash": self.GENESIS_HASH, "last_sequence": 0, "records": []}

    def _load(self) -> dict[str, Any]:
        if not self.path.exists():
            return self._empty()
        info = self.path.lstat()
        if stat.S_ISLNK(info.st_mode) or not stat.S_ISREG(info.st_mode):
            raise LocalAuditError("l'auditoria ha de ser un fitxer regular")
        if info.st_size > self.max_bytes:
            raise LocalAuditError("l'auditoria supera el límit de mida")
        try:
            payload = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
            raise LocalAuditError("auditoria no llegible o JSON invàlid") from error
        if not isinstance(payload, dict) or payload.get("schema_version") != self.SCHEMA_VERSION:
            raise LocalAuditError("esquema d'auditoria no compatible")
        if not isinstance(payload.get("records"), list) or len(payload["records"]) > self.max_records:
            raise LocalAuditError("registres d'auditoria invàlids")
        if not isinstance(payload.get("anchor_hash"), str) or len(payload["anchor_hash"]) != 64:
            raise LocalAuditError("àncora d'auditoria invàlida")
        if not isinstance(payload.get("last_sequence"), int) or payload["last_sequence"] < 0:
            raise LocalAuditError("seqüència d'auditoria invàlida")
        return payload

    def _trim(self, payload: dict[str, Any]) -> None:
        records = payload["records"]
        while len(records) > self.max_records or len(json.dumps(payload, separators=(",", ":")).encode("utf-8")) > self.max_bytes:
            removed = records.pop(0)
            payload["anchor_hash"] = removed["hash"]
        if records:
            records[0]["previous_hash"] = payload["anchor_hash"]
            records[0]["hash"] = hashlib.sha256(_canonical({k: v for k, v in records[0].items() if k != "hash"})).hexdigest()
            for index in range(1, len(records)):
                records[index]["previous_hash"] = records[index - 1]["hash"]
                records[index]["hash"] = hashlib.sha256(_canonical({k: v for k, v in records[index].items() if k != "hash"})).hexdigest()

    def _write(self, payload: dict[str, Any]) -> None:
        if self.path.parent.exists() and self.path.parent.is_symlink():
            raise LocalAuditError("el directori d'auditoria no pot ser un symlink")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_name(f".{self.path.name}.{os.getpid()}.tmp")
        data = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n"
        try:
            fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as stream:
                stream.write(data)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.path)
            os.chmod(self.path, 0o600)
            directory_fd = os.open(self.path.parent, os.O_RDONLY)
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
        except OSError as error:
            raise LocalAuditError("no s'ha pogut persistir l'auditoria") from error
        finally:
            temporary.unlink(missing_ok=True)

from __future__ import annotations

import json
import os
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path


class SafeModeError(ValueError):
    """Persistent safe-mode state is invalid or unsafe."""


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass(frozen=True, slots=True)
class SafeModeState:
    active: bool
    reason: str | None = None
    detail: str | None = None
    entered_at: str | None = None
    activation_count: int = 0

    def to_payload(self) -> dict[str, object]:
        return {
            "schema_version": 1,
            "active": self.active,
            "reason": self.reason,
            "detail": self.detail,
            "entered_at": self.entered_at,
            "activation_count": self.activation_count,
            "remote_commands_allowed": not self.active,
            "updates_allowed": not self.active,
            "heartbeat_allowed": True,
        }


class SafeModeStore:
    """Fail-closed persistent safe mode that preserves management heartbeats."""

    _MAX_BYTES = 16_384

    def __init__(self, path: Path) -> None:
        self.path = path

    def load(self) -> SafeModeState:
        if not self.path.exists():
            return SafeModeState(active=False)
        if self.path.is_symlink() or not self.path.is_file():
            raise SafeModeError("safe-mode state path must be a regular file")
        try:
            if self.path.stat().st_size > self._MAX_BYTES:
                raise SafeModeError("safe-mode state exceeds size limit")
            raw = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as error:
            raise SafeModeError("safe-mode state is corrupt") from error
        return self._validate(raw)

    def enter(self, reason: str, detail: str | None = None) -> SafeModeState:
        reason = reason.strip()
        detail = detail.strip() if detail else None
        if not reason or len(reason) > 128:
            raise SafeModeError("invalid safe-mode reason")
        if detail is not None and len(detail) > 1024:
            raise SafeModeError("safe-mode detail exceeds size limit")
        previous = self.load()
        state = SafeModeState(
            active=True,
            reason=reason,
            detail=detail,
            entered_at=previous.entered_at if previous.active else _utc_now(),
            activation_count=previous.activation_count + (0 if previous.active else 1),
        )
        self._save(state)
        return state

    def clear(self, *, expected_reason: str | None = None) -> SafeModeState:
        current = self.load()
        if expected_reason is not None and current.reason != expected_reason:
            raise SafeModeError("safe-mode reason does not match")
        state = SafeModeState(active=False, activation_count=current.activation_count)
        self._save(state)
        return state

    @staticmethod
    def _validate(raw: object) -> SafeModeState:
        if not isinstance(raw, dict) or raw.get("schema_version") != 1:
            raise SafeModeError("unsupported safe-mode state schema")
        active = raw.get("active")
        count = raw.get("activation_count")
        if not isinstance(active, bool):
            raise SafeModeError("invalid safe-mode active flag")
        if not isinstance(count, int) or isinstance(count, bool) or count < 0:
            raise SafeModeError("invalid safe-mode activation count")
        values: dict[str, str | None] = {}
        for field, limit in (("reason", 128), ("detail", 1024), ("entered_at", 256)):
            value = raw.get(field)
            if value is not None and (not isinstance(value, str) or not value or len(value) > limit):
                raise SafeModeError(f"invalid safe-mode field: {field}")
            values[field] = value
        if active and (values["reason"] is None or values["entered_at"] is None):
            raise SafeModeError("active safe mode requires reason and entered_at")
        return SafeModeState(active=active, activation_count=count, **values)

    def _save(self, state: SafeModeState) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if self.path.parent.is_symlink():
            raise SafeModeError("safe-mode directory must not be a symlink")
        fd, name = tempfile.mkstemp(prefix=f".{self.path.name}.", dir=self.path.parent)
        temporary = Path(name)
        try:
            os.fchmod(fd, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(state.to_payload(), handle, ensure_ascii=False, sort_keys=True)
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, self.path)
            directory_fd = os.open(self.path.parent, os.O_RDONLY)
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
        finally:
            temporary.unlink(missing_ok=True)

from __future__ import annotations

import platform
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

_OS_RELEASE_KEY = re.compile(r"^[A-Z0-9_]+$")


def _normalise(value: str | None) -> str | None:
    if value is None:
        return None
    cleaned = " ".join(value.replace("\x00", " ").split())
    return cleaned or None


def _unquote_os_release(value: str) -> str:
    value = value.strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in {'"', "'"}:
        quote = value[0]
        value = value[1:-1]
        if quote == '"':
            value = (
                value.replace(r"\\", "\\")
                .replace(r'\"', '"')
                .replace(r"\$", "$")
                .replace(r"\`", "`")
            )
    return value


def parse_os_release(text: str) -> dict[str, str]:
    values: dict[str, str] = {}
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, raw_value = line.split("=", 1)
        key = key.strip()
        if not _OS_RELEASE_KEY.fullmatch(key):
            continue
        value = _normalise(_unquote_os_release(raw_value))
        if value is not None:
            values[key] = value
    return values


@dataclass(frozen=True, slots=True)
class OperatingSystemInventory:
    name: str
    pretty_name: str
    version: str | None
    version_id: str | None
    distribution_id: str | None
    id_like: tuple[str, ...]
    kernel_name: str
    kernel_release: str
    kernel_version: str | None
    architecture: str
    machine: str
    timezone: str | None
    clock_synchronized: bool | None
    collected_at: str

    def to_payload(self) -> dict[str, object]:
        payload: dict[str, object] = {
            "name": self.name,
            "pretty_name": self.pretty_name,
            "kernel_name": self.kernel_name,
            "kernel_release": self.kernel_release,
            "architecture": self.architecture,
            "machine": self.machine,
            "id_like": list(self.id_like),
            "collected_at": self.collected_at,
        }
        optional = {
            "version": self.version,
            "version_id": self.version_id,
            "distribution_id": self.distribution_id,
            "kernel_version": self.kernel_version,
            "timezone": self.timezone,
            "clock_synchronized": self.clock_synchronized,
        }
        payload.update({key: value for key, value in optional.items() if value is not None})
        return payload


class OperatingSystemInventoryCollector:
    def __init__(
        self,
        *,
        os_release_path: Path = Path("/etc/os-release"),
        timezone_path: Path = Path("/etc/timezone"),
        localtime_path: Path = Path("/etc/localtime"),
        zoneinfo_root: Path = Path("/usr/share/zoneinfo"),
        clock_sync_path: Path = Path("/run/systemd/timesync/synchronized"),
        platform_system: Callable[[], str] = platform.system,
        platform_release: Callable[[], str] = platform.release,
        platform_version: Callable[[], str] = platform.version,
        platform_machine: Callable[[], str] = platform.machine,
        now: Callable[[], datetime] = lambda: datetime.now(timezone.utc),
    ) -> None:
        self._os_release_path = os_release_path
        self._timezone_path = timezone_path
        self._localtime_path = localtime_path
        self._zoneinfo_root = zoneinfo_root
        self._clock_sync_path = clock_sync_path
        self._platform_system = platform_system
        self._platform_release = platform_release
        self._platform_version = platform_version
        self._platform_machine = platform_machine
        self._now = now

    def collect(self) -> OperatingSystemInventory:
        release = self._read_os_release()
        kernel_name = _normalise(self._platform_system()) or "unknown"
        kernel_release = _normalise(self._platform_release()) or "unknown"
        machine = _normalise(self._platform_machine()) or "unknown"
        name = release.get("NAME") or kernel_name
        pretty_name = release.get("PRETTY_NAME") or name
        id_like = tuple(part for part in (release.get("ID_LIKE") or "").split() if part)
        return OperatingSystemInventory(
            name=name,
            pretty_name=pretty_name,
            version=release.get("VERSION"),
            version_id=release.get("VERSION_ID"),
            distribution_id=release.get("ID"),
            id_like=id_like,
            kernel_name=kernel_name,
            kernel_release=kernel_release,
            kernel_version=_normalise(self._platform_version()),
            architecture=machine,
            machine=machine,
            timezone=self._read_timezone(),
            clock_synchronized=self._read_clock_synchronized(),
            collected_at=self._now().astimezone(timezone.utc).isoformat().replace("+00:00", "Z"),
        )

    def _read_os_release(self) -> dict[str, str]:
        path = self._os_release_path
        try:
            if path.is_symlink() or not path.is_file():
                return {}
            return parse_os_release(path.read_text(encoding="utf-8", errors="replace"))
        except OSError:
            return {}

    def _read_timezone(self) -> str | None:
        try:
            if self._timezone_path.is_file() and not self._timezone_path.is_symlink():
                value = _normalise(self._timezone_path.read_text(encoding="utf-8", errors="replace"))
                if value:
                    return value
        except OSError:
            pass
        try:
            if self._localtime_path.is_symlink():
                resolved = self._localtime_path.resolve(strict=False)
                relative = resolved.relative_to(self._zoneinfo_root.resolve(strict=False))
                value = relative.as_posix()
                return value if value and ".." not in relative.parts else None
        except (OSError, ValueError):
            pass
        return None

    def _read_clock_synchronized(self) -> bool | None:
        path = self._clock_sync_path
        try:
            if path.is_symlink() or not path.is_file():
                return None
            value = path.read_text(encoding="ascii", errors="ignore").strip().lower()
        except OSError:
            return None
        if value in {"1", "yes", "true", "synchronized", "synced"}:
            return True
        if value in {"0", "no", "false", "unsynchronized", "not-synchronized"}:
            return False
        # systemd-timesyncd commonly uses an empty marker file when synchronized.
        if value == "":
            return True
        return None

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable


def _read_regular_text(path: Path) -> str | None:
    try:
        if path.is_symlink() or not path.is_file():
            return None
        return path.read_text(encoding="utf-8", errors="replace").strip()
    except OSError:
        return None


def _read_nonnegative_int(path: Path) -> int | None:
    value = _read_regular_text(path)
    if value is None:
        return None
    try:
        parsed = int(value)
    except ValueError:
        return None
    return parsed if parsed >= 0 else None


@dataclass(frozen=True, slots=True)
class StorageDevice:
    name: str
    device_path: str
    device_type: str
    size_bytes: int | None = None
    removable: bool | None = None
    rotational: bool | None = None
    read_only: bool | None = None
    model: str | None = None
    vendor: str | None = None
    serial: str | None = None
    partitions: tuple[str, ...] = field(default_factory=tuple)

    def to_payload(self) -> dict[str, object]:
        payload: dict[str, object] = {
            "name": self.name,
            "device_path": self.device_path,
            "device_type": self.device_type,
        }
        for key in ("size_bytes", "removable", "rotational", "read_only", "model", "vendor", "serial"):
            value = getattr(self, key)
            if value is not None:
                payload[key] = value
        if self.partitions:
            payload["partitions"] = list(self.partitions)
        return payload


@dataclass(frozen=True, slots=True)
class FilesystemUsage:
    source: str
    mount_point: str
    filesystem_type: str
    total_bytes: int | None = None
    free_bytes: int | None = None
    available_bytes: int | None = None
    used_bytes: int | None = None
    used_percent: float | None = None
    read_only: bool = False

    def to_payload(self) -> dict[str, object]:
        payload: dict[str, object] = {
            "source": self.source,
            "mount_point": self.mount_point,
            "filesystem_type": self.filesystem_type,
            "read_only": self.read_only,
        }
        for key in ("total_bytes", "free_bytes", "available_bytes", "used_bytes", "used_percent"):
            value = getattr(self, key)
            if value is not None:
                payload[key] = value
        return payload


@dataclass(frozen=True, slots=True)
class StorageInventory:
    devices: tuple[StorageDevice, ...] = field(default_factory=tuple)
    filesystems: tuple[FilesystemUsage, ...] = field(default_factory=tuple)
    total_capacity_bytes: int = 0
    emmc_present: bool = False

    def to_payload(self) -> dict[str, object]:
        return {
            "devices": [device.to_payload() for device in self.devices],
            "filesystems": [filesystem.to_payload() for filesystem in self.filesystems],
            "total_capacity_bytes": self.total_capacity_bytes,
            "emmc_present": self.emmc_present,
        }


class StorageInventoryCollector:
    _IGNORED_BLOCK_PREFIXES = ("loop", "ram", "zram", "fd", "sr")
    _IGNORED_FILESYSTEMS = frozenset({
        "autofs", "bpf", "cgroup", "cgroup2", "configfs", "debugfs", "devpts", "devtmpfs",
        "efivarfs", "fusectl", "hugetlbfs", "mqueue", "nsfs", "overlay", "proc", "pstore",
        "ramfs", "securityfs", "sysfs", "tmpfs", "tracefs",
    })

    def __init__(
        self,
        sys_block_path: Path = Path("/sys/class/block"),
        mountinfo_path: Path = Path("/proc/self/mountinfo"),
        statvfs: Callable[[str], os.statvfs_result] = os.statvfs,
    ) -> None:
        self._sys_block_path = sys_block_path
        self._mountinfo_path = mountinfo_path
        self._statvfs = statvfs

    def collect(self) -> StorageInventory:
        devices = self._collect_devices()
        filesystems = self._collect_filesystems()
        return StorageInventory(
            devices=devices,
            filesystems=filesystems,
            total_capacity_bytes=sum(device.size_bytes or 0 for device in devices),
            emmc_present=any(device.device_type == "emmc" for device in devices),
        )

    def _collect_devices(self) -> tuple[StorageDevice, ...]:
        try:
            entries = sorted(self._sys_block_path.iterdir(), key=lambda path: path.name)
        except OSError:
            return ()
        devices: list[StorageDevice] = []
        for entry in entries:
            name = entry.name
            if name.startswith(self._IGNORED_BLOCK_PREFIXES) or self._is_partition(entry, name):
                continue
            size_sectors = _read_nonnegative_int(entry / "size")
            device_type = self._device_type(name, entry)
            partitions = self._partition_names(entry, name)
            devices.append(StorageDevice(
                name=name,
                device_path=f"/dev/{name}",
                device_type=device_type,
                size_bytes=size_sectors * 512 if size_sectors is not None else None,
                removable=self._bool_file(entry / "removable"),
                rotational=self._bool_file(entry / "queue" / "rotational"),
                read_only=self._bool_file(entry / "ro"),
                model=self._clean_text(entry / "device" / "model"),
                vendor=self._clean_text(entry / "device" / "vendor"),
                serial=self._clean_text(entry / "device" / "serial"),
                partitions=partitions,
            ))
        return tuple(devices)

    def _collect_filesystems(self) -> tuple[FilesystemUsage, ...]:
        text = _read_regular_text(self._mountinfo_path)
        if not text:
            return ()
        values: list[FilesystemUsage] = []
        seen: set[str] = set()
        for line in text.splitlines():
            parsed = self._parse_mountinfo(line)
            if parsed is None:
                continue
            source, mount_point, fs_type, mount_options = parsed
            if fs_type in self._IGNORED_FILESYSTEMS or mount_point in seen:
                continue
            seen.add(mount_point)
            total = free = available = used = None
            used_percent = None
            try:
                stat = self._statvfs(mount_point)
                block_size = stat.f_frsize or stat.f_bsize
                total = stat.f_blocks * block_size
                free = stat.f_bfree * block_size
                available = stat.f_bavail * block_size
                used = max(0, total - free)
                used_percent = round(used * 100 / total, 2) if total else 0.0
            except OSError:
                pass
            values.append(FilesystemUsage(
                source=source,
                mount_point=mount_point,
                filesystem_type=fs_type,
                total_bytes=total,
                free_bytes=free,
                available_bytes=available,
                used_bytes=used,
                used_percent=used_percent,
                read_only="ro" in mount_options.split(","),
            ))
        return tuple(sorted(values, key=lambda item: item.mount_point))

    @staticmethod
    def _is_partition(entry: Path, name: str) -> bool:
        return (entry / "partition").exists() or (name.startswith("nvme") and "p" in name.rsplit("n", 1)[-1])

    @staticmethod
    def _partition_names(entry: Path, name: str) -> tuple[str, ...]:
        try:
            children = entry.iterdir()
        except OSError:
            return ()
        return tuple(sorted(child.name for child in children if child.name.startswith(name) and (child / "partition").exists()))

    @staticmethod
    def _device_type(name: str, entry: Path) -> str:
        if name.startswith("mmcblk"):
            device_type_file = _read_regular_text(entry / "device" / "type")
            return "emmc" if device_type_file and device_type_file.upper() == "MMC" else "sd-card"
        if name.startswith("nvme"):
            return "nvme"
        if name.startswith("vd") or name.startswith("xvd"):
            return "virtual"
        if name.startswith("sd"):
            return "disk"
        return "block"

    @staticmethod
    def _bool_file(path: Path) -> bool | None:
        value = _read_nonnegative_int(path)
        return None if value is None else bool(value)

    @staticmethod
    def _clean_text(path: Path) -> str | None:
        value = _read_regular_text(path)
        if value is None:
            return None
        cleaned = " ".join(value.replace("\x00", " ").split())
        return cleaned or None

    @staticmethod
    def _decode_mount_field(value: str) -> str:
        return value.replace("\\040", " ").replace("\\011", "\t").replace("\\012", "\n").replace("\\134", "\\")

    @classmethod
    def _parse_mountinfo(cls, line: str) -> tuple[str, str, str, str] | None:
        left, separator, right = line.partition(" - ")
        if not separator:
            return None
        left_fields = left.split()
        right_fields = right.split()
        if len(left_fields) < 6 or len(right_fields) < 2:
            return None
        mount_point = cls._decode_mount_field(left_fields[4])
        mount_options = left_fields[5]
        fs_type = right_fields[0]
        source = cls._decode_mount_field(right_fields[1])
        return source, mount_point, fs_type, mount_options

from __future__ import annotations

import base64
import json
import os
import stat
import uuid
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import Any, Mapping

from xaac_agent import __version__
from xaac_agent.device_keys import DeviceKeyPair
from xaac_agent.identity import DeviceIdentity

ENROLLMENT_SCHEMA_VERSION = 1
CREDENTIAL_SCHEMA_VERSION = 1


class EnrollmentError(RuntimeError):
    """Base error for XMP enrollment operations."""


class InvalidEnrollmentResponseError(EnrollmentError):
    """Raised when XMS returns an enrollment response that cannot be trusted."""


class InvalidDeviceCredentialsError(EnrollmentError):
    """Raised when persisted device credentials are invalid or unsafe."""


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def canonical_json(payload: Mapping[str, Any]) -> bytes:
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode(
        "utf-8"
    )


def parse_utc_timestamp(value: str, *, field_name: str) -> datetime:
    try:
        parsed = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    except (AttributeError, TypeError, ValueError) as error:
        raise InvalidDeviceCredentialsError(f"{field_name} no és una data UTC vàlida") from error
    if parsed.tzinfo is None:
        raise InvalidDeviceCredentialsError(f"{field_name} ha d'incloure zona horària")
    return parsed.astimezone(timezone.utc)


@dataclass(frozen=True, slots=True)
class EnrollmentRequest:
    request_id: str
    sent_at: str
    device_id: str
    agent_version: str
    public_key: dict[str, str]
    hardware: dict[str, object]
    signature: str
    schema_version: int = ENROLLMENT_SCHEMA_VERSION

    @classmethod
    def create(
        cls,
        identity: DeviceIdentity,
        key_pair: DeviceKeyPair,
        hardware: Mapping[str, object] | None = None,
        *,
        request_id: str | None = None,
        sent_at: str | None = None,
    ) -> "EnrollmentRequest":
        unsigned = {
            "schema_version": ENROLLMENT_SCHEMA_VERSION,
            "type": "enrollment",
            "request_id": request_id or str(uuid.uuid4()),
            "sent_at": sent_at or utc_now(),
            "device_id": identity.device_id,
            "agent_version": __version__,
            "public_key": key_pair.public_payload(),
            "hardware": dict(hardware or {}),
        }
        signature = base64.b64encode(key_pair.sign(canonical_json(unsigned))).decode("ascii")
        return cls(
            request_id=str(unsigned["request_id"]),
            sent_at=str(unsigned["sent_at"]),
            device_id=identity.device_id,
            agent_version=__version__,
            public_key=key_pair.public_payload(),
            hardware=dict(hardware or {}),
            signature=signature,
        )

    def unsigned_payload(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "type": "enrollment",
            "request_id": self.request_id,
            "sent_at": self.sent_at,
            "device_id": self.device_id,
            "agent_version": self.agent_version,
            "public_key": self.public_key,
            "hardware": self.hardware,
        }

    def to_payload(self) -> dict[str, Any]:
        return {**self.unsigned_payload(), "signature": self.signature}


@dataclass(frozen=True, slots=True)
class DeviceCredentials:
    device_id: str
    credential: str
    issued_at: str
    expires_at: str | None = None
    schema_version: int = CREDENTIAL_SCHEMA_VERSION

    @classmethod
    def from_response(
        cls, payload: Mapping[str, Any], *, expected_device_id: str
    ) -> "DeviceCredentials":
        if payload.get("schema_version", CREDENTIAL_SCHEMA_VERSION) != CREDENTIAL_SCHEMA_VERSION:
            raise InvalidEnrollmentResponseError("unsupported credential schema version")
        device_id = payload.get("device_id")
        credential = payload.get("credential")
        issued_at = payload.get("issued_at")
        expires_at = payload.get("expires_at")
        if not isinstance(device_id, str) or device_id != expected_device_id:
            raise InvalidEnrollmentResponseError("enrollment response device_id mismatch")
        if not isinstance(credential, str) or not credential.strip():
            raise InvalidEnrollmentResponseError("enrollment response credential is missing")
        if not isinstance(issued_at, str) or not issued_at.strip():
            raise InvalidEnrollmentResponseError("enrollment response issued_at is missing")
        if expires_at is not None and (not isinstance(expires_at, str) or not expires_at.strip()):
            raise InvalidEnrollmentResponseError("enrollment response expires_at is invalid")
        result = cls(
            device_id=device_id,
            credential=credential.strip(),
            issued_at=issued_at.strip(),
            expires_at=expires_at.strip() if isinstance(expires_at, str) else None,
        )
        try:
            result.validate_timestamps()
        except InvalidDeviceCredentialsError as error:
            raise InvalidEnrollmentResponseError(str(error)) from error
        return result

    def validate_timestamps(self) -> None:
        # Credencials antigues sense caducitat es mantenen compatibles.
        if self.expires_at is None:
            return
        issued = parse_utc_timestamp(self.issued_at, field_name="issued_at")
        expires = parse_utc_timestamp(self.expires_at, field_name="expires_at")
        if expires <= issued:
            raise InvalidDeviceCredentialsError("expires_at ha de ser posterior a issued_at")

    def is_expired(
        self,
        *,
        now: datetime | None = None,
        clock_skew_tolerance_seconds: int = 300,
    ) -> bool:
        if self.expires_at is None:
            return False
        current = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
        expires = parse_utc_timestamp(self.expires_at, field_name="expires_at")
        return current > expires + timedelta(seconds=clock_skew_tolerance_seconds)

    def renewal_due(
        self,
        *,
        now: datetime | None = None,
        renew_before_seconds: int = 3600,
        clock_skew_tolerance_seconds: int = 300,
    ) -> bool:
        if self.expires_at is None:
            return False
        current = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
        issued = parse_utc_timestamp(self.issued_at, field_name="issued_at")
        expires = parse_utc_timestamp(self.expires_at, field_name="expires_at")
        # Un rellotge local molt anterior a issued_at no força una renovació immediata.
        if current + timedelta(seconds=clock_skew_tolerance_seconds) < issued:
            return False
        return current >= expires - timedelta(seconds=renew_before_seconds)

    def to_payload(self) -> dict[str, object]:
        payload: dict[str, object] = {
            "schema_version": self.schema_version,
            "device_id": self.device_id,
            "credential": self.credential,
            "issued_at": self.issued_at,
        }
        if self.expires_at is not None:
            payload["expires_at"] = self.expires_at
        return payload


@dataclass(frozen=True, slots=True)
class CredentialRenewalRequest:
    request_id: str
    sent_at: str
    device_id: str
    key_id: str
    signature: str
    schema_version: int = CREDENTIAL_SCHEMA_VERSION

    @classmethod
    def create(
        cls,
        credentials: DeviceCredentials,
        key_pair: DeviceKeyPair,
        *,
        request_id: str | None = None,
        sent_at: str | None = None,
    ) -> "CredentialRenewalRequest":
        unsigned = {
            "schema_version": CREDENTIAL_SCHEMA_VERSION,
            "type": "credential_renewal",
            "request_id": request_id or str(uuid.uuid4()),
            "sent_at": sent_at or utc_now(),
            "device_id": credentials.device_id,
            "key_id": key_pair.key_id,
        }
        signature = base64.b64encode(key_pair.sign(canonical_json(unsigned))).decode("ascii")
        return cls(
            request_id=str(unsigned["request_id"]),
            sent_at=str(unsigned["sent_at"]),
            device_id=credentials.device_id,
            key_id=key_pair.key_id,
            signature=signature,
        )

    def unsigned_payload(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "type": "credential_renewal",
            "request_id": self.request_id,
            "sent_at": self.sent_at,
            "device_id": self.device_id,
            "key_id": self.key_id,
        }

    def to_payload(self) -> dict[str, Any]:
        payload = self.unsigned_payload()
        payload["signature"] = self.signature
        return payload


@dataclass(frozen=True, slots=True)
class UnenrollmentRequest:
    request_id: str
    sent_at: str
    device_id: str
    key_id: str
    reason: str
    signature: str
    schema_version: int = CREDENTIAL_SCHEMA_VERSION

    @classmethod
    def create(
        cls,
        credentials: DeviceCredentials,
        key_pair: DeviceKeyPair,
        *,
        reason: str = "administrator_request",
        request_id: str | None = None,
        sent_at: str | None = None,
    ) -> "UnenrollmentRequest":
        unsigned = {
            "schema_version": CREDENTIAL_SCHEMA_VERSION,
            "type": "unenrollment",
            "request_id": request_id or str(uuid.uuid4()),
            "sent_at": sent_at or utc_now(),
            "device_id": credentials.device_id,
            "key_id": key_pair.key_id,
            "reason": reason,
        }
        signature = base64.b64encode(key_pair.sign(canonical_json(unsigned))).decode("ascii")
        return cls(signature=signature, **{k: unsigned[k] for k in ("request_id", "sent_at", "device_id", "key_id", "reason")})

    def unsigned_payload(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "type": "unenrollment",
            "request_id": self.request_id,
            "sent_at": self.sent_at,
            "device_id": self.device_id,
            "key_id": self.key_id,
            "reason": self.reason,
        }

    def to_payload(self) -> dict[str, Any]:
        return {**self.unsigned_payload(), "signature": self.signature}


class DeviceCredentialsStore:
    """Atomically persist the credential issued by XMS with private permissions."""

    def __init__(self, path: Path) -> None:
        self._path = path

    @property
    def path(self) -> Path:
        return self._path

    def exists(self) -> bool:
        try:
            metadata = self._path.lstat()
        except FileNotFoundError:
            return False
        if stat.S_ISLNK(metadata.st_mode) or not stat.S_ISREG(metadata.st_mode):
            raise InvalidDeviceCredentialsError("device credentials path must be a regular file")
        return True

    def load(self) -> DeviceCredentials:
        self._validate_path()
        try:
            decoded = json.loads(self._path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            raise
        except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
            raise InvalidDeviceCredentialsError("cannot read device credentials") from error
        if not isinstance(decoded, dict):
            raise InvalidDeviceCredentialsError("device credentials must contain a JSON object")
        try:
            credentials = DeviceCredentials(
                schema_version=int(decoded.get("schema_version", 0)),
                device_id=str(decoded["device_id"]),
                credential=str(decoded["credential"]),
                issued_at=str(decoded["issued_at"]),
                expires_at=(
                    str(decoded["expires_at"]) if decoded.get("expires_at") is not None else None
                ),
            )
        except (KeyError, TypeError, ValueError) as error:
            raise InvalidDeviceCredentialsError("device credentials are incomplete") from error
        if credentials.schema_version != CREDENTIAL_SCHEMA_VERSION:
            raise InvalidDeviceCredentialsError("unsupported credential schema version")
        if not credentials.device_id or not credentials.credential or not credentials.issued_at:
            raise InvalidDeviceCredentialsError("device credentials contain empty fields")
        credentials.validate_timestamps()
        self._ensure_private_permissions()
        return credentials

    def save(self, credentials: DeviceCredentials) -> None:
        self._prepare_parent_directory()
        data = canonical_json(credentials.to_payload()) + b"\n"
        temporary_name: str | None = None
        try:
            with NamedTemporaryFile(
                "wb", dir=self._path.parent, prefix=".credentials-", suffix=".tmp", delete=False
            ) as handle:
                temporary_name = handle.name
                handle.write(data)
                handle.flush()
                os.fsync(handle.fileno())
            os.chmod(temporary_name, 0o600)
            os.replace(temporary_name, self._path)
            temporary_name = None
            self._fsync_directory(self._path.parent)
            self._ensure_private_permissions()
        except OSError as error:
            raise InvalidDeviceCredentialsError("cannot persist device credentials") from error
        finally:
            if temporary_name and os.path.exists(temporary_name):
                os.unlink(temporary_name)

    def delete(self) -> bool:
        """Remove credentials and fsync the parent directory.

        Overwriting flash-backed storage is not reliable; logical deletion plus
        directory synchronisation is the safe portable operation.
        """
        self._validate_path()
        try:
            self._path.unlink()
            self._fsync_directory(self._path.parent)
            return True
        except FileNotFoundError:
            return False
        except OSError as error:
            raise InvalidDeviceCredentialsError("cannot delete device credentials") from error

    def _validate_path(self) -> None:
        try:
            metadata = self._path.lstat()
        except FileNotFoundError:
            raise
        except OSError as error:
            raise InvalidDeviceCredentialsError("cannot inspect device credentials") from error
        if stat.S_ISLNK(metadata.st_mode) or not stat.S_ISREG(metadata.st_mode):
            raise InvalidDeviceCredentialsError("device credentials path must be a regular file")

    def _prepare_parent_directory(self) -> None:
        try:
            self._path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            if self._path.parent.is_symlink() or not self._path.parent.is_dir():
                raise InvalidDeviceCredentialsError("credentials parent must be a directory")
            mode = stat.S_IMODE(self._path.parent.stat().st_mode)
            if mode & 0o077:
                os.chmod(self._path.parent, mode & ~0o077)
        except InvalidDeviceCredentialsError:
            raise
        except OSError as error:
            raise InvalidDeviceCredentialsError("cannot prepare credentials directory") from error

    def _ensure_private_permissions(self) -> None:
        try:
            if stat.S_IMODE(self._path.stat().st_mode) != 0o600:
                os.chmod(self._path, 0o600)
        except OSError as error:
            raise InvalidDeviceCredentialsError("cannot enforce credentials permissions") from error

    @staticmethod
    def _fsync_directory(path: Path) -> None:
        descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any


class ReleaseCandidateError(ValueError):
    """Raised when a release manifest is incomplete or inconsistent."""


_VERSION_RE = re.compile(r'^version\s*=\s*"([^"]+)"\s*$', re.MULTILINE)
_INIT_VERSION_RE = re.compile(r'^__version__\s*=\s*"([^"]+)"\s*$', re.MULTILINE)


@dataclass(frozen=True, slots=True)
class ReleaseCandidate:
    package: str
    release: str
    python_version: str
    source_date_epoch: int
    release_notes: Path
    required_files: tuple[Path, ...]
    forbidden_paths: tuple[Path, ...]
    sha256: dict[str, str]

    @classmethod
    def load(cls, path: Path) -> "ReleaseCandidate":
        try:
            raw: Any = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ReleaseCandidateError("release_candidate_invalid") from exc
        if not isinstance(raw, dict) or raw.get("schema_version") != 1:
            raise ReleaseCandidateError("release_candidate_schema_invalid")
        reproducibility = raw.get("reproducibility")
        if not isinstance(reproducibility, dict):
            raise ReleaseCandidateError("release_candidate_reproducibility_invalid")
        hashes = raw.get("sha256")
        if not isinstance(hashes, dict):
            raise ReleaseCandidateError("release_candidate_hashes_invalid")
        return cls(
            package=str(raw.get("package", "")),
            release=str(raw.get("release", "")),
            python_version=str(raw.get("python_version", "")),
            source_date_epoch=int(reproducibility.get("source_date_epoch", 0)),
            release_notes=Path(str(raw.get("release_notes", ""))),
            required_files=tuple(Path(str(item)) for item in raw.get("required_files", [])),
            forbidden_paths=tuple(Path(str(item)) for item in raw.get("forbidden_paths", [])),
            sha256={str(key): str(value) for key, value in hashes.items()},
        )

    @staticmethod
    def _safe_relative(path: Path) -> bool:
        return not path.is_absolute() and ".." not in path.parts and str(path) not in {"", "."}

    @staticmethod
    def _digest(path: Path) -> str:
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(chunk)
        return digest.hexdigest()

    def validate(self, project_root: Path, *, strict: bool = False) -> None:
        if self.package != "xaac-agent" or self.release != "1.0.0":
            raise ReleaseCandidateError("release_candidate_identity_invalid")
        if self.python_version != "3.13.x" or self.source_date_epoch <= 0:
            raise ReleaseCandidateError("release_candidate_runtime_invalid")
        if not self._safe_relative(self.release_notes):
            raise ReleaseCandidateError("release_candidate_path_unsafe")
        if not (project_root / self.release_notes).is_file():
            raise ReleaseCandidateError("release_candidate_notes_missing")

        for relative in self.required_files:
            if not self._safe_relative(relative):
                raise ReleaseCandidateError("release_candidate_path_unsafe")
            if not (project_root / relative).is_file():
                raise ReleaseCandidateError("release_candidate_required_file_missing")

        # Validate the immutable release inventory before checking workspace
        # cleanliness. This guarantees that tampered release inputs always
        # report a hash error, even when the developer tree contains local
        # artifacts such as a virtual environment.

        pyproject = (project_root / "pyproject.toml").read_text(encoding="utf-8")
        init_file = (project_root / "src/xaac_agent/__init__.py").read_text(encoding="utf-8")
        project_match = _VERSION_RE.search(pyproject)
        init_match = _INIT_VERSION_RE.search(init_file)
        if not project_match or project_match.group(1) != "1.0.0":
            raise ReleaseCandidateError("release_candidate_project_version_invalid")
        if not init_match or init_match.group(1) != "1.0.0":
            raise ReleaseCandidateError("release_candidate_module_version_invalid")

        if set(self.sha256) != {str(item) for item in self.required_files}:
            raise ReleaseCandidateError("release_candidate_hash_inventory_invalid")
        for relative_text, expected in self.sha256.items():
            relative = Path(relative_text)
            if not re.fullmatch(r"[0-9a-f]{64}", expected):
                raise ReleaseCandidateError("release_candidate_hash_invalid")
            if self._digest(project_root / relative) != expected:
                raise ReleaseCandidateError("release_candidate_hash_mismatch")

        if strict:
            for relative in self.forbidden_paths:
                if not self._safe_relative(relative):
                    raise ReleaseCandidateError("release_candidate_path_unsafe")
                if (project_root / relative).exists():
                    raise ReleaseCandidateError("release_candidate_local_artifact_present")

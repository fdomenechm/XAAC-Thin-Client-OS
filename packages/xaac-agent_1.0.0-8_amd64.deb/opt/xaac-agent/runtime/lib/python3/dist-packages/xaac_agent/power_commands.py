from __future__ import annotations

import subprocess
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Protocol, Sequence

from xaac_agent.command_model import Command, CommandResult, CommandState, CommandType
from xaac_agent.privileged_helper import PrivilegedHelperClient


class PowerCommandBackend(Protocol):
    def run(self, argv: Sequence[str], *, timeout_seconds: int) -> subprocess.CompletedProcess[str]: ...


class SubprocessPowerBackend:
    """Backend mínim: argv fixa, sense shell, entrada ni entorn remot."""

    def run(self, argv: Sequence[str], *, timeout_seconds: int) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            list(argv),
            check=False,
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
            stdin=subprocess.DEVNULL,
        )


@dataclass(frozen=True, slots=True)
class PowerCommandExecutor:
    backend: PowerCommandBackend
    systemctl_path: str = "/usr/bin/systemctl"
    systemd_run_path: str = "/usr/bin/systemd-run"
    timeout_seconds: int = 15

    @classmethod
    def system_default(cls) -> "PowerCommandExecutor":
        return cls(backend=PrivilegedHelperClient())

    def execute(self, command: Command) -> CommandResult:
        if command.command_type not in {CommandType.REBOOT, CommandType.POWEROFF}:
            raise ValueError("unsupported_power_command")

        started_at = _utc_now()
        delay = int(command.parameters.get("delay_seconds", 0))
        force = bool(command.parameters.get("force", False))
        action = "reboot" if command.command_type is CommandType.REBOOT else "poweroff"
        argv = self._argv(action=action, delay_seconds=delay, force=force)
        try:
            completed = self.backend.run(argv, timeout_seconds=self.timeout_seconds)
        except subprocess.TimeoutExpired:
            return self._failed(command, started_at, "power_command_timeout")
        except OSError as error:
            return self._failed(command, started_at, "power_command_backend_error", str(error))

        if completed.returncode != 0:
            detail = _safe_detail(completed.stderr or completed.stdout)
            return self._failed(command, started_at, "power_command_rejected", detail)

        return CommandResult(
            command_id=command.command_id,
            state=CommandState.SUCCEEDED,
            started_at=started_at,
            finished_at=_utc_now(),
            code="power_command_scheduled" if delay else "power_command_started",
            data={
                "action": action,
                "delay_seconds": delay,
                "forced": force,
            },
        )

    def _argv(self, *, action: str, delay_seconds: int, force: bool) -> tuple[str, ...]:
        systemctl = [self.systemctl_path, action]
        if force:
            systemctl.append("--force")
        if delay_seconds == 0:
            return tuple(systemctl)
        return (
            self.systemd_run_path,
            "--quiet",
            "--collect",
            f"--on-active={delay_seconds}s",
            "--property=Type=oneshot",
            "--",
            *systemctl,
        )

    @staticmethod
    def _failed(command: Command, started_at: str, code: str, detail: str | None = None) -> CommandResult:
        return CommandResult(
            command_id=command.command_id,
            state=CommandState.FAILED,
            started_at=started_at,
            finished_at=_utc_now(),
            code=code,
            message=detail,
            data={"action": command.command_type.value},
        )


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _safe_detail(value: str | None) -> str | None:
    if not value:
        return None
    compact = " ".join(value.split())
    return compact[:512] or None

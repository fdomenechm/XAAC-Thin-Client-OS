from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Mapping


class CommandValidationError(ValueError):
    """Ordre XMP mal formada o incompatible amb el model local."""

    def __init__(self, code: str) -> None:
        super().__init__(code)
        self.code = code


class CommandType(str, Enum):
    NOOP = "noop"
    REBOOT = "reboot"
    POWEROFF = "poweroff"
    SERVICE = "service"
    TASK = "task"
    FILE_TRANSFER = "file-transfer"
    COLLECT_LOGS = "collect-logs"
    SIGNED_SCRIPT = "signed-script"
    CANCEL = "cancel"


class CommandState(str, Enum):
    RECEIVED = "received"
    ACCEPTED = "accepted"
    DENIED = "denied"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCELLED = "cancelled"
    EXPIRED = "expired"
    REJECTED = "rejected"


_TERMINAL_STATES = {
    CommandState.DENIED,
    CommandState.SUCCEEDED,
    CommandState.FAILED,
    CommandState.CANCELLED,
    CommandState.EXPIRED,
    CommandState.REJECTED,
}
_ID_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$")
_CAPABILITY_PATTERN = re.compile(r"^[a-z0-9][a-z0-9._-]{0,63}$")
_MAX_PARAMETERS = 64
_MAX_NESTING = 8
_MAX_STRING_LENGTH = 16_384


def parse_xmp_time(value: object, *, required: bool = False) -> datetime | None:
    if value is None and not required:
        return None
    if not isinstance(value, str) or not value.strip():
        raise CommandValidationError("missing_expiry" if required else "invalid_expiry")
    try:
        parsed = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    except ValueError as error:
        raise CommandValidationError("invalid_expiry") from error
    if parsed.tzinfo is None:
        raise CommandValidationError("invalid_expiry")
    return parsed.astimezone(timezone.utc)


def _validate_json_value(value: Any, *, depth: int = 0) -> None:
    if depth > _MAX_NESTING:
        raise CommandValidationError("parameters_too_deep")
    if value is None or isinstance(value, bool):
        return
    if isinstance(value, str):
        if len(value) > _MAX_STRING_LENGTH:
            raise CommandValidationError("parameter_string_too_long")
        return
    if isinstance(value, int):
        return
    if isinstance(value, float):
        if not math.isfinite(value):
            raise CommandValidationError("invalid_parameter_number")
        return
    if isinstance(value, list):
        for item in value:
            _validate_json_value(item, depth=depth + 1)
        return
    if isinstance(value, dict):
        if len(value) > _MAX_PARAMETERS:
            raise CommandValidationError("too_many_parameters")
        for key, item in value.items():
            if not isinstance(key, str) or not key or len(key) > 128:
                raise CommandValidationError("invalid_parameter_name")
            _validate_json_value(item, depth=depth + 1)
        return
    raise CommandValidationError("invalid_parameter_value")


@dataclass(frozen=True, slots=True)
class CommandIssuer:
    issuer_id: str
    kind: str = "xms"

    @classmethod
    def from_payload(cls, value: object) -> "CommandIssuer":
        if isinstance(value, str):
            issuer_id, kind = value.strip(), "xms"
        elif isinstance(value, Mapping):
            issuer_id = value.get("id")
            kind = value.get("kind", "xms")
            if not isinstance(issuer_id, str) or not isinstance(kind, str):
                raise CommandValidationError("invalid_issuer")
            issuer_id, kind = issuer_id.strip(), kind.strip().lower()
        else:
            raise CommandValidationError("missing_issuer")
        if not issuer_id or len(issuer_id) > 256 or not kind or len(kind) > 64:
            raise CommandValidationError("invalid_issuer")
        return cls(issuer_id=issuer_id, kind=kind)

    def to_payload(self) -> dict[str, str]:
        return {"id": self.issuer_id, "kind": self.kind}


@dataclass(frozen=True, slots=True)
class Command:
    command_id: str
    command_type: CommandType
    issuer: CommandIssuer
    expires_at: datetime
    parameters: dict[str, Any] = field(default_factory=dict)
    required_capabilities: tuple[str, ...] = ()
    issued_at: datetime | None = None
    nonce: str | None = None
    schema_version: int = 1

    @classmethod
    def from_payload(cls, payload: Mapping[str, Any]) -> "Command":
        schema_version = payload.get("schema_version", 1)
        if isinstance(schema_version, bool) or schema_version != 1:
            raise CommandValidationError("unsupported_schema_version")

        command_id = payload.get("command_id")
        if not isinstance(command_id, str) or not _ID_PATTERN.fullmatch(command_id.strip()):
            raise CommandValidationError("missing_command_id" if not command_id else "invalid_command_id")

        raw_type = payload.get("type")
        if not isinstance(raw_type, str) or not raw_type.strip():
            raise CommandValidationError("missing_command_type")
        try:
            command_type = CommandType(raw_type.strip().lower())
        except ValueError as error:
            raise CommandValidationError("unsupported_command_type") from error

        issuer = CommandIssuer.from_payload(payload.get("issuer"))
        expires_at = parse_xmp_time(payload.get("expires_at"), required=True)
        assert expires_at is not None

        issued_at = None
        if payload.get("issued_at") is not None:
            try:
                issued_at = parse_xmp_time(payload.get("issued_at"), required=True)
            except CommandValidationError as error:
                raise CommandValidationError("invalid_issued_at") from error
        if issued_at is not None and issued_at > expires_at:
            raise CommandValidationError("expiry_before_issue")

        nonce = payload.get("nonce")
        if nonce is not None:
            if not isinstance(nonce, str) or not _ID_PATTERN.fullmatch(nonce.strip()):
                raise CommandValidationError("invalid_nonce")
            nonce = nonce.strip()

        parameters = payload.get("parameters", {})
        if not isinstance(parameters, dict):
            raise CommandValidationError("invalid_parameters")
        _validate_json_value(parameters)

        raw_capabilities = payload.get("required_capabilities", [])
        if not isinstance(raw_capabilities, list):
            raise CommandValidationError("invalid_required_capabilities")
        capabilities: set[str] = set()
        for capability in raw_capabilities:
            if not isinstance(capability, str) or not _CAPABILITY_PATTERN.fullmatch(capability.strip()):
                raise CommandValidationError("invalid_required_capability")
            capabilities.add(capability.strip())

        return cls(
            command_id=command_id.strip(),
            command_type=command_type,
            issuer=issuer,
            expires_at=expires_at,
            parameters=dict(parameters),
            required_capabilities=tuple(sorted(capabilities)),
            issued_at=issued_at,
            nonce=nonce,
            schema_version=1,
        )

    def is_expired(self, *, now: datetime | None = None) -> bool:
        reference = now or datetime.now(timezone.utc)
        if reference.tzinfo is None:
            reference = reference.replace(tzinfo=timezone.utc)
        return self.expires_at <= reference.astimezone(timezone.utc)

    def to_payload(self) -> dict[str, object]:
        result: dict[str, object] = {
            "schema_version": self.schema_version,
            "command_id": self.command_id,
            "type": self.command_type.value,
            "issuer": self.issuer.to_payload(),
            "expires_at": self.expires_at.isoformat().replace("+00:00", "Z"),
            "parameters": dict(self.parameters),
            "required_capabilities": list(self.required_capabilities),
        }
        if self.issued_at is not None:
            result["issued_at"] = self.issued_at.isoformat().replace("+00:00", "Z")
        if self.nonce is not None:
            result["nonce"] = self.nonce
        return result


@dataclass(frozen=True, slots=True)
class CommandResult:
    command_id: str
    state: CommandState
    started_at: str | None = None
    finished_at: str | None = None
    code: str | None = None
    message: str | None = None
    data: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not _ID_PATTERN.fullmatch(self.command_id):
            raise CommandValidationError("invalid_command_id")
        _validate_json_value(self.data)
        if self.message is not None and len(self.message) > 4096:
            raise CommandValidationError("result_message_too_long")

    @property
    def terminal(self) -> bool:
        return self.state in _TERMINAL_STATES

    def to_payload(self) -> dict[str, object]:
        payload: dict[str, object] = {
            "command_id": self.command_id,
            "state": self.state.value,
            "terminal": self.terminal,
            "data": dict(self.data),
        }
        for key, value in (
            ("started_at", self.started_at),
            ("finished_at", self.finished_at),
            ("code", self.code),
            ("message", self.message),
        ):
            if value is not None:
                payload[key] = value
        return payload

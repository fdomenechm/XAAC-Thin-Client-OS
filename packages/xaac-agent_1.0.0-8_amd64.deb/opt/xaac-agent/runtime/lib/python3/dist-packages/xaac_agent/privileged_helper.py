from __future__ import annotations

import json
import os
import pwd
import re
import socket
import struct
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, Sequence

_MAX_MESSAGE_BYTES = 8192
_SERVICE = re.compile(r"^[A-Za-z0-9_.@:-]{1,200}\.service$")
_ALLOWED_SERVICE_ACTIONS = frozenset({"start", "stop", "restart", "reload", "status"})
_ALLOWED_VPN_POLICIES = frozenset({"disabled", "optional", "required"})
_VPN_ADMIN_PATH = "/usr/local/sbin/xaac-vpn-admin"


class PrivilegedHelperError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class HelperResponse:
    returncode: int
    stdout: str = ""
    stderr: str = ""


@dataclass(frozen=True, slots=True)
class PrivilegedHelperClient:
    socket_path: Path = Path("/run/xaac-agent/privileged.sock")
    timeout_seconds: float = 20.0
    max_response_bytes: int = _MAX_MESSAGE_BYTES

    def run(self, argv: Sequence[str], *, timeout_seconds: int) -> subprocess.CompletedProcess[str]:
        request = _request_from_argv(tuple(argv), timeout_seconds=timeout_seconds)
        payload = _encode(request)
        try:
            with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
                client.settimeout(min(float(timeout_seconds) + 2.0, self.timeout_seconds))
                client.connect(str(self.socket_path))
                client.sendall(payload)
                client.shutdown(socket.SHUT_WR)
                raw = _receive(client, self.max_response_bytes)
        except TimeoutError as error:
            raise subprocess.TimeoutExpired(list(argv), timeout_seconds) from error
        except OSError as error:
            raise PrivilegedHelperError("privileged_helper_unavailable") from error
        response = _parse_response(raw)
        return subprocess.CompletedProcess(list(argv), response.returncode, response.stdout, response.stderr)


@dataclass(frozen=True, slots=True)
class PrivilegedHelperServer:
    allowed_services: frozenset[str] = frozenset()
    allowed_peer_uid: int | None = None
    systemctl_path: Path = Path("/usr/bin/systemctl")
    systemd_run_path: Path = Path("/usr/bin/systemd-run")
    vpn_admin_path: Path = Path(_VPN_ADMIN_PATH)
    max_message_bytes: int = _MAX_MESSAGE_BYTES

    def serve_connection(self, connection: socket.socket) -> None:
        try:
            self._authorize_peer(connection)
            request = _parse_request(_receive(connection, self.max_message_bytes))
            response = self.execute(request)
        except (PrivilegedHelperError, ValueError, OSError) as error:
            response = HelperResponse(126, stderr=_safe_text(str(error) or "privileged_helper_rejected"))
        connection.sendall(_encode({"returncode": response.returncode, "stdout": response.stdout, "stderr": response.stderr}))

    def execute(self, request: Mapping[str, object]) -> HelperResponse:
        operation = request.get("operation")
        timeout = request.get("timeout_seconds")
        if isinstance(timeout, bool) or not isinstance(timeout, int) or not 1 <= timeout <= 3600:
            raise PrivilegedHelperError("invalid_helper_timeout")
        if operation == "service":
            argv = self._service_argv(request)
        elif operation == "power":
            argv = self._power_argv(request)
        elif operation == "vpn-policy":
            argv = self._vpn_policy_argv(request)
        elif operation == "vpn-status":
            argv = self._vpn_status_argv(request)
        else:
            raise PrivilegedHelperError("unsupported_privileged_operation")
        try:
            completed = subprocess.run(
                argv, check=False, capture_output=True, text=True, timeout=timeout,
                stdin=subprocess.DEVNULL, env={"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LC_ALL": "C"},
            )
        except subprocess.TimeoutExpired as error:
            raise PrivilegedHelperError("privileged_operation_timeout") from error
        return HelperResponse(completed.returncode, _safe_text(completed.stdout), _safe_text(completed.stderr))

    def _authorize_peer(self, connection: socket.socket) -> None:
        if self.allowed_peer_uid is None:
            raise PrivilegedHelperError("privileged_helper_peer_policy_missing")
        if not hasattr(socket, "SO_PEERCRED"):
            raise PrivilegedHelperError("peer_credentials_unavailable")
        credentials = connection.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, struct.calcsize("3i"))
        _pid, uid, _gid = struct.unpack("3i", credentials)
        if uid != self.allowed_peer_uid:
            raise PrivilegedHelperError("privileged_helper_peer_denied")

    def _service_argv(self, request: Mapping[str, object]) -> list[str]:
        service, action = request.get("service"), request.get("action")
        if not isinstance(service, str) or not _SERVICE.fullmatch(service):
            raise PrivilegedHelperError("invalid_service")
        if service not in self.allowed_services:
            raise PrivilegedHelperError("service_not_allowed")
        if action not in _ALLOWED_SERVICE_ACTIONS:
            raise PrivilegedHelperError("service_action_not_allowed")
        if action == "status":
            return [str(self.systemctl_path), "show", service, "--property=LoadState,ActiveState,SubState,UnitFileState", "--value", "--no-pager"]
        return [str(self.systemctl_path), str(action), service, "--no-block", "--no-pager"]


    def _vpn_policy_argv(self, request: Mapping[str, object]) -> list[str]:
        policy = request.get("policy")
        if not isinstance(policy, str) or policy not in _ALLOWED_VPN_POLICIES:
            raise PrivilegedHelperError("invalid_vpn_policy")
        unknown = set(request) - {"operation", "policy", "timeout_seconds"}
        if unknown:
            raise PrivilegedHelperError("unexpected_vpn_policy_field")
        return [str(self.vpn_admin_path), "policy", policy]

    def _vpn_status_argv(self, request: Mapping[str, object]) -> list[str]:
        unknown = set(request) - {"operation", "timeout_seconds"}
        if unknown:
            raise PrivilegedHelperError("unexpected_vpn_status_field")
        return [str(self.vpn_admin_path), "status", "--json"]

    def _power_argv(self, request: Mapping[str, object]) -> list[str]:
        action, delay, force = request.get("action"), request.get("delay_seconds"), request.get("force")
        if action not in {"reboot", "poweroff"}:
            raise PrivilegedHelperError("invalid_power_action")
        if isinstance(delay, bool) or not isinstance(delay, int) or not 0 <= delay <= 3600:
            raise PrivilegedHelperError("invalid_power_delay")
        if not isinstance(force, bool):
            raise PrivilegedHelperError("invalid_power_force")
        systemctl = [str(self.systemctl_path), str(action)]
        if force:
            systemctl.append("--force")
        if delay == 0:
            return systemctl
        return [str(self.systemd_run_path), "--quiet", "--collect", f"--on-active={delay}s", "--property=Type=oneshot", "--", *systemctl]


def _request_from_argv(argv: tuple[str, ...], *, timeout_seconds: int) -> dict[str, object]:
    if len(argv) == 3 and argv[0] == _VPN_ADMIN_PATH and argv[1] == "policy" and argv[2] in _ALLOWED_VPN_POLICIES:
        return {"operation": "vpn-policy", "policy": argv[2], "timeout_seconds": timeout_seconds}
    if argv == (_VPN_ADMIN_PATH, "status", "--json"):
        return {"operation": "vpn-status", "timeout_seconds": timeout_seconds}
    if len(argv) >= 2 and argv[0] == "/usr/bin/systemctl" and argv[1] in {"reboot", "poweroff"}:
        return {"operation": "power", "action": argv[1], "delay_seconds": 0, "force": "--force" in argv[2:], "timeout_seconds": timeout_seconds}
    if len(argv) >= 8 and argv[:2] == ("/usr/bin/systemd-run", "--quiet") and "--" in argv:
        marker = argv.index("--")
        delay_arg = next((value for value in argv[:marker] if value.startswith("--on-active=") and value.endswith("s")), "")
        nested = argv[marker + 1:]
        if len(nested) >= 2 and nested[0] == "/usr/bin/systemctl" and nested[1] in {"reboot", "poweroff"} and delay_arg:
            return {"operation": "power", "action": nested[1], "delay_seconds": int(delay_arg[12:-1]), "force": "--force" in nested[2:], "timeout_seconds": timeout_seconds}
    if len(argv) >= 3 and argv[0] == "/usr/bin/systemctl":
        if argv[1] == "show":
            service, action = argv[2], "status"
        else:
            action, service = argv[1], argv[2]
        return {"operation": "service", "service": service, "action": action, "timeout_seconds": timeout_seconds}
    raise PrivilegedHelperError("unsupported_privileged_argv")


def _receive(connection: socket.socket, limit: int) -> bytes:
    chunks: list[bytes] = []
    size = 0
    while True:
        chunk = connection.recv(min(4096, limit + 1 - size))
        if not chunk:
            break
        chunks.append(chunk); size += len(chunk)
        if size > limit:
            raise PrivilegedHelperError("privileged_helper_message_too_large")
    return b"".join(chunks)


def _encode(payload: Mapping[str, object]) -> bytes:
    return json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")


def _parse_request(raw: bytes) -> Mapping[str, object]:
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeError, json.JSONDecodeError) as error:
        raise PrivilegedHelperError("invalid_privileged_helper_request") from error
    if not isinstance(payload, dict):
        raise PrivilegedHelperError("invalid_privileged_helper_request")
    return payload


def _parse_response(raw: bytes) -> HelperResponse:
    payload = _parse_request(raw)
    returncode, stdout, stderr = payload.get("returncode"), payload.get("stdout", ""), payload.get("stderr", "")
    if isinstance(returncode, bool) or not isinstance(returncode, int) or not isinstance(stdout, str) or not isinstance(stderr, str):
        raise PrivilegedHelperError("invalid_privileged_helper_response")
    return HelperResponse(returncode, stdout, stderr)


def _safe_text(value: str) -> str:
    return value.replace("\x00", "")[:4096]


def _xaac_agent_uid() -> int:
    try:
        return pwd.getpwnam("xaac-agent").pw_uid
    except KeyError as error:
        raise PrivilegedHelperError("xaac_agent_account_missing") from error


def main() -> int:
    allowed = frozenset(filter(None, os.environ.get("XAAC_HELPER_ALLOWED_SERVICES", "").split(",")))
    server = PrivilegedHelperServer(allowed_services=allowed, allowed_peer_uid=_xaac_agent_uid())
    listener = socket.socket(fileno=3)
    while True:
        connection, _ = listener.accept()
        with connection:
            server.serve_connection(connection)


if __name__ == "__main__":
    raise SystemExit(main())

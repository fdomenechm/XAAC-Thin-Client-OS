from __future__ import annotations

import contextlib
import contextvars
import json
import logging
import os
from datetime import datetime, timezone
from typing import Iterator, Mapping

from xaac_agent.secrets import SecretRedactionFilter, redact_text

_SCHEMA_VERSION = 1
_CORRELATION_ID: contextvars.ContextVar[str] = contextvars.ContextVar(
    "xaac_log_correlation_id", default=""
)
_RESERVED = frozenset(logging.makeLogRecord({}).__dict__) | {
    "message", "asctime", "event", "correlation_id"
}


class StructuredJsonFormatter(logging.Formatter):
    """Emit one bounded, deterministic JSON object for every log record."""

    def format(self, record: logging.LogRecord) -> str:
        try:
            message = redact_text(record.getMessage())
        except (TypeError, ValueError):
            message = redact_text(record.msg)
        event = getattr(record, "event", "") or _event_from_message(message)
        correlation_id = getattr(record, "correlation_id", "") or _CORRELATION_ID.get()
        payload: dict[str, object] = {
            "schema_version": _SCHEMA_VERSION,
            "timestamp": datetime.fromtimestamp(record.created, timezone.utc).isoformat(
                timespec="milliseconds"
            ).replace("+00:00", "Z"),
            "level": record.levelname.lower(),
            "logger": record.name,
            "event": _safe_scalar(event),
            "message": message,
            "process_id": record.process,
            "thread_name": record.threadName,
        }
        if correlation_id:
            payload["correlation_id"] = _safe_scalar(correlation_id)
        fields = _extra_fields(record)
        if fields:
            payload["fields"] = fields
        if record.exc_info:
            payload["exception"] = redact_text(self.formatException(record.exc_info))
        return json.dumps(payload, ensure_ascii=False, separators=(",", ":"), sort_keys=True)


class TextFormatter(logging.Formatter):
    def __init__(self) -> None:
        super().__init__("%(asctime)s %(levelname)s %(name)s %(message)s")


def configure_logging(*, level: str = "INFO", output_format: str = "json") -> None:
    normalized = output_format.strip().lower()
    if normalized not in {"json", "text"}:
        raise ValueError("log output format must be json or text")
    handler = logging.StreamHandler()
    handler.setFormatter(StructuredJsonFormatter() if normalized == "json" else TextFormatter())
    handler.addFilter(SecretRedactionFilter())
    root = logging.getLogger()
    root.handlers.clear()
    root.addHandler(handler)
    root.setLevel(getattr(logging, level.upper()))


@contextlib.contextmanager
def log_correlation(correlation_id: str) -> Iterator[None]:
    token = _CORRELATION_ID.set(_safe_scalar(correlation_id))
    try:
        yield
    finally:
        _CORRELATION_ID.reset(token)


def log_event(
    logger: logging.Logger,
    level: int,
    event: str,
    message: str,
    *,
    fields: Mapping[str, object] | None = None,
    correlation_id: str = "",
) -> None:
    extra: dict[str, object] = {"event": _safe_scalar(event)}
    if correlation_id:
        extra["correlation_id"] = _safe_scalar(correlation_id)
    if fields:
        for key, value in fields.items():
            safe_key = str(key).strip()
            if safe_key and safe_key not in _RESERVED and not safe_key.startswith("_"):
                extra[safe_key] = value
    logger.log(level, message, extra=extra)


def _event_from_message(message: str) -> str:
    candidate = message.split(" ", 1)[0].strip().lower()
    if candidate and all(character.isalnum() or character in "._-" for character in candidate):
        return candidate[:128]
    return "log_message"


def _safe_scalar(value: object) -> str:
    return redact_text(value).replace("\x00", "")[:512]


def _extra_fields(record: logging.LogRecord) -> dict[str, object]:
    fields: dict[str, object] = {}
    for key, value in record.__dict__.items():
        if key in _RESERVED or key.startswith("_"):
            continue
        if key in {"msg", "args", "exc_info", "exc_text", "stack_info"}:
            continue
        fields[key] = _safe_value(value)
    return fields


def _safe_value(value: object) -> object:
    if value is None or isinstance(value, (bool, int, float)):
        return value
    if isinstance(value, str):
        return _safe_scalar(value)
    if isinstance(value, (list, tuple)):
        return [_safe_value(item) for item in value[:32]]
    if isinstance(value, dict):
        return {
            str(key)[:128]: _safe_value(item)
            for key, item in list(value.items())[:32]
        }
    return _safe_scalar(value)

from __future__ import annotations

import json
import os
import stat
from dataclasses import dataclass
from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import Any

from xaac_agent.enrollment import canonical_json, utc_now

REGISTRATION_STATE_SCHEMA_VERSION = 1
_ALLOWED_STATUSES = frozenset({"active", "revoked", "unenrolled"})


class RegistrationStateError(RuntimeError):
    """Raised when the persisted registration state is invalid or unsafe."""


@dataclass(frozen=True, slots=True)
class RegistrationState:
    status: str
    changed_at: str
    reason: str | None = None
    reenrollment_authorized: bool = False
    schema_version: int = REGISTRATION_STATE_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.status not in _ALLOWED_STATUSES:
            raise RegistrationStateError("unsupported registration status")
        if not self.changed_at.strip():
            raise RegistrationStateError("registration changed_at is required")

    @property
    def blocks_enrollment(self) -> bool:
        return self.status in {"revoked", "unenrolled"} and not self.reenrollment_authorized

    def to_payload(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "schema_version": self.schema_version,
            "status": self.status,
            "changed_at": self.changed_at,
            "reenrollment_authorized": self.reenrollment_authorized,
        }
        if self.reason:
            payload["reason"] = self.reason
        return payload


class RegistrationStateStore:
    """Persist revocation/unenrollment state so it survives service restarts."""

    def __init__(self, path: Path) -> None:
        self._path = path

    @property
    def path(self) -> Path:
        return self._path

    def load(self) -> RegistrationState:
        self._validate_path()
        try:
            decoded = json.loads(self._path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return RegistrationState("active", utc_now())
        except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
            raise RegistrationStateError("cannot read registration state") from error
        if not isinstance(decoded, dict):
            raise RegistrationStateError("registration state must be a JSON object")
        try:
            state = RegistrationState(
                schema_version=int(decoded.get("schema_version", 0)),
                status=str(decoded["status"]),
                changed_at=str(decoded["changed_at"]),
                reason=str(decoded["reason"]) if decoded.get("reason") else None,
                reenrollment_authorized=bool(decoded.get("reenrollment_authorized", False)),
            )
        except (KeyError, TypeError, ValueError) as error:
            raise RegistrationStateError("registration state is incomplete") from error
        if state.schema_version != REGISTRATION_STATE_SCHEMA_VERSION:
            raise RegistrationStateError("unsupported registration state schema")
        self._ensure_private_permissions()
        return state

    def mark_revoked(self, reason: str | None = None) -> RegistrationState:
        state = RegistrationState("revoked", utc_now(), reason=reason)
        self.save(state)
        return state

    def mark_unenrolled(self, reason: str | None = None) -> RegistrationState:
        state = RegistrationState("unenrolled", utc_now(), reason=reason)
        self.save(state)
        return state

    def authorize_reenrollment(self) -> RegistrationState:
        current = self.load()
        state = RegistrationState(
            current.status,
            utc_now(),
            reason=current.reason,
            reenrollment_authorized=True,
        )
        self.save(state)
        return state

    def mark_active(self) -> RegistrationState:
        state = RegistrationState("active", utc_now())
        self.save(state)
        return state

    def save(self, state: RegistrationState) -> None:
        self._prepare_parent_directory()
        data = canonical_json(state.to_payload()) + b"\n"
        temporary_name: str | None = None
        try:
            with NamedTemporaryFile(
                "wb", dir=self._path.parent, prefix=".registration-", suffix=".tmp", delete=False
            ) as handle:
                temporary_name = handle.name
                handle.write(data)
                handle.flush()
                os.fsync(handle.fileno())
            os.chmod(temporary_name, 0o600)
            os.replace(temporary_name, self._path)
            temporary_name = None
            self._fsync_directory(self._path.parent)
            self._ensure_private_permissions()
        except OSError as error:
            raise RegistrationStateError("cannot persist registration state") from error
        finally:
            if temporary_name and os.path.exists(temporary_name):
                os.unlink(temporary_name)

    def _validate_path(self) -> None:
        try:
            metadata = self._path.lstat()
        except FileNotFoundError:
            return
        except OSError as error:
            raise RegistrationStateError("cannot inspect registration state") from error
        if stat.S_ISLNK(metadata.st_mode) or not stat.S_ISREG(metadata.st_mode):
            raise RegistrationStateError("registration state path must be a regular file")

    def _prepare_parent_directory(self) -> None:
        try:
            self._path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            if self._path.parent.is_symlink() or not self._path.parent.is_dir():
                raise RegistrationStateError("registration state parent must be a directory")
            mode = stat.S_IMODE(self._path.parent.stat().st_mode)
            if mode & 0o077:
                os.chmod(self._path.parent, mode & ~0o077)
        except RegistrationStateError:
            raise
        except OSError as error:
            raise RegistrationStateError("cannot prepare registration state directory") from error

    def _ensure_private_permissions(self) -> None:
        try:
            if self._path.exists() and stat.S_IMODE(self._path.stat().st_mode) != 0o600:
                os.chmod(self._path, 0o600)
        except OSError as error:
            raise RegistrationStateError("cannot enforce registration state permissions") from error

    @staticmethod
    def _fsync_directory(path: Path) -> None:
        descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)

from __future__ import annotations

import base64
import hashlib
import os
import subprocess
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Mapping, Protocol, Sequence

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from xaac_agent.command_model import Command, CommandResult, CommandState, CommandType


class SignedScriptBackend(Protocol):
    def run(self, argv: Sequence[str], *, timeout_seconds: int) -> subprocess.CompletedProcess[str]: ...


class SubprocessSignedScriptBackend:
    def run(self, argv: Sequence[str], *, timeout_seconds: int) -> subprocess.CompletedProcess[str]:
        return subprocess.run(list(argv), check=False, capture_output=True, text=True,
                              timeout=timeout_seconds, stdin=subprocess.DEVNULL)


@dataclass(frozen=True, slots=True)
class SignedScriptDefinition:
    script_id: str
    path: Path


def parse_signed_scripts(values: tuple[str, ...]) -> dict[str, SignedScriptDefinition]:
    result: dict[str, SignedScriptDefinition] = {}
    for value in values:
        script_id, separator, raw_path = value.partition("=")
        if not separator or not script_id.strip() or not raw_path.strip():
            raise ValueError(f"invalid_signed_script_definition:{value}")
        result[script_id.strip()] = SignedScriptDefinition(script_id.strip(), Path(raw_path.strip()))
    return result


def parse_trusted_script_keys(values: tuple[str, ...]) -> dict[str, Ed25519PublicKey]:
    result: dict[str, Ed25519PublicKey] = {}
    for value in values:
        key_id, separator, encoded = value.partition("=")
        if not separator or not key_id.strip() or not encoded.strip():
            raise ValueError(f"invalid_script_key_definition:{value}")
        try:
            raw = base64.b64decode(encoded.strip(), validate=True)
            result[key_id.strip()] = Ed25519PublicKey.from_public_bytes(raw)
        except (ValueError, TypeError) as error:
            raise ValueError(f"invalid_script_public_key:{key_id.strip()}") from error
    return result


@dataclass(frozen=True, slots=True)
class SignedScriptCommandExecutor:
    backend: SignedScriptBackend
    scripts: Mapping[str, SignedScriptDefinition]
    trusted_keys: Mapping[str, Ed25519PublicKey]
    max_script_bytes: int = 1024 * 1024

    @classmethod
    def system_default(cls, *, scripts: Mapping[str, SignedScriptDefinition],
                       trusted_keys: Mapping[str, Ed25519PublicKey], max_script_bytes: int = 1024 * 1024) -> "SignedScriptCommandExecutor":
        return cls(SubprocessSignedScriptBackend(), scripts, trusted_keys, max_script_bytes)

    def execute(self, command: Command) -> CommandResult:
        if command.command_type is not CommandType.SIGNED_SCRIPT:
            raise ValueError("unsupported_signed_script_command")
        started = _now()
        p = command.parameters
        script_id, key_id = str(p["script_id"]), str(p["key_id"])
        definition = self.scripts.get(script_id)
        key = self.trusted_keys.get(key_id)
        if definition is None:
            return self._failed(command, started, "signed_script_unavailable", script_id)
        if key is None:
            return self._failed(command, started, "script_signing_key_untrusted", key_id)
        path = definition.path
        try:
            st = path.lstat()
            if path.is_symlink():
                return self._failed(command, started, "signed_script_symlink", script_id)
            if not path.is_file():
                return self._failed(command, started, "signed_script_not_regular", script_id)
            if st.st_size < 1 or st.st_size > self.max_script_bytes:
                return self._failed(command, started, "signed_script_size_invalid", script_id)
            data = path.read_bytes()
        except OSError as error:
            return self._failed(command, started, "signed_script_read_error", script_id, str(error))
        digest = hashlib.sha256(data).hexdigest()
        if digest != str(p["sha256"]).lower():
            return self._failed(command, started, "signed_script_digest_mismatch", script_id)
        try:
            signature = base64.b64decode(str(p["signature"]), validate=True)
            key.verify(signature, data)
        except (ValueError, InvalidSignature):
            return self._failed(command, started, "signed_script_signature_invalid", script_id)
        if not os.access(path, os.X_OK):
            return self._failed(command, started, "signed_script_not_executable", script_id)
        try:
            completed = self.backend.run((str(path),), timeout_seconds=int(p.get("timeout_seconds", 300)))
        except subprocess.TimeoutExpired:
            return self._failed(command, started, "signed_script_timeout", script_id)
        except OSError as error:
            return self._failed(command, started, "signed_script_backend_error", script_id, str(error))
        if completed.returncode != 0:
            return self._failed(command, started, "signed_script_failed", script_id, _safe(completed.stderr or completed.stdout))
        return CommandResult(command_id=command.command_id, state=CommandState.SUCCEEDED,
                             started_at=started, finished_at=_now(), code="signed_script_completed",
                             data={"script_id": script_id, "key_id": key_id, "sha256": digest})

    @staticmethod
    def _failed(command: Command, started: str, code: str, subject: str, detail: str | None = None) -> CommandResult:
        data = {"subject": subject}
        if detail: data["detail"] = _safe(detail)
        return CommandResult(command_id=command.command_id, state=CommandState.FAILED,
                             started_at=started, finished_at=_now(), code=code, data=data)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

def _safe(value: str) -> str:
    return " ".join(value.replace("\x00", " ").split())[:512]

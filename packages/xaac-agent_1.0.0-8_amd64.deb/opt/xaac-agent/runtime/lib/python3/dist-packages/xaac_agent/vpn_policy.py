from __future__ import annotations

import json
import subprocess
from dataclasses import dataclass
from typing import Mapping

from xaac_agent.privileged_helper import PrivilegedHelperClient, PrivilegedHelperError

VPN_ADMIN = "/usr/local/sbin/xaac-vpn-admin"
VALID_VPN_POLICIES = frozenset({"disabled", "optional", "required"})
VPN_STATUS_SCHEMA = "xaac-vpn-status/v1"


class VpnPolicyError(RuntimeError):
    def __init__(self, code: str) -> None:
        super().__init__(code)
        self.code = code


@dataclass(frozen=True, slots=True)
class VpnStatus:
    policy: str
    profile_name: str
    profile_provisioned: bool
    profile_valid: bool
    manager_state: str
    connected: bool

    @classmethod
    def from_payload(cls, payload: Mapping[str, object]) -> "VpnStatus":
        if payload.get("schema") != VPN_STATUS_SCHEMA:
            raise VpnPolicyError("vpn_status_schema_unsupported")
        policy = payload.get("policy")
        profile = payload.get("profile")
        manager = payload.get("manager")
        session = payload.get("session")
        if policy not in VALID_VPN_POLICIES:
            raise VpnPolicyError("vpn_status_policy_invalid")
        if not isinstance(profile, Mapping) or not isinstance(manager, Mapping) or not isinstance(session, Mapping):
            raise VpnPolicyError("vpn_status_structure_invalid")
        name = profile.get("name")
        provisioned = profile.get("provisioned")
        valid = profile.get("valid")
        state = manager.get("state")
        connected = session.get("connected")
        if not isinstance(name, str) or not name or len(name) > 256:
            raise VpnPolicyError("vpn_status_profile_name_invalid")
        if not isinstance(provisioned, bool) or not isinstance(valid, bool):
            raise VpnPolicyError("vpn_status_profile_state_invalid")
        if not isinstance(state, str) or not state or len(state) > 128:
            raise VpnPolicyError("vpn_status_manager_state_invalid")
        if not isinstance(connected, bool):
            raise VpnPolicyError("vpn_status_session_state_invalid")
        return cls(str(policy), name, provisioned, valid, state, connected)

    def to_payload(self) -> dict[str, object]:
        return {
            "schema": VPN_STATUS_SCHEMA,
            "policy": self.policy,
            "profile": {
                "name": self.profile_name,
                "provisioned": self.profile_provisioned,
                "valid": self.profile_valid,
            },
            "manager": {"state": self.manager_state},
            "session": {"connected": self.connected},
        }


@dataclass(frozen=True, slots=True)
class VpnPolicyController:
    backend: object
    timeout_seconds: int = 30

    @classmethod
    def system_default(cls) -> "VpnPolicyController":
        return cls(PrivilegedHelperClient())

    def status(self) -> VpnStatus:
        result = self._run((VPN_ADMIN, "status", "--json"))
        try:
            payload = json.loads(result.stdout)
        except (TypeError, json.JSONDecodeError) as error:
            raise VpnPolicyError("vpn_status_invalid_json") from error
        if not isinstance(payload, dict):
            raise VpnPolicyError("vpn_status_invalid_document")
        return VpnStatus.from_payload(payload)

    def apply(self, policy: str) -> VpnStatus:
        if policy not in VALID_VPN_POLICIES:
            raise VpnPolicyError("vpn_policy_invalid")
        self._run((VPN_ADMIN, "policy", policy))
        status = self.status()
        if status.policy != policy:
            raise VpnPolicyError("vpn_policy_postcondition_failed")
        return status

    def _run(self, argv: tuple[str, ...]) -> subprocess.CompletedProcess[str]:
        try:
            result = self.backend.run(argv, timeout_seconds=self.timeout_seconds)
        except subprocess.TimeoutExpired as error:
            raise VpnPolicyError("vpn_privileged_operation_timeout") from error
        except PrivilegedHelperError as error:
            raise VpnPolicyError(str(error)) from error
        except OSError as error:
            raise VpnPolicyError("vpn_privileged_operation_unavailable") from error
        if not isinstance(result, subprocess.CompletedProcess):
            raise VpnPolicyError("vpn_privileged_operation_invalid_result")
        if result.returncode != 0:
            raise VpnPolicyError("vpn_privileged_operation_failed")
        return result

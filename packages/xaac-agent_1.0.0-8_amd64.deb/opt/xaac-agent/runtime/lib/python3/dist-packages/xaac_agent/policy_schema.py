from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Callable, Mapping

from .policy_model import Policy, PolicyResult, PolicyState, PolicyType


class PolicySchemaError(ValueError):
    """La política no compleix un esquema local conegut."""

    def __init__(self, code: str, *, path: str = "", message: str | None = None) -> None:
        super().__init__(code)
        self.code = code
        self.path = path
        self.message = message


@dataclass(frozen=True, slots=True)
class ValidationIssue:
    code: str
    path: str
    message: str | None = None

    def to_payload(self) -> dict[str, str]:
        payload = {"code": self.code, "path": self.path}
        if self.message:
            payload["message"] = self.message
        return payload


@dataclass(frozen=True, slots=True)
class ValidatedPolicy:
    policy: Policy
    schema_id: str
    schema_revision: int
    normalized_sections: dict[str, Any]
    warnings: tuple[ValidationIssue, ...] = ()

    @property
    def result(self) -> PolicyResult:
        return PolicyResult(
            policy_id=self.policy.policy_id,
            revision=self.policy.revision,
            state=PolicyState.VALIDATED,
            code="policy_schema_valid",
            data={
                "schema_id": self.schema_id,
                "schema_revision": self.schema_revision,
                "warnings": [item.to_payload() for item in self.warnings],
            },
        )


@dataclass(frozen=True, slots=True)
class FieldRule:
    types: tuple[type, ...]
    required: bool = False
    minimum: int | float | None = None
    maximum: int | float | None = None
    choices: frozenset[Any] | None = None
    pattern: re.Pattern[str] | None = None
    item_types: tuple[type, ...] | None = None
    max_items: int | None = None


@dataclass(frozen=True, slots=True)
class SectionRule:
    fields: Mapping[str, FieldRule] = field(default_factory=dict)
    allow_unknown_fields: bool = False
    validator: Callable[[Mapping[str, Any]], None] | None = None


@dataclass(frozen=True, slots=True)
class PolicySchema:
    schema_id: str
    revision: int
    policy_type: PolicyType
    sections: Mapping[str, SectionRule]
    required_sections: frozenset[str] = frozenset()
    allow_unknown_sections: bool = False


class PolicySchemaRegistry:
    def __init__(self, schemas: tuple[PolicySchema, ...] | None = None) -> None:
        values = schemas or default_policy_schemas()
        self._schemas: dict[tuple[PolicyType, int], PolicySchema] = {}
        for schema in values:
            key = (schema.policy_type, schema.revision)
            if key in self._schemas:
                raise ValueError("duplicate_policy_schema")
            self._schemas[key] = schema

    def validate(self, policy: Policy) -> ValidatedPolicy:
        requested_revision = policy.metadata.get("content_schema_revision", 1)
        if isinstance(requested_revision, bool) or not isinstance(requested_revision, int) or requested_revision < 1:
            raise PolicySchemaError("invalid_content_schema_revision", path="metadata.content_schema_revision")
        schema = self._schemas.get((policy.policy_type, requested_revision))
        if schema is None:
            raise PolicySchemaError("unsupported_content_schema", path="metadata.content_schema_revision")

        unknown_sections = set(policy.sections) - set(schema.sections)
        if unknown_sections and not schema.allow_unknown_sections:
            name = sorted(unknown_sections)[0]
            raise PolicySchemaError("unknown_policy_section", path=f"sections.{name}")
        missing_sections = schema.required_sections - set(policy.sections)
        if missing_sections:
            name = sorted(missing_sections)[0]
            raise PolicySchemaError("missing_required_section", path=f"sections.{name}")

        normalized: dict[str, Any] = {}
        for name, raw_section in policy.sections.items():
            rule = schema.sections.get(name)
            if rule is None:
                normalized[name] = raw_section
                continue
            normalized[name] = _validate_section(name, raw_section, rule)
        return ValidatedPolicy(policy, schema.schema_id, schema.revision, normalized)

    def validate_result(self, policy: Policy) -> PolicyResult:
        try:
            return self.validate(policy).result
        except PolicySchemaError as error:
            data: dict[str, Any] = {"path": error.path}
            if error.message:
                data["detail"] = error.message
            return PolicyResult(
                policy_id=policy.policy_id,
                revision=policy.revision,
                state=PolicyState.REJECTED,
                code=error.code,
                data=data,
            )


def _validate_section(name: str, value: Any, rule: SectionRule) -> dict[str, Any]:
    path = f"sections.{name}"
    if not isinstance(value, Mapping):
        raise PolicySchemaError("invalid_section_type", path=path)
    unknown = set(value) - set(rule.fields)
    if unknown and not rule.allow_unknown_fields:
        field_name = sorted(unknown)[0]
        raise PolicySchemaError("unknown_policy_field", path=f"{path}.{field_name}")
    for field_name, field_rule in rule.fields.items():
        if field_rule.required and field_name not in value:
            raise PolicySchemaError("missing_required_field", path=f"{path}.{field_name}")
    normalized: dict[str, Any] = {}
    for field_name, field_value in value.items():
        field_rule = rule.fields.get(field_name)
        if field_rule is None:
            normalized[field_name] = field_value
            continue
        normalized[field_name] = _validate_field(field_value, field_rule, f"{path}.{field_name}")
    if rule.validator is not None:
        try:
            rule.validator(normalized)
        except PolicySchemaError:
            raise
        except ValueError as error:
            raise PolicySchemaError("section_constraint_failed", path=path, message=str(error)) from error
    return normalized


def _validate_field(value: Any, rule: FieldRule, path: str) -> Any:
    # bool és subclass d'int; no s'ha d'acceptar com a enter.
    if isinstance(value, bool) and bool not in rule.types:
        raise PolicySchemaError("invalid_field_type", path=path)
    if not isinstance(value, rule.types):
        raise PolicySchemaError("invalid_field_type", path=path)
    if rule.minimum is not None and value < rule.minimum:
        raise PolicySchemaError("field_below_minimum", path=path)
    if rule.maximum is not None and value > rule.maximum:
        raise PolicySchemaError("field_above_maximum", path=path)
    if rule.choices is not None and value not in rule.choices:
        raise PolicySchemaError("invalid_field_value", path=path)
    if rule.pattern is not None and isinstance(value, str) and not rule.pattern.fullmatch(value):
        raise PolicySchemaError("invalid_field_format", path=path)
    if isinstance(value, list):
        if rule.max_items is not None and len(value) > rule.max_items:
            raise PolicySchemaError("field_list_too_large", path=path)
        if rule.item_types is not None:
            for index, item in enumerate(value):
                if isinstance(item, bool) and bool not in rule.item_types:
                    raise PolicySchemaError("invalid_list_item_type", path=f"{path}[{index}]")
                if not isinstance(item, rule.item_types):
                    raise PolicySchemaError("invalid_list_item_type", path=f"{path}[{index}]")
    return value


def _timeout_order(section: Mapping[str, Any]) -> None:
    connect = section.get("connect_timeout_seconds")
    request = section.get("request_timeout_seconds")
    if connect is not None and request is not None and connect > request:
        raise PolicySchemaError(
            "section_constraint_failed",
            path="sections.transport.connect_timeout_seconds",
            message="connect_timeout_exceeds_request_timeout",
        )


def default_policy_schemas() -> tuple[PolicySchema, ...]:
    integer = (int,)
    string = (str,)
    boolean = (bool,)
    identifier = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$")

    agent = PolicySchema(
        schema_id="xaac-agent-policy",
        revision=1,
        policy_type=PolicyType.AGENT,
        sections={
            "agent": SectionRule({
                "heartbeat_interval_seconds": FieldRule(integer, minimum=10, maximum=3600),
                "inventory_interval_seconds": FieldRule(integer, minimum=60, maximum=86400),
                "enabled": FieldRule(boolean),
            }),
            "heartbeat": SectionRule({
                "interval_seconds": FieldRule(integer, minimum=10, maximum=3600),
                "include_health": FieldRule(boolean),
            }),
            "commands": SectionRule({
                "allowed": FieldRule(boolean),
                "allowed_types": FieldRule((list,), item_types=string, max_items=32),
                "max_per_response": FieldRule(integer, minimum=1, maximum=64),
                "max_timeout_seconds": FieldRule(integer, minimum=1, maximum=3600),
            }),
            "monitoring": SectionRule({
                "enabled": FieldRule(boolean),
                "interval_seconds": FieldRule(integer, minimum=10, maximum=3600),
                "cpu_warning_percent": FieldRule(integer, minimum=1, maximum=100),
                "memory_warning_percent": FieldRule(integer, minimum=1, maximum=100),
            }),
            "transport": SectionRule({
                "connect_timeout_seconds": FieldRule(integer, minimum=1, maximum=300),
                "request_timeout_seconds": FieldRule(integer, minimum=1, maximum=600),
                "compression": FieldRule(string, choices=frozenset({"none", "gzip"})),
            }, validator=_timeout_order),
            "inventory": SectionRule({
                "enabled": FieldRule(boolean),
                "providers": FieldRule((list,), item_types=string, max_items=64),
            }),
        },
    )
    thin_client = PolicySchema(
        schema_id="xaac-thin-client-policy",
        revision=1,
        policy_type=PolicyType.THIN_CLIENT,
        sections={
            "thin-client": SectionRule({"enabled": FieldRule(boolean), "profile": FieldRule(string, pattern=identifier)}),
            "rdp": SectionRule({
                "server": FieldRule(string, required=True),
                "port": FieldRule(integer, minimum=1, maximum=65535),
                "fullscreen": FieldRule(boolean),
                "security": FieldRule(string, choices=frozenset({"auto", "tls", "nla"})),
            }),
            "display": SectionRule({"scale_percent": FieldRule(integer, minimum=50, maximum=300), "multimonitor": FieldRule(boolean)}),
            "input": SectionRule({"keyboard_layout": FieldRule(string, pattern=identifier)}),
            "peripherals": SectionRule({"clipboard": FieldRule(boolean), "audio": FieldRule(boolean), "usb": FieldRule(boolean)}),
            "kiosk": SectionRule({"enabled": FieldRule(boolean), "allow_local_exit": FieldRule(boolean)}),
        },
    )
    system_sections = {
        "system": SectionRule({"hostname": FieldRule(string, pattern=identifier), "timezone": FieldRule(string)}),
        "network": SectionRule({"managed": FieldRule(boolean), "interface": FieldRule(string, pattern=identifier)}),
        "time": SectionRule({"servers": FieldRule((list,), item_types=string, max_items=8), "enabled": FieldRule(boolean)}),
        "services": SectionRule({"enabled": FieldRule((list,), item_types=string, max_items=32), "disabled": FieldRule((list,), item_types=string, max_items=32)}),
        "maintenance": SectionRule({"window": FieldRule(string), "allow_reboot": FieldRule(boolean)}),
    }
    system = PolicySchema(
        schema_id="xaac-system-policy",
        revision=1,
        policy_type=PolicyType.SYSTEM,
        sections=system_sections,
    )
    system_v2 = PolicySchema(
        schema_id="xaac-system-policy",
        revision=2,
        policy_type=PolicyType.SYSTEM,
        sections={
            **system_sections,
            "vpn": SectionRule({
                "mode": FieldRule(string, required=True, choices=frozenset({"disabled", "optional", "required"})),
            }),
        },
    )
    return agent, thin_client, system, system_v2

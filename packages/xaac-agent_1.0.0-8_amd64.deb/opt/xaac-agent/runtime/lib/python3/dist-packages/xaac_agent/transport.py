from __future__ import annotations

import gzip
import json
import socket
import ssl
from http.client import HTTPSConnection
from dataclasses import dataclass
from enum import Enum
from threading import Event
from typing import Any, Callable
from urllib.error import HTTPError, URLError
from urllib.request import HTTPSHandler, ProxyHandler, Request, build_opener, urlopen

from xaac_agent.tls_policy import TlsPolicy, TlsPolicyError, verify_certificate_pin

from xaac_agent.config import AgentSettings


class TransportErrorCategory(str, Enum):
    HTTP = "http"
    TIMEOUT = "timeout"
    DNS = "dns"
    TLS = "tls"
    CONNECTION = "connection"
    CANCELLED = "cancelled"
    RESPONSE_TOO_LARGE = "response_too_large"
    PROTOCOL = "protocol"
    UNKNOWN = "unknown"


class AgentTransportError(RuntimeError):
    """Error classificat de comunicació amb XAAC Management Server."""

    def __init__(self, message: str, *, status: int | None = None, error_code: str | None = None,
                 category: TransportErrorCategory = TransportErrorCategory.UNKNOWN,
                 retryable: bool | None = None, retry_after_seconds: float | None = None) -> None:
        super().__init__(message)
        self.status = status
        self.error_code = error_code
        self.category = category
        self.retryable = self._default_retryable() if retryable is None else retryable
        self.retry_after_seconds = retry_after_seconds

    def _default_retryable(self) -> bool:
        if self.category in {TransportErrorCategory.TIMEOUT, TransportErrorCategory.DNS, TransportErrorCategory.CONNECTION}:
            return True
        if self.category is TransportErrorCategory.HTTP:
            return self.status in {408, 425, 429} or (self.status is not None and self.status >= 500)
        return False

    @property
    def credential_revoked(self) -> bool:
        return self.status in {401, 403} and self.error_code == "credential_revoked"


@dataclass(frozen=True, slots=True)
class TransportResponse:
    status: int
    payload: dict[str, Any]


UrlOpen = Callable[..., Any]


class _PinnedHTTPSConnection(HTTPSConnection):
    def __init__(self, *args: Any, certificate_pins: tuple[str, ...] = (), **kwargs: Any) -> None:
        self._certificate_pins = certificate_pins
        super().__init__(*args, **kwargs)

    def connect(self) -> None:
        super().connect()
        if not self._certificate_pins:
            return
        if self.sock is None:
            raise ssl.SSLError("TLS socket unavailable for pin verification")
        try:
            certificate_der = self.sock.getpeercert(binary_form=True)
            verify_certificate_pin(certificate_der, self._certificate_pins)
        except TlsPolicyError as error:
            try:
                self.close()
            finally:
                raise ssl.SSLError(str(error)) from error


class _PinnedHTTPSHandler(HTTPSHandler):
    def __init__(self, *, context: ssl.SSLContext, certificate_pins: tuple[str, ...]) -> None:
        super().__init__(context=context)
        self._certificate_pins = certificate_pins

    def https_open(self, req: Request) -> Any:
        def connection_factory(host: str, **kwargs: Any) -> _PinnedHTTPSConnection:
            kwargs["context"] = self._context
            kwargs["certificate_pins"] = self._certificate_pins
            return _PinnedHTTPSConnection(host, **kwargs)

        return self.do_open(connection_factory, req)


class XmpTransport:
    def __init__(self, opener: UrlOpen | None = None, cancellation_event: Event | None = None) -> None:
        self._opener = opener
        self._cancellation_event = cancellation_event or Event()

    def cancel(self) -> None:
        self._cancellation_event.set()

    def reset_cancellation(self) -> None:
        self._cancellation_event.clear()

    def send_enrollment(self, payload: dict[str, Any], settings: AgentSettings, enrollment_token: str) -> TransportResponse:
        return self._post_json(f"{settings.server_url}/api/xmp/v1/enrollments", payload, settings, authorization=enrollment_token)

    def renew_credentials(self, payload: dict[str, Any], settings: AgentSettings, device_credential: str) -> TransportResponse:
        return self._post_json(f"{settings.server_url}/api/xmp/v1/credentials/renew", payload, settings, authorization=device_credential)

    def send_unenrollment(self, payload: dict[str, Any], settings: AgentSettings, device_credential: str) -> TransportResponse:
        return self._post_json(f"{settings.server_url}/api/xmp/v1/devices/unenroll", payload, settings, authorization=device_credential)

    def send_heartbeat(self, payload: dict[str, Any], settings: AgentSettings, device_credential: str | None) -> TransportResponse:
        return self._post_json(f"{settings.server_url}/api/xmp/v1/heartbeats", payload, settings, authorization=device_credential)

    def _post_json(self, url: str, payload: dict[str, Any], settings: AgentSettings, *, authorization: str | None) -> TransportResponse:
        self._raise_if_cancelled()
        raw_body = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
        request_body = raw_body
        headers = {"Content-Type": "application/json", "Accept": "application/json",
                   "User-Agent": "XAAC-Agent/0.3 XMP/1.0"}
        if settings.compression_enabled:
            headers["Accept-Encoding"] = "gzip"
            if len(raw_body) >= settings.compression_threshold_bytes:
                request_body = gzip.compress(raw_body, mtime=0)
                headers["Content-Encoding"] = "gzip"
        if authorization:
            headers["Authorization"] = f"Bearer {authorization}"
        request = Request(url, data=request_body, headers=headers, method="POST")
        context = self._ssl_context(settings) if settings.server_url.startswith("https://") else None
        try:
            with self._open(request, settings, context) as response:
                status = int(getattr(response, "status", 200))
                body = self._read_response(response, settings)
        except HTTPError as error:
            body = self._read_response(error, settings, tolerate_oversize=True)
            error_code = self._decode_error_code(body)
            retry_after = self._parse_retry_after(getattr(error, "headers", None))
            raise AgentTransportError(f"XMS ha retornat HTTP {error.code}", status=int(error.code), error_code=error_code,
                                      category=TransportErrorCategory.HTTP, retry_after_seconds=retry_after) from error
        except AgentTransportError:
            raise
        except (socket.timeout, TimeoutError) as error:
            raise AgentTransportError("Temps d'espera de comunicació esgotat", category=TransportErrorCategory.TIMEOUT) from error
        except ssl.SSLError as error:
            raise AgentTransportError(f"Error TLS: {error}", category=TransportErrorCategory.TLS) from error
        except URLError as error:
            reason = error.reason
            if isinstance(reason, (socket.timeout, TimeoutError)): category = TransportErrorCategory.TIMEOUT
            elif isinstance(reason, ssl.SSLError): category = TransportErrorCategory.TLS
            elif isinstance(reason, socket.gaierror): category = TransportErrorCategory.DNS
            else: category = TransportErrorCategory.CONNECTION
            raise AgentTransportError(f"No s'ha pogut connectar amb XMS: {reason}", category=category) from error
        except (ConnectionError, OSError) as error:
            category = TransportErrorCategory.DNS if isinstance(error, socket.gaierror) else TransportErrorCategory.CONNECTION
            raise AgentTransportError(f"Error de connexió amb XMS: {error}", category=category) from error
        except Exception as error:
            raise AgentTransportError(str(error), category=TransportErrorCategory.UNKNOWN) from error

        self._raise_if_cancelled()
        if not 200 <= status < 300:
            raise AgentTransportError(f"XMS ha retornat HTTP {status}", status=status, category=TransportErrorCategory.HTTP)
        if not body:
            return TransportResponse(status=status, payload={})
        try:
            decoded = json.loads(body.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise AgentTransportError("Resposta JSON no vàlida", category=TransportErrorCategory.PROTOCOL) from error
        if not isinstance(decoded, dict):
            raise AgentTransportError("Resposta XMP no vàlida", category=TransportErrorCategory.PROTOCOL)
        authentication = payload.get("xmp_authentication")
        if isinstance(authentication, dict):
            expected_request_id = authentication.get("request_id")
            if decoded.get("request_id") != expected_request_id:
                raise AgentTransportError("La resposta XMP no correspon amb la petició", error_code="request_id_mismatch",
                                          category=TransportErrorCategory.PROTOCOL)
        return TransportResponse(status=status, payload=decoded)

    def _read_response(self, response: Any, settings: AgentSettings, *, tolerate_oversize: bool = False) -> bytes:
        body = self._read_limited(response, settings.max_response_bytes, tolerate_oversize=tolerate_oversize)
        encoding = ""
        headers = getattr(response, "headers", None)
        if headers is not None:
            encoding = str(headers.get("Content-Encoding", "")).strip().lower()
        if not encoding:
            return body
        if encoding != "gzip":
            raise AgentTransportError(f"Codificació de resposta no suportada: {encoding}", category=TransportErrorCategory.PROTOCOL)
        try:
            decoded = gzip.decompress(body)
        except (OSError, EOFError) as error:
            raise AgentTransportError("Resposta gzip no vàlida", category=TransportErrorCategory.PROTOCOL) from error
        if len(decoded) > settings.max_decompressed_response_bytes:
            raise AgentTransportError(
                f"La resposta descomprimida supera el límit de {settings.max_decompressed_response_bytes} bytes",
                category=TransportErrorCategory.RESPONSE_TOO_LARGE,
            )
        return decoded

    def _ssl_context(self, settings: AgentSettings) -> ssl.SSLContext:
        cafile = str(settings.tls_ca_file) if settings.tls_ca_file is not None else None
        try:
            return TlsPolicy(
                minimum_version=settings.tls_minimum_version,
                maximum_version=settings.tls_maximum_version,
                ciphers=settings.tls_ciphers,
                certificate_pins=settings.tls_certificate_pins,
            ).create_context(cafile=cafile)
        except (OSError, ssl.SSLError, TlsPolicyError) as error:
            raise AgentTransportError(f"No s'ha pogut carregar la confiança TLS: {error}", category=TransportErrorCategory.TLS) from error

    def _open(self, request: Request, settings: AgentSettings, context: ssl.SSLContext | None) -> Any:
        if self._opener is not None:
            return self._opener(request, timeout=settings.request_timeout_seconds, context=context)
        if settings.proxy_url:
            handlers: list[Any] = [ProxyHandler({"http": settings.proxy_url, "https": settings.proxy_url})]
            if context is not None:
                handlers.append(_PinnedHTTPSHandler(context=context, certificate_pins=settings.tls_certificate_pins))
            return build_opener(*handlers).open(request, timeout=settings.request_timeout_seconds)
        if context is not None and settings.tls_certificate_pins:
            return build_opener(_PinnedHTTPSHandler(context=context, certificate_pins=settings.tls_certificate_pins)).open(
                request, timeout=settings.request_timeout_seconds
            )
        return urlopen(request, timeout=settings.request_timeout_seconds, context=context)

    def _read_limited(self, response: Any, limit: int, *, tolerate_oversize: bool = False) -> bytes:
        self._raise_if_cancelled()
        body = response.read(limit + 1)
        self._raise_if_cancelled()
        if len(body) > limit:
            if tolerate_oversize: return body[:limit]
            raise AgentTransportError(f"La resposta de XMS supera el límit de {limit} bytes",
                                      category=TransportErrorCategory.RESPONSE_TOO_LARGE)
        return body


    @staticmethod
    def _parse_retry_after(headers: Any) -> float | None:
        if headers is None:
            return None
        value = headers.get("Retry-After")
        if value is None:
            return None
        try:
            seconds = float(str(value).strip())
        except ValueError:
            return None
        return max(0.0, seconds)

    @staticmethod
    def _decode_error_code(body: bytes) -> str | None:
        try: decoded = json.loads(body.decode("utf-8")) if body else {}
        except (UnicodeDecodeError, json.JSONDecodeError): return None
        return decoded.get("error") if isinstance(decoded, dict) and isinstance(decoded.get("error"), str) else None

    def _raise_if_cancelled(self) -> None:
        if self._cancellation_event.is_set():
            raise AgentTransportError("Operació de xarxa cancel·lada", category=TransportErrorCategory.CANCELLED)

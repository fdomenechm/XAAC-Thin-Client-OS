from __future__ import annotations

import base64
import hashlib
import hmac
import ssl
from dataclasses import dataclass
from typing import Iterable


class TlsPolicyError(ValueError):
    """Invalid local TLS policy or failed certificate pin verification."""


_TLS_VERSIONS = {
    "TLSv1.2": ssl.TLSVersion.TLSv1_2,
    "TLSv1.3": ssl.TLSVersion.TLSv1_3,
}


def parse_tls_version(value: str, *, allow_empty: bool = False) -> ssl.TLSVersion | None:
    normalized = value.strip()
    if allow_empty and not normalized:
        return None
    try:
        return _TLS_VERSIONS[normalized]
    except KeyError as error:
        raise TlsPolicyError("unsupported TLS version") from error


def normalize_certificate_pin(value: str) -> str:
    pin = value.strip()
    if pin.startswith("sha256/"):
        encoded = pin[7:]
    else:
        encoded = pin
    try:
        digest = base64.b64decode(encoded, validate=True)
    except (ValueError, base64.binascii.Error) as error:
        raise TlsPolicyError("invalid SHA-256 certificate pin") from error
    if len(digest) != hashlib.sha256().digest_size:
        raise TlsPolicyError("invalid SHA-256 certificate pin length")
    return "sha256/" + base64.b64encode(digest).decode("ascii")


def certificate_pin(certificate_der: bytes) -> str:
    if not certificate_der:
        raise TlsPolicyError("peer did not provide a certificate")
    return "sha256/" + base64.b64encode(hashlib.sha256(certificate_der).digest()).decode("ascii")


def verify_certificate_pin(certificate_der: bytes, configured_pins: Iterable[str]) -> str:
    actual = certificate_pin(certificate_der)
    normalized = tuple(normalize_certificate_pin(pin) for pin in configured_pins)
    if not normalized:
        return actual
    if not any(hmac.compare_digest(actual, expected) for expected in normalized):
        raise TlsPolicyError("TLS certificate pin mismatch")
    return actual


@dataclass(frozen=True, slots=True)
class TlsPolicy:
    minimum_version: str = "TLSv1.2"
    maximum_version: str = ""
    ciphers: str = ""
    certificate_pins: tuple[str, ...] = ()

    def validate(self) -> None:
        minimum = parse_tls_version(self.minimum_version)
        maximum = parse_tls_version(self.maximum_version, allow_empty=True)
        if maximum is not None and minimum is not None and maximum < minimum:
            raise TlsPolicyError("TLS maximum version is lower than minimum version")
        normalized = tuple(normalize_certificate_pin(pin) for pin in self.certificate_pins)
        if len(set(normalized)) != len(normalized):
            raise TlsPolicyError("duplicate TLS certificate pin")
        if len(normalized) > 8:
            raise TlsPolicyError("too many TLS certificate pins")
        if self.ciphers:
            context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
            try:
                context.set_ciphers(self.ciphers)
            except ssl.SSLError as error:
                raise TlsPolicyError("invalid TLS cipher configuration") from error

    def create_context(self, *, cafile: str | None = None) -> ssl.SSLContext:
        self.validate()
        context = ssl.create_default_context(cafile=cafile)
        context.minimum_version = parse_tls_version(self.minimum_version) or ssl.TLSVersion.TLSv1_2
        maximum = parse_tls_version(self.maximum_version, allow_empty=True)
        if maximum is not None:
            context.maximum_version = maximum
        if self.ciphers:
            context.set_ciphers(self.ciphers)
        context.check_hostname = True
        context.verify_mode = ssl.CERT_REQUIRED
        return context

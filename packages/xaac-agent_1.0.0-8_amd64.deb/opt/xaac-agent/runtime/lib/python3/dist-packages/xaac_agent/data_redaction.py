from __future__ import annotations

import argparse
import hashlib
import ipaddress
import json
import os
import re
import stat
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Mapping
from urllib.parse import urlsplit, urlunsplit


class DataRedactionError(ValueError):
    pass


_SENSITIVE_KEY_RE = re.compile(
    r"(?i)(?:^|[_-])(authorization|password|passwd|secret|token|api[_-]?key|"
    r"client[_-]?secret|access[_-]?token|refresh[_-]?token|credential|private[_-]?key)(?:$|[_-])"
)
_BEARER_RE = re.compile(r"(?i)(\bauthorization\s*[:=]\s*bearer\s+|\bbearer\s+)([^\s,;]+)")
_ASSIGNMENT_RE = re.compile(
    r"(?i)\b(password|passwd|secret|token|api[_-]?key|client[_-]?secret|access[_-]?token|"
    r"refresh[_-]?token|credential)\s*[:=]\s*([^\s,;]+)"
)
_EMAIL_RE = re.compile(r"(?<![\w.+-])([A-Z0-9._%+-]+)@([A-Z0-9.-]+\.[A-Z]{2,})(?![\w.-])", re.I)
_MAC_RE = re.compile(r"(?i)(?<![0-9a-f])(?:[0-9a-f]{2}:){5}[0-9a-f]{2}(?![0-9a-f])")
_PRIVATE_KEY_RE = re.compile(r"-----BEGIN (?:[A-Z0-9 ]+ )?PRIVATE KEY-----[\s\S]*?-----END (?:[A-Z0-9 ]+ )?PRIVATE KEY-----")
_URL_RE = re.compile(r"\bhttps?://[^\s\"'<>]+", re.I)


@dataclass(frozen=True, slots=True)
class RedactionPolicy:
    redact_secrets: bool = True
    pseudonymize_email: bool = True
    pseudonymize_mac: bool = True
    pseudonymize_public_ip: bool = True
    preserve_private_ip: bool = True
    max_depth: int = 16
    max_items: int = 10000

    def validate(self) -> None:
        if not 1 <= self.max_depth <= 64:
            raise DataRedactionError("redaction_max_depth_out_of_range")
        if not 1 <= self.max_items <= 100000:
            raise DataRedactionError("redaction_max_items_out_of_range")


@dataclass(slots=True)
class RedactionReport:
    secret_values: int = 0
    emails: int = 0
    mac_addresses: int = 0
    public_ip_addresses: int = 0
    url_credentials: int = 0

    @property
    def total(self) -> int:
        return self.secret_values + self.emails + self.mac_addresses + self.public_ip_addresses + self.url_credentials

    def as_dict(self) -> dict[str, int]:
        return {
            "total": self.total,
            "secret_values": self.secret_values,
            "emails": self.emails,
            "mac_addresses": self.mac_addresses,
            "public_ip_addresses": self.public_ip_addresses,
            "url_credentials": self.url_credentials,
        }


class DataRedactor:
    def __init__(self, *, policy: RedactionPolicy | None = None, salt: bytes = b"xaac-support-redaction-v1") -> None:
        self.policy = policy or RedactionPolicy()
        self.policy.validate()
        if not salt or len(salt) > 1024:
            raise DataRedactionError("redaction_salt_invalid")
        self.salt = bytes(salt)
        self.report = RedactionReport()
        self._items = 0

    def redact(self, value: object) -> object:
        self.report = RedactionReport()
        self._items = 0
        return self._walk(value, depth=0, key=None)

    def _walk(self, value: object, *, depth: int, key: str | None) -> object:
        self._items += 1
        if self._items > self.policy.max_items:
            raise DataRedactionError("redaction_item_limit_exceeded")
        if depth > self.policy.max_depth:
            raise DataRedactionError("redaction_depth_limit_exceeded")
        if key is not None and self.policy.redact_secrets and _SENSITIVE_KEY_RE.search(key):
            if value not in (None, "", False):
                self.report.secret_values += 1
            return "[REDACTED]"
        if isinstance(value, Mapping):
            result: dict[str, object] = {}
            for raw_key, item in value.items():
                if not isinstance(raw_key, str):
                    raise DataRedactionError("redaction_non_string_key")
                result[raw_key] = self._walk(item, depth=depth + 1, key=raw_key)
            return result
        if isinstance(value, list):
            return [self._walk(item, depth=depth + 1, key=None) for item in value]
        if isinstance(value, tuple):
            return [self._walk(item, depth=depth + 1, key=None) for item in value]
        if isinstance(value, str):
            return self._redact_text(value)
        if value is None or isinstance(value, (bool, int, float)):
            return value
        raise DataRedactionError("redaction_unsupported_value")

    def _tag(self, category: str, value: str) -> str:
        digest = hashlib.sha256(self.salt + b"\0" + category.encode("ascii") + b"\0" + value.encode("utf-8")).hexdigest()[:12]
        return f"[{category.upper()}:{digest}]"

    def _redact_text(self, text: str) -> str:
        if self.policy.redact_secrets:
            private_keys = len(_PRIVATE_KEY_RE.findall(text))
            if private_keys:
                self.report.secret_values += private_keys
                text = _PRIVATE_KEY_RE.sub("[REDACTED_PRIVATE_KEY]", text)
            def bearer(match: re.Match[str]) -> str:
                self.report.secret_values += 1
                return f"{match.group(1)}[REDACTED]"
            text = _BEARER_RE.sub(bearer, text)
            def assignment(match: re.Match[str]) -> str:
                self.report.secret_values += 1
                return f"{match.group(1)}=[REDACTED]"
            text = _ASSIGNMENT_RE.sub(assignment, text)

        def sanitize_url(match: re.Match[str]) -> str:
            raw = match.group(0)
            try:
                parsed = urlsplit(raw)
            except ValueError:
                return raw
            if parsed.username is None and parsed.password is None:
                return raw
            host = parsed.hostname or ""
            if parsed.port is not None:
                host = f"{host}:{parsed.port}"
            self.report.url_credentials += 1
            return urlunsplit((parsed.scheme, host, parsed.path, parsed.query, parsed.fragment))
        text = _URL_RE.sub(sanitize_url, text)

        if self.policy.pseudonymize_email:
            def email(match: re.Match[str]) -> str:
                self.report.emails += 1
                return self._tag("email", match.group(0).lower())
            text = _EMAIL_RE.sub(email, text)
        if self.policy.pseudonymize_mac:
            def mac(match: re.Match[str]) -> str:
                self.report.mac_addresses += 1
                return self._tag("mac", match.group(0).lower())
            text = _MAC_RE.sub(mac, text)
        if self.policy.pseudonymize_public_ip:
            text = self._replace_ip_tokens(text)
        return text

    def _replace_ip_tokens(self, text: str) -> str:
        # Split conservatively so punctuation remains untouched; invalid candidates are retained.
        token_re = re.compile(r"(?<![0-9A-Fa-f:.])(?:\d{1,3}(?:\.\d{1,3}){3}|[0-9A-Fa-f]*:[0-9A-Fa-f:]+)(?![0-9A-Fa-f:.])")
        def replace(match: re.Match[str]) -> str:
            candidate = match.group(0)
            try:
                address = ipaddress.ip_address(candidate)
            except ValueError:
                return candidate
            if self.policy.preserve_private_ip and (address.is_private or address.is_loopback or address.is_link_local):
                return candidate
            self.report.public_ip_addresses += 1
            return self._tag("ip", address.compressed)
        return token_re.sub(replace, text)


def ensure_no_high_risk_secrets(value: object) -> None:
    raw = json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    cleaned = raw.replace("[REDACTED_PRIVATE_KEY]", "")
    cleaned = re.sub(r"(?i)(authorization\s*[:=]\s*bearer\s+)\[REDACTED\]", "", cleaned)
    cleaned = re.sub(
        r"(?i)\b(password|passwd|secret|token|api[_-]?key|client[_-]?secret|access[_-]?token|"
        r"refresh[_-]?token|credential)\s*[:=]\s*\[REDACTED\]",
        "",
        cleaned,
    )
    if _PRIVATE_KEY_RE.search(cleaned) or _BEARER_RE.search(cleaned) or _ASSIGNMENT_RE.search(cleaned):
        raise DataRedactionError("redaction_residual_secret_detected")


def _read_json(path: Path, limit: int = 2 * 1024 * 1024) -> object:
    st = path.lstat()
    if stat.S_ISLNK(st.st_mode) or not stat.S_ISREG(st.st_mode) or st.st_size > limit:
        raise DataRedactionError("redaction_input_invalid")
    data = path.read_bytes()
    if len(data) > limit:
        raise DataRedactionError("redaction_input_invalid")
    try:
        return json.loads(data.decode("utf-8", errors="strict"))
    except (UnicodeError, json.JSONDecodeError) as error:
        raise DataRedactionError("redaction_input_invalid") from error


def main(argv: Iterable[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Redact sensitive data from an approved diagnostic JSON")
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--redact-private-ip", action="store_true")
    args = parser.parse_args(list(argv) if argv is not None else None)
    try:
        if not args.input.is_absolute() or not args.output.is_absolute():
            raise DataRedactionError("redaction_paths_must_be_absolute")
        payload = _read_json(args.input)
        redactor = DataRedactor(policy=RedactionPolicy(preserve_private_ip=not args.redact_private_ip))
        redacted = redactor.redact(payload)
        ensure_no_high_risk_secrets(redacted)
        result = {
            "format": "xaac-redacted-diagnostic/v1",
            "redaction": redactor.report.as_dict(),
            "payload": redacted,
        }
        args.output.parent.mkdir(parents=True, exist_ok=True)
        temporary = args.output.with_name(f".{args.output.name}.tmp-{os.getpid()}")
        temporary.write_text(json.dumps(result, sort_keys=True, separators=(",", ":"), ensure_ascii=False), encoding="utf-8")
        os.chmod(temporary, 0o600)
        os.replace(temporary, args.output)
    except (OSError, DataRedactionError) as error:
        print(json.dumps({"format": "xaac-redaction-error/v1", "status": "error", "code": str(error)}, sort_keys=True))
        return 2
    print(json.dumps({"format": "xaac-redaction-result/v1", "status": "ok", "output": str(args.output), "redaction": redactor.report.as_dict()}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

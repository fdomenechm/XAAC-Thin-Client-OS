from __future__ import annotations

import os
import time
from collections import deque
from dataclasses import dataclass
from pathlib import Path
from typing import Callable


def _read_regular_text(path: Path) -> str | None:
    try:
        if path.is_symlink() or not path.is_file():
            return None
        return path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None


@dataclass(frozen=True, slots=True)
class CpuTimes:
    total: int
    idle: int


@dataclass(frozen=True, slots=True)
class ResourceSample:
    sampled_at_monotonic: float
    cpu_percent: float | None
    memory_percent: float | None
    memory_total_bytes: int | None
    memory_available_bytes: int | None
    load_1m: float | None
    load_5m: float | None
    load_15m: float | None
    logical_cpus: int

    @property
    def load_1m_per_cpu(self) -> float | None:
        if self.load_1m is None or self.logical_cpus <= 0:
            return None
        return round(self.load_1m / self.logical_cpus, 3)


@dataclass(frozen=True, slots=True)
class MonitoringThresholds:
    cpu_warning_percent: float = 80.0
    cpu_critical_percent: float = 95.0
    memory_warning_percent: float = 80.0
    memory_critical_percent: float = 95.0
    load_warning_per_cpu: float = 1.0
    load_critical_per_cpu: float = 2.0
    hysteresis_percent: float = 5.0


class ThresholdTracker:
    """Aplica llindars amb histèresi i conserva l'estat entre mostres."""

    def __init__(self, thresholds: MonitoringThresholds) -> None:
        self._thresholds = thresholds
        self._states = {"cpu": "normal", "memory": "normal", "load": "normal"}

    def evaluate(self, sample: ResourceSample) -> dict[str, str]:
        values = {
            "cpu": sample.cpu_percent,
            "memory": sample.memory_percent,
            "load": sample.load_1m_per_cpu,
        }
        limits = {
            "cpu": (self._thresholds.cpu_warning_percent, self._thresholds.cpu_critical_percent),
            "memory": (self._thresholds.memory_warning_percent, self._thresholds.memory_critical_percent),
            "load": (self._thresholds.load_warning_per_cpu, self._thresholds.load_critical_per_cpu),
        }
        for name, value in values.items():
            if value is None:
                continue
            warning, critical = limits[name]
            previous = self._states[name]
            hysteresis = self._thresholds.hysteresis_percent
            if previous == "critical":
                if value >= critical - hysteresis:
                    state = "critical"
                elif value >= warning - hysteresis:
                    state = "warning"
                else:
                    state = "normal"
            elif previous == "warning":
                if value >= critical:
                    state = "critical"
                elif value >= warning - hysteresis:
                    state = "warning"
                else:
                    state = "normal"
            else:
                state = "critical" if value >= critical else ("warning" if value >= warning else "normal")
            self._states[name] = state
        return dict(self._states)


class ResourceMonitor:
    """Mostreig lleuger de CPU, memòria i càrrega a partir de /proc."""

    def __init__(
        self,
        *,
        stat_path: Path = Path("/proc/stat"),
        meminfo_path: Path = Path("/proc/meminfo"),
        loadavg_path: Path = Path("/proc/loadavg"),
        window_samples: int = 5,
        thresholds: MonitoringThresholds | None = None,
        monotonic: Callable[[], float] = time.monotonic,
        logical_cpus: int | None = None,
    ) -> None:
        if window_samples < 1:
            raise ValueError("window_samples ha de ser almenys 1")
        self._stat_path = stat_path
        self._meminfo_path = meminfo_path
        self._loadavg_path = loadavg_path
        self._samples: deque[ResourceSample] = deque(maxlen=window_samples)
        self._previous_cpu: CpuTimes | None = None
        self._monotonic = monotonic
        self._logical_cpus = max(1, logical_cpus or os.cpu_count() or 1)
        self._tracker = ThresholdTracker(thresholds or MonitoringThresholds())

    def sample(self) -> dict[str, object]:
        cpu_times = self._read_cpu_times()
        cpu_percent = self._cpu_percent(cpu_times)
        total, available, memory_percent = self._read_memory()
        load_1m, load_5m, load_15m = self._read_load()
        sample = ResourceSample(
            sampled_at_monotonic=self._monotonic(),
            cpu_percent=cpu_percent,
            memory_percent=memory_percent,
            memory_total_bytes=total,
            memory_available_bytes=available,
            load_1m=load_1m,
            load_5m=load_5m,
            load_15m=load_15m,
            logical_cpus=self._logical_cpus,
        )
        self._samples.append(sample)
        states = self._tracker.evaluate(sample)
        severity = "critical" if "critical" in states.values() else ("warning" if "warning" in states.values() else "normal")
        return {
            "sample": self._sample_payload(sample),
            "aggregate": self._aggregate_payload(),
            "thresholds": states,
            "severity": severity,
            "sample_count": len(self._samples),
        }

    def _read_cpu_times(self) -> CpuTimes | None:
        text = _read_regular_text(self._stat_path)
        if not text:
            return None
        first = text.splitlines()[0].split()
        if not first or first[0] != "cpu":
            return None
        try:
            values = [int(value) for value in first[1:]]
        except ValueError:
            return None
        if len(values) < 4 or any(value < 0 for value in values):
            return None
        total = sum(values)
        idle = values[3] + (values[4] if len(values) > 4 else 0)
        return CpuTimes(total=total, idle=idle)

    def _cpu_percent(self, current: CpuTimes | None) -> float | None:
        previous = self._previous_cpu
        self._previous_cpu = current
        if current is None or previous is None:
            return None
        total_delta = current.total - previous.total
        idle_delta = current.idle - previous.idle
        if total_delta <= 0 or idle_delta < 0:
            return None
        busy = max(0, total_delta - idle_delta)
        return round(min(100.0, busy * 100.0 / total_delta), 2)

    def _read_memory(self) -> tuple[int | None, int | None, float | None]:
        text = _read_regular_text(self._meminfo_path)
        if not text:
            return None, None, None
        values: dict[str, int] = {}
        for line in text.splitlines():
            if ":" not in line:
                continue
            key, raw = line.split(":", 1)
            parts = raw.strip().split()
            try:
                value = int(parts[0])
            except (IndexError, ValueError):
                continue
            if value < 0:
                continue
            values[key] = value * (1024 if len(parts) > 1 and parts[1].lower() == "kb" else 1)
        total = values.get("MemTotal")
        available = values.get("MemAvailable")
        if available is None and values.get("MemFree") is not None:
            available = values["MemFree"] + values.get("Buffers", 0) + values.get("Cached", 0)
        percent = None
        if total and available is not None:
            percent = round(max(0.0, min(100.0, (total - available) * 100.0 / total)), 2)
        return total, available, percent

    def _read_load(self) -> tuple[float | None, float | None, float | None]:
        text = _read_regular_text(self._loadavg_path)
        if not text:
            return None, None, None
        parts = text.split()
        try:
            values = tuple(float(parts[index]) for index in range(3))
        except (IndexError, ValueError):
            return None, None, None
        return values  # type: ignore[return-value]

    @staticmethod
    def _sample_payload(sample: ResourceSample) -> dict[str, object]:
        payload: dict[str, object] = {"logical_cpus": sample.logical_cpus}
        for key in ("cpu_percent", "memory_percent", "memory_total_bytes", "memory_available_bytes", "load_1m", "load_5m", "load_15m", "load_1m_per_cpu"):
            value = getattr(sample, key)
            if value is not None:
                payload[key] = value
        return payload

    def _aggregate_payload(self) -> dict[str, object]:
        result: dict[str, object] = {}
        metrics = ("cpu_percent", "memory_percent", "load_1m_per_cpu")
        for metric in metrics:
            values = [float(value) for sample in self._samples if (value := getattr(sample, metric)) is not None]
            if values:
                result[metric] = {
                    "minimum": round(min(values), 2),
                    "average": round(sum(values) / len(values), 2),
                    "maximum": round(max(values), 2),
                }
        return result

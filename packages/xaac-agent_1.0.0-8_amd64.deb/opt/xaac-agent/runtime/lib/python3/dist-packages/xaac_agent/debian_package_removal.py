from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any


class DebianPackageRemovalError(ValueError):
    """Raised when the Debian package-removal policy is unsafe."""


@dataclass(frozen=True, slots=True)
class DebianPackageRemovalPolicy:
    package: str
    service_unit: str
    socket_unit: str
    stop_on_remove: bool
    disable_on_remove: bool
    stop_on_upgrade: bool
    preserve_configuration: bool
    preserve_state: bool
    preserve_cache: bool
    preserve_logs: bool
    remove_account_on_remove: bool
    purge_paths: tuple[Path, ...]
    remove_account_on_purge: bool
    purge_groups: tuple[str, ...]
    system_python_modified: bool

    @classmethod
    def load(cls, path: Path) -> "DebianPackageRemovalPolicy":
        try:
            raw: Any = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise DebianPackageRemovalError("debian_package_removal_invalid") from exc
        if not isinstance(raw, dict) or raw.get("schema_version") != 1:
            raise DebianPackageRemovalError("debian_package_removal_schema_invalid")
        service = raw.get("service")
        remove = raw.get("remove")
        purge = raw.get("purge")
        if not all(isinstance(value, dict) for value in (service, remove, purge)):
            raise DebianPackageRemovalError("debian_package_removal_sections_invalid")
        paths = purge.get("paths")
        groups = purge.get("remove_service_groups")
        if not isinstance(paths, list) or not isinstance(groups, list):
            raise DebianPackageRemovalError("debian_package_removal_lists_invalid")
        return cls(
            package=str(raw.get("package", "")),
            service_unit=str(service.get("unit", "")),
            socket_unit=str(service.get("socket_unit", "")),
            stop_on_remove=service.get("stop_on_remove") is True,
            disable_on_remove=service.get("disable_on_remove") is True,
            stop_on_upgrade=service.get("stop_on_upgrade") is True,
            preserve_configuration=remove.get("preserve_configuration") is True,
            preserve_state=remove.get("preserve_state") is True,
            preserve_cache=remove.get("preserve_cache") is True,
            preserve_logs=remove.get("preserve_logs") is True,
            remove_account_on_remove=remove.get("remove_service_account") is True,
            purge_paths=tuple(Path(str(value)) for value in paths),
            remove_account_on_purge=purge.get("remove_service_account") is True,
            purge_groups=tuple(str(value) for value in groups),
            system_python_modified=purge.get("system_python_modified") is True,
        )

    def validate(self) -> None:
        if self.package != "xaac-agent":
            raise DebianPackageRemovalError("debian_package_removal_package_invalid")
        if self.service_unit != "xaac-agent.service" or self.socket_unit != "xaac-privileged-helper.socket":
            raise DebianPackageRemovalError("debian_package_removal_units_invalid")
        if not self.stop_on_remove or not self.disable_on_remove or self.stop_on_upgrade:
            raise DebianPackageRemovalError("debian_package_removal_service_policy_invalid")
        if not all((self.preserve_configuration, self.preserve_state, self.preserve_cache, self.preserve_logs)):
            raise DebianPackageRemovalError("debian_package_removal_remove_policy_invalid")
        if self.remove_account_on_remove:
            raise DebianPackageRemovalError("debian_package_removal_account_policy_invalid")
        expected = {
            Path("/etc/xaac-agent"), Path("/var/lib/xaac-agent"), Path("/var/cache/xaac-agent"),
            Path("/var/log/xaac-agent"), Path("/run/xaac-agent"),
        }
        if set(self.purge_paths) != expected or len(self.purge_paths) != len(expected):
            raise DebianPackageRemovalError("debian_package_removal_purge_paths_invalid")
        if not self.remove_account_on_purge or set(self.purge_groups) != {"xaac-agent", "xaac-command"}:
            raise DebianPackageRemovalError("debian_package_removal_purge_accounts_invalid")
        if self.system_python_modified:
            raise DebianPackageRemovalError("debian_package_removal_system_python_invalid")
        for path in self.purge_paths:
            if not path.is_absolute() or ".." in path.parts or path == Path("/"):
                raise DebianPackageRemovalError("debian_package_removal_path_unsafe")

from __future__ import annotations

import argparse
import configparser
import json
import os
import stat
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from .config import AgentSettings


class ConfigurationMigrationError(ValueError):
    """Raised when a configuration migration cannot be completed safely."""


@dataclass(frozen=True, slots=True)
class ConfigurationMigrationPolicy:
    config_path: Path
    latest_schema: int
    maximum_bytes: int
    backup_suffix: str
    preserve_mode: bool
    validate_after_migration: bool
    rollback_on_failure: bool

    @classmethod
    def load(cls, path: Path) -> "ConfigurationMigrationPolicy":
        try:
            raw: Any = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ConfigurationMigrationError("configuration_migration_policy_invalid") from exc
        if not isinstance(raw, dict) or raw.get("schema_version") != 1:
            raise ConfigurationMigrationError("configuration_migration_policy_schema_invalid")
        return cls(
            config_path=Path(str(raw.get("config_path", ""))),
            latest_schema=int(raw.get("latest_configuration_schema", -1)),
            maximum_bytes=int(raw.get("maximum_bytes", 0)),
            backup_suffix=str(raw.get("backup_suffix", "")),
            preserve_mode=raw.get("preserve_mode") is True,
            validate_after_migration=raw.get("validate_after_migration") is True,
            rollback_on_failure=raw.get("rollback_on_failure") is True,
        )

    def validate(self) -> None:
        if self.config_path != Path("/etc/xaac-agent/agent.ini"):
            raise ConfigurationMigrationError("configuration_migration_path_invalid")
        if self.latest_schema != 2:
            raise ConfigurationMigrationError("configuration_migration_latest_schema_invalid")
        if not 4096 <= self.maximum_bytes <= 1024 * 1024:
            raise ConfigurationMigrationError("configuration_migration_size_invalid")
        if self.backup_suffix != ".pre-migration" or not all((self.preserve_mode, self.validate_after_migration, self.rollback_on_failure)):
            raise ConfigurationMigrationError("configuration_migration_safety_invalid")


def _migration_0_to_1(parser: configparser.ConfigParser) -> None:
    section = parser["agent"]
    if "xms_url" in section and "server_url" not in section:
        section["server_url"] = section.pop("xms_url")
    section["config_schema_version"] = "1"


def _migration_1_to_2(parser: configparser.ConfigParser) -> None:
    section = parser["agent"]
    section.setdefault("production_profile_mode", "auto")
    section.setdefault("xms_address_require_https", "true")
    section["config_schema_version"] = "2"


_MIGRATIONS: dict[int, Callable[[configparser.ConfigParser], None]] = {
    0: _migration_0_to_1,
    1: _migration_1_to_2,
}


def migrate_configuration(path: Path, *, latest_schema: int = 2, maximum_bytes: int = 262144) -> bool:
    try:
        info = path.lstat()
    except OSError as exc:
        raise ConfigurationMigrationError("configuration_missing") from exc
    if stat.S_ISLNK(info.st_mode) or not stat.S_ISREG(info.st_mode):
        raise ConfigurationMigrationError("configuration_file_unsafe")
    if info.st_size > maximum_bytes:
        raise ConfigurationMigrationError("configuration_too_large")

    original = path.read_bytes()
    parser = configparser.ConfigParser(interpolation=None)
    try:
        parser.read_string(original.decode("utf-8"))
    except (UnicodeDecodeError, configparser.Error) as exc:
        raise ConfigurationMigrationError("configuration_invalid") from exc
    if "agent" not in parser:
        raise ConfigurationMigrationError("configuration_agent_section_missing")
    try:
        current = parser["agent"].getint("config_schema_version", fallback=0)
    except ValueError as exc:
        raise ConfigurationMigrationError("configuration_schema_invalid") from exc
    if current > latest_schema:
        raise ConfigurationMigrationError("configuration_schema_newer_than_package")
    if current == latest_schema:
        AgentSettings.load(path)
        return False

    backup = path.with_name(path.name + ".pre-migration")
    _atomic_write(backup, original, stat.S_IMODE(info.st_mode))
    try:
        while current < latest_schema:
            migration = _MIGRATIONS.get(current)
            if migration is None:
                raise ConfigurationMigrationError("configuration_migration_path_missing")
            migration(parser)
            current += 1
        with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, prefix=f".{path.name}.", delete=False) as handle:
            parser.write(handle)
            handle.flush()
            os.fsync(handle.fileno())
            temporary = Path(handle.name)
        os.chmod(temporary, stat.S_IMODE(info.st_mode))
        os.replace(temporary, path)
        _fsync_directory(path.parent)
        AgentSettings.load(path)
    except Exception as exc:
        _atomic_write(path, original, stat.S_IMODE(info.st_mode))
        if isinstance(exc, ConfigurationMigrationError):
            raise
        raise ConfigurationMigrationError("configuration_migration_validation_failed") from exc
    return True


def _atomic_write(path: Path, payload: bytes, mode: int) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temporary, mode)
        os.replace(temporary, path)
        _fsync_directory(path.parent)
    finally:
        temporary.unlink(missing_ok=True)


def _fsync_directory(path: Path) -> None:
    descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Migra de manera segura la configuració de XAAC Agent")
    parser.add_argument("--config", type=Path, default=Path("/etc/xaac-agent/agent.ini"))
    args = parser.parse_args(argv)
    try:
        changed = migrate_configuration(args.config)
    except ConfigurationMigrationError as exc:
        parser.error(str(exc))
    print("migrated" if changed else "current")
    return 0

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from xaac_agent.hardware_profile import HardwareProfile

_ALLOWED_MODES = {"auto", "generic", "dell-wyse-3040"}


class ProductionProfileError(ValueError):
    """Invalid or inconsistent production profile selection."""


@dataclass(frozen=True, slots=True)
class ProductionProfile:
    profile_id: str
    hardware_profile_id: str
    optimized: bool
    mode: str
    resource_drop_in: str | None
    sampling_profile: str
    consistency: str = "ok"

    def to_payload(self) -> dict[str, object]:
        payload: dict[str, object] = {
            "profile_id": self.profile_id,
            "hardware_profile_id": self.hardware_profile_id,
            "optimized": self.optimized,
            "mode": self.mode,
            "sampling_profile": self.sampling_profile,
            "consistency": self.consistency,
        }
        if self.resource_drop_in is not None:
            payload["resource_drop_in"] = self.resource_drop_in
        return payload


def resolve_production_profile(hardware: HardwareProfile, mode: str = "auto") -> ProductionProfile:
    normalized = mode.strip().lower()
    if normalized not in _ALLOWED_MODES:
        raise ProductionProfileError("production_profile_mode must be auto, generic or dell-wyse-3040")
    selected = hardware.profile_id if normalized == "auto" else normalized
    if selected == "dell-wyse-3040" and hardware.profile_id != "dell-wyse-3040":
        raise ProductionProfileError("production_profile_mismatch")
    if selected == "dell-wyse-3040":
        return ProductionProfile(
            profile_id="production-dell-wyse-3040",
            hardware_profile_id=hardware.profile_id,
            optimized=True,
            mode=normalized,
            resource_drop_in="20-wyse-3040-resources.conf",
            sampling_profile="wyse-3040-balanced",
        )
    return ProductionProfile(
        profile_id="production-generic",
        hardware_profile_id=hardware.profile_id,
        optimized=False,
        mode=normalized,
        resource_drop_in=None,
        sampling_profile="default",
    )


def validate_wyse_drop_in(path: Path) -> tuple[str, ...]:
    required = {
        "MemoryHigh": "192M",
        "MemoryMax": "256M",
        "MemorySwapMax": "64M",
        "TasksMax": "64",
        "LimitNOFILE": "1024",
        "CPUWeight": "25",
        "IOWeight": "25",
    }
    if not path.is_file() or path.is_symlink():
        return ("missing_or_unsafe_drop_in",)
    values: dict[str, str] = {}
    section = ""
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith(("#", ";")):
            continue
        if line.startswith("[") and line.endswith("]"):
            section = line[1:-1]
            continue
        if section == "Service" and "=" in line:
            key, value = line.split("=", 1)
            values[key.strip()] = value.strip()
    findings = [f"invalid_{key}" for key, expected in required.items() if values.get(key) != expected]
    if "ExecStart" in values or "User" in values or "Group" in values:
        findings.append("privilege_or_command_override")
    return tuple(findings)


def main(argv: Iterable[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Validate the XAAC production profile artifacts")
    parser.add_argument("--drop-in", type=Path, required=True)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(list(argv) if argv is not None else None)
    findings = validate_wyse_drop_in(args.drop_in)
    result = {"format": "xaac-production-profile-validation/v1", "passed": not findings, "findings": list(findings)}
    print(json.dumps(result, sort_keys=True, separators=(",", ":")) if args.json else ("PASS" if not findings else "FAIL " + ",".join(findings)))
    return 0 if not findings else 1


if __name__ == "__main__":
    raise SystemExit(main())

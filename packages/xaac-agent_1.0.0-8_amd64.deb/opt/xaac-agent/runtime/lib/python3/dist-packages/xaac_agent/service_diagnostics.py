from __future__ import annotations

import argparse
import json
import re
import subprocess
import time
from dataclasses import asdict, dataclass
from typing import Callable, Iterable, Sequence


_SERVICE_RE = re.compile(r"^[A-Za-z0-9_.@:-]{1,128}\.service$")
_ALLOWED_PROPERTIES = (
    "LoadState", "ActiveState", "SubState", "Result", "MainPID", "ExecMainCode",
    "ExecMainStatus", "NRestarts", "UnitFileState", "FragmentPath",
)


class ServiceDiagnosticError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class ServiceDiagnosticPolicy:
    timeout_seconds: float = 3.0
    max_services: int = 32
    include_fragment_paths: bool = False

    def validate(self) -> None:
        if not 0.1 <= self.timeout_seconds <= 30.0:
            raise ServiceDiagnosticError("service_diagnostic_timeout_out_of_range")
        if not 1 <= self.max_services <= 128:
            raise ServiceDiagnosticError("service_diagnostic_max_services_out_of_range")


@dataclass(frozen=True, slots=True)
class ServiceDiagnosticResult:
    format: str
    generated_at_unix: int
    status: str
    services: tuple[dict[str, object], ...]
    summary: dict[str, int]
    findings: tuple[str, ...]

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def _normalise_services(values: Iterable[str], limit: int) -> tuple[str, ...]:
    result: list[str] = []
    for value in values:
        name = value.strip()
        if not _SERVICE_RE.fullmatch(name):
            raise ServiceDiagnosticError("service_diagnostic_invalid_service_name")
        if name not in result:
            result.append(name)
        if len(result) > limit:
            raise ServiceDiagnosticError("service_diagnostic_too_many_services")
    if not result:
        raise ServiceDiagnosticError("service_diagnostic_no_services")
    return tuple(result)


def query_service(name: str, timeout_seconds: float) -> tuple[int, str]:
    try:
        completed = subprocess.run(
            ["systemctl", "show", name, "--no-pager", "--property=" + ",".join(_ALLOWED_PROPERTIES)],
            check=False,
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
            env={"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LC_ALL": "C"},
        )
    except subprocess.TimeoutExpired:
        return 124, ""
    except OSError:
        return 127, ""
    return completed.returncode, completed.stdout[:32768]


class ServiceDiagnosticCollector:
    def __init__(self, *, policy: ServiceDiagnosticPolicy | None = None,
                 reader: Callable[[str, float], tuple[int, str]] = query_service,
                 clock: Callable[[], float] = time.time) -> None:
        self.policy = policy or ServiceDiagnosticPolicy()
        self.policy.validate()
        self.reader = reader
        self.clock = clock

    def collect(self, *, services: Sequence[str]) -> ServiceDiagnosticResult:
        names = _normalise_services(services, self.policy.max_services)
        payloads = tuple(self._inspect(name) for name in names)
        critical = sum(1 for item in payloads if item["severity"] == "critical")
        warning = sum(1 for item in payloads if item["severity"] == "warning")
        normal = len(payloads) - critical - warning
        findings: list[str] = []
        if critical:
            findings.append("critical_services_detected")
        if warning:
            findings.append("degraded_services_detected")
        status = "critical" if critical else ("warning" if warning else "ok")
        return ServiceDiagnosticResult(
            format="xaac-service-diagnostic/v1",
            generated_at_unix=int(self.clock()),
            status=status,
            services=payloads,
            summary={"total": len(payloads), "normal": normal, "warning": warning, "critical": critical},
            findings=tuple(findings),
        )

    def _inspect(self, name: str) -> dict[str, object]:
        returncode, stdout = self.reader(name, self.policy.timeout_seconds)
        if returncode == 124:
            return {"name": name, "severity": "critical", "code": "query_timeout"}
        if returncode == 127:
            return {"name": name, "severity": "critical", "code": "systemctl_unavailable"}
        values: dict[str, str] = {}
        for line in stdout.splitlines():
            key, sep, value = line.partition("=")
            if sep and key in _ALLOWED_PROPERTIES:
                values[key] = value.strip()[:4096]
        if not values:
            return {"name": name, "severity": "critical", "code": "unit_unavailable"}
        load = values.get("LoadState", "unknown")
        active = values.get("ActiveState", "unknown")
        result = values.get("Result", "unknown")
        if load in {"not-found", "masked", "error"} or active == "failed" or result not in {"", "success", "unknown"}:
            severity = "critical"
        elif active == "active":
            severity = "normal"
        else:
            severity = "warning"
        item: dict[str, object] = {
            "name": name, "severity": severity, "load_state": load,
            "active_state": active, "sub_state": values.get("SubState", "unknown"),
            "result": result, "unit_file_state": values.get("UnitFileState", "unknown"),
        }
        for source, target in (("MainPID", "main_pid"), ("ExecMainCode", "exec_main_code"),
                               ("ExecMainStatus", "exec_main_status"), ("NRestarts", "restart_count")):
            raw = values.get(source, "")
            if raw.isdigit():
                item[target] = int(raw)
        if self.policy.include_fragment_paths:
            path = values.get("FragmentPath", "")
            if path.startswith("/") and "\x00" not in path:
                item["fragment_path"] = path
        return item


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="XAAC systemd service diagnostic")
    parser.add_argument("--service", action="append", required=True, dest="services")
    parser.add_argument("--timeout", type=float, default=3.0)
    parser.add_argument("--include-fragment-paths", action="store_true")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    try:
        result = ServiceDiagnosticCollector(policy=ServiceDiagnosticPolicy(
            timeout_seconds=args.timeout,
            include_fragment_paths=args.include_fragment_paths,
        )).collect(services=args.services)
    except ServiceDiagnosticError as error:
        print(json.dumps({"format": "xaac-service-diagnostic/v1", "status": "error", "code": str(error)}, sort_keys=True))
        return 2
    print(json.dumps(result.to_dict(), sort_keys=True, separators=(",", ":")))
    return 0 if result.status == "ok" else 1


if __name__ == "__main__":
    raise SystemExit(main())

from __future__ import annotations

import argparse
import getpass
import json
import os
import pwd
import grp
import stat
import subprocess
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import Callable, Sequence
from urllib.parse import urlsplit, urlunsplit

from xaac_agent.config import AgentConfigurationError, AgentSettings
from xaac_agent.enrollment import DeviceCredentialsStore, InvalidDeviceCredentialsError
from xaac_agent.registration import RegistrationStateError, RegistrationStateStore

_STATUS_SCHEMA = "xaac-agent-admin-status/v1"
_DEFAULT_CONFIG = Path("/etc/xaac-agent/agent.ini")
_DEFAULT_TOKEN = Path("/etc/xaac-agent/enrollment.token")
_DEFAULT_SERVICE = "xaac-agent.service"
_DEFAULT_AGENT = "/usr/bin/xaac-agent"
_MAX_CONFIG_BYTES = 1024 * 1024
_MAX_TOKEN_BYTES = 16 * 1024


class AgentAdminError(RuntimeError):
    """Raised when a local administrative operation cannot be completed safely."""


@dataclass(frozen=True, slots=True)
class CommandResult:
    returncode: int
    stdout: str = ""
    stderr: str = ""


@dataclass(frozen=True, slots=True)
class AgentAdminStatus:
    schema: str
    configured: bool
    enabled: bool
    enrolled: bool
    device_id: str | None
    registration_status: str
    reenrollment_authorized: bool
    service_enabled: bool
    service_active: bool
    server_url: str
    bootstrap_token_present: bool

    def to_payload(self) -> dict[str, object]:
        return asdict(self)


Runner = Callable[[Sequence[str], bool], CommandResult]
Sleeper = Callable[[float], None]


class AgentAdmin:
    """Root-only orchestration for XMS bootstrap and xaac-agent lifecycle.

    The enrollment token is deliberately transient. It is installed with 0600
    permissions only while systemd starts the agent and XMS issues persistent
    device credentials. On success and on every failure path the token is
    removed again.
    """

    def __init__(
        self,
        config_path: Path = _DEFAULT_CONFIG,
        *,
        token_path: Path | None = None,
        service: str = _DEFAULT_SERVICE,
        agent_binary: str = _DEFAULT_AGENT,
        runner: Runner | None = None,
        sleeper: Sleeper = time.sleep,
    ) -> None:
        self.config_path = config_path
        self._token_path_override = token_path
        self.service = service
        self.agent_binary = agent_binary
        self._runner = runner or self._run_command
        self._sleep = sleeper

    def provision(
        self,
        *,
        server_url: str,
        token: str,
        timeout_seconds: int = 45,
        allow_reenrollment: bool = False,
    ) -> AgentAdminStatus:
        if not 5 <= timeout_seconds <= 300:
            raise AgentAdminError("timeout_seconds must be between 5 and 300")
        url = normalize_server_url(server_url)
        clean_token = validate_enrollment_token(token)
        settings = AgentSettings.load(self.config_path)
        token_path = self._token_path(settings)
        credentials_store = DeviceCredentialsStore(settings.device_credentials_file)
        try:
            already_enrolled = credentials_store.exists()
        except InvalidDeviceCredentialsError as error:
            raise AgentAdminError(f"cannot inspect device credentials: {error}") from error
        if already_enrolled:
            raise AgentAdminError("device is already enrolled; unenroll it before provisioning again")

        registration_store = RegistrationStateStore(settings.registration_state_file)
        try:
            registration = registration_store.load()
        except RegistrationStateError as error:
            raise AgentAdminError(f"registration state is invalid: {error}") from error
        if registration.blocks_enrollment and not allow_reenrollment:
            raise AgentAdminError("reenrollment is blocked; repeat provision with --reenroll after verifying the device")

        self._systemctl("stop", self.service, acceptable={0, 5})
        self._update_config({"server_url": url, "enabled": "true"})
        self._write_token(clean_token, token_path)
        try:
            if registration.blocks_enrollment:
                result = self._runner(
                    [self.agent_binary, "--config", str(self.config_path), "--authorize-reenrollment"],
                    True,
                )
                if result.returncode != 0:
                    raise AgentAdminError("could not authorize local reenrollment")
            self._systemctl("enable", self.service)
            self._systemctl("start", self.service)

            deadline = time.monotonic() + timeout_seconds
            while time.monotonic() < deadline:
                try:
                    if credentials_store.exists():
                        credentials_store.load()
                        self._remove_token(token_path)
                        return self.status()
                except InvalidDeviceCredentialsError as error:
                    raise AgentAdminError(f"XMS credentials are invalid: {error}") from error
                if not self._service_active():
                    raise AgentAdminError("xaac-agent stopped before enrollment completed")
                self._sleep(0.25)
            raise AgentAdminError("XMS enrollment did not complete before the local timeout")
        except Exception:
            self._systemctl("stop", self.service, acceptable={0, 5})
            self._update_config({"enabled": "false"})
            self._remove_token(token_path)
            raise

    def enable(self) -> AgentAdminStatus:
        settings = AgentSettings.load(self.config_path)
        token_path = self._token_path(settings)
        try:
            if not DeviceCredentialsStore(settings.device_credentials_file).exists():
                raise AgentAdminError("device is not enrolled; run xaac-agent-admin provision first")
        except InvalidDeviceCredentialsError as error:
            raise AgentAdminError(f"cannot inspect device credentials: {error}") from error
        self._remove_token(token_path)
        self._update_config({"enabled": "true"})
        self._systemctl("enable", self.service)
        self._systemctl("start", self.service)
        return self.status()

    def disable(self) -> AgentAdminStatus:
        settings = AgentSettings.load(self.config_path)
        token_path = self._token_path(settings)
        self._systemctl("stop", self.service, acceptable={0, 5})
        self._systemctl("disable", self.service, acceptable={0, 1, 5})
        self._update_config({"enabled": "false"})
        self._remove_token(token_path)
        return self.status()

    def unenroll(self, *, reason: str = "administrator_request") -> AgentAdminStatus:
        clean_reason = normalize_reason(reason)
        settings = AgentSettings.load(self.config_path)
        token_path = self._token_path(settings)
        was_active = self._service_active()
        self._systemctl("stop", self.service, acceptable={0, 5})
        try:
            try:
                DeviceCredentialsStore(settings.device_credentials_file).exists()
            except InvalidDeviceCredentialsError as error:
                raise AgentAdminError(f"cannot inspect device credentials: {error}") from error

            # The agent CLI owns the XMS-confirmed unenrollment protocol and
            # persists a blocking local registration state even when no
            # credentials are present. Run it as the unprivileged service
            # account so xaac-agent-admin never handles persistent secrets.
            result = self._runner(
                [
                    self.agent_binary,
                    "--config",
                    str(self.config_path),
                    "--unenroll",
                    "--reason",
                    clean_reason,
                ],
                True,
            )
            if result.returncode != 0:
                raise AgentAdminError("XMS did not confirm device unenrollment")
        except Exception:
            # Failure to obtain XMS confirmation must not silently strand a
            # previously active management agent. Restore the running state
            # and leave config/credentials untouched.
            if was_active:
                self._systemctl("start", self.service)
            raise

        self._update_config({"enabled": "false"})
        self._remove_token(token_path)
        self._systemctl("disable", self.service, acceptable={0, 1, 5})
        return self.status()

    def status(self) -> AgentAdminStatus:
        settings = AgentSettings.load(self.config_path)
        token_path = self._token_path(settings)
        credentials_store = DeviceCredentialsStore(settings.device_credentials_file)
        try:
            enrolled = credentials_store.exists()
            credentials = credentials_store.load() if enrolled else None
        except InvalidDeviceCredentialsError as error:
            raise AgentAdminError(f"device credentials are invalid: {error}") from error
        try:
            registration = RegistrationStateStore(settings.registration_state_file).load()
        except RegistrationStateError as error:
            raise AgentAdminError(f"registration state is invalid: {error}") from error

        return AgentAdminStatus(
            schema=_STATUS_SCHEMA,
            configured=bool(settings.server_url),
            enabled=settings.enabled,
            enrolled=enrolled,
            device_id=credentials.device_id if credentials is not None else None,
            registration_status=(registration.status if enrolled or registration.status != "active" else "not_enrolled"),
            reenrollment_authorized=registration.reenrollment_authorized,
            service_enabled=self._service_enabled(),
            service_active=self._service_active(),
            server_url=settings.server_url,
            bootstrap_token_present=self._safe_regular_file_exists(token_path),
        )

    def _update_config(self, updates: dict[str, str]) -> None:
        path = self.config_path
        try:
            metadata = path.lstat()
        except OSError as error:
            raise AgentAdminError(f"cannot inspect {path}: {error}") from error
        if stat.S_ISLNK(metadata.st_mode) or not stat.S_ISREG(metadata.st_mode):
            raise AgentAdminError("agent.ini must be a regular file, not a symbolic link")
        if metadata.st_size > _MAX_CONFIG_BYTES:
            raise AgentAdminError("agent.ini exceeds the administrative size limit")
        try:
            original = path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError) as error:
            raise AgentAdminError(f"cannot read {path}: {error}") from error
        rewritten = _rewrite_agent_section(original, updates)
        temporary_name: str | None = None
        try:
            with NamedTemporaryFile(
                "w", encoding="utf-8", dir=path.parent, prefix=".agent-admin-", suffix=".tmp", delete=False
            ) as handle:
                temporary_name = handle.name
                handle.write(rewritten)
                handle.flush()
                os.fsync(handle.fileno())
            os.chmod(temporary_name, stat.S_IMODE(metadata.st_mode))
            try:
                os.chown(temporary_name, metadata.st_uid, metadata.st_gid)
            except PermissionError:
                # Unit tests and developer workspaces may not run as root. The
                # user-facing CLI rejects non-root execution before this point.
                pass
            try:
                AgentSettings.load(Path(temporary_name))
            except AgentConfigurationError as error:
                raise AgentAdminError(f"updated agent configuration is invalid: {error}") from error
            os.replace(temporary_name, path)
            temporary_name = None
            _fsync_directory(path.parent)
        except AgentAdminError:
            raise
        except OSError as error:
            raise AgentAdminError(f"cannot update {path}: {error}") from error
        finally:
            if temporary_name and os.path.exists(temporary_name):
                os.unlink(temporary_name)

    def _token_path(self, settings: AgentSettings) -> Path:
        return self._token_path_override if self._token_path_override is not None else settings.enrollment_token_file

    def _write_token(self, token: str, path: Path) -> None:
        path.parent.mkdir(mode=0o750, parents=True, exist_ok=True)
        if path.parent.is_symlink() or not path.parent.is_dir():
            raise AgentAdminError("enrollment token parent must be a directory")
        if path.exists() and (path.is_symlink() or not path.is_file()):
            raise AgentAdminError("enrollment token path must be a regular file")
        temporary_name: str | None = None
        try:
            with NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, prefix=".enrollment-", suffix=".tmp", delete=False) as handle:
                temporary_name = handle.name
                handle.write(token + "\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.chmod(temporary_name, 0o600)
            os.replace(temporary_name, path)
            temporary_name = None
            os.chmod(path, 0o600)
            _fsync_directory(path.parent)
        except OSError as error:
            raise AgentAdminError("cannot install enrollment token") from error
        finally:
            if temporary_name and os.path.exists(temporary_name):
                os.unlink(temporary_name)

    def _remove_token(self, path: Path) -> None:
        try:
            metadata = path.lstat()
        except FileNotFoundError:
            return
        except OSError as error:
            raise AgentAdminError("cannot inspect enrollment token") from error
        if stat.S_ISLNK(metadata.st_mode) or not stat.S_ISREG(metadata.st_mode):
            raise AgentAdminError("refusing to remove unsafe enrollment token path")
        try:
            path.unlink()
            _fsync_directory(path.parent)
        except OSError as error:
            raise AgentAdminError("cannot remove enrollment token") from error

    def _systemctl(self, action: str, unit: str, *, acceptable: set[int] | None = None) -> CommandResult:
        result = self._runner(["/bin/systemctl", action, unit], False)
        accepted = acceptable or {0}
        if result.returncode not in accepted:
            raise AgentAdminError(f"systemctl {action} {unit} failed")
        return result

    def _service_active(self) -> bool:
        return self._runner(["/bin/systemctl", "is-active", "--quiet", self.service], False).returncode == 0

    def _service_enabled(self) -> bool:
        return self._runner(["/bin/systemctl", "is-enabled", "--quiet", self.service], False).returncode == 0

    @staticmethod
    def _safe_regular_file_exists(path: Path) -> bool:
        try:
            metadata = path.lstat()
        except FileNotFoundError:
            return False
        except OSError as error:
            raise AgentAdminError(f"cannot inspect {path}: {error}") from error
        if stat.S_ISLNK(metadata.st_mode) or not stat.S_ISREG(metadata.st_mode):
            raise AgentAdminError(f"unsafe file at {path}")
        return True

    @staticmethod
    def _run_command(argv: Sequence[str], as_agent: bool) -> CommandResult:
        kwargs: dict[str, object] = {
            "capture_output": True,
            "text": True,
            "timeout": 330,
            "check": False,
        }
        if as_agent:
            try:
                account = pwd.getpwnam("xaac-agent")
            except KeyError as error:
                raise AgentAdminError("xaac-agent account does not exist") from error
            supplementary = [item.gr_gid for item in grp.getgrall() if "xaac-agent" in item.gr_mem]
            kwargs.update(user=account.pw_uid, group=account.pw_gid, extra_groups=supplementary)
        try:
            completed = subprocess.run(list(argv), **kwargs)
        except (OSError, subprocess.SubprocessError) as error:
            raise AgentAdminError(f"cannot execute administrative command: {argv[0]}") from error
        return CommandResult(completed.returncode, completed.stdout or "", completed.stderr or "")


def normalize_server_url(value: str) -> str:
    text = str(value).strip().rstrip("/")
    if not text or len(text) > 2048:
        raise AgentAdminError("XMS server URL is invalid")
    parsed = urlsplit(text)
    if parsed.scheme.lower() != "https" or not parsed.hostname:
        raise AgentAdminError("XMS server URL must use HTTPS")
    if parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise AgentAdminError("XMS server URL must not contain credentials, query parameters or fragments")
    try:
        port = parsed.port
    except ValueError as error:
        raise AgentAdminError("XMS server URL contains an invalid port") from error
    host = parsed.hostname.lower()
    netloc = host if port is None else f"{host}:{port}"
    path = parsed.path.rstrip("/")
    return urlunsplit(("https", netloc, path, "", ""))


def validate_enrollment_token(value: str) -> str:
    token = str(value).strip()
    encoded = token.encode("utf-8", errors="strict")
    if not 16 <= len(encoded) <= _MAX_TOKEN_BYTES:
        raise AgentAdminError("enrollment token length is invalid")
    if any(ord(char) < 0x20 or ord(char) == 0x7F for char in token):
        raise AgentAdminError("enrollment token must contain one printable text value")
    return token


def normalize_reason(value: str) -> str:
    clean = " ".join(str(value).split())
    if not clean or len(clean) > 160:
        raise AgentAdminError("unenrollment reason is invalid")
    return clean


def _rewrite_agent_section(text: str, updates: dict[str, str]) -> str:
    lines = text.splitlines(keepends=True)
    start: int | None = None
    end = len(lines)
    for index, line in enumerate(lines):
        stripped = line.strip()
        if stripped.lower() == "[agent]":
            start = index
            continue
        if start is not None and index > start and stripped.startswith("[") and stripped.endswith("]"):
            end = index
            break
    if start is None:
        raise AgentAdminError("agent.ini does not contain an [agent] section")

    pending = {key.lower(): (key, value) for key, value in updates.items()}
    key_pattern = __import__("re").compile(r"^(\s*)([A-Za-z0-9_.-]+)(\s*=).*$")
    for index in range(start + 1, end):
        raw = lines[index].rstrip("\r\n")
        match = key_pattern.match(raw)
        if not match:
            continue
        key_lower = match.group(2).lower()
        if key_lower not in pending:
            continue
        _original_key, value = pending.pop(key_lower)
        newline = "\r\n" if lines[index].endswith("\r\n") else "\n"
        lines[index] = f"{match.group(1)}{match.group(2)}{match.group(3)} {value}{newline}"

    additions = [f"{key} = {value}\n" for key, value in pending.values()]
    if additions:
        lines[end:end] = additions
    result = "".join(lines)
    return result if result.endswith("\n") else result + "\n"


def _fsync_directory(path: Path) -> None:
    descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _read_token(args: argparse.Namespace) -> str:
    if args.token_file is not None:
        path = args.token_file
        try:
            metadata = path.lstat()
        except OSError as error:
            raise AgentAdminError(f"cannot inspect token file: {error}") from error
        if stat.S_ISLNK(metadata.st_mode) or not stat.S_ISREG(metadata.st_mode):
            raise AgentAdminError("token file must be a regular file")
        if metadata.st_mode & 0o077:
            raise AgentAdminError("token file must not grant group or other access")
        if metadata.st_size > _MAX_TOKEN_BYTES:
            raise AgentAdminError("token file is too large")
        try:
            return validate_enrollment_token(path.read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError) as error:
            raise AgentAdminError(f"cannot read token file: {error}") from error
    if args.token_stdin:
        return validate_enrollment_token(sys.stdin.readline(_MAX_TOKEN_BYTES + 2))
    return validate_enrollment_token(getpass.getpass("XMS enrollment token: "))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Administrative tool for XAAC Agent enrollment and lifecycle")
    parser.add_argument("--config", type=Path, default=_DEFAULT_CONFIG, help=argparse.SUPPRESS)
    subparsers = parser.add_subparsers(dest="command", required=True)

    provision = subparsers.add_parser("provision", help="provision XMS and enroll this device")
    provision.add_argument("--json", action="store_true", help="emit machine-readable JSON")
    provision.add_argument("--server-url", required=True, help="HTTPS base URL of the XMS server")
    source = provision.add_mutually_exclusive_group()
    source.add_argument("--token-file", type=Path, help="read the bootstrap token from a private file")
    source.add_argument("--token-stdin", action="store_true", help="read the bootstrap token from standard input")
    provision.add_argument("--timeout", type=int, default=45, help="local enrollment timeout in seconds (5-300)")
    provision.add_argument("--reenroll", action="store_true", help="explicitly authorize reenrollment of a previously blocked device")

    enable = subparsers.add_parser("enable", help="enable and start an already enrolled agent")
    enable.add_argument("--json", action="store_true", help="emit machine-readable JSON")
    disable = subparsers.add_parser("disable", help="stop and disable the agent without deleting its identity")
    disable.add_argument("--json", action="store_true", help="emit machine-readable JSON")
    status = subparsers.add_parser("status", help="show enrollment and service status")
    status.add_argument("--json", action="store_true", help="emit machine-readable JSON")
    unenroll = subparsers.add_parser("unenroll", help="unenroll from XMS and disable the agent")
    unenroll.add_argument("--json", action="store_true", help="emit machine-readable JSON")
    unenroll.add_argument("--reason", default="administrator_request", help="auditable reason; never include secrets")
    return parser


def _emit(status: AgentAdminStatus, *, as_json: bool) -> None:
    payload = status.to_payload()
    if as_json:
        print(json.dumps(payload, sort_keys=True, separators=(",", ":")))
        return
    print(f"Configured: {'yes' if status.configured else 'no'}")
    print(f"Enabled: {'yes' if status.enabled else 'no'}")
    print(f"Enrolled: {'yes' if status.enrolled else 'no'}")
    print(f"Registration: {status.registration_status}")
    print(f"Service: {'active' if status.service_active else 'inactive'} ({'enabled' if status.service_enabled else 'disabled'})")
    print(f"XMS: {status.server_url or '-'}")
    if status.device_id:
        print(f"Device ID: {status.device_id}")
    print(f"Bootstrap token present: {'yes' if status.bootstrap_token_present else 'no'}")


def main() -> int:
    args = build_parser().parse_args()
    if os.geteuid() != 0:
        print("xaac-agent-admin must be run as root", file=sys.stderr)
        return 77
    admin = AgentAdmin(args.config)
    try:
        if args.command == "provision":
            status = admin.provision(
                server_url=args.server_url,
                token=_read_token(args),
                timeout_seconds=args.timeout,
                allow_reenrollment=args.reenroll,
            )
        elif args.command == "enable":
            status = admin.enable()
        elif args.command == "disable":
            status = admin.disable()
        elif args.command == "unenroll":
            status = admin.unenroll(reason=args.reason)
        else:
            status = admin.status()
        _emit(status, as_json=args.json)
        return 0
    except (AgentAdminError, AgentConfigurationError) as error:
        if args.json:
            print(json.dumps({"schema": _STATUS_SCHEMA, "status": "error", "error": str(error)}, sort_keys=True, separators=(",", ":")))
        else:
            print(f"Error: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

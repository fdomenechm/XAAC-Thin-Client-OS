from __future__ import annotations

import re
import subprocess
from dataclasses import dataclass
from datetime import datetime, timezone
from types import MappingProxyType
from typing import Mapping, Protocol, Sequence

from xaac_agent.command_model import Command, CommandResult, CommandState, CommandType


_ARGUMENT_VALUE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:@/+ -]{0,127}$")


class TaskCommandBackend(Protocol):
    def run(self, argv: Sequence[str], *, timeout_seconds: int) -> subprocess.CompletedProcess[str]: ...


class SubprocessTaskBackend:
    """Executa únicament argv construïdes des del catàleg local, mai una shell."""

    def run(self, argv: Sequence[str], *, timeout_seconds: int) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            list(argv),
            check=False,
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
            stdin=subprocess.DEVNULL,
        )


@dataclass(frozen=True, slots=True)
class TaskDefinition:
    task_id: str
    executable: str
    fixed_arguments: tuple[str, ...] = ()
    allowed_arguments: tuple[str, ...] = ()
    success_code: str = "task_completed"

    def build_argv(self, arguments: Mapping[str, object]) -> tuple[str, ...]:
        unknown = sorted(set(arguments) - set(self.allowed_arguments))
        if unknown:
            raise ValueError(f"task_argument_not_allowed:{unknown[0]}")
        argv = [self.executable, *self.fixed_arguments]
        for name in self.allowed_arguments:
            if name not in arguments:
                continue
            value = arguments[name]
            if not isinstance(value, str) or not _ARGUMENT_VALUE.fullmatch(value):
                raise ValueError(f"invalid_task_argument:{name}")
            argv.extend((f"--{name.replace('_', '-')}", value))
        return tuple(argv)


_DEFAULT_CATALOG: Mapping[str, TaskDefinition] = MappingProxyType({
    "sync-filesystems": TaskDefinition(
        task_id="sync-filesystems",
        executable="/usr/bin/sync",
        success_code="filesystems_synced",
    ),
})


@dataclass(frozen=True, slots=True)
class TaskCommandExecutor:
    backend: TaskCommandBackend
    catalog: Mapping[str, TaskDefinition] = _DEFAULT_CATALOG

    @classmethod
    def system_default(cls) -> "TaskCommandExecutor":
        return cls(backend=SubprocessTaskBackend())

    def execute(self, command: Command) -> CommandResult:
        if command.command_type is not CommandType.TASK:
            raise ValueError("unsupported_task_command")

        started_at = _utc_now()
        task_id = str(command.parameters["task_id"])
        timeout = int(command.parameters.get("timeout_seconds", 300))
        arguments = command.parameters.get("arguments", {})
        definition = self.catalog.get(task_id)
        if definition is None:
            return self._failed(command, started_at, "task_definition_unavailable", task_id)
        if not isinstance(arguments, Mapping):
            return self._failed(command, started_at, "invalid_task_arguments", task_id)
        try:
            argv = definition.build_argv(arguments)
        except ValueError as error:
            code, _, detail = str(error).partition(":")
            return self._failed(command, started_at, code, task_id, detail or None)

        try:
            completed = self.backend.run(argv, timeout_seconds=timeout)
        except subprocess.TimeoutExpired:
            return self._failed(command, started_at, "task_timeout", task_id)
        except OSError as error:
            return self._failed(command, started_at, "task_backend_error", task_id, str(error))
        if completed.returncode != 0:
            return self._failed(
                command,
                started_at,
                "task_failed",
                task_id,
                _safe_detail(completed.stderr or completed.stdout),
            )
        return CommandResult(
            command_id=command.command_id,
            state=CommandState.SUCCEEDED,
            started_at=started_at,
            finished_at=_utc_now(),
            code=definition.success_code,
            data={"task_id": task_id},
        )

    @staticmethod
    def _failed(
        command: Command,
        started_at: str,
        code: str,
        task_id: str,
        detail: str | None = None,
    ) -> CommandResult:
        return CommandResult(
            command_id=command.command_id,
            state=CommandState.FAILED,
            started_at=started_at,
            finished_at=_utc_now(),
            code=code,
            message=_safe_detail(detail),
            data={"task_id": task_id},
        )


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _safe_detail(value: str | None) -> str | None:
    if not value:
        return None
    compact = " ".join(value.split())
    return compact[:512] or None

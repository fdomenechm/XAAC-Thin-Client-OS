from __future__ import annotations

import platform
from dataclasses import dataclass, field
from pathlib import Path


def _read_regular_text(path: Path) -> str | None:
    try:
        if path.is_symlink() or not path.is_file():
            return None
        return path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None


@dataclass(frozen=True, slots=True)
class CpuInventory:
    vendor: str | None = None
    model: str | None = None
    architecture: str | None = None
    logical_cpus: int | None = None
    physical_cores: int | None = None
    threads_per_core: int | None = None
    features: tuple[str, ...] = field(default_factory=tuple)
    wyse_3040_cpu: bool = False

    def to_payload(self) -> dict[str, object]:
        payload: dict[str, object] = {}
        for key in ("vendor", "model", "architecture", "logical_cpus", "physical_cores", "threads_per_core"):
            value = getattr(self, key)
            if value is not None:
                payload[key] = value
        if self.features:
            payload["features"] = list(self.features)
        payload["wyse_3040_cpu"] = self.wyse_3040_cpu
        return payload


@dataclass(frozen=True, slots=True)
class MemoryInventory:
    total_bytes: int | None = None
    available_bytes: int | None = None
    free_bytes: int | None = None
    swap_total_bytes: int | None = None
    swap_free_bytes: int | None = None
    swap_used_bytes: int | None = None
    used_percent: float | None = None

    def to_payload(self) -> dict[str, object]:
        return {key: value for key in (
            "total_bytes", "available_bytes", "free_bytes", "swap_total_bytes",
            "swap_free_bytes", "swap_used_bytes", "used_percent"
        ) if (value := getattr(self, key)) is not None}


@dataclass(frozen=True, slots=True)
class CpuMemoryInventory:
    cpu: CpuInventory = field(default_factory=CpuInventory)
    memory: MemoryInventory = field(default_factory=MemoryInventory)

    def to_payload(self) -> dict[str, object]:
        return {"cpu": self.cpu.to_payload(), "memory": self.memory.to_payload()}


class CpuMemoryInventoryCollector:
    _FEATURES = ("sse", "sse2", "sse3", "ssse3", "sse4_1", "sse4_2", "avx", "avx2", "aes", "fma", "vmx", "svm")

    def __init__(self, cpuinfo_path: Path = Path("/proc/cpuinfo"), meminfo_path: Path = Path("/proc/meminfo")) -> None:
        self._cpuinfo_path = cpuinfo_path
        self._meminfo_path = meminfo_path

    def collect(self) -> CpuMemoryInventory:
        return CpuMemoryInventory(cpu=self._collect_cpu(), memory=self._collect_memory())

    def _collect_cpu(self) -> CpuInventory:
        text = _read_regular_text(self._cpuinfo_path) or ""
        sections = [s for s in text.split("\n\n") if s.strip()]
        parsed = [self._parse_kv(s) for s in sections]
        first = parsed[0] if parsed else {}
        logical = len(parsed) or None
        pairs = {(p.get("physical id"), p.get("core id")) for p in parsed if p.get("physical id") is not None and p.get("core id") is not None}
        physical = len(pairs) if pairs else None
        model = first.get("model name") or first.get("hardware") or first.get("processor")
        flags = set((first.get("flags") or first.get("features") or "").split())
        features = tuple(sorted(f for f in self._FEATURES if f in flags))
        threads = logical // physical if logical and physical and logical % physical == 0 else None
        return CpuInventory(
            vendor=first.get("vendor_id") or first.get("cpu implementer"),
            model=model,
            architecture=platform.machine() or None,
            logical_cpus=logical,
            physical_cores=physical,
            threads_per_core=threads,
            features=features,
            wyse_3040_cpu=bool(model and "x5-e8000" in model.lower()),
        )

    def _collect_memory(self) -> MemoryInventory:
        text = _read_regular_text(self._meminfo_path) or ""
        values: dict[str, int] = {}
        for line in text.splitlines():
            if ":" not in line:
                continue
            key, raw = line.split(":", 1)
            parts = raw.strip().split()
            if not parts:
                continue
            try:
                value = int(parts[0])
            except ValueError:
                continue
            if value < 0:
                continue
            multiplier = 1024 if len(parts) > 1 and parts[1].lower() == "kb" else 1
            values[key] = value * multiplier
        total = values.get("MemTotal")
        free = values.get("MemFree")
        available = values.get("MemAvailable")
        if available is None and free is not None:
            available = free + values.get("Buffers", 0) + values.get("Cached", 0)
        swap_total = values.get("SwapTotal")
        swap_free = values.get("SwapFree")
        swap_used = max(0, swap_total - swap_free) if swap_total is not None and swap_free is not None else None
        used_percent = round((total - available) * 100 / total, 2) if total and available is not None else None
        return MemoryInventory(total, available, free, swap_total, swap_free, swap_used, used_percent)

    @staticmethod
    def _parse_kv(section: str) -> dict[str, str]:
        result: dict[str, str] = {}
        for line in section.splitlines():
            if ":" in line:
                key, value = line.split(":", 1)
                result[key.strip().lower()] = value.strip()
        return result

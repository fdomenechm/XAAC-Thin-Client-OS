from __future__ import annotations

import hashlib
import json
import os
import stat
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Mapping

from xaac_agent.command_authorization import CommandAuthorizationPolicy
from xaac_agent.command_model import Command, CommandValidationError
from xaac_agent.enrollment import canonical_json


class CommandJournalError(RuntimeError):
    """L'estat persistent de confirmacions d'ordres és invàlid o insegur."""


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


def _parse_time(value: object) -> datetime | None:
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        parsed = datetime.fromisoformat(value.strip().replace('Z', '+00:00'))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


@dataclass(frozen=True, slots=True)
class CommandAcknowledgement:
    command_id: str
    status: str
    acknowledged_at: str
    detail: str | None = None
    duplicate: bool = field(default=False, compare=False)

    def to_payload(self) -> dict[str, object]:
        payload: dict[str, object] = {
            'command_id': self.command_id,
            'status': self.status,
            'acknowledged_at': self.acknowledged_at,
        }
        if self.detail:
            payload['detail'] = self.detail
        return payload


class CommandJournal:
    SCHEMA_VERSION = 1

    def __init__(
        self,
        path: Path,
        *,
        max_records: int = 256,
        authorization_policy: CommandAuthorizationPolicy | None = None,
        max_lifetime_seconds: int = 86400,
        replay_window_seconds: int = 900,
        clock_skew_seconds: int = 300,
        require_nonce: bool = False,
        reject_command_id_reuse: bool = False,
    ) -> None:
        self.path = path
        self.max_records = max(16, max_records)
        self.authorization_policy = authorization_policy
        self.max_lifetime_seconds = max(60, max_lifetime_seconds)
        self.replay_window_seconds = max(60, replay_window_seconds)
        self.clock_skew_seconds = max(0, clock_skew_seconds)
        self.require_nonce = require_nonce
        self.reject_command_id_reuse = reject_command_id_reuse

    def record_received(self, command: Mapping[str, Any]) -> CommandAcknowledgement | None:
        command_id = command.get('command_id')
        if not isinstance(command_id, str) or not command_id.strip():
            return None
        command_id = command_id.strip()
        state = self._load()
        fingerprint = hashlib.sha256(canonical_json(dict(command))).hexdigest()
        existing = state['records'].get(command_id)
        if isinstance(existing, dict):
            if self.reject_command_id_reuse and existing.get('fingerprint') not in (None, fingerprint):
                return CommandAcknowledgement(command_id, 'rejected', _utc_now(), 'command_id_reuse_detected', True)
            return self._ack_from_record(command_id, existing, duplicate=True)

        status = 'accepted'
        detail: str | None = None
        try:
            parsed_command = Command.from_payload(command)
        except CommandValidationError as error:
            status, detail = 'rejected', error.code
        else:
            now = datetime.now(timezone.utc)
            nonce_records = state.setdefault('nonces', {})
            self._prune_nonces(nonce_records, now)
            if self.require_nonce and parsed_command.nonce is None:
                status, detail = 'rejected', 'missing_nonce'
            elif parsed_command.nonce is not None and parsed_command.nonce in nonce_records:
                status, detail = 'rejected', 'replay_detected'
            elif parsed_command.issued_at is not None and parsed_command.issued_at > now + timedelta(seconds=self.clock_skew_seconds):
                status, detail = 'rejected', 'issued_at_in_future'
            elif parsed_command.issued_at is not None and (now - parsed_command.issued_at).total_seconds() > self.replay_window_seconds:
                status, detail = 'rejected', 'command_outside_replay_window'
            elif parsed_command.is_expired(now=now):
                status, detail = 'expired', 'command_expired'
            elif parsed_command.issued_at is not None and (parsed_command.expires_at - parsed_command.issued_at).total_seconds() > self.max_lifetime_seconds:
                status, detail = 'rejected', 'command_lifetime_exceeded'
            elif self.authorization_policy is not None:
                decision = self.authorization_policy.authorize(parsed_command)
                if not decision.allowed:
                    status, detail = 'denied', decision.code

        record = {
            'status': status,
            'detail': detail,
            'acknowledged_at': _utc_now(),
            'pending': True,
            'fingerprint': fingerprint,
        }
        if status == 'accepted' and 'parsed_command' in locals() and parsed_command.nonce is not None:
            state.setdefault('nonces', {})[parsed_command.nonce] = _utc_now()
        state['records'][command_id] = record
        self._trim(state)
        self._write(state)
        return self._ack_from_record(command_id, record)


    def cancel(self, target_command_id: str, *, reason: str | None = None) -> tuple[bool, str]:
        state = self._load()
        record = state['records'].get(target_command_id)
        if isinstance(record, dict):
            status = str(record.get('status') or '')
            result_status = str(record.get('result_status') or '')
            if status in {'expired', 'denied', 'rejected', 'cancelled'} or result_status in {'succeeded', 'failed', 'expired', 'cancelled'}:
                return False, 'command_already_terminal'
        else:
            record = {'acknowledged_at': _utc_now(), 'pending': True}
            state['records'][target_command_id] = record
        record['status'] = 'cancelled'
        record['detail'] = reason or 'cancelled_by_remote_request'
        record['pending'] = True
        self._trim(state)
        self._write(state)
        return True, 'command_cancelled'

    def mark_result(self, command_id: str, status: str, detail: str | None = None) -> None:
        state = self._load()
        record = state['records'].get(command_id)
        if not isinstance(record, dict):
            return
        record['result_status'] = status
        record['result_detail'] = detail
        self._write(state)

    def pending(self) -> list[CommandAcknowledgement]:
        state = self._load()
        result = []
        for command_id, record in state['records'].items():
            if isinstance(record, dict) and record.get('pending') is True:
                result.append(self._ack_from_record(command_id, record))
        return result

    def mark_delivered(self, command_ids: list[str]) -> None:
        if not command_ids:
            return
        state = self._load()
        changed = False
        for command_id in command_ids:
            record = state['records'].get(command_id)
            if isinstance(record, dict) and record.get('pending') is True:
                record['pending'] = False
                changed = True
        if changed:
            self._write(state)

    def _load(self) -> dict[str, Any]:
        if not self.path.exists():
            return {'schema_version': self.SCHEMA_VERSION, 'records': {}, 'nonces': {}}
        try:
            mode = self.path.lstat().st_mode
        except OSError as error:
            raise CommandJournalError(f'no es pot inspeccionar el journal: {error}') from error
        if stat.S_ISLNK(mode) or not stat.S_ISREG(mode):
            raise CommandJournalError('el journal ha de ser un fitxer regular')
        try:
            payload = json.loads(self.path.read_text(encoding='utf-8'))
        except (OSError, json.JSONDecodeError) as error:
            raise CommandJournalError('journal no llegible o JSON invàlid') from error
        if not isinstance(payload, dict) or payload.get('schema_version') != self.SCHEMA_VERSION:
            raise CommandJournalError('esquema de journal no compatible')
        records = payload.get('records')
        if not isinstance(records, dict):
            raise CommandJournalError('registres de journal invàlids')
        nonces = payload.setdefault('nonces', {})
        if not isinstance(nonces, dict):
            raise CommandJournalError('registre de nonces invàlid')
        return payload

    def _prune_nonces(self, nonces: dict[str, Any], now: datetime) -> None:
        for nonce, seen_at in list(nonces.items()):
            parsed = _parse_time(seen_at)
            if parsed is None or (now - parsed).total_seconds() > self.replay_window_seconds:
                nonces.pop(nonce, None)

    def _write(self, payload: dict[str, Any]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_name(f'.{self.path.name}.{os.getpid()}.tmp')
        data = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':')) + '\n'
        try:
            fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, 'w', encoding='utf-8') as stream:
                stream.write(data)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.path)
            os.chmod(self.path, 0o600)
        finally:
            try:
                temporary.unlink()
            except FileNotFoundError:
                pass

    def _trim(self, state: dict[str, Any]) -> None:
        records = state['records']
        overflow = len(records) - self.max_records
        if overflow <= 0:
            return
        completed = [key for key, value in records.items() if isinstance(value, dict) and not value.get('pending')]
        for key in completed[:overflow]:
            records.pop(key, None)

    @staticmethod
    def _ack_from_record(command_id: str, record: Mapping[str, Any], *, duplicate: bool = False) -> CommandAcknowledgement:
        detail = record.get('detail')
        return CommandAcknowledgement(
            command_id=command_id,
            status=str(record.get('status') or 'rejected'),
            acknowledged_at=str(record.get('acknowledged_at') or _utc_now()),
            detail=str(detail) if detail else None,
            duplicate=duplicate,
        )

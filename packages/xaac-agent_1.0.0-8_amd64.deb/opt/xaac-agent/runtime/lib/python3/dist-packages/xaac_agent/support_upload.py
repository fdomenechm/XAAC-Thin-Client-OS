from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
import socket
import ssl
import stat
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Iterable
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import Request, build_opener

from .secrets import SecretFile
from .support_bundle import SupportBundleError, verify_support_bundle
from .tls_policy import TlsPolicy, TlsPolicyError
from .transport import _PinnedHTTPSHandler


class SupportUploadError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class SupportUploadPolicy:
    max_bundle_bytes: int = 16 * 1024 * 1024
    max_response_bytes: int = 64 * 1024
    timeout_seconds: float = 30.0

    def validate(self) -> None:
        if not 1024 <= self.max_bundle_bytes <= 64 * 1024 * 1024:
            raise SupportUploadError("support_upload_bundle_limit_invalid")
        if not 1024 <= self.max_response_bytes <= 1024 * 1024:
            raise SupportUploadError("support_upload_response_limit_invalid")
        if not 1.0 <= self.timeout_seconds <= 300.0:
            raise SupportUploadError("support_upload_timeout_invalid")


def _read_bundle(path: Path, limit: int) -> bytes:
    try:
        meta = path.lstat()
    except OSError as error:
        raise SupportUploadError("support_upload_bundle_unavailable") from error
    if stat.S_ISLNK(meta.st_mode) or not stat.S_ISREG(meta.st_mode):
        raise SupportUploadError("support_upload_bundle_not_regular")
    if meta.st_size > limit:
        raise SupportUploadError("support_upload_bundle_too_large")
    flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NOFOLLOW", 0)
    try:
        fd = os.open(path, flags)
        try:
            data = os.read(fd, limit + 1)
        finally:
            os.close(fd)
    except OSError as error:
        raise SupportUploadError("support_upload_bundle_unavailable") from error
    if len(data) > limit:
        raise SupportUploadError("support_upload_bundle_too_large")
    return data


class SupportBundleUploader:
    def __init__(self, *, opener: Callable[..., Any] | None = None, policy: SupportUploadPolicy | None = None) -> None:
        self.opener = opener
        self.policy = policy or SupportUploadPolicy()
        self.policy.validate()

    def upload(
        self,
        *,
        bundle: Path,
        server_url: str,
        credential: str,
        ca_file: Path | None = None,
        minimum_tls: str = "TLSv1.2",
        maximum_tls: str = "",
        ciphers: str = "",
        certificate_pins: tuple[str, ...] = (),
    ) -> dict[str, object]:
        parsed = urlsplit(server_url)
        if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise SupportUploadError("support_upload_https_url_required")
        if not credential or any(ch in credential for ch in "\r\n\x00"):
            raise SupportUploadError("support_upload_credential_invalid")
        try:
            verification = verify_support_bundle(bundle, max_archive_bytes=self.policy.max_bundle_bytes)
        except SupportBundleError as error:
            raise SupportUploadError(str(error)) from error
        body = _read_bundle(bundle, self.policy.max_bundle_bytes)
        bundle_id = str(verification["bundle_id"])
        digest = base64.b64encode(hashlib.sha256(body).digest()).decode("ascii")
        endpoint = server_url.rstrip("/") + "/api/xmp/v1/support-bundles"
        request = Request(endpoint, data=body, method="POST", headers={
            "Accept": "application/json",
            "Authorization": f"Bearer {credential}",
            "Content-Type": "application/vnd.xaac.support-bundle+zip",
            "Content-Length": str(len(body)),
            "Digest": f"sha-256={digest}",
            "Idempotency-Key": bundle_id,
            "X-XAAC-Bundle-ID": bundle_id,
            "User-Agent": "XAAC-Agent/0.11 XMP/1.0",
        })
        try:
            context = TlsPolicy(minimum_tls, maximum_tls, ciphers, certificate_pins).create_context(
                cafile=str(ca_file) if ca_file else None
            )
            if self.opener is not None:
                response_context = self.opener(request, timeout=self.policy.timeout_seconds, context=context)
            else:
                response_context = build_opener(
                    _PinnedHTTPSHandler(context=context, certificate_pins=certificate_pins)
                ).open(request, timeout=self.policy.timeout_seconds)
            with response_context as response:
                status = int(getattr(response, "status", 200))
                raw = response.read(self.policy.max_response_bytes + 1)
        except HTTPError as error:
            raise SupportUploadError(f"support_upload_http_{error.code}") from error
        except (socket.timeout, TimeoutError) as error:
            raise SupportUploadError("support_upload_timeout") from error
        except (ssl.SSLError, TlsPolicyError) as error:
            raise SupportUploadError("support_upload_tls_failure") from error
        except URLError as error:
            raise SupportUploadError("support_upload_connection_failure") from error
        except OSError as error:
            raise SupportUploadError("support_upload_connection_failure") from error
        if len(raw) > self.policy.max_response_bytes:
            raise SupportUploadError("support_upload_response_too_large")
        if status not in {200, 201, 202}:
            raise SupportUploadError(f"support_upload_http_{status}")
        try:
            payload = json.loads(raw.decode("utf-8")) if raw else {}
        except (UnicodeError, json.JSONDecodeError) as error:
            raise SupportUploadError("support_upload_response_invalid") from error
        if not isinstance(payload, dict):
            raise SupportUploadError("support_upload_response_invalid")
        receipt_bundle_id = payload.get("bundle_id", bundle_id)
        if receipt_bundle_id != bundle_id:
            raise SupportUploadError("support_upload_receipt_mismatch")
        return {
            "format": "xaac-support-upload-result/v1",
            "status": "accepted",
            "http_status": status,
            "bundle_id": bundle_id,
            "receipt_id": payload.get("receipt_id"),
        }


def main(argv: Iterable[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Verify and securely upload an XAAC support bundle")
    parser.add_argument("--bundle", required=True, type=Path)
    parser.add_argument("--server-url", required=True)
    parser.add_argument("--credential-file", required=True, type=Path)
    parser.add_argument("--ca-file", type=Path)
    parser.add_argument("--tls-minimum-version", default="TLSv1.2")
    parser.add_argument("--tls-maximum-version", default="")
    parser.add_argument("--tls-ciphers", default="")
    parser.add_argument("--certificate-pin", action="append", default=[])
    parser.add_argument("--timeout", type=float, default=30.0)
    args = parser.parse_args(list(argv) if argv is not None else None)
    try:
        credential = SecretFile(args.credential_file).read()
        result = SupportBundleUploader(policy=SupportUploadPolicy(timeout_seconds=args.timeout)).upload(
            bundle=args.bundle,
            server_url=args.server_url,
            credential=credential,
            ca_file=args.ca_file,
            minimum_tls=args.tls_minimum_version,
            maximum_tls=args.tls_maximum_version,
            ciphers=args.tls_ciphers,
            certificate_pins=tuple(args.certificate_pin),
        )
    except (SupportUploadError, OSError, ValueError) as error:
        print(json.dumps({"format": "xaac-support-upload-error/v1", "status": "error", "code": str(error)}, sort_keys=True))
        return 2
    print(json.dumps(result, sort_keys=True, separators=(",", ":")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

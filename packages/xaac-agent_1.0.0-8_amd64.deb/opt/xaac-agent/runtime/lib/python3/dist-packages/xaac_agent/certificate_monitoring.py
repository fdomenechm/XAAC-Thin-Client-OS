from __future__ import annotations

import hashlib
import socket
import ssl
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable
from urllib.parse import urlparse

from cryptography import x509
from cryptography.hazmat.primitives import serialization
from cryptography.x509.oid import NameOID

from xaac_agent.enrollment import (
    DeviceCredentialsStore,
    InvalidDeviceCredentialsError,
    parse_utc_timestamp,
)


@dataclass(frozen=True, slots=True)
class ExpiryThresholds:
    warning_days: int = 30
    critical_days: int = 7

    def validate(self) -> None:
        if not 1 <= self.critical_days < self.warning_days <= 3650:
            raise ValueError("invalid certificate expiry thresholds")


def _utc(value: datetime) -> datetime:
    return value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value.astimezone(timezone.utc)


def _days_remaining(expires_at: datetime, now: datetime) -> float:
    return round((_utc(expires_at) - _utc(now)).total_seconds() / 86400.0, 3)


def _expiry_state(days: float, thresholds: ExpiryThresholds) -> str:
    if days < 0:
        return "critical"
    if days <= thresholds.critical_days:
        return "critical"
    if days <= thresholds.warning_days:
        return "warning"
    return "normal"


def _name_value(name: x509.Name, oid: x509.ObjectIdentifier) -> str | None:
    values = name.get_attributes_for_oid(oid)
    return values[0].value if values else None


def _certificate_payload(cert: x509.Certificate, *, now: datetime, thresholds: ExpiryThresholds) -> dict[str, object]:
    not_before = getattr(cert, "not_valid_before_utc", None) or cert.not_valid_before.replace(tzinfo=timezone.utc)
    not_after = getattr(cert, "not_valid_after_utc", None) or cert.not_valid_after.replace(tzinfo=timezone.utc)
    days = _days_remaining(not_after, now)
    payload: dict[str, object] = {
        "not_before": _utc(not_before).isoformat().replace("+00:00", "Z"),
        "not_after": _utc(not_after).isoformat().replace("+00:00", "Z"),
        "days_remaining": days,
        "currently_valid": _utc(not_before) <= _utc(now) <= _utc(not_after),
        "state": _expiry_state(days, thresholds),
        "sha256": hashlib.sha256(cert.public_bytes(serialization.Encoding.DER)).hexdigest(),
    }
    common_name = _name_value(cert.subject, NameOID.COMMON_NAME)
    issuer = _name_value(cert.issuer, NameOID.COMMON_NAME)
    if common_name:
        payload["common_name"] = common_name
    if issuer:
        payload["issuer_common_name"] = issuer
    return payload


class CertificateCredentialMonitor:
    """Monitor device credential and TLS certificate expiration without exposing secrets."""

    def __init__(
        self,
        server_url: str,
        credentials_file: Path,
        *,
        timeout_seconds: float = 2.0,
        thresholds: ExpiryThresholds | None = None,
        tls_ca_file: Path | None = None,
        now: Callable[[], datetime] | None = None,
        peer_certificate_fetcher: Callable[[str, int, float, Path | None], bytes] | None = None,
    ) -> None:
        self._server_url = server_url
        self._credentials_file = credentials_file
        self._timeout = timeout_seconds
        self._thresholds = thresholds or ExpiryThresholds()
        self._thresholds.validate()
        self._tls_ca_file = tls_ca_file
        self._now = now or (lambda: datetime.now(timezone.utc))
        self._peer_certificate_fetcher = peer_certificate_fetcher or self._fetch_peer_certificate

    def sample(self) -> dict[str, object]:
        now = _utc(self._now())
        credential = self._credential_payload(now)
        tls = self._tls_payload(now)
        severities = [credential.get("severity"), tls.get("severity")]
        severity = "critical" if "critical" in severities else "warning" if "warning" in severities else "normal"
        return {"credential": credential, "tls": tls, "severity": severity}

    def _credential_payload(self, now: datetime) -> dict[str, object]:
        store = DeviceCredentialsStore(self._credentials_file)
        try:
            credentials = store.load()
        except FileNotFoundError:
            return {"present": False, "status": "missing", "severity": "critical"}
        except InvalidDeviceCredentialsError as error:
            return {"present": True, "status": "invalid", "severity": "critical", "error": str(error)}

        payload: dict[str, object] = {
            "present": True,
            "status": "valid",
            "issued_at": credentials.issued_at,
            "severity": "normal",
        }
        if credentials.expires_at is None:
            payload.update({"status": "legacy-no-expiry", "severity": "warning"})
            return payload
        expires = parse_utc_timestamp(credentials.expires_at, field_name="expires_at")
        days = _days_remaining(expires, now)
        state = _expiry_state(days, self._thresholds)
        payload.update(
            {
                "expires_at": credentials.expires_at,
                "days_remaining": days,
                "expired": days < 0,
                "renewal_due": days <= self._thresholds.warning_days,
                "status": "expired" if days < 0 else "valid",
                "severity": state,
            }
        )
        return payload

    def _tls_payload(self, now: datetime) -> dict[str, object]:
        parsed = urlparse(self._server_url)
        if parsed.scheme != "https":
            return {"applicable": False, "status": "not-applicable", "severity": "normal"}
        if not parsed.hostname:
            return {"applicable": True, "status": "invalid-server-url", "severity": "critical"}
        port = parsed.port or 443
        try:
            der = self._peer_certificate_fetcher(parsed.hostname, port, self._timeout, self._tls_ca_file)
            cert = x509.load_der_x509_certificate(der)
            payload = _certificate_payload(cert, now=now, thresholds=self._thresholds)
            payload.update({"applicable": True, "status": "valid" if payload["currently_valid"] else "invalid"})
            payload["severity"] = payload.pop("state")
            return payload
        except (OSError, ssl.SSLError, ValueError, x509.ExtensionNotFound) as error:
            return {
                "applicable": True,
                "status": "unavailable",
                "severity": "warning",
                "error_category": "tls-certificate",
                "error": str(error),
            }

    @staticmethod
    def _fetch_peer_certificate(host: str, port: int, timeout: float, ca_file: Path | None) -> bytes:
        context = ssl.create_default_context(cafile=str(ca_file) if ca_file else None)
        with socket.create_connection((host, port), timeout=timeout) as raw:
            with context.wrap_socket(raw, server_hostname=host) as secured:
                certificate = secured.getpeercert(binary_form=True)
                if not certificate:
                    raise ssl.SSLError("peer did not provide a certificate")
                return certificate

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re
import subprocess
from typing import Callable, Iterable


_PROCESS_NAME_RE = re.compile(r"^[A-Za-z0-9_.@+-]{1,128}$")
_SERVICE_NAME_RE = re.compile(r"^[A-Za-z0-9_.@:-]{1,200}\.service$")


def _safe_iterdir(path: Path) -> tuple[Path, ...]:
    try:
        if not path.is_dir():
            return ()
        return tuple(path.iterdir())
    except OSError:
        return ()


def _read_regular_text(path: Path) -> str | None:
    try:
        if path.is_symlink() or not path.is_file():
            return None
        return path.read_text(encoding="utf-8", errors="replace").strip()
    except OSError:
        return None


def _parse_status_rss_bytes(raw: str | None) -> int | None:
    if not raw:
        return None
    for line in raw.splitlines():
        if not line.startswith("VmRSS:"):
            continue
        fields = line.split()
        if len(fields) >= 2 and fields[1].isdigit():
            return int(fields[1]) * 1024
    return None


def _normalise_processes(values: Iterable[str]) -> tuple[str, ...]:
    result = []
    for value in values:
        name = value.strip()
        if name and _PROCESS_NAME_RE.fullmatch(name) and name not in result:
            result.append(name)
    return tuple(result)


def _normalise_services(values: Iterable[str]) -> tuple[str, ...]:
    result = []
    for value in values:
        name = value.strip()
        if name and _SERVICE_NAME_RE.fullmatch(name) and name not in result:
            result.append(name)
    return tuple(result)


@dataclass(frozen=True, slots=True)
class ServiceStatus:
    name: str
    load_state: str = "unknown"
    active_state: str = "unknown"
    sub_state: str = "unknown"
    result: str = "unknown"
    main_pid: int | None = None
    available: bool = True

    @property
    def state(self) -> str:
        if not self.available or self.load_state in {"not-found", "masked"}:
            return "critical"
        if self.active_state == "failed" or self.result not in {"", "success", "unknown"}:
            return "critical"
        if self.active_state == "active":
            return "normal"
        return "warning"

    def to_payload(self) -> dict[str, object]:
        payload: dict[str, object] = {
            "name": self.name,
            "load_state": self.load_state,
            "active_state": self.active_state,
            "sub_state": self.sub_state,
            "result": self.result,
            "state": self.state,
        }
        if self.main_pid is not None:
            payload["main_pid"] = self.main_pid
        return payload


def query_systemd_service(name: str, timeout_seconds: float) -> ServiceStatus:
    try:
        completed = subprocess.run(
            [
                "systemctl", "show", name, "--no-pager",
                "--property=LoadState,ActiveState,SubState,Result,MainPID",
            ],
            check=False,
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
        )
    except (OSError, subprocess.TimeoutExpired):
        return ServiceStatus(name=name, available=False)
    values: dict[str, str] = {}
    for line in completed.stdout.splitlines():
        key, separator, value = line.partition("=")
        if separator:
            values[key] = value.strip()
    main_pid_raw = values.get("MainPID", "")
    main_pid = int(main_pid_raw) if main_pid_raw.isdigit() and int(main_pid_raw) > 0 else None
    return ServiceStatus(
        name=name,
        load_state=values.get("LoadState", "unknown"),
        active_state=values.get("ActiveState", "unknown"),
        sub_state=values.get("SubState", "unknown"),
        result=values.get("Result", "unknown"),
        main_pid=main_pid,
        available=bool(values) and completed.returncode in {0, 3, 4},
    )


class ProcessServiceMonitor:
    """Estat lleuger de processos configurats i serveis systemd crítics."""

    def __init__(
        self,
        *,
        process_names: Iterable[str] = (),
        service_names: Iterable[str] = (),
        proc_root: Path = Path("/proc"),
        service_timeout_seconds: float = 2.0,
        service_reader: Callable[[str, float], ServiceStatus] = query_systemd_service,
    ) -> None:
        self._process_names = _normalise_processes(process_names)
        self._service_names = _normalise_services(service_names)
        self._proc_root = proc_root
        self._service_timeout_seconds = service_timeout_seconds
        self._service_reader = service_reader

    def sample(self) -> dict[str, object]:
        process_payloads = self._process_payloads()
        service_payloads = [
            self._service_reader(name, self._service_timeout_seconds).to_payload()
            for name in self._service_names
        ]
        states = [str(item["state"]) for item in (*process_payloads, *service_payloads)]
        severity = "critical" if "critical" in states else ("warning" if "warning" in states else "normal")
        return {
            "configured_process_count": len(self._process_names),
            "configured_service_count": len(self._service_names),
            "processes": process_payloads,
            "services": service_payloads,
            "severity": severity,
        }

    def _process_payloads(self) -> list[dict[str, object]]:
        found: dict[str, list[tuple[int, int | None]]] = {name: [] for name in self._process_names}
        if not found:
            return []
        for entry in _safe_iterdir(self._proc_root):
            if not entry.name.isdigit() or not entry.is_dir():
                continue
            comm = _read_regular_text(entry / "comm")
            if comm not in found:
                continue
            rss = _parse_status_rss_bytes(_read_regular_text(entry / "status"))
            found[comm].append((int(entry.name), rss))
        payloads: list[dict[str, object]] = []
        for name in self._process_names:
            matches = found[name]
            payload: dict[str, object] = {
                "name": name,
                "running": bool(matches),
                "instance_count": len(matches),
                "pids": sorted(pid for pid, _ in matches),
                "state": "normal" if matches else "critical",
            }
            rss_values = [rss for _, rss in matches if rss is not None]
            if rss_values:
                payload["rss_bytes"] = sum(rss_values)
            payloads.append(payload)
        return payloads

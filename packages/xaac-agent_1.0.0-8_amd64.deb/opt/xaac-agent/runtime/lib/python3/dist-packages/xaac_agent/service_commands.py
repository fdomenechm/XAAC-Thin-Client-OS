from __future__ import annotations

import subprocess
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Protocol, Sequence

from xaac_agent.command_model import Command, CommandResult, CommandState, CommandType
from xaac_agent.privileged_helper import PrivilegedHelperClient


class ServiceCommandBackend(Protocol):
    def run(self, argv: Sequence[str], *, timeout_seconds: int) -> subprocess.CompletedProcess[str]: ...


class SubprocessServiceBackend:
    """Execució local mínima: argv validada, sense shell, stdin ni entorn remot."""

    def run(self, argv: Sequence[str], *, timeout_seconds: int) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            list(argv),
            check=False,
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
            stdin=subprocess.DEVNULL,
        )


@dataclass(frozen=True, slots=True)
class ServiceCommandExecutor:
    backend: ServiceCommandBackend
    systemctl_path: str = "/usr/bin/systemctl"

    @classmethod
    def system_default(cls) -> "ServiceCommandExecutor":
        return cls(backend=PrivilegedHelperClient())

    def execute(self, command: Command) -> CommandResult:
        if command.command_type is not CommandType.SERVICE:
            raise ValueError("unsupported_service_command")

        started_at = _utc_now()
        service = str(command.parameters["service"])
        action = str(command.parameters["action"])
        timeout = int(command.parameters.get("timeout_seconds", 300))
        argv = self._argv(service=service, action=action)
        try:
            completed = self.backend.run(argv, timeout_seconds=timeout)
        except subprocess.TimeoutExpired:
            return self._failed(command, started_at, "service_command_timeout", service, action)
        except OSError as error:
            return self._failed(
                command, started_at, "service_command_backend_error", service, action, str(error)
            )

        if action == "status":
            return self._status_result(command, started_at, completed, service)
        if completed.returncode != 0:
            return self._failed(
                command,
                started_at,
                "service_command_rejected",
                service,
                action,
                _safe_detail(completed.stderr or completed.stdout),
            )
        return CommandResult(
            command_id=command.command_id,
            state=CommandState.SUCCEEDED,
            started_at=started_at,
            finished_at=_utc_now(),
            code="service_action_completed",
            data={"service": service, "action": action},
        )

    def _argv(self, *, service: str, action: str) -> tuple[str, ...]:
        if action == "status":
            return (
                self.systemctl_path,
                "show",
                service,
                "--property=LoadState,ActiveState,SubState,UnitFileState",
                "--value",
                "--no-pager",
            )
        return (self.systemctl_path, action, service, "--no-block", "--no-pager")

    def _status_result(
        self,
        command: Command,
        started_at: str,
        completed: subprocess.CompletedProcess[str],
        service: str,
    ) -> CommandResult:
        if completed.returncode != 0:
            return self._failed(
                command,
                started_at,
                "service_status_unavailable",
                service,
                "status",
                _safe_detail(completed.stderr or completed.stdout),
            )
        values = [line.strip() for line in completed.stdout.splitlines()]
        values.extend([""] * (4 - len(values)))
        load_state, active_state, sub_state, unit_file_state = values[:4]
        return CommandResult(
            command_id=command.command_id,
            state=CommandState.SUCCEEDED,
            started_at=started_at,
            finished_at=_utc_now(),
            code="service_status_collected",
            data={
                "service": service,
                "action": "status",
                "load_state": load_state or "unknown",
                "active_state": active_state or "unknown",
                "sub_state": sub_state or "unknown",
                "unit_file_state": unit_file_state or "unknown",
            },
        )

    @staticmethod
    def _failed(
        command: Command,
        started_at: str,
        code: str,
        service: str,
        action: str,
        detail: str | None = None,
    ) -> CommandResult:
        return CommandResult(
            command_id=command.command_id,
            state=CommandState.FAILED,
            started_at=started_at,
            finished_at=_utc_now(),
            code=code,
            message=detail,
            data={"service": service, "action": action},
        )


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _safe_detail(value: str | None) -> str | None:
    if not value:
        return None
    compact = " ".join(value.split())
    return compact[:512] or None

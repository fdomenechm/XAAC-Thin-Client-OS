from __future__ import annotations

import hashlib
import json
import os
import stat
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

from .policy_model import Policy, PolicyResult


class PolicyAuditError(RuntimeError):
    """El registre d'auditoria de polítiques és invàlid o insegur."""


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _canonical(value: Mapping[str, Any]) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _safe_data(data: Mapping[str, Any] | None) -> dict[str, Any]:
    """Conserva només metadades d'auditoria no sensibles i de mida acotada."""
    if not data:
        return {}
    allowed = {
        "sha256",
        "canonical_sha256",
        "schema_id",
        "schema_revision",
        "key_id",
        "algorithm",
        "agent_version",
        "protocol_version",
        "previous_preserved",
        "verified_at",
        "applied_at",
        "rolled_back_from_revision",
        "replaced_revision",
        "conflict_count",
        "warning_count",
        "probe_count",
        "vpn_mode",
        "previous_vpn_mode",
        "changed",
        "rollback_failed",
    }
    result: dict[str, Any] = {}
    for key in sorted(allowed.intersection(data)):
        value = data[key]
        if isinstance(value, (str, int, float, bool)) or value is None:
            if isinstance(value, str):
                value = value[:512]
            result[key] = value
    return result


class PolicyAuditJournal:
    """Historial local limitat amb cadena hash per al cicle de vida de polítiques."""

    SCHEMA_VERSION = 1
    GENESIS_HASH = "0" * 64

    def __init__(self, path: Path, *, max_records: int = 512) -> None:
        self.path = path
        self.max_records = max(32, max_records)

    def append(
        self,
        event: str,
        policy_id: str,
        revision: int,
        *,
        policy_type: str | None = None,
        issuer_id: str | None = None,
        state: str | None = None,
        code: str | None = None,
        data: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        payload = self._load()
        records = payload["records"]
        previous_hash = records[-1]["hash"] if records else self.GENESIS_HASH
        record: dict[str, Any] = {
            "sequence": (records[-1]["sequence"] + 1) if records else 1,
            "recorded_at": _utc_now(),
            "event": self._clean_text(event, "event"),
            "policy_id": self._clean_text(policy_id, "policy_id"),
            "revision": self._revision(revision),
            "previous_hash": previous_hash,
        }
        for key, value in (
            ("policy_type", policy_type),
            ("issuer_id", issuer_id),
            ("state", state),
            ("code", code),
        ):
            if value is not None:
                record[key] = self._clean_text(value, key)
        safe = _safe_data(data)
        if safe:
            record["data"] = safe
        record["hash"] = hashlib.sha256(_canonical(record)).hexdigest()
        records.append(record)
        self._trim_and_rechain(records)
        self._write(payload)
        return dict(record)

    def append_policy(
        self,
        event: str,
        policy: Policy,
        *,
        state: str | None = None,
        code: str | None = None,
        data: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        return self.append(
            event,
            policy.policy_id,
            policy.revision,
            policy_type=policy.policy_type.value,
            issuer_id=policy.issuer.issuer_id,
            state=state,
            code=code,
            data=data,
        )

    def append_result(self, event: str, result: PolicyResult) -> dict[str, Any]:
        return self.append(
            event,
            result.policy_id,
            result.revision,
            state=result.state.value,
            code=result.code,
            data=result.data,
        )

    def records(self) -> list[dict[str, Any]]:
        return [dict(record) for record in self._load()["records"]]

    def history(self, policy_id: str, *, revision: int | None = None) -> list[dict[str, Any]]:
        wanted = self._clean_text(policy_id, "policy_id")
        return [
            dict(record)
            for record in self._load()["records"]
            if record.get("policy_id") == wanted and (revision is None or record.get("revision") == revision)
        ]

    def verify(self) -> bool:
        records = self._load()["records"]
        previous = self.GENESIS_HASH
        last_sequence = 0
        for record in records:
            if not isinstance(record, dict):
                return False
            sequence = record.get("sequence")
            if not isinstance(sequence, int) or sequence <= last_sequence:
                return False
            if record.get("previous_hash") != previous:
                return False
            claimed = record.get("hash")
            content = {key: value for key, value in record.items() if key != "hash"}
            if claimed != hashlib.sha256(_canonical(content)).hexdigest():
                return False
            previous = str(claimed)
            last_sequence = sequence
        return True

    def _trim_and_rechain(self, records: list[dict[str, Any]]) -> None:
        if len(records) <= self.max_records:
            return
        records[:] = records[-self.max_records :]
        previous = self.GENESIS_HASH
        for record in records:
            record["previous_hash"] = previous
            record["hash"] = hashlib.sha256(
                _canonical({key: value for key, value in record.items() if key != "hash"})
            ).hexdigest()
            previous = record["hash"]

    def _load(self) -> dict[str, Any]:
        if not self.path.exists():
            return {"schema_version": self.SCHEMA_VERSION, "records": []}
        mode = self.path.lstat().st_mode
        if stat.S_ISLNK(mode) or not stat.S_ISREG(mode):
            raise PolicyAuditError("l'auditoria de polítiques ha de ser un fitxer regular")
        try:
            payload = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
            raise PolicyAuditError("auditoria de polítiques no llegible o JSON invàlid") from error
        if not isinstance(payload, dict) or payload.get("schema_version") != self.SCHEMA_VERSION:
            raise PolicyAuditError("esquema d'auditoria de polítiques no compatible")
        if not isinstance(payload.get("records"), list):
            raise PolicyAuditError("registres d'auditoria de polítiques invàlids")
        return payload

    def _write(self, payload: dict[str, Any]) -> None:
        if self.path.parent.is_symlink():
            raise PolicyAuditError("el directori d'auditoria de polítiques no pot ser un symlink")
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            if not stat.S_ISDIR(self.path.parent.stat().st_mode):
                raise PolicyAuditError("directori d'auditoria de polítiques invàlid")
            os.chmod(self.path.parent, 0o700)
        except OSError as error:
            raise PolicyAuditError("directori d'auditoria de polítiques no disponible") from error

        temporary = self.path.with_name(f".{self.path.name}.{os.getpid()}.tmp")
        data = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n"
        try:
            fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as stream:
                stream.write(data)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.path)
            os.chmod(self.path, 0o600)
            directory_fd = os.open(self.path.parent, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
        except OSError as error:
            raise PolicyAuditError("no s'ha pogut persistir l'auditoria de polítiques") from error
        finally:
            temporary.unlink(missing_ok=True)

    @staticmethod
    def _clean_text(value: str, field: str) -> str:
        if not isinstance(value, str) or not value.strip() or len(value.strip()) > 256:
            raise PolicyAuditError(f"{field} invàlid")
        return value.strip()

    @staticmethod
    def _revision(value: int) -> int:
        if isinstance(value, bool) or not isinstance(value, int) or value < 1:
            raise PolicyAuditError("revision invàlida")
        return value

from __future__ import annotations

import argparse
import json
import os
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Callable, Iterable, Sequence

_FORMAT = "xaac-soak-test/v1"
_MAX_READ_BYTES = 131072
_MAX_SAMPLES = 100000
_MAX_DURATION_SECONDS = 30 * 24 * 3600


class SoakTestError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class ProcessSample:
    monotonic_seconds: float
    rss_bytes: int
    threads: int
    file_descriptors: int
    cpu_seconds: float
    write_bytes: int


@dataclass(frozen=True, slots=True)
class SoakThresholds:
    rss_warning_growth_bytes: int
    rss_critical_growth_bytes: int
    fd_warning_growth: int
    fd_critical_growth: int
    thread_warning_growth: int
    thread_critical_growth: int
    write_warning_bytes_per_hour: int
    write_critical_bytes_per_hour: int


@dataclass(frozen=True, slots=True)
class SoakTestReport:
    format: str
    profile_id: str
    status: str
    sample_count: int
    elapsed_seconds: float
    first: dict[str, int | float]
    last: dict[str, int | float]
    peak: dict[str, int | float]
    growth: dict[str, int | float]
    rates: dict[str, float]
    signals: dict[str, str]
    thresholds: dict[str, int]

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def thresholds_for_profile(profile_id: str) -> SoakThresholds:
    if profile_id == "dell-wyse-3040":
        return SoakThresholds(
            rss_warning_growth_bytes=32 * 1024 * 1024,
            rss_critical_growth_bytes=96 * 1024 * 1024,
            fd_warning_growth=32,
            fd_critical_growth=128,
            thread_warning_growth=8,
            thread_critical_growth=32,
            write_warning_bytes_per_hour=256 * 1024 * 1024,
            write_critical_bytes_per_hour=1024 * 1024 * 1024,
        )
    return SoakThresholds(
        rss_warning_growth_bytes=64 * 1024 * 1024,
        rss_critical_growth_bytes=192 * 1024 * 1024,
        fd_warning_growth=64,
        fd_critical_growth=256,
        thread_warning_growth=16,
        thread_critical_growth=64,
        write_warning_bytes_per_hour=512 * 1024 * 1024,
        write_critical_bytes_per_hour=2 * 1024 * 1024 * 1024,
    )


def _safe_read(path: Path, *, max_bytes: int = _MAX_READ_BYTES) -> str:
    if path.is_symlink():
        raise SoakTestError(f"symlink_not_allowed:{path.name}")
    try:
        stat = path.stat()
    except OSError as exc:
        raise SoakTestError(f"unavailable:{path.name}") from exc
    if not path.is_file() or stat.st_size > max_bytes:
        raise SoakTestError(f"invalid_file:{path.name}")
    try:
        data = path.read_bytes()
    except OSError as exc:
        raise SoakTestError(f"unreadable:{path.name}") from exc
    if len(data) > max_bytes:
        raise SoakTestError(f"oversized:{path.name}")
    return data.decode("utf-8", errors="strict")


def read_process_sample(pid: int, *, proc_root: Path = Path("/proc"), clock: Callable[[], float] = time.monotonic) -> ProcessSample:
    if pid <= 0:
        raise SoakTestError("pid_must_be_positive")
    base = proc_root / str(pid)
    status = _safe_read(base / "status")
    io_text = _safe_read(base / "io")
    stat_text = _safe_read(base / "stat")

    status_values: dict[str, str] = {}
    for line in status.splitlines():
        if ":" in line:
            key, value = line.split(":", 1)
            status_values[key] = value.strip()
    try:
        rss_kib = int(status_values["VmRSS"].split()[0])
        threads = int(status_values["Threads"].split()[0])
    except (KeyError, ValueError, IndexError) as exc:
        raise SoakTestError("invalid_status") from exc

    write_bytes = 0
    for line in io_text.splitlines():
        if line.startswith("write_bytes:"):
            try:
                write_bytes = int(line.split(":", 1)[1].strip())
            except ValueError as exc:
                raise SoakTestError("invalid_io") from exc
            break

    # /proc/PID/stat may contain spaces inside the comm field. Parse after the final ')'.
    close = stat_text.rfind(")")
    if close < 0:
        raise SoakTestError("invalid_stat")
    fields = stat_text[close + 2 :].split()
    try:
        user_ticks = int(fields[11])
        system_ticks = int(fields[12])
        ticks_per_second = int(os.sysconf("SC_CLK_TCK"))
    except (IndexError, ValueError, OSError) as exc:
        raise SoakTestError("invalid_stat") from exc

    fd_dir = base / "fd"
    if fd_dir.is_symlink():
        raise SoakTestError("symlink_not_allowed:fd")
    try:
        file_descriptors = sum(1 for _ in os.scandir(fd_dir))
    except OSError as exc:
        raise SoakTestError("unavailable:fd") from exc

    return ProcessSample(
        monotonic_seconds=float(clock()),
        rss_bytes=rss_kib * 1024,
        threads=threads,
        file_descriptors=file_descriptors,
        cpu_seconds=(user_ticks + system_ticks) / ticks_per_second,
        write_bytes=write_bytes,
    )


def analyse_samples(samples: Sequence[ProcessSample], *, profile_id: str = "generic") -> SoakTestReport:
    if len(samples) < 2:
        raise SoakTestError("at_least_two_samples_required")
    if len(samples) > _MAX_SAMPLES:
        raise SoakTestError("too_many_samples")
    for previous, current in zip(samples, samples[1:]):
        if current.monotonic_seconds <= previous.monotonic_seconds:
            raise SoakTestError("sample_times_must_increase")

    first, last = samples[0], samples[-1]
    elapsed = last.monotonic_seconds - first.monotonic_seconds
    rss_growth = last.rss_bytes - first.rss_bytes
    fd_growth = last.file_descriptors - first.file_descriptors
    thread_growth = last.threads - first.threads
    write_growth = max(0, last.write_bytes - first.write_bytes)
    cpu_growth = max(0.0, last.cpu_seconds - first.cpu_seconds)
    hours = elapsed / 3600.0
    write_rate = write_growth / hours if hours > 0 else 0.0
    cpu_percent = (cpu_growth / elapsed) * 100.0 if elapsed > 0 else 0.0

    thresholds = thresholds_for_profile(profile_id)
    signals = {
        "rss_growth": _severity(rss_growth, thresholds.rss_warning_growth_bytes, thresholds.rss_critical_growth_bytes),
        "file_descriptor_growth": _severity(fd_growth, thresholds.fd_warning_growth, thresholds.fd_critical_growth),
        "thread_growth": _severity(thread_growth, thresholds.thread_warning_growth, thresholds.thread_critical_growth),
        "write_rate": _severity(write_rate, thresholds.write_warning_bytes_per_hour, thresholds.write_critical_bytes_per_hour),
    }
    status = "critical" if "critical" in signals.values() else "warning" if "warning" in signals.values() else "ok"

    return SoakTestReport(
        format=_FORMAT,
        profile_id=profile_id,
        status=status,
        sample_count=len(samples),
        elapsed_seconds=round(elapsed, 6),
        first=_sample_payload(first),
        last=_sample_payload(last),
        peak={
            "rss_bytes": max(item.rss_bytes for item in samples),
            "threads": max(item.threads for item in samples),
            "file_descriptors": max(item.file_descriptors for item in samples),
        },
        growth={
            "rss_bytes": rss_growth,
            "threads": thread_growth,
            "file_descriptors": fd_growth,
            "write_bytes": write_growth,
            "cpu_seconds": round(cpu_growth, 6),
        },
        rates={
            "write_bytes_per_hour": round(write_rate, 3),
            "average_cpu_percent": round(cpu_percent, 3),
        },
        signals=signals,
        thresholds=asdict(thresholds),
    )


def run_soak_test(
    *,
    pid: int,
    duration_seconds: float,
    interval_seconds: float,
    profile_id: str = "generic",
    sampler: Callable[[int], ProcessSample] = read_process_sample,
    sleeper: Callable[[float], None] = time.sleep,
) -> SoakTestReport:
    if not 1 <= duration_seconds <= _MAX_DURATION_SECONDS:
        raise SoakTestError("duration_out_of_range")
    if not 1 <= interval_seconds <= duration_seconds:
        raise SoakTestError("interval_out_of_range")
    sample_count = int(duration_seconds // interval_seconds) + 1
    if sample_count > _MAX_SAMPLES:
        raise SoakTestError("too_many_samples")
    samples: list[ProcessSample] = []
    for index in range(sample_count):
        samples.append(sampler(pid))
        if index + 1 < sample_count:
            sleeper(interval_seconds)
    return analyse_samples(samples, profile_id=profile_id)


def _severity(value: float, warning: float, critical: float) -> str:
    if value >= critical:
        return "critical"
    if value >= warning:
        return "warning"
    return "normal"


def _sample_payload(sample: ProcessSample) -> dict[str, int | float]:
    return {
        "rss_bytes": sample.rss_bytes,
        "threads": sample.threads,
        "file_descriptors": sample.file_descriptors,
        "cpu_seconds": round(sample.cpu_seconds, 6),
        "write_bytes": sample.write_bytes,
    }


def main(argv: Iterable[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run a bounded XAAC Agent soak test")
    parser.add_argument("--pid", type=int, required=True)
    parser.add_argument("--duration-seconds", type=float, default=3600.0)
    parser.add_argument("--interval-seconds", type=float, default=60.0)
    parser.add_argument("--profile", choices=("generic", "dell-wyse-3040"), default="generic")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(list(argv) if argv is not None else None)
    try:
        report = run_soak_test(
            pid=args.pid,
            duration_seconds=args.duration_seconds,
            interval_seconds=args.interval_seconds,
            profile_id=args.profile,
        )
    except SoakTestError as exc:
        parser.error(str(exc))
    payload = json.dumps(report.to_dict(), sort_keys=True, separators=(",", ":")) + "\n"
    if args.output is None:
        print(payload, end="")
    else:
        args.output.write_text(payload, encoding="utf-8")
        os.chmod(args.output, 0o600)
    return 1 if report.status == "critical" else 0


if __name__ == "__main__":
    raise SystemExit(main())

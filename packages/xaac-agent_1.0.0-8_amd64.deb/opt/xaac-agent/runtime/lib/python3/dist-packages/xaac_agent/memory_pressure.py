from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

from xaac_agent.hardware_profile import HardwareProfile

_MAX_PROC_BYTES = 128 * 1024
_PSI_LINE = re.compile(r"^(some|full)\s+avg10=([0-9.]+)\s+avg60=([0-9.]+)\s+avg300=([0-9.]+)\s+total=(\d+)$")


def _read_bounded(path: Path) -> str | None:
    try:
        if path.is_symlink() or not path.is_file():
            return None
        with path.open("rb") as handle:
            raw = handle.read(_MAX_PROC_BYTES + 1)
    except OSError:
        return None
    if len(raw) > _MAX_PROC_BYTES:
        return None
    return raw.decode("utf-8", errors="replace")


@dataclass(frozen=True, slots=True)
class MemoryPressurePolicy:
    profile_id: str
    available_warning_bytes: int
    available_critical_bytes: int
    psi_some_warning_avg10: float
    psi_some_critical_avg10: float
    swap_warning_percent: float
    swap_critical_percent: float

    @classmethod
    def for_profile(cls, profile: HardwareProfile) -> "MemoryPressurePolicy":
        if profile.profile_id == "dell-wyse-3040":
            return cls(
                profile_id=profile.profile_id,
                available_warning_bytes=256 * 1024 * 1024,
                available_critical_bytes=128 * 1024 * 1024,
                psi_some_warning_avg10=10.0,
                psi_some_critical_avg10=25.0,
                swap_warning_percent=50.0,
                swap_critical_percent=85.0,
            )
        return cls(
            profile_id="generic",
            available_warning_bytes=128 * 1024 * 1024,
            available_critical_bytes=64 * 1024 * 1024,
            psi_some_warning_avg10=20.0,
            psi_some_critical_avg10=50.0,
            swap_warning_percent=70.0,
            swap_critical_percent=95.0,
        )


class MemoryPressureMonitor:
    """Bounded memory-pressure monitor tailored by the detected hardware profile."""

    def __init__(
        self,
        policy: MemoryPressurePolicy,
        *,
        meminfo_path: Path = Path("/proc/meminfo"),
        pressure_path: Path = Path("/proc/pressure/memory"),
        vmstat_path: Path = Path("/proc/vmstat"),
    ) -> None:
        self._policy = policy
        self._meminfo_path = meminfo_path
        self._pressure_path = pressure_path
        self._vmstat_path = vmstat_path
        self._previous_oom_kill: int | None = None

    def sample(self) -> dict[str, object]:
        memory = self._memory_values()
        psi = self._psi_values()
        oom_kill = self._oom_kill_count()
        oom_delta = None if oom_kill is None or self._previous_oom_kill is None else max(0, oom_kill - self._previous_oom_kill)
        self._previous_oom_kill = oom_kill

        signals: dict[str, str] = {}
        available = memory.get("available_bytes")
        if isinstance(available, int):
            if available <= self._policy.available_critical_bytes:
                signals["available_memory"] = "critical"
            elif available <= self._policy.available_warning_bytes:
                signals["available_memory"] = "warning"
            else:
                signals["available_memory"] = "normal"
        swap_percent = memory.get("swap_used_percent")
        if isinstance(swap_percent, float):
            if swap_percent >= self._policy.swap_critical_percent:
                signals["swap"] = "critical"
            elif swap_percent >= self._policy.swap_warning_percent:
                signals["swap"] = "warning"
            else:
                signals["swap"] = "normal"
        some_avg10 = psi.get("some_avg10")
        if isinstance(some_avg10, float):
            if some_avg10 >= self._policy.psi_some_critical_avg10:
                signals["psi_some"] = "critical"
            elif some_avg10 >= self._policy.psi_some_warning_avg10:
                signals["psi_some"] = "warning"
            else:
                signals["psi_some"] = "normal"
        if oom_delta is not None:
            signals["oom_kill"] = "critical" if oom_delta > 0 else "normal"

        severity = "critical" if "critical" in signals.values() else ("warning" if "warning" in signals.values() else "normal")
        payload: dict[str, object] = {
            "profile_id": self._policy.profile_id,
            "severity": severity,
            "signals": signals,
            "memory": memory,
            "psi": psi,
        }
        if oom_kill is not None:
            payload["oom_kill_total"] = oom_kill
        if oom_delta is not None:
            payload["oom_kill_delta"] = oom_delta
        return payload

    def _memory_values(self) -> dict[str, object]:
        text = _read_bounded(self._meminfo_path)
        if not text:
            return {}
        values: dict[str, int] = {}
        for line in text.splitlines():
            if ":" not in line:
                continue
            key, raw = line.split(":", 1)
            parts = raw.strip().split()
            try:
                value = int(parts[0])
            except (IndexError, ValueError):
                continue
            if value < 0:
                continue
            values[key] = value * (1024 if len(parts) > 1 and parts[1].lower() == "kb" else 1)
        result: dict[str, object] = {}
        available = values.get("MemAvailable")
        if available is not None:
            result["available_bytes"] = available
        swap_total = values.get("SwapTotal")
        swap_free = values.get("SwapFree")
        if swap_total is not None:
            result["swap_total_bytes"] = swap_total
        if swap_total and swap_free is not None:
            used = max(0, swap_total - swap_free)
            result["swap_used_bytes"] = used
            result["swap_used_percent"] = round(used * 100.0 / swap_total, 2)
        return result

    def _psi_values(self) -> dict[str, object]:
        text = _read_bounded(self._pressure_path)
        result: dict[str, object] = {}
        if not text:
            return result
        for line in text.splitlines():
            match = _PSI_LINE.match(line.strip())
            if not match:
                continue
            prefix = match.group(1)
            result[f"{prefix}_avg10"] = float(match.group(2))
            result[f"{prefix}_avg60"] = float(match.group(3))
            result[f"{prefix}_avg300"] = float(match.group(4))
            result[f"{prefix}_total_microseconds"] = int(match.group(5))
        return result

    def _oom_kill_count(self) -> int | None:
        text = _read_bounded(self._vmstat_path)
        if not text:
            return None
        for line in text.splitlines():
            key, _, raw = line.partition(" ")
            if key != "oom_kill":
                continue
            try:
                value = int(raw.strip())
            except ValueError:
                return None
            return value if value >= 0 else None
        return None

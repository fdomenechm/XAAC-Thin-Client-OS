from __future__ import annotations

import json
import os
import stat
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse


class XmsAddressError(ValueError):
    """Estat o canvi d'adreça XMS no vàlid."""


@dataclass(frozen=True, slots=True)
class XmsAddressState:
    active_url: str
    previous_url: str | None = None
    changed_at: str | None = None
    change_id: str | None = None


class XmsAddressStore:
    """Persistència mínima i atòmica de l'adreça XMS activa.

    El canvi només és acceptable quan declara l'adreça activa esperada. Això
    evita aplicar instruccions retardades sobre una topologia posterior.
    """

    schema = "xaac-xms-address/v1"

    def __init__(self, path: Path, *, require_https: bool = True, max_bytes: int = 32768) -> None:
        self.path = path
        self.require_https = require_https
        self.max_bytes = max_bytes

    def resolve(self, configured_url: str) -> str:
        state = self.load()
        if state is not None:
            return state.active_url
        if not isinstance(configured_url, str) or not configured_url.strip():
            return ""
        return _normalise_url(configured_url, require_https=self.require_https)

    def load(self) -> XmsAddressState | None:
        if not self.path.exists():
            return None
        info = self.path.lstat()
        if stat.S_ISLNK(info.st_mode) or not stat.S_ISREG(info.st_mode):
            raise XmsAddressError("xms_address_state_unsafe_file")
        if info.st_size > self.max_bytes:
            raise XmsAddressError("xms_address_state_too_large")
        try:
            payload = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError) as error:
            raise XmsAddressError("xms_address_state_corrupt") from error
        if not isinstance(payload, dict) or payload.get("schema") != self.schema:
            raise XmsAddressError("xms_address_state_invalid_schema")
        active = _normalise_url(payload.get("active_url"), require_https=self.require_https)
        previous_raw = payload.get("previous_url")
        previous = None if previous_raw is None else _normalise_url(previous_raw, require_https=self.require_https)
        changed_at = payload.get("changed_at")
        change_id = payload.get("change_id")
        if changed_at is not None and (not isinstance(changed_at, str) or len(changed_at) > 64):
            raise XmsAddressError("xms_address_state_invalid_changed_at")
        if change_id is not None and (not isinstance(change_id, str) or not 1 <= len(change_id) <= 128):
            raise XmsAddressError("xms_address_state_invalid_change_id")
        return XmsAddressState(active, previous, changed_at, change_id)

    def apply_change(self, *, expected_current_url: str, new_url: str, change_id: str) -> XmsAddressState:
        expected = _normalise_url(expected_current_url, require_https=self.require_https)
        target = _normalise_url(new_url, require_https=self.require_https)
        if not isinstance(change_id, str) or not change_id.strip() or len(change_id.strip()) > 128:
            raise XmsAddressError("xms_address_change_id_invalid")
        current_state = self.load()
        current = current_state.active_url if current_state else expected
        if current != expected:
            raise XmsAddressError("xms_address_current_mismatch")
        if target == current:
            return current_state or XmsAddressState(current)
        state = XmsAddressState(
            active_url=target,
            previous_url=current,
            changed_at=datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            change_id=change_id.strip(),
        )
        self._write(state)
        return state

    def rollback(self, *, expected_active_url: str, change_id: str) -> XmsAddressState:
        expected = _normalise_url(expected_active_url, require_https=self.require_https)
        state = self.load()
        if state is None or state.active_url != expected or state.previous_url is None:
            raise XmsAddressError("xms_address_rollback_not_available")
        return self.apply_change(expected_current_url=state.active_url, new_url=state.previous_url, change_id=change_id)

    def _write(self, state: XmsAddressState) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "schema": self.schema,
            "active_url": state.active_url,
            "previous_url": state.previous_url,
            "changed_at": state.changed_at,
            "change_id": state.change_id,
        }
        data = (json.dumps(payload, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")
        if len(data) > self.max_bytes:
            raise XmsAddressError("xms_address_state_too_large")
        fd, temporary = tempfile.mkstemp(prefix=f".{self.path.name}.", dir=self.path.parent)
        try:
            os.fchmod(fd, 0o600)
            with os.fdopen(fd, "wb", closefd=True) as stream:
                stream.write(data)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.path)
            directory_fd = os.open(self.path.parent, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
        finally:
            try:
                os.unlink(temporary)
            except FileNotFoundError:
                pass


def _normalise_url(value: object, *, require_https: bool) -> str:
    if not isinstance(value, str) or not value.strip():
        raise XmsAddressError("xms_address_url_missing")
    candidate = value.strip().rstrip("/")
    parsed = urlparse(candidate)
    allowed = {"https"} if require_https else {"http", "https"}
    if parsed.scheme.lower() not in allowed or not parsed.hostname or parsed.username or parsed.password:
        raise XmsAddressError("xms_address_url_invalid")
    if parsed.fragment or parsed.query:
        raise XmsAddressError("xms_address_url_invalid")
    return candidate

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Mapping, Protocol, runtime_checkable

logger = logging.getLogger(__name__)


class InventoryProviderError(RuntimeError):
    pass


class DuplicateInventoryKeyError(InventoryProviderError):
    pass


class DuplicateProviderNameError(InventoryProviderError):
    pass


@runtime_checkable
class InventoryProvider(Protocol):
    name: str
    version: str
    order: int
    capabilities: tuple[str, ...]

    def collect(self) -> Mapping[str, object]: ...


@dataclass(frozen=True, slots=True)
class InventoryCollectionResult:
    payload: dict[str, object]
    capabilities: tuple[str, ...]
    errors: dict[str, str] = field(default_factory=dict)


class InventoryRegistry:
    def __init__(self, providers: tuple[InventoryProvider, ...] | None = None) -> None:
        self._providers: dict[str, InventoryProvider] = {}
        for provider in providers or ():
            self.register(provider)

    def register(self, provider: InventoryProvider) -> None:
        if provider.name in self._providers:
            raise DuplicateProviderNameError(provider.name)
        self._providers[provider.name] = provider

    @property
    def providers(self) -> tuple[InventoryProvider, ...]:
        return tuple(sorted(self._providers.values(), key=lambda p: (p.order, p.name)))

    def collect(self) -> InventoryCollectionResult:
        payload: dict[str, object] = {}
        capabilities: set[str] = set()
        errors: dict[str, str] = {}
        for provider in self.providers:
            try:
                fragment = dict(provider.collect())
                duplicate = payload.keys() & fragment.keys()
                if duplicate:
                    raise DuplicateInventoryKeyError(", ".join(sorted(duplicate)))
                payload.update(fragment)
                capabilities.update(provider.capabilities)
            except Exception as exc:  # provider isolation boundary
                errors[provider.name] = f"{type(exc).__name__}: {exc}"
                logger.warning("Inventory provider %s failed: %s", provider.name, exc)
        return InventoryCollectionResult(payload, tuple(sorted(capabilities)), errors)

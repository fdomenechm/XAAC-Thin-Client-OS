from __future__ import annotations

import hashlib
import os
import stat
import tempfile
import urllib.error
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import BinaryIO, Protocol

from xaac_agent.update_model import UpdatePlan, UpdateState


class UpdateCacheError(ValueError):
    def __init__(self, code: str) -> None:
        super().__init__(code)
        self.code = code


class UpdateDownloadBackend(Protocol):
    def open(self, url: str, *, timeout_seconds: int) -> BinaryIO: ...


class HttpsUpdateDownloadBackend:
    def open(self, url: str, *, timeout_seconds: int) -> BinaryIO:
        if not isinstance(url, str) or not url.lower().startswith("https://"):
            raise UpdateCacheError("insecure_update_url")
        request = urllib.request.Request(url, headers={"User-Agent": "XAAC-Agent/0.9.5"})
        response = urllib.request.urlopen(request, timeout=timeout_seconds)
        final_url = response.geturl()
        if not isinstance(final_url, str) or not final_url.lower().startswith("https://"):
            response.close()
            raise UpdateCacheError("insecure_update_redirect")
        return response


@dataclass(frozen=True, slots=True)
class CachedUpdateArtifact:
    plan: UpdatePlan
    path: Path
    sha256: str
    size_bytes: int
    cached_at: datetime
    reused: bool = False

    @property
    def state(self) -> UpdateState:
        return UpdateState.CACHED

    def to_payload(self) -> dict[str, object]:
        return {
            "update_id": self.plan.update_id,
            "component": self.plan.component.value,
            "target_version": self.plan.target_version,
            "state": self.state.value,
            "sha256": self.sha256,
            "size_bytes": self.size_bytes,
            "cached_at": self.cached_at.isoformat().replace("+00:00", "Z"),
            "reused": self.reused,
            "filename": self.path.name,
        }


@dataclass(frozen=True, slots=True)
class UpdateArtifactCache:
    directory: Path
    backend: UpdateDownloadBackend
    max_artifact_bytes: int = 512 * 1024 * 1024
    timeout_seconds: int = 60
    max_entries: int = 8

    @classmethod
    def system_default(
        cls,
        directory: Path,
        *,
        max_artifact_bytes: int = 512 * 1024 * 1024,
        timeout_seconds: int = 60,
        max_entries: int = 8,
    ) -> "UpdateArtifactCache":
        return cls(directory, HttpsUpdateDownloadBackend(), max_artifact_bytes, timeout_seconds, max_entries)

    def download(self, plan: UpdatePlan) -> CachedUpdateArtifact:
        artifact = plan.artifact
        if artifact.size > self.max_artifact_bytes:
            raise UpdateCacheError("update_artifact_too_large")
        self._prepare_directory()
        existing = self._find_by_digest(artifact.sha256)
        if existing is not None:
            cached = self._load_cached(plan, existing, artifact.sha256, artifact.size)
            return CachedUpdateArtifact(plan, cached.path, cached.sha256, cached.size_bytes, cached.cached_at, True)
        try:
            with self.backend.open(artifact.url, timeout_seconds=self.timeout_seconds) as source:
                temporary, digest, size = self._download_temporary(source, expected_size=artifact.size)
        except UpdateCacheError:
            raise
        except TimeoutError as error:
            raise UpdateCacheError("update_download_timeout") from error
        except (urllib.error.URLError, OSError) as error:
            raise UpdateCacheError("update_download_failed") from error
        try:
            if size != artifact.size:
                raise UpdateCacheError("update_artifact_size_mismatch")
            if digest != artifact.sha256:
                raise UpdateCacheError("update_artifact_digest_mismatch")
            destination = self._entry_path(plan)
            self._validate_destination(destination)
            if destination.exists():
                destination.unlink()
            os.replace(temporary, destination)
            _fsync_directory(self.directory)
            result = CachedUpdateArtifact(plan, destination, digest, size, datetime.now(timezone.utc))
            self._prune(keep=destination)
            return result
        except Exception:
            temporary.unlink(missing_ok=True)
            raise

    def load(self, plan: UpdatePlan) -> CachedUpdateArtifact | None:
        self._prepare_directory()
        path = self._entry_path(plan)
        if not path.exists():
            return None
        return self._load_cached(plan, path, plan.artifact.sha256, plan.artifact.size)

    def _prepare_directory(self) -> None:
        try:
            info = self.directory.lstat()
            if stat.S_ISLNK(info.st_mode):
                raise UpdateCacheError("update_cache_symlink")
            if not stat.S_ISDIR(info.st_mode):
                raise UpdateCacheError("update_cache_not_directory")
        except FileNotFoundError:
            self.directory.mkdir(parents=True, mode=0o700)
        os.chmod(self.directory, 0o700)

    def _find_by_digest(self, digest: str) -> Path | None:
        matches = list(self.directory.glob(f"*--{digest}--*"))
        if not matches:
            return None
        if len(matches) > 1:
            raise UpdateCacheError("duplicate_cached_update_digest")
        return matches[0]

    def _download_temporary(self, source: BinaryIO, *, expected_size: int) -> tuple[Path, str, int]:
        digest = hashlib.sha256()
        written = 0
        fd, raw_path = tempfile.mkstemp(prefix=".update-", suffix=".part", dir=self.directory)
        temporary = Path(raw_path)
        try:
            os.fchmod(fd, 0o600)
            with os.fdopen(fd, "wb") as output:
                while True:
                    chunk = source.read(64 * 1024)
                    if not chunk:
                        break
                    if not isinstance(chunk, bytes):
                        raise UpdateCacheError("invalid_update_stream")
                    written += len(chunk)
                    if written > expected_size or written > self.max_artifact_bytes:
                        raise UpdateCacheError("update_artifact_size_exceeded")
                    digest.update(chunk)
                    output.write(chunk)
                output.flush()
                os.fsync(output.fileno())
        except Exception:
            try:
                os.close(fd)
            except OSError:
                pass
            temporary.unlink(missing_ok=True)
            raise
        return temporary, digest.hexdigest(), written

    def _load_cached(self, plan: UpdatePlan, path: Path, expected_digest: str, expected_size: int) -> CachedUpdateArtifact:
        info = path.lstat()
        if stat.S_ISLNK(info.st_mode):
            raise UpdateCacheError("cached_update_symlink")
        if not stat.S_ISREG(info.st_mode):
            raise UpdateCacheError("cached_update_not_regular")
        digest = hashlib.sha256()
        size = 0
        flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
        fd = os.open(path, flags)
        try:
            with os.fdopen(fd, "rb") as source:
                while chunk := source.read(64 * 1024):
                    size += len(chunk)
                    if size > self.max_artifact_bytes:
                        raise UpdateCacheError("cached_update_too_large")
                    digest.update(chunk)
        except Exception:
            try:
                os.close(fd)
            except OSError:
                pass
            raise
        if size != expected_size:
            raise UpdateCacheError("cached_update_size_mismatch")
        calculated = digest.hexdigest()
        if calculated != expected_digest:
            raise UpdateCacheError("cached_update_digest_mismatch")
        return CachedUpdateArtifact(plan, path, calculated, size, datetime.fromtimestamp(info.st_mtime, timezone.utc))

    def _entry_path(self, plan: UpdatePlan) -> Path:
        artifact = plan.artifact
        suffix = _safe_filename(artifact.filename or "artifact.bin")
        return self.directory / (
            f"{_safe_component(plan.update_id)}--{_safe_component(plan.component.value)}--"
            f"{_safe_component(plan.target_version)}--{artifact.sha256}--{suffix}"
        )

    @staticmethod
    def _validate_destination(path: Path) -> None:
        try:
            info = path.lstat()
        except FileNotFoundError:
            return
        if stat.S_ISLNK(info.st_mode):
            raise UpdateCacheError("cached_update_symlink")
        if not stat.S_ISREG(info.st_mode):
            raise UpdateCacheError("cached_update_not_regular")

    def _prune(self, *, keep: Path) -> None:
        if not 1 <= self.max_entries <= 128:
            raise UpdateCacheError("invalid_update_cache_limit")
        entries: list[tuple[int, Path]] = []
        for path in self.directory.iterdir():
            if path.name.startswith("."):
                continue
            try:
                info = path.lstat()
            except OSError:
                continue
            if stat.S_ISREG(info.st_mode) and not stat.S_ISLNK(info.st_mode):
                entries.append((info.st_mtime_ns, path))
        entries.sort(reverse=True)
        for _, path in entries[self.max_entries:]:
            if path != keep:
                path.unlink(missing_ok=True)
        _fsync_directory(self.directory)


def _safe_component(value: str) -> str:
    return "".join(char if char.isalnum() or char in "._-" else "_" for char in value)


def _safe_filename(value: str) -> str:
    return _safe_component(Path(value).name)[:255] or "artifact.bin"


def _fsync_directory(directory: Path) -> None:
    fd = os.open(directory, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
    try:
        os.fsync(fd)
    finally:
        os.close(fd)

from __future__ import annotations

import ipaddress
import socket
import ssl
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable
from urllib.parse import urlparse

from xaac_agent.tls_policy import TlsPolicy, TlsPolicyError, verify_certificate_pin


@dataclass(frozen=True, slots=True)
class ConnectivityThresholds:
    warning_latency_ms: float = 500.0
    critical_latency_ms: float = 2000.0
    hysteresis_ms: float = 100.0

    def validate(self) -> None:
        if not 0 < self.warning_latency_ms < self.critical_latency_ms <= 60000:
            raise ValueError("invalid connectivity latency thresholds")
        if not 0 <= self.hysteresis_ms <= self.warning_latency_ms:
            raise ValueError("invalid connectivity hysteresis")


class _LatencyState:
    def __init__(self, thresholds: ConnectivityThresholds) -> None:
        thresholds.validate()
        self._thresholds = thresholds
        self._state = "normal"

    def evaluate(self, latency_ms: float) -> str:
        t = self._thresholds
        if self._state == "critical":
            if latency_ms < t.critical_latency_ms - t.hysteresis_ms:
                self._state = "warning" if latency_ms >= t.warning_latency_ms else "normal"
        elif self._state == "warning":
            if latency_ms >= t.critical_latency_ms:
                self._state = "critical"
            elif latency_ms < t.warning_latency_ms - t.hysteresis_ms:
                self._state = "normal"
        else:
            if latency_ms >= t.critical_latency_ms:
                self._state = "critical"
            elif latency_ms >= t.warning_latency_ms:
                self._state = "warning"
        return self._state


class ConnectivityMonitor:
    """Comprova DNS i connectivitat TCP/TLS amb XMS sense fer peticions XMP."""

    def __init__(
        self,
        server_url: str,
        *,
        timeout_seconds: float = 2.0,
        thresholds: ConnectivityThresholds | None = None,
        tls_ca_file: Path | None = None,
        tls_minimum_version: str = "TLSv1.2",
        tls_maximum_version: str = "",
        tls_ciphers: str = "",
        tls_certificate_pins: tuple[str, ...] = (),
        resolver: Callable[..., list[tuple]] = socket.getaddrinfo,
        socket_factory: Callable[..., socket.socket] = socket.create_connection,
        monotonic: Callable[[], float] = time.monotonic,
        ssl_context_factory: Callable[[], ssl.SSLContext] = ssl.create_default_context,
    ) -> None:
        self._server_url = server_url
        self._timeout = timeout_seconds
        self._thresholds = thresholds or ConnectivityThresholds()
        self._latency_state = _LatencyState(self._thresholds)
        self._tls_ca_file = tls_ca_file
        self._tls_policy = TlsPolicy(
            minimum_version=tls_minimum_version,
            maximum_version=tls_maximum_version,
            ciphers=tls_ciphers,
            certificate_pins=tls_certificate_pins,
        )
        self._resolver = resolver
        self._socket_factory = socket_factory
        self._monotonic = monotonic
        self._ssl_context_factory = ssl_context_factory

    def sample(self) -> dict[str, object]:
        parsed = urlparse(self._server_url)
        host = parsed.hostname
        if not host or parsed.scheme not in {"http", "https"}:
            return {"configured": False, "reachable": False, "severity": "normal"}
        port = parsed.port or (443 if parsed.scheme == "https" else 80)
        result: dict[str, object] = {
            "configured": True,
            "scheme": parsed.scheme,
            "host": host,
            "port": port,
            "dns_resolved": False,
            "tcp_connected": False,
            "tls_established": False if parsed.scheme == "https" else None,
            "reachable": False,
        }
        started = self._monotonic()
        try:
            addresses = self._resolver(host, port, type=socket.SOCK_STREAM)
            normalized: list[str] = []
            for item in addresses:
                try:
                    address = str(ipaddress.ip_address(item[4][0]))
                except (IndexError, ValueError, TypeError):
                    continue
                if address not in normalized:
                    normalized.append(address)
            if not normalized:
                raise socket.gaierror("no usable address")
            result["dns_resolved"] = True
            result["resolved_addresses"] = normalized[:8]
            dns_elapsed = (self._monotonic() - started) * 1000.0
            result["dns_latency_ms"] = round(max(0.0, dns_elapsed), 2)
        except (socket.gaierror, OSError) as exc:
            result.update({"error_category": "dns", "error": type(exc).__name__, "severity": "critical"})
            return result

        connect_started = self._monotonic()
        raw_socket: socket.socket | None = None
        try:
            raw_socket = self._socket_factory((host, port), timeout=self._timeout)
            result["tcp_connected"] = True
            if parsed.scheme == "https":
                if self._ssl_context_factory is ssl.create_default_context:
                    context = self._tls_policy.create_context(
                        cafile=str(self._tls_ca_file) if self._tls_ca_file is not None else None
                    )
                else:
                    context = self._ssl_context_factory()
                    if self._tls_ca_file is not None:
                        context.load_verify_locations(cafile=str(self._tls_ca_file))
                with context.wrap_socket(raw_socket, server_hostname=host) as tls_socket:
                    raw_socket = None
                    if self._tls_policy.certificate_pins:
                        verify_certificate_pin(
                            tls_socket.getpeercert(binary_form=True), self._tls_policy.certificate_pins
                        )
                    result["tls_established"] = True
                    cipher = tls_socket.cipher()
                    if cipher:
                        result["tls_cipher"] = cipher[0]
                    result["tls_version"] = tls_socket.version()
            result["reachable"] = True
        except socket.timeout as exc:
            result.update({"error_category": "timeout", "error": type(exc).__name__, "severity": "critical"})
            return result
        except (ssl.SSLError, TlsPolicyError) as exc:
            result.update({"error_category": "tls", "error": type(exc).__name__, "severity": "critical"})
            return result
        except OSError as exc:
            result.update({"error_category": "connection", "error": type(exc).__name__, "severity": "critical"})
            return result
        finally:
            if raw_socket is not None:
                try:
                    raw_socket.close()
                except OSError:
                    pass

        latency_ms = max(0.0, (self._monotonic() - connect_started) * 1000.0)
        result["connect_latency_ms"] = round(latency_ms, 2)
        result["severity"] = self._latency_state.evaluate(latency_ms)
        return result

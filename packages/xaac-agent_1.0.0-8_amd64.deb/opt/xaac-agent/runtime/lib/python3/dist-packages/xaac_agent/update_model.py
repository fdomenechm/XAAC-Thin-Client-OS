from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Mapping
from urllib.parse import urlparse


class UpdateValidationError(ValueError):
    """Actualització XMP mal formada o incompatible amb el model local."""

    def __init__(self, code: str) -> None:
        super().__init__(code)
        self.code = code


class UpdateComponent(str, Enum):
    AGENT = "agent"
    THIN_CLIENT = "thin-client"
    DEBIAN_PACKAGES = "debian-packages"
    SYSTEM_COMPONENT = "system-component"


class UpdateState(str, Enum):
    RECEIVED = "received"
    VALIDATED = "validated"
    CACHED = "cached"
    VERIFIED = "verified"
    SCHEDULED = "scheduled"
    INSTALLING = "installing"
    INSTALLED = "installed"
    REBOOT_PENDING = "reboot-pending"
    COMPLETED = "completed"
    REJECTED = "rejected"
    FAILED = "failed"
    ROLLED_BACK = "rolled-back"
    CANCELLED = "cancelled"
    EXPIRED = "expired"


_TERMINAL_STATES = {
    UpdateState.COMPLETED,
    UpdateState.REJECTED,
    UpdateState.FAILED,
    UpdateState.ROLLED_BACK,
    UpdateState.CANCELLED,
    UpdateState.EXPIRED,
}
_ID_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$")
_VERSION_PATTERN = re.compile(r"^[0-9]+\.[0-9]+\.[0-9]+(?:[-+][0-9A-Za-z.-]+)?$")
_SHA256_PATTERN = re.compile(r"^[0-9a-f]{64}$")
_CAPABILITY_PATTERN = re.compile(r"^[a-z0-9][a-z0-9._-]{0,63}$")
_MEDIA_TYPE_PATTERN = re.compile(r"^[a-z0-9][a-z0-9!#$&^_.+-]*/[a-z0-9][a-z0-9!#$&^_.+-]*$")
_MAX_MAPPING_ITEMS = 128
_MAX_LIST_ITEMS = 256
_MAX_NESTING = 10
_MAX_STRING_LENGTH = 65_536
_MAX_RESULT_MESSAGE = 4096
_MAX_ARTIFACT_BYTES = 8 * 1024 * 1024 * 1024


def _parse_time(value: object, *, field: str, required: bool = False) -> datetime | None:
    if value is None and not required:
        return None
    if not isinstance(value, str) or not value.strip():
        raise UpdateValidationError(f"missing_{field}" if required else f"invalid_{field}")
    try:
        parsed = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    except ValueError as error:
        raise UpdateValidationError(f"invalid_{field}") from error
    if parsed.tzinfo is None:
        raise UpdateValidationError(f"invalid_{field}")
    return parsed.astimezone(timezone.utc)


def _validate_json_value(value: Any, *, depth: int = 0) -> None:
    if depth > _MAX_NESTING:
        raise UpdateValidationError("update_data_too_deep")
    if value is None or isinstance(value, bool):
        return
    if isinstance(value, str):
        if len(value) > _MAX_STRING_LENGTH:
            raise UpdateValidationError("update_string_too_long")
        return
    if isinstance(value, int):
        return
    if isinstance(value, float):
        if not math.isfinite(value):
            raise UpdateValidationError("invalid_update_number")
        return
    if isinstance(value, list):
        if len(value) > _MAX_LIST_ITEMS:
            raise UpdateValidationError("update_list_too_large")
        for item in value:
            _validate_json_value(item, depth=depth + 1)
        return
    if isinstance(value, dict):
        if len(value) > _MAX_MAPPING_ITEMS:
            raise UpdateValidationError("update_mapping_too_large")
        for key, item in value.items():
            if not isinstance(key, str) or not key or len(key) > 128:
                raise UpdateValidationError("invalid_update_key")
            _validate_json_value(item, depth=depth + 1)
        return
    raise UpdateValidationError("invalid_update_value")


def _parse_version(value: object, *, field: str, required: bool = False) -> str | None:
    if value is None and not required:
        return None
    if not isinstance(value, str) or not value.strip():
        raise UpdateValidationError(f"missing_{field}" if required else f"invalid_{field}")
    normalized = value.strip()
    if not _VERSION_PATTERN.fullmatch(normalized):
        raise UpdateValidationError(f"invalid_{field}")
    return normalized


@dataclass(frozen=True, slots=True)
class UpdateIssuer:
    issuer_id: str
    kind: str = "xms"

    @classmethod
    def from_payload(cls, value: object) -> "UpdateIssuer":
        if isinstance(value, str):
            issuer_id, kind = value.strip(), "xms"
        elif isinstance(value, Mapping):
            issuer_id = value.get("id")
            kind = value.get("kind", "xms")
            if not isinstance(issuer_id, str) or not isinstance(kind, str):
                raise UpdateValidationError("invalid_update_issuer")
            issuer_id, kind = issuer_id.strip(), kind.strip().lower()
        else:
            raise UpdateValidationError("missing_update_issuer")
        if not issuer_id or len(issuer_id) > 256 or not kind or len(kind) > 64:
            raise UpdateValidationError("invalid_update_issuer")
        return cls(issuer_id=issuer_id, kind=kind)

    def to_payload(self) -> dict[str, str]:
        return {"id": self.issuer_id, "kind": self.kind}


@dataclass(frozen=True, slots=True)
class UpdateArtifact:
    url: str
    size: int
    sha256: str
    media_type: str = "application/octet-stream"
    filename: str | None = None

    @classmethod
    def from_payload(cls, value: object) -> "UpdateArtifact":
        if not isinstance(value, Mapping):
            raise UpdateValidationError("missing_update_artifact")
        unknown = set(value) - {"url", "size", "sha256", "media_type", "filename"}
        if unknown:
            raise UpdateValidationError("unknown_update_artifact_field")

        url = value.get("url")
        if not isinstance(url, str) or not url.strip():
            raise UpdateValidationError("missing_update_artifact_url")
        url = url.strip()
        parsed = urlparse(url)
        if parsed.scheme.lower() != "https" or not parsed.netloc or parsed.username or parsed.password:
            raise UpdateValidationError("invalid_update_artifact_url")

        size = value.get("size")
        if isinstance(size, bool) or not isinstance(size, int) or not 0 < size <= _MAX_ARTIFACT_BYTES:
            raise UpdateValidationError("invalid_update_artifact_size")

        sha256 = value.get("sha256")
        if not isinstance(sha256, str) or not _SHA256_PATTERN.fullmatch(sha256.strip().lower()):
            raise UpdateValidationError("invalid_update_artifact_sha256")

        media_type = value.get("media_type", "application/octet-stream")
        if not isinstance(media_type, str) or not _MEDIA_TYPE_PATTERN.fullmatch(media_type.strip().lower()):
            raise UpdateValidationError("invalid_update_artifact_media_type")

        filename = value.get("filename")
        if filename is not None:
            if (
                not isinstance(filename, str)
                or not filename.strip()
                or len(filename.strip()) > 255
                or "/" in filename
                or "\\" in filename
                or filename.strip() in {".", ".."}
            ):
                raise UpdateValidationError("invalid_update_artifact_filename")
            filename = filename.strip()

        return cls(
            url=url,
            size=size,
            sha256=sha256.strip().lower(),
            media_type=media_type.strip().lower(),
            filename=filename,
        )

    def to_payload(self) -> dict[str, object]:
        payload: dict[str, object] = {
            "url": self.url,
            "size": self.size,
            "sha256": self.sha256,
            "media_type": self.media_type,
        }
        if self.filename is not None:
            payload["filename"] = self.filename
        return payload


@dataclass(frozen=True, slots=True)
class UpdatePlan:
    update_id: str
    component: UpdateComponent
    target_version: str
    issuer: UpdateIssuer
    issued_at: datetime
    artifact: UpdateArtifact
    current_version: str | None = None
    minimum_version: str | None = None
    expires_at: datetime | None = None
    required_capabilities: tuple[str, ...] = ()
    reboot_required: bool = False
    rollback_supported: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: int = 1

    @classmethod
    def from_payload(cls, payload: Mapping[str, Any]) -> "UpdatePlan":
        if not isinstance(payload, Mapping):
            raise UpdateValidationError("invalid_update")
        schema_version = payload.get("schema_version", 1)
        if isinstance(schema_version, bool) or schema_version != 1:
            raise UpdateValidationError("unsupported_update_schema_version")

        update_id = payload.get("update_id")
        if not isinstance(update_id, str) or not _ID_PATTERN.fullmatch(update_id.strip()):
            raise UpdateValidationError("missing_update_id" if not update_id else "invalid_update_id")

        raw_component = payload.get("component")
        if not isinstance(raw_component, str) or not raw_component.strip():
            raise UpdateValidationError("missing_update_component")
        try:
            component = UpdateComponent(raw_component.strip().lower())
        except ValueError as error:
            raise UpdateValidationError("unsupported_update_component") from error

        target_version = _parse_version(payload.get("target_version"), field="target_version", required=True)
        assert target_version is not None
        current_version = _parse_version(payload.get("current_version"), field="current_version")
        minimum_version = _parse_version(payload.get("minimum_version"), field="minimum_version")

        issuer = UpdateIssuer.from_payload(payload.get("issuer"))
        issued_at = _parse_time(payload.get("issued_at"), field="update_issued_at", required=True)
        assert issued_at is not None
        expires_at = _parse_time(payload.get("expires_at"), field="update_expiry")
        if expires_at is not None and expires_at <= issued_at:
            raise UpdateValidationError("update_expiry_before_issue")

        artifact = UpdateArtifact.from_payload(payload.get("artifact"))

        raw_capabilities = payload.get("required_capabilities", [])
        if not isinstance(raw_capabilities, list):
            raise UpdateValidationError("invalid_update_capabilities")
        capabilities: set[str] = set()
        for capability in raw_capabilities:
            if not isinstance(capability, str) or not _CAPABILITY_PATTERN.fullmatch(capability.strip()):
                raise UpdateValidationError("invalid_update_capability")
            capabilities.add(capability.strip())

        reboot_required = payload.get("reboot_required", False)
        rollback_supported = payload.get("rollback_supported", False)
        if not isinstance(reboot_required, bool):
            raise UpdateValidationError("invalid_reboot_required")
        if not isinstance(rollback_supported, bool):
            raise UpdateValidationError("invalid_rollback_supported")

        metadata = payload.get("metadata", {})
        if not isinstance(metadata, dict):
            raise UpdateValidationError("invalid_update_metadata")
        _validate_json_value(metadata)

        return cls(
            update_id=update_id.strip(),
            component=component,
            target_version=target_version,
            current_version=current_version,
            minimum_version=minimum_version,
            issuer=issuer,
            issued_at=issued_at,
            expires_at=expires_at,
            artifact=artifact,
            required_capabilities=tuple(sorted(capabilities)),
            reboot_required=reboot_required,
            rollback_supported=rollback_supported,
            metadata=dict(metadata),
            schema_version=1,
        )

    @property
    def identity(self) -> tuple[str, str, str]:
        return self.update_id, self.component.value, self.target_version

    def is_expired(self, *, now: datetime | None = None) -> bool:
        if self.expires_at is None:
            return False
        reference = now or datetime.now(timezone.utc)
        if reference.tzinfo is None:
            reference = reference.replace(tzinfo=timezone.utc)
        return self.expires_at <= reference.astimezone(timezone.utc)

    def to_payload(self) -> dict[str, object]:
        payload: dict[str, object] = {
            "schema_version": self.schema_version,
            "update_id": self.update_id,
            "component": self.component.value,
            "target_version": self.target_version,
            "issuer": self.issuer.to_payload(),
            "issued_at": self.issued_at.isoformat().replace("+00:00", "Z"),
            "artifact": self.artifact.to_payload(),
            "required_capabilities": list(self.required_capabilities),
            "reboot_required": self.reboot_required,
            "rollback_supported": self.rollback_supported,
            "metadata": dict(self.metadata),
        }
        if self.current_version is not None:
            payload["current_version"] = self.current_version
        if self.minimum_version is not None:
            payload["minimum_version"] = self.minimum_version
        if self.expires_at is not None:
            payload["expires_at"] = self.expires_at.isoformat().replace("+00:00", "Z")
        return payload


@dataclass(frozen=True, slots=True)
class UpdateResult:
    update_id: str
    component: UpdateComponent
    target_version: str
    state: UpdateState
    code: str | None = None
    message: str | None = None
    data: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not _ID_PATTERN.fullmatch(self.update_id):
            raise UpdateValidationError("invalid_update_id")
        if not _VERSION_PATTERN.fullmatch(self.target_version):
            raise UpdateValidationError("invalid_target_version")
        if self.message is not None and len(self.message) > _MAX_RESULT_MESSAGE:
            raise UpdateValidationError("update_result_message_too_long")
        _validate_json_value(self.data)

    @property
    def terminal(self) -> bool:
        return self.state in _TERMINAL_STATES

    def to_payload(self) -> dict[str, object]:
        payload: dict[str, object] = {
            "update_id": self.update_id,
            "component": self.component.value,
            "target_version": self.target_version,
            "state": self.state.value,
            "terminal": self.terminal,
            "data": dict(self.data),
        }
        if self.code is not None:
            payload["code"] = self.code
        if self.message is not None:
            payload["message"] = self.message
        return payload

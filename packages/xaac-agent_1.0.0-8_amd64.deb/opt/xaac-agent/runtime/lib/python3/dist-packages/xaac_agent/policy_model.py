from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Mapping


class PolicyValidationError(ValueError):
    """Política XMP mal formada o incompatible amb el model local."""

    def __init__(self, code: str) -> None:
        super().__init__(code)
        self.code = code


class PolicyType(str, Enum):
    AGENT = "agent"
    THIN_CLIENT = "thin-client"
    SYSTEM = "system"


class PolicyState(str, Enum):
    RECEIVED = "received"
    CACHED = "cached"
    VALIDATED = "validated"
    REJECTED = "rejected"
    APPLIED = "applied"
    FAILED = "failed"
    ROLLED_BACK = "rolled-back"
    SUPERSEDED = "superseded"
    EXPIRED = "expired"


_TERMINAL_STATES = {
    PolicyState.REJECTED,
    PolicyState.APPLIED,
    PolicyState.FAILED,
    PolicyState.ROLLED_BACK,
    PolicyState.SUPERSEDED,
    PolicyState.EXPIRED,
}
_ID_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$")
_CAPABILITY_PATTERN = re.compile(r"^[a-z0-9][a-z0-9._-]{0,63}$")
_SECTION_PATTERN = re.compile(r"^[a-z][a-z0-9._-]{0,63}$")
_MAX_MAPPING_ITEMS = 128
_MAX_LIST_ITEMS = 256
_MAX_NESTING = 10
_MAX_STRING_LENGTH = 65_536
_MAX_RESULT_MESSAGE = 4096


def _parse_time(value: object, *, field: str, required: bool = False) -> datetime | None:
    if value is None and not required:
        return None
    if not isinstance(value, str) or not value.strip():
        raise PolicyValidationError(f"missing_{field}" if required else f"invalid_{field}")
    try:
        parsed = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    except ValueError as error:
        raise PolicyValidationError(f"invalid_{field}") from error
    if parsed.tzinfo is None:
        raise PolicyValidationError(f"invalid_{field}")
    return parsed.astimezone(timezone.utc)


def _validate_json_value(value: Any, *, depth: int = 0) -> None:
    if depth > _MAX_NESTING:
        raise PolicyValidationError("policy_data_too_deep")
    if value is None or isinstance(value, bool):
        return
    if isinstance(value, str):
        if len(value) > _MAX_STRING_LENGTH:
            raise PolicyValidationError("policy_string_too_long")
        return
    if isinstance(value, int):
        return
    if isinstance(value, float):
        if not math.isfinite(value):
            raise PolicyValidationError("invalid_policy_number")
        return
    if isinstance(value, list):
        if len(value) > _MAX_LIST_ITEMS:
            raise PolicyValidationError("policy_list_too_large")
        for item in value:
            _validate_json_value(item, depth=depth + 1)
        return
    if isinstance(value, dict):
        if len(value) > _MAX_MAPPING_ITEMS:
            raise PolicyValidationError("policy_mapping_too_large")
        for key, item in value.items():
            if not isinstance(key, str) or not key or len(key) > 128:
                raise PolicyValidationError("invalid_policy_key")
            _validate_json_value(item, depth=depth + 1)
        return
    raise PolicyValidationError("invalid_policy_value")


@dataclass(frozen=True, slots=True)
class PolicyIssuer:
    issuer_id: str
    kind: str = "xms"

    @classmethod
    def from_payload(cls, value: object) -> "PolicyIssuer":
        if isinstance(value, str):
            issuer_id, kind = value.strip(), "xms"
        elif isinstance(value, Mapping):
            issuer_id = value.get("id")
            kind = value.get("kind", "xms")
            if not isinstance(issuer_id, str) or not isinstance(kind, str):
                raise PolicyValidationError("invalid_policy_issuer")
            issuer_id, kind = issuer_id.strip(), kind.strip().lower()
        else:
            raise PolicyValidationError("missing_policy_issuer")
        if not issuer_id or len(issuer_id) > 256 or not kind or len(kind) > 64:
            raise PolicyValidationError("invalid_policy_issuer")
        return cls(issuer_id=issuer_id, kind=kind)

    def to_payload(self) -> dict[str, str]:
        return {"id": self.issuer_id, "kind": self.kind}


@dataclass(frozen=True, slots=True)
class PolicyTarget:
    device_id: str | None = None
    groups: tuple[str, ...] = ()
    labels: tuple[str, ...] = ()

    @classmethod
    def from_payload(cls, value: object) -> "PolicyTarget":
        if value is None:
            return cls()
        if not isinstance(value, Mapping):
            raise PolicyValidationError("invalid_policy_target")
        unknown = set(value) - {"device_id", "groups", "labels"}
        if unknown:
            raise PolicyValidationError("unknown_policy_target_field")

        device_id = value.get("device_id")
        if device_id is not None:
            if not isinstance(device_id, str) or not _ID_PATTERN.fullmatch(device_id.strip()):
                raise PolicyValidationError("invalid_target_device_id")
            device_id = device_id.strip()

        def parse_names(field: str) -> tuple[str, ...]:
            raw = value.get(field, [])
            if not isinstance(raw, list):
                raise PolicyValidationError(f"invalid_target_{field}")
            names: set[str] = set()
            for item in raw:
                if not isinstance(item, str) or not _ID_PATTERN.fullmatch(item.strip()):
                    raise PolicyValidationError(f"invalid_target_{field}")
                names.add(item.strip())
            return tuple(sorted(names))

        return cls(device_id=device_id, groups=parse_names("groups"), labels=parse_names("labels"))

    def to_payload(self) -> dict[str, object]:
        payload: dict[str, object] = {}
        if self.device_id is not None:
            payload["device_id"] = self.device_id
        if self.groups:
            payload["groups"] = list(self.groups)
        if self.labels:
            payload["labels"] = list(self.labels)
        return payload


@dataclass(frozen=True, slots=True)
class Policy:
    policy_id: str
    policy_type: PolicyType
    revision: int
    issuer: PolicyIssuer
    issued_at: datetime
    sections: dict[str, Any]
    target: PolicyTarget = field(default_factory=PolicyTarget)
    expires_at: datetime | None = None
    priority: int = 0
    required_capabilities: tuple[str, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: int = 1

    @classmethod
    def from_payload(cls, payload: Mapping[str, Any]) -> "Policy":
        if not isinstance(payload, Mapping):
            raise PolicyValidationError("invalid_policy")
        schema_version = payload.get("schema_version", 1)
        if isinstance(schema_version, bool) or schema_version != 1:
            raise PolicyValidationError("unsupported_policy_schema_version")

        policy_id = payload.get("policy_id")
        if not isinstance(policy_id, str) or not _ID_PATTERN.fullmatch(policy_id.strip()):
            raise PolicyValidationError("missing_policy_id" if not policy_id else "invalid_policy_id")

        raw_type = payload.get("type")
        if not isinstance(raw_type, str) or not raw_type.strip():
            raise PolicyValidationError("missing_policy_type")
        try:
            policy_type = PolicyType(raw_type.strip().lower())
        except ValueError as error:
            raise PolicyValidationError("unsupported_policy_type") from error

        revision = payload.get("revision")
        if isinstance(revision, bool) or not isinstance(revision, int) or revision < 1:
            raise PolicyValidationError("invalid_policy_revision")

        issuer = PolicyIssuer.from_payload(payload.get("issuer"))
        issued_at = _parse_time(payload.get("issued_at"), field="policy_issued_at", required=True)
        assert issued_at is not None
        expires_at = _parse_time(payload.get("expires_at"), field="policy_expiry")
        if expires_at is not None and expires_at <= issued_at:
            raise PolicyValidationError("policy_expiry_before_issue")

        priority = payload.get("priority", 0)
        if isinstance(priority, bool) or not isinstance(priority, int) or not -1000 <= priority <= 1000:
            raise PolicyValidationError("invalid_policy_priority")

        sections = payload.get("sections")
        if not isinstance(sections, dict) or not sections:
            raise PolicyValidationError("missing_policy_sections" if sections is None else "invalid_policy_sections")
        for section in sections:
            if not isinstance(section, str) or not _SECTION_PATTERN.fullmatch(section):
                raise PolicyValidationError("invalid_policy_section")
        _validate_json_value(sections)

        metadata = payload.get("metadata", {})
        if not isinstance(metadata, dict):
            raise PolicyValidationError("invalid_policy_metadata")
        _validate_json_value(metadata)

        raw_capabilities = payload.get("required_capabilities", [])
        if not isinstance(raw_capabilities, list):
            raise PolicyValidationError("invalid_policy_capabilities")
        capabilities: set[str] = set()
        for capability in raw_capabilities:
            if not isinstance(capability, str) or not _CAPABILITY_PATTERN.fullmatch(capability.strip()):
                raise PolicyValidationError("invalid_policy_capability")
            capabilities.add(capability.strip())

        target = PolicyTarget.from_payload(payload.get("target"))
        return cls(
            policy_id=policy_id.strip(),
            policy_type=policy_type,
            revision=revision,
            issuer=issuer,
            issued_at=issued_at,
            expires_at=expires_at,
            priority=priority,
            target=target,
            sections=dict(sections),
            required_capabilities=tuple(sorted(capabilities)),
            metadata=dict(metadata),
            schema_version=1,
        )

    @property
    def identity(self) -> tuple[str, int]:
        return self.policy_id, self.revision

    def is_expired(self, *, now: datetime | None = None) -> bool:
        if self.expires_at is None:
            return False
        reference = now or datetime.now(timezone.utc)
        if reference.tzinfo is None:
            reference = reference.replace(tzinfo=timezone.utc)
        return self.expires_at <= reference.astimezone(timezone.utc)

    def to_payload(self) -> dict[str, object]:
        payload: dict[str, object] = {
            "schema_version": self.schema_version,
            "policy_id": self.policy_id,
            "type": self.policy_type.value,
            "revision": self.revision,
            "issuer": self.issuer.to_payload(),
            "issued_at": self.issued_at.isoformat().replace("+00:00", "Z"),
            "priority": self.priority,
            "target": self.target.to_payload(),
            "sections": dict(self.sections),
            "required_capabilities": list(self.required_capabilities),
            "metadata": dict(self.metadata),
        }
        if self.expires_at is not None:
            payload["expires_at"] = self.expires_at.isoformat().replace("+00:00", "Z")
        return payload


@dataclass(frozen=True, slots=True)
class PolicyResult:
    policy_id: str
    revision: int
    state: PolicyState
    code: str | None = None
    message: str | None = None
    data: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not _ID_PATTERN.fullmatch(self.policy_id):
            raise PolicyValidationError("invalid_policy_id")
        if isinstance(self.revision, bool) or self.revision < 1:
            raise PolicyValidationError("invalid_policy_revision")
        if self.message is not None and len(self.message) > _MAX_RESULT_MESSAGE:
            raise PolicyValidationError("policy_result_message_too_long")
        _validate_json_value(self.data)

    @property
    def terminal(self) -> bool:
        return self.state in _TERMINAL_STATES

    def to_payload(self) -> dict[str, object]:
        payload: dict[str, object] = {
            "policy_id": self.policy_id,
            "revision": self.revision,
            "state": self.state.value,
            "terminal": self.terminal,
            "data": dict(self.data),
        }
        if self.code is not None:
            payload["code"] = self.code
        if self.message is not None:
            payload["message"] = self.message
        return payload

from __future__ import annotations

import base64
import hashlib
import json
import re
from dataclasses import dataclass
from typing import Any, Mapping

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from xaac_agent.policy_model import Policy, PolicyResult, PolicyState, PolicyType, PolicyValidationError

_KEY_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$")


class PolicyTrustError(ValueError):
    """La política no compleix els requisits locals de signatura o confiança."""

    def __init__(self, code: str) -> None:
        super().__init__(code)
        self.code = code


@dataclass(frozen=True, slots=True)
class PolicyTrustAnchor:
    key_id: str
    public_key: Ed25519PublicKey
    issuer_id: str | None = None


def parse_trusted_policy_keys(values: tuple[str, ...]) -> dict[str, PolicyTrustAnchor]:
    """Parseja entrades ``key_id[ @issuer_id ]=public_key_base64``."""
    anchors: dict[str, PolicyTrustAnchor] = {}
    for value in values:
        subject, separator, encoded = value.partition("=")
        if not separator or not subject.strip() or not encoded.strip():
            raise ValueError(f"invalid_policy_key_definition:{value}")
        key_id, issuer_separator, issuer_id = subject.strip().partition("@")
        if not _KEY_ID.fullmatch(key_id):
            raise ValueError(f"invalid_policy_key_id:{key_id}")
        if issuer_separator and (not issuer_id.strip() or len(issuer_id.strip()) > 256):
            raise ValueError(f"invalid_policy_key_issuer:{key_id}")
        if key_id in anchors:
            raise ValueError(f"duplicate_policy_key_id:{key_id}")
        try:
            raw = base64.b64decode(encoded.strip(), validate=True)
            key = Ed25519PublicKey.from_public_bytes(raw)
        except (TypeError, ValueError) as error:
            raise ValueError(f"invalid_policy_public_key:{key_id}") from error
        anchors[key_id] = PolicyTrustAnchor(
            key_id=key_id,
            public_key=key,
            issuer_id=issuer_id.strip() if issuer_separator else None,
        )
    return anchors


def canonical_policy_bytes(policy: Policy) -> bytes:
    """Representació estable que se signa; la signatura no forma part del contingut."""
    return json.dumps(
        policy.to_payload(),
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    ).encode("utf-8")


@dataclass(frozen=True, slots=True)
class VerifiedPolicy:
    policy: Policy
    key_id: str
    algorithm: str
    canonical_sha256: str

    def to_result(self) -> PolicyResult:
        return PolicyResult(
            self.policy.policy_id,
            self.policy.revision,
            PolicyState.VALIDATED,
            code="policy_signature_verified",
            data={
                "algorithm": self.algorithm,
                "key_id": self.key_id,
                "canonical_sha256": self.canonical_sha256,
            },
        )


@dataclass(frozen=True, slots=True)
class PolicyTrustVerifier:
    trusted_keys: Mapping[str, PolicyTrustAnchor]
    allowed_issuer_kinds: tuple[str, ...] = ("xms",)
    allowed_policy_types: tuple[PolicyType, ...] = tuple(PolicyType)
    require_signature: bool = True

    def verify(self, document: Mapping[str, Any]) -> VerifiedPolicy:
        if not isinstance(document, Mapping):
            raise PolicyTrustError("invalid_policy_document")
        try:
            policy = Policy.from_payload(document)
        except PolicyValidationError as error:
            raise PolicyTrustError(error.code) from error

        if policy.issuer.kind not in self.allowed_issuer_kinds:
            raise PolicyTrustError("policy_issuer_kind_untrusted")
        if policy.policy_type not in self.allowed_policy_types:
            raise PolicyTrustError("policy_type_untrusted")

        signature = document.get("signature")
        if signature is None and not self.require_signature:
            raise PolicyTrustError("unsigned_policy_not_verifiable")
        if not isinstance(signature, Mapping):
            raise PolicyTrustError("missing_policy_signature" if signature is None else "invalid_policy_signature")
        unknown = set(signature) - {"algorithm", "key_id", "value"}
        if unknown:
            raise PolicyTrustError("unknown_policy_signature_field")
        algorithm = signature.get("algorithm")
        key_id = signature.get("key_id")
        encoded = signature.get("value")
        if algorithm != "Ed25519":
            raise PolicyTrustError("unsupported_policy_signature_algorithm")
        if not isinstance(key_id, str) or not _KEY_ID.fullmatch(key_id.strip()):
            raise PolicyTrustError("invalid_policy_signature_key_id")
        if not isinstance(encoded, str) or not encoded.strip():
            raise PolicyTrustError("invalid_policy_signature_value")

        anchor = self.trusted_keys.get(key_id.strip())
        if anchor is None:
            raise PolicyTrustError("policy_signing_key_untrusted")
        if anchor.issuer_id is not None and anchor.issuer_id != policy.issuer.issuer_id:
            raise PolicyTrustError("policy_signing_key_issuer_mismatch")
        try:
            raw_signature = base64.b64decode(encoded.strip(), validate=True)
        except (TypeError, ValueError) as error:
            raise PolicyTrustError("invalid_policy_signature_encoding") from error
        if len(raw_signature) != 64:
            raise PolicyTrustError("invalid_policy_signature_length")

        canonical = canonical_policy_bytes(policy)
        try:
            anchor.public_key.verify(raw_signature, canonical)
        except InvalidSignature as error:
            raise PolicyTrustError("policy_signature_invalid") from error
        return VerifiedPolicy(
            policy=policy,
            key_id=anchor.key_id,
            algorithm="Ed25519",
            canonical_sha256=hashlib.sha256(canonical).hexdigest(),
        )

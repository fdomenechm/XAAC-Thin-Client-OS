from __future__ import annotations

import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from xaac_agent.hardware_profile import HardwareProfile


@dataclass(frozen=True, slots=True)
class NetworkThresholds:
    warning_error_percent: float = 1.0
    critical_error_percent: float = 5.0
    hysteresis_percent: float = 0.5


@dataclass(frozen=True, slots=True)
class NetworkOptimizationPolicy:
    profile_id: str = "generic"
    stable_sampling_multiplier: int = 1
    minimum_link_speed_mbps: int = 10
    max_interfaces: int = 64
    max_proc_bytes: int = 131072
    max_sysfs_bytes: int = 4096

    @classmethod
    def for_profile(cls, profile: HardwareProfile) -> "NetworkOptimizationPolicy":
        if profile.profile_id == "dell-wyse-3040":
            return cls(
                profile_id=profile.profile_id,
                stable_sampling_multiplier=2,
                minimum_link_speed_mbps=100,
                max_interfaces=16,
            )
        return cls(profile_id=profile.profile_id)


@dataclass(frozen=True, slots=True)
class NetworkCounters:
    rx_bytes: int
    rx_packets: int
    rx_errors: int
    rx_dropped: int
    tx_bytes: int
    tx_packets: int
    tx_errors: int
    tx_dropped: int


class NetworkStateTracker:
    def __init__(self, thresholds: NetworkThresholds) -> None:
        self._thresholds = thresholds
        self._states: dict[str, str] = {}

    def evaluate(self, name: str, error_percent: float) -> str:
        previous = self._states.get(name, "normal")
        warning = self._thresholds.warning_error_percent
        critical = self._thresholds.critical_error_percent
        hysteresis = self._thresholds.hysteresis_percent
        if previous == "critical":
            state = "critical" if error_percent >= critical - hysteresis else (
                "warning" if error_percent >= warning - hysteresis else "normal"
            )
        elif previous == "warning":
            state = "critical" if error_percent >= critical else (
                "warning" if error_percent >= warning - hysteresis else "normal"
            )
        else:
            state = "critical" if error_percent >= critical else (
                "warning" if error_percent >= warning else "normal"
            )
        self._states[name] = state
        return state


class NetworkMonitor:
    """Monitorització lleugera d'enllaç i comptadors de xarxa Linux."""

    def __init__(
        self,
        *,
        net_dev_path: Path = Path("/proc/net/dev"),
        sys_class_net: Path = Path("/sys/class/net"),
        thresholds: NetworkThresholds | None = None,
        policy: NetworkOptimizationPolicy | None = None,
        monotonic: Callable[[], float] = time.monotonic,
    ) -> None:
        self._net_dev_path = net_dev_path
        self._sys_class_net = sys_class_net
        self._tracker = NetworkStateTracker(thresholds or NetworkThresholds())
        self._policy = policy or NetworkOptimizationPolicy()
        self._monotonic = monotonic
        self._previous: dict[str, tuple[float, NetworkCounters]] = {}

    def sample(self) -> dict[str, object]:
        now = self._monotonic()
        counters = self._read_counters()
        interfaces: list[dict[str, object]] = []
        active_count = 0
        link_down_count = 0
        for name in sorted(counters)[: self._policy.max_interfaces]:
            if name == "lo":
                continue
            current = counters[name]
            link = self._read_link(name)
            carrier = link.get("carrier")
            operational_state = link.get("operational_state")
            active = carrier is True or operational_state in {"up", "unknown", "dormant"}
            if active:
                active_count += 1
            elif carrier is False or operational_state in {"down", "lowerlayerdown", "notpresent"}:
                link_down_count += 1

            entry: dict[str, object] = {
                "name": name,
                "operational_state": operational_state or "unknown",
                "carrier": carrier,
                "rx_bytes": current.rx_bytes,
                "tx_bytes": current.tx_bytes,
                "rx_packets": current.rx_packets,
                "tx_packets": current.tx_packets,
                "rx_errors": current.rx_errors,
                "tx_errors": current.tx_errors,
                "rx_dropped": current.rx_dropped,
                "tx_dropped": current.tx_dropped,
                "speed_mbps": link.get("speed_mbps"),
                "duplex": link.get("duplex", "unknown"),
                "mtu": link.get("mtu"),
                "carrier_changes": link.get("carrier_changes"),
            }
            previous = self._previous.get(name)
            error_percent = 0.0
            if previous is not None:
                previous_time, old = previous
                elapsed = now - previous_time
                if elapsed > 0:
                    rx_bytes_delta = max(0, current.rx_bytes - old.rx_bytes)
                    tx_bytes_delta = max(0, current.tx_bytes - old.tx_bytes)
                    packets_delta = max(0, current.rx_packets - old.rx_packets) + max(0, current.tx_packets - old.tx_packets)
                    errors_delta = (
                        max(0, current.rx_errors - old.rx_errors)
                        + max(0, current.tx_errors - old.tx_errors)
                        + max(0, current.rx_dropped - old.rx_dropped)
                        + max(0, current.tx_dropped - old.tx_dropped)
                    )
                    error_percent = round(errors_delta * 100.0 / max(1, packets_delta + errors_delta), 4)
                    entry.update({
                        "sample_interval_seconds": round(elapsed, 3),
                        "rx_bytes_per_second": round(rx_bytes_delta / elapsed, 2),
                        "tx_bytes_per_second": round(tx_bytes_delta / elapsed, 2),
                        "error_drop_percent": error_percent,
                    })
            state = self._tracker.evaluate(name, error_percent)
            if carrier is False or operational_state in {"down", "lowerlayerdown", "notpresent"}:
                state = "critical"
            elif link.get("duplex") == "half" and state == "normal":
                state = "warning"
            elif isinstance(link.get("speed_mbps"), int) and 0 < link["speed_mbps"] < self._policy.minimum_link_speed_mbps and state == "normal":
                state = "warning"
            entry["state"] = state
            interfaces.append(entry)
            self._previous[name] = (now, current)

        present = set(counters)
        self._previous = {name: value for name, value in self._previous.items() if name in present}
        severity = "critical" if any(item["state"] == "critical" for item in interfaces) else (
            "warning" if any(item["state"] == "warning" for item in interfaces) else "normal"
        )
        sampling_multiplier = self._policy.stable_sampling_multiplier if severity == "normal" else 1
        return {
            "profile_id": self._policy.profile_id,
            "availability": "available" if interfaces else "unavailable",
            "interface_count": len(interfaces),
            "active_interface_count": active_count,
            "link_down_count": link_down_count,
            "interfaces": interfaces,
            "severity": severity,
            "sampling": {
                "recommended_interval_multiplier": sampling_multiplier,
                "reason": "profile_default" if sampling_multiplier > 1 else "network_attention" if severity != "normal" else "default",
            },
            "recommendations": {
                "active_probe_traffic_generated": False,
                "prefer_wired_ethernet": self._policy.profile_id == "dell-wyse-3040",
            },
        }

    def _read_counters(self) -> dict[str, NetworkCounters]:
        try:
            if self._net_dev_path.is_symlink() or not self._net_dev_path.is_file():
                return {}
            if self._net_dev_path.stat().st_size > self._policy.max_proc_bytes:
                return {}
            text = self._net_dev_path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return {}
        result: dict[str, NetworkCounters] = {}
        for line in text.splitlines()[2:]:
            if ":" not in line:
                continue
            raw_name, raw_values = line.split(":", 1)
            name = raw_name.strip()
            values = raw_values.split()
            if not name or len(values) < 16:
                continue
            try:
                nums = [max(0, int(value)) for value in values[:16]]
            except ValueError:
                continue
            result[name] = NetworkCounters(
                rx_bytes=nums[0], rx_packets=nums[1], rx_errors=nums[2], rx_dropped=nums[3],
                tx_bytes=nums[8], tx_packets=nums[9], tx_errors=nums[10], tx_dropped=nums[11],
            )
        return result

    def _read_link(self, name: str) -> dict[str, object]:
        root = self._sys_class_net / name
        result: dict[str, object] = {}
        value = self._read_text(root / "operstate")
        if value:
            result["operational_state"] = value.lower()
        carrier = self._read_text(root / "carrier")
        if carrier in {"0", "1"}:
            result["carrier"] = carrier == "1"
        speed = self._read_text(root / "speed")
        if speed:
            try:
                parsed_speed = int(speed)
                if 0 < parsed_speed <= 1_000_000:
                    result["speed_mbps"] = parsed_speed
            except ValueError:
                pass
        duplex = self._read_text(root / "duplex")
        if duplex and duplex.lower() in {"full", "half", "unknown"}:
            result["duplex"] = duplex.lower()
        for filename, key in (("mtu", "mtu"), ("carrier_changes", "carrier_changes")):
            value = self._read_text(root / filename)
            if value:
                try:
                    parsed = int(value)
                    if parsed >= 0:
                        result[key] = parsed
                except ValueError:
                    pass
        return result

    def _read_text(self, path: Path) -> str | None:
        try:
            if path.is_symlink() or not path.is_file():
                return None
            if path.stat().st_size > self._policy.max_sysfs_bytes:
                return None
            return path.read_text(encoding="utf-8", errors="replace").strip()
        except OSError:
            return None

from __future__ import annotations

import argparse
import ipaddress
import json
import os
import socket
import ssl
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Callable, Iterable
from urllib.parse import urlparse


class NetworkDiagnosticError(ValueError):
    """Diagnòstic de xarxa no executable o configuració no vàlida."""


@dataclass(frozen=True, slots=True)
class NetworkDiagnosticPolicy:
    timeout_seconds: float = 3.0
    max_interfaces: int = 64
    max_addresses_per_interface: int = 16
    include_mac_addresses: bool = False
    include_dns_servers: bool = False

    def validate(self) -> None:
        if not 0.1 <= self.timeout_seconds <= 30.0:
            raise NetworkDiagnosticError("network_diagnostic_timeout_out_of_range")
        if not 1 <= self.max_interfaces <= 256:
            raise NetworkDiagnosticError("network_diagnostic_max_interfaces_out_of_range")
        if not 1 <= self.max_addresses_per_interface <= 64:
            raise NetworkDiagnosticError("network_diagnostic_max_addresses_out_of_range")


@dataclass(frozen=True, slots=True)
class NetworkDiagnosticResult:
    format: str
    generated_at_unix: int
    status: str
    target: str
    interfaces: tuple[dict[str, object], ...]
    default_routes: tuple[dict[str, object], ...]
    dns: dict[str, object]
    endpoint: dict[str, object]
    findings: tuple[str, ...]

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


class NetworkDiagnosticCollector:
    def __init__(
        self,
        *,
        policy: NetworkDiagnosticPolicy | None = None,
        sys_class_net: Path = Path("/sys/class/net"),
        proc_net_route: Path = Path("/proc/net/route"),
        resolv_conf: Path = Path("/etc/resolv.conf"),
        resolver: Callable[..., list[tuple]] = socket.getaddrinfo,
        connector: Callable[..., socket.socket] = socket.create_connection,
        clock: Callable[[], float] = time.time,
    ) -> None:
        self.policy = policy or NetworkDiagnosticPolicy()
        self.policy.validate()
        self.sys_class_net = sys_class_net
        self.proc_net_route = proc_net_route
        self.resolv_conf = resolv_conf
        self.resolver = resolver
        self.connector = connector
        self.clock = clock

    def collect(self, *, server_url: str) -> NetworkDiagnosticResult:
        parsed = urlparse(server_url)
        if parsed.scheme not in {"http", "https"} or not parsed.hostname:
            raise NetworkDiagnosticError("network_diagnostic_invalid_server_url")
        port = parsed.port or (443 if parsed.scheme == "https" else 80)
        target = f"{parsed.hostname}:{port}"
        interfaces = tuple(self._collect_interfaces())
        routes = tuple(self._collect_default_routes())
        dns = self._collect_dns(parsed.hostname, port)
        endpoint = self._probe_endpoint(parsed.hostname, port, parsed.scheme == "https")
        findings: list[str] = []
        if not interfaces:
            findings.append("no_network_interfaces")
        if not routes:
            findings.append("no_default_route")
        if dns["status"] != "ok":
            findings.append("dns_resolution_failed")
        if endpoint["status"] != "ok":
            findings.append("endpoint_unreachable")
        status = "ok" if not findings else ("critical" if "endpoint_unreachable" in findings else "warning")
        return NetworkDiagnosticResult(
            format="xaac-network-diagnostic/v1",
            generated_at_unix=int(self.clock()),
            status=status,
            target=target,
            interfaces=interfaces,
            default_routes=routes,
            dns=dns,
            endpoint=endpoint,
            findings=tuple(findings),
        )

    def _collect_interfaces(self) -> Iterable[dict[str, object]]:
        try:
            entries = sorted(self.sys_class_net.iterdir(), key=lambda p: p.name)[: self.policy.max_interfaces]
        except OSError:
            return ()
        output: list[dict[str, object]] = []
        for entry in entries:
            name = entry.name
            if not name or len(name) > 64 or any(ord(ch) < 32 for ch in name):
                continue
            state = self._read_text(entry / "operstate", 32) or "unknown"
            mtu_text = self._read_text(entry / "mtu", 16)
            mtu = int(mtu_text) if mtu_text and mtu_text.isdigit() else None
            item: dict[str, object] = {"name": name, "state": state, "mtu": mtu}
            if self.policy.include_mac_addresses:
                address = self._read_text(entry / "address", 64)
                if address and len(address) <= 32:
                    item["mac_address"] = address.lower()
            output.append(item)
        return output

    def _collect_default_routes(self) -> Iterable[dict[str, object]]:
        try:
            lines = self.proc_net_route.read_text(encoding="utf-8", errors="strict").splitlines()
        except (OSError, UnicodeError):
            return ()
        routes: list[dict[str, object]] = []
        for line in lines[1:]:
            fields = line.split()
            if len(fields) < 8 or fields[1] != "00000000":
                continue
            try:
                gateway_raw = bytes.fromhex(fields[2])
                gateway = str(ipaddress.IPv4Address(gateway_raw[::-1]))
                metric = int(fields[6])
            except (ValueError, ipaddress.AddressValueError):
                continue
            routes.append({"interface": fields[0][:64], "gateway": gateway, "metric": metric})
        return sorted(routes, key=lambda item: (int(item["metric"]), str(item["interface"])))[:16]

    def _collect_dns(self, hostname: str, port: int) -> dict[str, object]:
        started = time.monotonic()
        try:
            answers = self.resolver(hostname, port, type=socket.SOCK_STREAM)
            addresses = sorted({str(answer[4][0]) for answer in answers})[:16]
            result: dict[str, object] = {
                "status": "ok" if addresses else "error",
                "address_count": len(addresses),
                "latency_ms": round((time.monotonic() - started) * 1000, 3),
            }
            if self.policy.include_dns_servers:
                result["servers"] = self._read_dns_servers()
            return result
        except (OSError, socket.gaierror, UnicodeError) as error:
            return {"status": "error", "code": type(error).__name__.lower(), "address_count": 0}

    def _probe_endpoint(self, hostname: str, port: int, use_tls: bool) -> dict[str, object]:
        started = time.monotonic()
        try:
            connection = self.connector((hostname, port), timeout=self.policy.timeout_seconds)
            with connection:
                tls_version = None
                if use_tls:
                    context = ssl.create_default_context()
                    with context.wrap_socket(connection, server_hostname=hostname) as tls_socket:
                        tls_version = tls_socket.version()
                result: dict[str, object] = {
                    "status": "ok",
                    "transport": "tls" if use_tls else "tcp",
                    "latency_ms": round((time.monotonic() - started) * 1000, 3),
                }
                if tls_version:
                    result["tls_version"] = tls_version
                return result
        except (OSError, ssl.SSLError, TimeoutError) as error:
            return {
                "status": "error",
                "transport": "tls" if use_tls else "tcp",
                "code": type(error).__name__.lower(),
            }

    def _read_dns_servers(self) -> tuple[str, ...]:
        try:
            lines = self.resolv_conf.read_text(encoding="utf-8", errors="strict").splitlines()
        except (OSError, UnicodeError):
            return ()
        servers: list[str] = []
        for line in lines:
            parts = line.split()
            if len(parts) == 2 and parts[0] == "nameserver":
                try:
                    servers.append(str(ipaddress.ip_address(parts[1])))
                except ValueError:
                    continue
        return tuple(servers[:8])

    @staticmethod
    def _read_text(path: Path, max_bytes: int) -> str | None:
        try:
            if path.is_symlink():
                # /sys/class/net entries are symlinks by design; child attribute files are safe sysfs nodes.
                pass
            data = path.read_bytes()
        except OSError:
            return None
        if len(data) > max_bytes:
            return None
        try:
            return data.decode("utf-8", errors="strict").strip()
        except UnicodeError:
            return None


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="XAAC network diagnostic")
    parser.add_argument("--server-url", required=True)
    parser.add_argument("--timeout", type=float, default=3.0)
    parser.add_argument("--include-mac-addresses", action="store_true")
    parser.add_argument("--include-dns-servers", action="store_true")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    try:
        collector = NetworkDiagnosticCollector(
            policy=NetworkDiagnosticPolicy(
                timeout_seconds=args.timeout,
                include_mac_addresses=args.include_mac_addresses,
                include_dns_servers=args.include_dns_servers,
            )
        )
        result = collector.collect(server_url=args.server_url)
    except NetworkDiagnosticError as error:
        print(json.dumps({"format": "xaac-network-diagnostic/v1", "status": "error", "code": str(error)}, sort_keys=True))
        return 2
    print(json.dumps(result.to_dict(), sort_keys=True, separators=(",", ":")))
    return 0 if result.status == "ok" else 1


if __name__ == "__main__":
    raise SystemExit(main())

from __future__ import annotations

import os
import socket
from dataclasses import dataclass
from typing import Mapping


@dataclass(frozen=True, slots=True)
class SystemdNotifier:
    """Client mínim de sd_notify, sense dependències externes."""

    socket_address: str | None
    watchdog_timeout_seconds: float | None = None

    @classmethod
    def from_environment(
        cls,
        environment: Mapping[str, str] | None = None,
        *,
        pid: int | None = None,
    ) -> "SystemdNotifier":
        env = os.environ if environment is None else environment
        current_pid = os.getpid() if pid is None else pid
        address = env.get("NOTIFY_SOCKET") or None
        watchdog_pid = env.get("WATCHDOG_PID")
        if watchdog_pid:
            try:
                if int(watchdog_pid) != current_pid:
                    return cls(address, None)
            except ValueError:
                return cls(address, None)
        watchdog_usec = env.get("WATCHDOG_USEC")
        timeout: float | None = None
        if watchdog_usec:
            try:
                parsed = int(watchdog_usec)
                if parsed > 0:
                    timeout = parsed / 1_000_000
            except ValueError:
                timeout = None
        return cls(address, timeout)

    @property
    def available(self) -> bool:
        return bool(self.socket_address)

    @property
    def watchdog_enabled(self) -> bool:
        return self.available and self.watchdog_timeout_seconds is not None

    def notify(self, message: str) -> bool:
        if not self.socket_address:
            return False
        address = self.socket_address
        if address.startswith("@"):
            address = "\0" + address[1:]
        try:
            with socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM) as client:
                client.connect(address)
                client.sendall(message.encode("utf-8"))
        except OSError:
            return False
        return True

    def ready(self, status: str = "XAAC Agent actiu") -> bool:
        return self.notify(f"READY=1\nSTATUS={status}")

    def watchdog(self, status: str | None = None) -> bool:
        message = "WATCHDOG=1"
        if status:
            message += f"\nSTATUS={status}"
        return self.notify(message)

    def stopping(self, status: str = "XAAC Agent aturant-se") -> bool:
        return self.notify(f"STOPPING=1\nSTATUS={status}")

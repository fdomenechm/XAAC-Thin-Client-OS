from __future__ import annotations

import json
import os
import stat
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Mapping

from xaac_agent.thin_client_contract import ContractOperation, ThinClientIntegrationContract


class ThinClientStateError(ValueError):
    """Estat local de XAAC Thin Client no vàlid o insegur."""


class SupervisorState(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    FAILED = "failed"
    UNKNOWN = "unknown"


# Backward-compatible import name.  Production state v2 models the real
# session supervisor, not a non-existent xaac-thin-client.service.
ServiceState = SupervisorState


class SessionState(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    CONNECTING = "connecting"
    ERROR = "error"
    UNKNOWN = "unknown"


class HealthState(str, Enum):
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    UNKNOWN = "unknown"


_ALLOWED_ROOT_KEYS_V1 = frozenset({"format", "published_at", "heartbeat_at", "thin_client", "service", "sessions", "last_error", "health"})
_ALLOWED_ROOT_KEYS_V2 = frozenset({"format", "published_at", "heartbeat_at", "thin_client", "supervisor", "sessions", "last_error", "health"})
_ALLOWED_THIN_CLIENT_KEYS = frozenset({"installed", "version"})
_ALLOWED_SUPERVISOR_KEYS = frozenset({"state"})
_ALLOWED_SESSIONS_KEYS = frozenset({"graphical", "rdp"})
_ALLOWED_SESSION_KEYS = frozenset({"state"})
_ALLOWED_ERROR_KEYS = frozenset({"code", "message", "occurred_at", "recoverable"})
_ALLOWED_HEALTH_KEYS = frozenset({"status", "reasons"})


def _parse_timestamp(value: object, *, field: str) -> datetime:
    if not isinstance(value, str) or not value.strip():
        raise ThinClientStateError(f"invalid_{field}")
    text = value.strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError as error:
        raise ThinClientStateError(f"invalid_{field}") from error
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ThinClientStateError(f"{field}_must_be_timezone_aware")
    return parsed.astimezone(timezone.utc)


def _expect_mapping(value: object, *, field: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ThinClientStateError(f"invalid_{field}")
    return value


def _reject_unknown(mapping: Mapping[str, Any], allowed: frozenset[str], *, field: str) -> None:
    if set(mapping) - allowed:
        raise ThinClientStateError(f"unknown_{field}_field")


def _parse_session(value: object, *, field: str) -> SessionState:
    data = _expect_mapping(value, field=field)
    _reject_unknown(data, _ALLOWED_SESSION_KEYS, field=field)
    try:
        return SessionState(data.get("state"))
    except ValueError as error:
        raise ThinClientStateError(f"invalid_{field}_state") from error


@dataclass(frozen=True, slots=True)
class ThinClientLastError:
    code: str
    message: str
    occurred_at: datetime
    recoverable: bool

    def to_payload(self) -> dict[str, object]:
        return {
            "code": self.code,
            "message": self.message,
            "occurred_at": self.occurred_at.isoformat(),
            "recoverable": self.recoverable,
        }


@dataclass(frozen=True, slots=True)
class ThinClientStateSnapshot:
    installed: bool
    version: str | None
    supervisor_state: SupervisorState
    graphical_session: SessionState
    rdp_session: SessionState
    last_error: ThinClientLastError | None
    health: HealthState
    health_reasons: tuple[str, ...]
    published_at: datetime | None
    heartbeat_at: datetime | None
    stale: bool
    source: str

    @property
    def service_state(self) -> SupervisorState:
        """Compatibility alias for pre-7.3 callers."""
        return self.supervisor_state

    @classmethod
    def absent(cls) -> "ThinClientStateSnapshot":
        return cls(
            installed=False,
            version=None,
            supervisor_state=SupervisorState.UNKNOWN,
            graphical_session=SessionState.UNKNOWN,
            rdp_session=SessionState.UNKNOWN,
            last_error=None,
            health=HealthState.UNKNOWN,
            health_reasons=("state-unavailable",),
            published_at=None,
            heartbeat_at=None,
            stale=False,
            source="absent",
        )

    @classmethod
    def from_document(
        cls,
        document: Mapping[str, Any],
        *,
        now: datetime | None = None,
        max_heartbeat_age_seconds: int = 180,
    ) -> "ThinClientStateSnapshot":
        format_name = document.get("format")
        if format_name == "xaac-state/v2":
            _reject_unknown(document, _ALLOWED_ROOT_KEYS_V2, field="state")
            supervisor_field = "supervisor"
        elif format_name == "xaac-state/v1":
            # Read-only migration compatibility with the pre-7.3 contract.
            _reject_unknown(document, _ALLOWED_ROOT_KEYS_V1, field="state")
            supervisor_field = "service"
        else:
            raise ThinClientStateError("unsupported_state_format")

        published_at = _parse_timestamp(document.get("published_at"), field="published_at")
        heartbeat_raw = document.get("heartbeat_at", document.get("published_at"))
        heartbeat_at = _parse_timestamp(heartbeat_raw, field="heartbeat_at")
        if heartbeat_at > published_at:
            raise ThinClientStateError("heartbeat_after_publication")

        thin_client = _expect_mapping(document.get("thin_client"), field="thin_client")
        _reject_unknown(thin_client, _ALLOWED_THIN_CLIENT_KEYS, field="thin_client")
        installed = thin_client.get("installed")
        if not isinstance(installed, bool):
            raise ThinClientStateError("invalid_installed_state")
        version = thin_client.get("version")
        if version is not None and (not isinstance(version, str) or not version.strip() or len(version) > 64):
            raise ThinClientStateError("invalid_thin_client_version")
        if installed and version is None:
            raise ThinClientStateError("installed_version_missing")
        if not installed and version is not None:
            raise ThinClientStateError("absent_version_present")

        supervisor = _expect_mapping(document.get(supervisor_field), field="supervisor")
        _reject_unknown(supervisor, _ALLOWED_SUPERVISOR_KEYS, field="supervisor")
        try:
            supervisor_state = SupervisorState(supervisor.get("state"))
        except ValueError as error:
            raise ThinClientStateError("invalid_supervisor_state") from error

        sessions = _expect_mapping(document.get("sessions"), field="sessions")
        _reject_unknown(sessions, _ALLOWED_SESSIONS_KEYS, field="sessions")
        graphical = _parse_session(sessions.get("graphical"), field="graphical_session")
        rdp = _parse_session(sessions.get("rdp"), field="rdp_session")

        last_error: ThinClientLastError | None = None
        error_raw = document.get("last_error")
        if error_raw is not None:
            error_data = _expect_mapping(error_raw, field="last_error")
            _reject_unknown(error_data, _ALLOWED_ERROR_KEYS, field="last_error")
            code = error_data.get("code")
            message = error_data.get("message")
            recoverable = error_data.get("recoverable")
            if not isinstance(code, str) or not code or len(code) > 64:
                raise ThinClientStateError("invalid_last_error_code")
            if not isinstance(message, str) or len(message) > 512 or "\x00" in message:
                raise ThinClientStateError("invalid_last_error_message")
            if not isinstance(recoverable, bool):
                raise ThinClientStateError("invalid_last_error_recoverable")
            last_error = ThinClientLastError(
                code=code,
                message=message,
                occurred_at=_parse_timestamp(error_data.get("occurred_at"), field="last_error_occurred_at"),
                recoverable=recoverable,
            )

        health_data = _expect_mapping(document.get("health"), field="health")
        _reject_unknown(health_data, _ALLOWED_HEALTH_KEYS, field="health")
        try:
            health = HealthState(health_data.get("status"))
        except ValueError as error:
            raise ThinClientStateError("invalid_health_state") from error
        reasons_raw = health_data.get("reasons", [])
        if not isinstance(reasons_raw, list) or len(reasons_raw) > 16:
            raise ThinClientStateError("invalid_health_reasons")
        reasons: list[str] = []
        for reason in reasons_raw:
            if not isinstance(reason, str) or not reason or len(reason) > 128:
                raise ThinClientStateError("invalid_health_reason")
            if reason not in reasons:
                reasons.append(reason)

        current = now or datetime.now(timezone.utc)
        if current.tzinfo is None or current.utcoffset() is None:
            raise ThinClientStateError("now_must_be_timezone_aware")
        if max_heartbeat_age_seconds < 1:
            raise ThinClientStateError("invalid_heartbeat_age_limit")
        stale = (current.astimezone(timezone.utc) - heartbeat_at).total_seconds() > max_heartbeat_age_seconds

        if not installed and any(
            value not in {SupervisorState.UNKNOWN, SessionState.UNKNOWN, SessionState.INACTIVE}
            for value in (supervisor_state, graphical, rdp)
        ):
            raise ThinClientStateError("absent_thin_client_has_active_state")

        return cls(
            installed=installed,
            version=version.strip() if version is not None else None,
            supervisor_state=supervisor_state,
            graphical_session=graphical,
            rdp_session=rdp,
            last_error=last_error,
            health=health,
            health_reasons=tuple(reasons),
            published_at=published_at,
            heartbeat_at=heartbeat_at,
            stale=stale,
            source="published",
        )

    def to_payload(self) -> dict[str, object]:
        return {
            "format": "xaac-agent-thin-client-state/v2",
            "installed": self.installed,
            "version": self.version,
            "supervisor": {"state": self.supervisor_state.value},
            "sessions": {
                "graphical": {"state": self.graphical_session.value},
                "rdp": {"state": self.rdp_session.value},
            },
            "last_error": self.last_error.to_payload() if self.last_error else None,
            "health": {
                "status": self.health.value,
                "reasons": list(self.health_reasons),
                "stale": self.stale,
            },
            "published_at": self.published_at.isoformat() if self.published_at else None,
            "heartbeat_at": self.heartbeat_at.isoformat() if self.heartbeat_at else None,
            "source": self.source,
        }


@dataclass(frozen=True, slots=True)
class ThinClientStateReader:
    contract: ThinClientIntegrationContract
    filename: str = "state.json"
    max_bytes: int = 65536
    max_heartbeat_age_seconds: int = 180

    def __post_init__(self) -> None:
        if self.filename != Path(self.filename).name or not self.filename.endswith(".json"):
            raise ThinClientStateError("invalid_state_filename")
        if not 1024 <= self.max_bytes <= 1024 * 1024:
            raise ThinClientStateError("invalid_state_size_limit")
        if not 1 <= self.max_heartbeat_age_seconds <= 86400:
            raise ThinClientStateError("invalid_heartbeat_age_limit")

    @property
    def state_file(self) -> Path:
        return self.contract.state_root / self.filename

    def read(self, *, now: datetime | None = None) -> ThinClientStateSnapshot:
        if not self.contract.is_operation_allowed(ContractOperation.READ_STATE):
            raise ThinClientStateError("read_state_not_authorized")
        root = self.contract.state_root
        if root.is_symlink():
            raise ThinClientStateError("state_directory_symlink")
        if not root.exists():
            return ThinClientStateSnapshot.absent()
        try:
            root_mode = root.stat(follow_symlinks=False).st_mode
        except OSError as error:
            raise ThinClientStateError("state_directory_unreadable") from error
        if not stat.S_ISDIR(root_mode):
            raise ThinClientStateError("state_directory_not_directory")

        path = self.state_file
        if path.is_symlink():
            raise ThinClientStateError("state_file_symlink")
        if not path.exists():
            return ThinClientStateSnapshot.absent()
        try:
            info = path.stat(follow_symlinks=False)
        except OSError as error:
            raise ThinClientStateError("state_file_unreadable") from error
        if not stat.S_ISREG(info.st_mode):
            raise ThinClientStateError("state_file_not_regular")
        if info.st_size > self.max_bytes:
            raise ThinClientStateError("state_file_too_large")
        try:
            flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NOFOLLOW", 0)
            descriptor = os.open(path, flags)
            try:
                raw = os.read(descriptor, self.max_bytes + 1)
            finally:
                os.close(descriptor)
        except OSError as error:
            raise ThinClientStateError("state_file_read_failed") from error
        if len(raw) > self.max_bytes:
            raise ThinClientStateError("state_file_too_large")
        try:
            document = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise ThinClientStateError("invalid_state_json") from error
        if not isinstance(document, Mapping):
            raise ThinClientStateError("invalid_state_document")
        return ThinClientStateSnapshot.from_document(
            document,
            now=now,
            max_heartbeat_age_seconds=self.max_heartbeat_age_seconds,
        )

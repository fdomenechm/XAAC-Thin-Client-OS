from __future__ import annotations

import logging
import threading
import time
from collections.abc import Callable

from xaac_agent.systemd_notify import SystemdNotifier

logger = logging.getLogger(__name__)


class WatchdogMonitor:
    """Notifica systemd només mentre el bucle principal continua progressant."""

    def __init__(
        self,
        notifier: SystemdNotifier,
        *,
        monotonic: Callable[[], float] = time.monotonic,
        on_stall: Callable[[float], None] | None = None,
    ) -> None:
        self._notifier = notifier
        self._monotonic = monotonic
        self._on_stall = on_stall
        timeout = notifier.watchdog_timeout_seconds or 0.0
        self.poll_interval_seconds = max(1.0, timeout / 3.0) if timeout else 0.0
        self.stall_timeout_seconds = max(2.0, timeout * 0.75) if timeout else 0.0
        self._last_progress = monotonic()
        self._lock = threading.Lock()
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None
        self._stall_reported = False

    @property
    def enabled(self) -> bool:
        return self._notifier.watchdog_enabled

    def start(self) -> None:
        self._notifier.ready()
        if not self.enabled or self._thread is not None:
            return
        self._thread = threading.Thread(
            target=self._run,
            name="xaac-agent-watchdog",
            daemon=True,
        )
        self._thread.start()

    def mark_progress(self) -> None:
        with self._lock:
            self._last_progress = self._monotonic()
            self._stall_reported = False

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=max(1.0, self.poll_interval_seconds + 1.0))
        self._notifier.stopping()

    def check_once(self) -> bool:
        if not self.enabled:
            return False
        with self._lock:
            age = self._monotonic() - self._last_progress
            already_reported = self._stall_reported
        if age > self.stall_timeout_seconds:
            if not already_reported:
                with self._lock:
                    self._stall_reported = True
                logger.critical("watchdog_stall_detected age_seconds=%.3f", age)
                if self._on_stall is not None:
                    self._on_stall(age)
                self._notifier.notify(f"STATUS=XAAC Agent bloquejat ({age:.1f}s)")
            return False
        return self._notifier.watchdog("XAAC Agent saludable")

    def _run(self) -> None:
        while not self._stop_event.wait(self.poll_interval_seconds):
            self.check_once()

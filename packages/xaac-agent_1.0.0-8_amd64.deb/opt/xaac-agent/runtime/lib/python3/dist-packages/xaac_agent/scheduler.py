from __future__ import annotations

import logging
import threading
import time
from collections import deque
from collections.abc import Callable
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass(slots=True)
class ScheduledTask:
    name: str
    interval_seconds: float
    callback: Callable[[], object]
    run_immediately: bool = True
    next_run: float | None = None
    running: bool = False

    def validate(self) -> None:
        if not self.name.strip():
            raise ValueError("El nom de la tasca no pot ser buit")
        if self.interval_seconds <= 0:
            raise ValueError("L'interval de la tasca ha de ser major que zero")


class TaskScheduler:
    """Planificador monotònic, interrompible i d'un sol fil."""

    def __init__(
        self,
        *,
        monotonic: Callable[[], float] = time.monotonic,
        wait: Callable[[threading.Event, float], bool] | None = None,
    ) -> None:
        self._monotonic = monotonic
        self._wait = wait or (lambda event, timeout: event.wait(timeout))
        self._tasks: dict[str, ScheduledTask] = {}
        self._pending_callbacks: deque[Callable[[], object]] = deque()
        self._pending_lock = threading.Lock()
        self._stop_event = threading.Event()
        self._wake_event = threading.Event()
        self._progress_callback: Callable[[], object] | None = None
        self._max_wait_seconds: float | None = None

    @property
    def stopping(self) -> bool:
        return self._stop_event.is_set()

    def add_task(self, task: ScheduledTask) -> None:
        task.validate()
        if task.name in self._tasks:
            raise ValueError(f"La tasca ja existeix: {task.name}")
        now = self._monotonic()
        task.next_run = now if task.run_immediately else now + task.interval_seconds
        self._tasks[task.name] = task
        self.wake()

    def update_task_interval(self, name: str, interval_seconds: float) -> None:
        if interval_seconds <= 0:
            raise ValueError("L'interval de la tasca ha de ser major que zero")
        try:
            task = self._tasks[name]
        except KeyError as error:
            raise KeyError(f"La tasca no existeix: {name}") from error
        task.interval_seconds = interval_seconds
        task.next_run = self._monotonic() + interval_seconds
        self.wake()

    def set_progress_callback(self, callback: Callable[[], object] | None) -> None:
        self._progress_callback = callback

    def set_max_wait_seconds(self, seconds: float | None) -> None:
        if seconds is not None and seconds <= 0:
            raise ValueError("El temps màxim d'espera ha de ser major que zero")
        self._max_wait_seconds = seconds
        self.wake()

    def call_soon(self, callback: Callable[[], object]) -> None:
        with self._pending_lock:
            self._pending_callbacks.append(callback)
        self.wake()

    def stop(self) -> None:
        self._stop_event.set()
        self.wake()

    def wake(self) -> None:
        self._wake_event.set()

    def run(self) -> None:
        if not self._tasks and not self._pending_callbacks:
            logger.info("scheduler_no_tasks")
            return
        logger.info("scheduler_started tasks=%s", len(self._tasks))
        while not self.stopping:
            self._report_progress()
            self.run_pending_callbacks()
            self.run_due_tasks()
            if self.stopping:
                break
            timeout = self.seconds_until_next_task()
            if self._max_wait_seconds is not None:
                timeout = min(timeout, self._max_wait_seconds)
            self._wake_event.clear()
            self._wait(self._wake_event, timeout)
        self._report_progress()
        logger.info("scheduler_stopped")

    def _report_progress(self) -> None:
        if self._progress_callback is None:
            return
        try:
            self._progress_callback()
        except Exception:
            logger.exception("scheduler_progress_callback_failed")

    def run_pending_callbacks(self) -> int:
        executed = 0
        while not self.stopping:
            with self._pending_lock:
                if not self._pending_callbacks:
                    break
                callback = self._pending_callbacks.popleft()
            try:
                callback()
            except Exception:
                logger.exception("scheduled_callback_failed")
            executed += 1
        return executed

    def run_due_tasks(self) -> int:
        executed = 0
        now = self._monotonic()
        for task in tuple(self._tasks.values()):
            if self.stopping:
                break
            if task.next_run is None or task.next_run > now:
                continue
            if task.running:
                logger.warning("scheduled_task_overlap_prevented task=%s", task.name)
                task.next_run = now + task.interval_seconds
                continue
            task.running = True
            started = self._monotonic()
            try:
                task.callback()
            except Exception:
                logger.exception("scheduled_task_failed task=%s", task.name)
            finally:
                task.running = False
                finished = self._monotonic()
                task.next_run = max(started + task.interval_seconds, finished)
            executed += 1
            now = self._monotonic()
        return executed

    def seconds_until_next_task(self) -> float:
        if self._pending_callbacks:
            return 0.0
        if not self._tasks:
            return 0.0
        now = self._monotonic()
        due_times = [task.next_run for task in self._tasks.values() if task.next_run is not None]
        if not due_times:
            return 0.0
        return max(0.0, min(due_times) - now)

from __future__ import annotations

import hashlib
import json
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping


class InventoryStateError(ValueError):
    """L'estat persistent de l'inventari és invàlid o insegur."""


def canonical_inventory_bytes(payload: Mapping[str, object]) -> bytes:
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def inventory_fingerprint(payload: Mapping[str, object]) -> str:
    return "sha256:" + hashlib.sha256(canonical_inventory_bytes(payload)).hexdigest()


def _diff(previous: Any, current: Any, path: str = "") -> tuple[Any, list[str], bool]:
    if isinstance(previous, dict) and isinstance(current, dict):
        changed: dict[str, Any] = {}
        removed: list[str] = []
        for key in sorted(previous.keys() - current.keys()):
            removed.append(f"{path}/{key}" if path else f"/{key}")
        for key in sorted(current):
            child_path = f"{path}/{key}" if path else f"/{key}"
            if key not in previous:
                changed[key] = current[key]
                continue
            child, child_removed, differs = _diff(previous[key], current[key], child_path)
            removed.extend(child_removed)
            if differs and child not in ({}, None):
                changed[key] = child
        return changed, removed, bool(changed or removed)
    if previous != current:
        return current, [], True
    return None, [], False


@dataclass(frozen=True, slots=True)
class InventoryTransmission:
    mode: str
    fingerprint: str
    base_fingerprint: str | None
    payload: dict[str, object]
    removed_paths: tuple[str, ...]
    full_inventory: dict[str, object]
    heartbeat_sequence: int


@dataclass(frozen=True, slots=True)
class InventoryState:
    fingerprint: str
    inventory: dict[str, object]
    last_full_sequence: int


class InventoryStateStore:
    def __init__(self, path: Path, *, full_interval_heartbeats: int = 1440) -> None:
        self.path = path
        self.full_interval_heartbeats = full_interval_heartbeats

    def prepare(self, inventory: Mapping[str, object], *, heartbeat_sequence: int) -> InventoryTransmission:
        current = dict(inventory)
        fingerprint = inventory_fingerprint(current)
        previous = self._load_optional()
        full_due = (
            previous is None
            or heartbeat_sequence <= previous.last_full_sequence
            or heartbeat_sequence - previous.last_full_sequence >= self.full_interval_heartbeats
        )
        if full_due:
            return InventoryTransmission(
                mode="full",
                fingerprint=fingerprint,
                base_fingerprint=previous.fingerprint if previous else None,
                payload=current,
                removed_paths=(),
                full_inventory=current,
                heartbeat_sequence=heartbeat_sequence,
            )
        if fingerprint == previous.fingerprint:
            return InventoryTransmission(
                mode="unchanged",
                fingerprint=fingerprint,
                base_fingerprint=previous.fingerprint,
                payload={},
                removed_paths=(),
                full_inventory=current,
                heartbeat_sequence=heartbeat_sequence,
            )
        delta, removed, _ = _diff(previous.inventory, current)
        return InventoryTransmission(
            mode="delta",
            fingerprint=fingerprint,
            base_fingerprint=previous.fingerprint,
            payload=dict(delta or {}),
            removed_paths=tuple(removed),
            full_inventory=current,
            heartbeat_sequence=heartbeat_sequence,
        )

    def commit(self, transmission: InventoryTransmission) -> None:
        previous = self._load_optional()
        last_full_sequence = (
            transmission.heartbeat_sequence
            if transmission.mode == "full"
            else (previous.last_full_sequence if previous else transmission.heartbeat_sequence)
        )
        self._save(
            InventoryState(
                fingerprint=transmission.fingerprint,
                inventory=transmission.full_inventory,
                last_full_sequence=last_full_sequence,
            )
        )

    def invalidate(self) -> None:
        if self.path.is_symlink() or (self.path.exists() and not self.path.is_file()):
            raise InventoryStateError("inventory state path must be a regular file")
        try:
            self.path.unlink()
        except FileNotFoundError:
            return

    def _load_optional(self) -> InventoryState | None:
        try:
            if self.path.is_symlink() or (self.path.exists() and not self.path.is_file()):
                raise InventoryStateError("inventory state path must be a regular file")
            raw = json.loads(self.path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return None
        except (OSError, json.JSONDecodeError) as error:
            raise InventoryStateError("inventory state is not readable JSON") from error
        if not isinstance(raw, dict) or raw.get("schema_version") != 1:
            raise InventoryStateError("unsupported inventory state schema")
        fingerprint = raw.get("fingerprint")
        inventory = raw.get("inventory")
        last_full_sequence = raw.get("last_full_sequence")
        if not isinstance(fingerprint, str) or not fingerprint.startswith("sha256:"):
            raise InventoryStateError("invalid inventory fingerprint")
        if not isinstance(inventory, dict):
            raise InventoryStateError("invalid cached inventory")
        if not isinstance(last_full_sequence, int) or last_full_sequence < 1:
            raise InventoryStateError("invalid last full inventory sequence")
        if inventory_fingerprint(inventory) != fingerprint:
            raise InventoryStateError("cached inventory fingerprint mismatch")
        return InventoryState(fingerprint, inventory, last_full_sequence)

    def _save(self, state: InventoryState) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        descriptor, name = tempfile.mkstemp(prefix=f".{self.path.name}.", dir=self.path.parent)
        temporary = Path(name)
        try:
            os.fchmod(descriptor, 0o600)
            with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                json.dump(
                    {
                        "schema_version": 1,
                        "fingerprint": state.fingerprint,
                        "inventory": state.inventory,
                        "last_full_sequence": state.last_full_sequence,
                    },
                    handle,
                    sort_keys=True,
                    separators=(",", ":"),
                )
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, self.path)
            os.chmod(self.path, 0o600)
        finally:
            temporary.unlink(missing_ok=True)

from __future__ import annotations

import logging
import os
import re
import stat
from pathlib import Path
from typing import Iterable


class SecretError(RuntimeError):
    """Base error for local secret handling."""


class InvalidSecretFileError(SecretError):
    """Raised when a secret file is missing required safety properties."""


_SECRET_PATTERNS = (
    re.compile(r"(?i)(authorization\s*[:=]\s*bearer\s+)([^\s,;]+)"),
    re.compile(
        r"(?i)\b(password|passwd|secret|token|api[_-]?key|client[_-]?secret|"
        r"access[_-]?token|refresh[_-]?token|credential)\s*[:=]\s*([^\s,;]+)"
    ),
)


def redact_text(value: object, *, known_secrets: Iterable[str] = ()) -> str:
    """Return a log-safe representation without common or explicitly known secrets."""
    text = str(value)
    for secret in known_secrets:
        if secret:
            text = text.replace(secret, "[REDACTED]")
    text = _SECRET_PATTERNS[0].sub(r"\1[REDACTED]", text)
    text = _SECRET_PATTERNS[1].sub(lambda match: f"{match.group(1)}=[REDACTED]", text)
    return text


class SecretRedactionFilter(logging.Filter):
    """Redact secrets from the final formatted message and its arguments."""

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            rendered = record.getMessage()
        except (TypeError, ValueError):
            rendered = str(record.msg)
        record.msg = redact_text(rendered)
        record.args = ()
        return True


def install_secret_redaction_filter() -> None:
    root = logging.getLogger()
    for handler in root.handlers:
        if not any(isinstance(item, SecretRedactionFilter) for item in handler.filters):
            handler.addFilter(SecretRedactionFilter())


class SecretFile:
    """Read a small secret from a regular, non-linked, privately accessible file."""

    def __init__(
        self, path: Path, *, max_bytes: int = 16 * 1024, repair_permissions: bool = False
    ) -> None:
        self.path = path
        self.max_bytes = max_bytes
        self.repair_permissions = repair_permissions

    @classmethod
    def from_systemd_credential(cls, name: str, *, fallback: Path | None = None) -> "SecretFile":
        directory = os.environ.get("CREDENTIALS_DIRECTORY", "").strip()
        if directory:
            candidate = Path(directory) / name
            if candidate.exists():
                return cls(candidate)
        if fallback is None:
            raise FileNotFoundError(name)
        return cls(fallback, repair_permissions=True)

    def read(self) -> str:
        metadata = self._metadata()
        if metadata.st_size > self.max_bytes:
            raise InvalidSecretFileError("secret file exceeds maximum size")
        mode = stat.S_IMODE(metadata.st_mode)
        if mode & 0o077:
            if not self.repair_permissions:
                raise InvalidSecretFileError("secret file permissions must not grant group or other access")
            try:
                os.chmod(self.path, mode & ~0o077)
            except OSError as error:
                raise InvalidSecretFileError("cannot enforce private secret permissions") from error
        try:
            descriptor = os.open(self.path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
        except FileNotFoundError:
            raise
        except OSError as error:
            raise InvalidSecretFileError("cannot open secret file safely") from error
        try:
            data = os.read(descriptor, self.max_bytes + 1)
        finally:
            os.close(descriptor)
        if len(data) > self.max_bytes:
            raise InvalidSecretFileError("secret file exceeds maximum size")
        try:
            value = data.decode("utf-8").strip()
        except UnicodeDecodeError as error:
            raise InvalidSecretFileError("secret file must contain UTF-8 text") from error
        if not value:
            raise InvalidSecretFileError("secret file is empty")
        if "\x00" in value or "\n" in value or "\r" in value:
            raise InvalidSecretFileError("secret file must contain exactly one text value")
        return value

    def _metadata(self) -> os.stat_result:
        try:
            metadata = self.path.lstat()
        except FileNotFoundError:
            raise
        except OSError as error:
            raise InvalidSecretFileError("cannot inspect secret file") from error
        if stat.S_ISLNK(metadata.st_mode):
            raise InvalidSecretFileError("secret file must not be a symbolic link")
        if not stat.S_ISREG(metadata.st_mode):
            raise InvalidSecretFileError("secret path must be a regular file")
        return metadata

from __future__ import annotations

import json
import os
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class CompromiseResponseError(ValueError):
    """Estat o política de resposta a compromís no vàlids."""


_ALLOWED_REASONS = {
    "file_integrity_failure",
    "boot_security_failure",
    "tpm_attestation_failure",
    "credential_misuse",
    "operator_request",
    "unknown",
}


@dataclass(frozen=True, slots=True)
class CompromiseResponsePolicy:
    enabled: bool = False
    automatic_quarantine: bool = False
    state_file: Path = Path("/var/lib/xaac-agent/compromise-state.json")
    block_remote_commands: bool = True
    block_updates: bool = True
    allow_heartbeat: bool = True
    max_state_bytes: int = 65536

    def validate(self) -> None:
        if not self.state_file.is_absolute():
            raise CompromiseResponseError("compromise_state_file ha de ser absolut")
        if not 1024 <= self.max_state_bytes <= 1024 * 1024:
            raise CompromiseResponseError("compromise_max_state_bytes fora de rang")
        if self.automatic_quarantine and not self.enabled:
            raise CompromiseResponseError("la quarantena automàtica requereix compromise_response_enabled")
        if self.enabled and not self.allow_heartbeat:
            raise CompromiseResponseError("el heartbeat ha de continuar permés durant la quarantena")


@dataclass(frozen=True, slots=True)
class CompromiseState:
    quarantined: bool
    reason: str = ""
    detected_at: str = ""
    source: str = ""
    incident_id: str = ""
    released_at: str = ""
    released_by: str = ""

    def to_payload(self) -> dict[str, object]:
        return {
            "quarantined": self.quarantined,
            "reason": self.reason,
            "detected_at": self.detected_at,
            "source": self.source,
            "incident_id": self.incident_id,
            "released_at": self.released_at,
            "released_by": self.released_by,
        }


class CompromiseResponseManager:
    def __init__(self, policy: CompromiseResponsePolicy) -> None:
        policy.validate()
        self._policy = policy

    @property
    def policy(self) -> CompromiseResponsePolicy:
        return self._policy

    def load(self) -> CompromiseState:
        if not self._policy.enabled or not self._policy.state_file.exists():
            return CompromiseState(quarantined=False)
        path = self._policy.state_file
        if path.is_symlink() or not path.is_file():
            raise CompromiseResponseError("estat de compromís no regular")
        if path.stat().st_size > self._policy.max_state_bytes:
            raise CompromiseResponseError("estat de compromís massa gran")
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
            raise CompromiseResponseError("estat de compromís invàlid") from error
        if not isinstance(raw, dict) or raw.get("version") != 1:
            raise CompromiseResponseError("versió d’estat de compromís no admesa")
        state = CompromiseState(
            quarantined=bool(raw.get("quarantined", False)),
            reason=str(raw.get("reason", "")),
            detected_at=str(raw.get("detected_at", "")),
            source=str(raw.get("source", "")),
            incident_id=str(raw.get("incident_id", "")),
            released_at=str(raw.get("released_at", "")),
            released_by=str(raw.get("released_by", "")),
        )
        if state.quarantined and (state.reason not in _ALLOWED_REASONS or not state.detected_at):
            raise CompromiseResponseError("estat de quarantena incomplet")
        return state

    def quarantine(self, *, reason: str, source: str, incident_id: str = "", now: datetime | None = None) -> CompromiseState:
        if not self._policy.enabled:
            raise CompromiseResponseError("resposta a compromís desactivada")
        if reason not in _ALLOWED_REASONS:
            raise CompromiseResponseError("motiu de compromís no admés")
        source = source.strip()
        if not source or len(source) > 128 or any(ch in source for ch in "\r\n"):
            raise CompromiseResponseError("font de detecció invàlida")
        incident_id = incident_id.strip()
        if len(incident_id) > 128 or any(ch in incident_id for ch in "\r\n"):
            raise CompromiseResponseError("incident_id invàlid")
        timestamp = (now or datetime.now(timezone.utc)).astimezone(timezone.utc).isoformat()
        state = CompromiseState(True, reason, timestamp, source, incident_id)
        self._write(state)
        return state

    def release(self, *, operator: str, now: datetime | None = None) -> CompromiseState:
        current = self.load()
        operator = operator.strip()
        if not operator or len(operator) > 128 or any(ch in operator for ch in "\r\n"):
            raise CompromiseResponseError("operador de recuperació invàlid")
        if not current.quarantined:
            return current
        timestamp = (now or datetime.now(timezone.utc)).astimezone(timezone.utc).isoformat()
        state = CompromiseState(False, current.reason, current.detected_at, current.source, current.incident_id, timestamp, operator)
        self._write(state)
        return state

    def capabilities(self) -> dict[str, bool]:
        state = self.load()
        quarantined = self._policy.enabled and state.quarantined
        return {
            "heartbeat": True,
            "remote_commands": not (quarantined and self._policy.block_remote_commands),
            "updates": not (quarantined and self._policy.block_updates),
            "enrollment": not quarantined,
        }

    def telemetry(self) -> dict[str, object]:
        state = self.load()
        return {
            "enabled": self._policy.enabled,
            "quarantined": state.quarantined,
            "reason": state.reason,
            "detected_at": state.detected_at,
            "source": state.source,
            "incident_id": state.incident_id,
            "severity": "critical" if state.quarantined else "normal",
            "capabilities": self.capabilities(),
        }

    def _write(self, state: CompromiseState) -> None:
        path = self._policy.state_file
        path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        payload: dict[str, Any] = {"version": 1, **state.to_payload()}
        encoded = (json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")
        if len(encoded) > self._policy.max_state_bytes:
            raise CompromiseResponseError("estat de compromís massa gran")
        fd, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
        try:
            os.fchmod(fd, 0o600)
            with os.fdopen(fd, "wb") as stream:
                stream.write(encoded)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, path)
        finally:
            try:
                os.unlink(temporary)
            except FileNotFoundError:
                pass

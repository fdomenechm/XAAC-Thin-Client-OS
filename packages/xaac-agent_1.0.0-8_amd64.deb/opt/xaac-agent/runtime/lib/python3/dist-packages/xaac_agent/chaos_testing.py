from __future__ import annotations

import argparse
import json
import os
import shutil
import tempfile
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Callable, Iterable, Mapping

from xaac_agent.outbox import PersistentOutbox
from xaac_agent.safe_mode import SafeModeStore
from xaac_agent.xms_failover import XmsFailoverStore

_FORMAT = "xaac-chaos-report/v1"
_REQUIRED_TOKEN = "XAAC_CONTROLLED_CHAOS"
_MAX_WORKSPACE_BYTES = 64 * 1024 * 1024
_ALLOWED_SCENARIOS = (
    "process-crash-outbox",
    "corrupt-local-state",
    "prolonged-network-loss",
    "authorized-xms-failover",
)


class ChaosTestError(ValueError):
    """Controlled chaos request is invalid or unsafe."""


@dataclass(frozen=True, slots=True)
class ChaosScenarioResult:
    scenario: str
    passed: bool
    observations: dict[str, object]


@dataclass(frozen=True, slots=True)
class ChaosReport:
    format: str
    passed: bool
    workspace: str
    scenarios: tuple[ChaosScenarioResult, ...]

    def to_dict(self) -> dict[str, object]:
        return {
            "format": self.format,
            "passed": self.passed,
            "workspace": self.workspace,
            "scenarios": [asdict(item) for item in self.scenarios],
        }


def validate_workspace(path: Path, *, token: str | None) -> Path:
    if token != _REQUIRED_TOKEN:
        raise ChaosTestError("controlled_chaos_token_required")
    resolved = path.expanduser().resolve()
    forbidden = {Path("/"), Path("/etc"), Path("/var"), Path("/usr"), Path("/run"), Path("/home")}
    if resolved in forbidden or any(parent in forbidden - {Path("/")} for parent in resolved.parents):
        raise ChaosTestError("production_path_not_allowed")
    if resolved.exists() and resolved.is_symlink():
        raise ChaosTestError("workspace_symlink_not_allowed")
    resolved.mkdir(parents=True, exist_ok=True, mode=0o700)
    if resolved.is_symlink() or not resolved.is_dir():
        raise ChaosTestError("workspace_must_be_directory")
    marker = resolved / ".xaac-controlled-chaos"
    if marker.exists() and (marker.is_symlink() or not marker.is_file()):
        raise ChaosTestError("invalid_workspace_marker")
    marker.write_text(_REQUIRED_TOKEN + "\n", encoding="utf-8")
    os.chmod(marker, 0o600)
    return resolved


def run_controlled_chaos(
    workspace: Path,
    *,
    token: str | None,
    scenarios: Iterable[str] = _ALLOWED_SCENARIOS,
) -> ChaosReport:
    root = validate_workspace(workspace, token=token)
    selected = tuple(dict.fromkeys(str(item).strip() for item in scenarios))
    if not selected:
        raise ChaosTestError("at_least_one_scenario_required")
    unknown = sorted(set(selected) - set(_ALLOWED_SCENARIOS))
    if unknown:
        raise ChaosTestError(f"unknown_scenario:{','.join(unknown)}")

    handlers: Mapping[str, Callable[[Path], ChaosScenarioResult]] = {
        "process-crash-outbox": _process_crash_outbox,
        "corrupt-local-state": _corrupt_local_state,
        "prolonged-network-loss": _prolonged_network_loss,
        "authorized-xms-failover": _authorized_xms_failover,
    }
    results: list[ChaosScenarioResult] = []
    for name in selected:
        scenario_root = root / name
        if scenario_root.exists():
            shutil.rmtree(scenario_root)
        scenario_root.mkdir(mode=0o700)
        results.append(handlers[name](scenario_root))
        if _tree_size(root) > _MAX_WORKSPACE_BYTES:
            raise ChaosTestError("workspace_size_limit_exceeded")
    return ChaosReport(_FORMAT, all(item.passed for item in results), str(root), tuple(results))


def _process_crash_outbox(root: Path) -> ChaosScenarioResult:
    outbox = PersistentOutbox(root / "outbox.json")
    first = outbox.enqueue("heartbeat", {"sequence": 1}, message_id="chaos-message-1")
    delivery_id, batch, _ = outbox.reserve_batch(limit=10, delivery_id="chaos-delivery-1")
    restarted = PersistentOutbox(root / "outbox.json")
    next_delivery, recovered, report = restarted.reserve_batch(limit=10, delivery_id="chaos-delivery-2")
    passed = (
        first.message_id == "chaos-message-1"
        and delivery_id == "chaos-delivery-1"
        and [item.message_id for item in batch] == ["chaos-message-1"]
        and next_delivery == "chaos-delivery-2"
        and [item.message_id for item in recovered] == ["chaos-message-1"]
        and report.recovered_messages == 1
    )
    return ChaosScenarioResult("process-crash-outbox", passed, {
        "message_id_preserved": bool(recovered and recovered[0].message_id == first.message_id),
        "recovered_messages": report.recovered_messages,
    })


def _corrupt_local_state(root: Path) -> ChaosScenarioResult:
    path = root / "safe-mode.json"
    store = SafeModeStore(path)
    store.enter("chaos_baseline", "controlled test")
    path.write_text("{broken-json", encoding="utf-8")
    failed_closed = False
    try:
        store.load()
    except Exception:
        failed_closed = True
    return ChaosScenarioResult("corrupt-local-state", failed_closed, {
        "corruption_detected": failed_closed,
        "unsafe_default_used": False,
    })


def _prolonged_network_loss(root: Path) -> ChaosScenarioResult:
    # Deterministic model: retries grow but remain bounded and preserve pending work.
    delays = [min(300, 2 ** attempt) for attempt in range(1, 12)]
    outbox = PersistentOutbox(root / "outbox.json")
    outbox.enqueue("inventory", {"revision": 7}, message_id="offline-message")
    restarted = PersistentOutbox(root / "outbox.json")
    pending = restarted.pending()
    passed = delays == sorted(delays) and max(delays) == 300 and [item.message_id for item in pending] == ["offline-message"]
    return ChaosScenarioResult("prolonged-network-loss", passed, {
        "attempts": len(delays),
        "maximum_delay_seconds": max(delays),
        "pending_messages": len(pending),
    })


def _authorized_xms_failover(root: Path) -> ChaosScenarioResult:
    primary = "https://xms-primary.example"
    alternate = "https://xms-backup.example"
    store = XmsFailoverStore(root / "xms-failover.json", primary_url=primary, alternate_urls=(alternate,), failure_threshold=2)
    first = store.record_failure(active_url=primary, reason="chaos_network_error")
    second = store.record_failure(active_url=primary, reason="chaos_network_error")
    restored = store.prefer_primary()
    passed = first.active_url == primary and second.active_url == alternate and restored.active_url == primary
    return ChaosScenarioResult("authorized-xms-failover", passed, {
        "unauthorized_server_used": False,
        "alternate_selected": second.active_url == alternate,
        "primary_restored": restored.active_url == primary,
    })


def _tree_size(root: Path) -> int:
    total = 0
    for path in root.rglob("*"):
        if path.is_symlink():
            raise ChaosTestError("workspace_symlink_not_allowed")
        if path.is_file():
            total += path.stat().st_size
    return total


def main(argv: Iterable[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run bounded, local XAAC Agent chaos scenarios")
    parser.add_argument("--workspace", type=Path, required=True)
    parser.add_argument("--scenario", action="append", choices=_ALLOWED_SCENARIOS)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(list(argv) if argv is not None else None)
    try:
        report = run_controlled_chaos(
            args.workspace,
            token=os.environ.get("XAAC_CHAOS_TOKEN"),
            scenarios=args.scenario or _ALLOWED_SCENARIOS,
        )
    except ChaosTestError as error:
        if args.json:
            print(json.dumps({"format": _FORMAT, "passed": False, "error": str(error)}, sort_keys=True, separators=(",", ":")))
        else:
            print(f"FAIL {error}")
        return 2
    payload = report.to_dict()
    if args.json:
        print(json.dumps(payload, sort_keys=True, separators=(",", ":")))
    else:
        print("PASS" if report.passed else "FAIL")
        for item in report.scenarios:
            print(f"{'PASS' if item.passed else 'FAIL'} {item.scenario}")
    return 0 if report.passed else 1


if __name__ == "__main__":
    raise SystemExit(main())

from __future__ import annotations

import json
import os
import stat
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Mapping

from xaac_agent.agent_update import AgentPackageInstaller, AgentUpdateError
from xaac_agent.thin_client_update import ThinClientPackageInstaller, ThinClientUpdateError
from xaac_agent.update_model import UpdateComponent, UpdatePlan, UpdateResult, UpdateState
from xaac_agent.update_trust import VerifiedUpdateArtifact


class UpdateRollbackError(RuntimeError):
    def __init__(self, code: str, *, data: Mapping[str, object] | None = None) -> None:
        super().__init__(code)
        self.code = code
        self.data = dict(data or {})


Installer = Callable[[VerifiedUpdateArtifact], UpdateResult]


@dataclass(frozen=True, slots=True)
class UpdateRollbackManager:
    state_file: Path
    agent_installer: AgentPackageInstaller | None = None
    thin_client_installer: ThinClientPackageInstaller | None = None
    max_state_bytes: int = 65536

    def __post_init__(self) -> None:
        if not 1024 <= self.max_state_bytes <= 1024 * 1024:
            raise ValueError("invalid_update_rollback_state_limit")

    def rollback(
        self,
        original_plan: UpdatePlan,
        installation_result: UpdateResult,
        rollback_artifact: VerifiedUpdateArtifact,
    ) -> UpdateResult:
        self._validate_request(original_plan, installation_result, rollback_artifact)
        installer = self._installer_for(original_plan.component)
        started_at = datetime.now(timezone.utc)
        self._write_state({
            "format": "xaac-update-rollback/v1",
            "update_id": original_plan.update_id,
            "rollback_update_id": rollback_artifact.plan.update_id,
            "component": original_plan.component.value,
            "from_version": original_plan.target_version,
            "to_version": rollback_artifact.plan.target_version,
            "state": "rolling-back",
            "started_at": started_at.isoformat().replace("+00:00", "Z"),
        })
        try:
            installed = installer(rollback_artifact)
        except (AgentUpdateError, ThinClientUpdateError) as error:
            self._write_failure_state(original_plan, rollback_artifact.plan, error.code, error.data, started_at)
            raise UpdateRollbackError("update_rollback_install_failed", data={"cause": error.code, **error.data}) from error
        except Exception as error:  # defensive boundary around injected installers
            self._write_failure_state(original_plan, rollback_artifact.plan, "unexpected_installer_error", {}, started_at)
            raise UpdateRollbackError("update_rollback_backend_error") from error

        if installed.state not in {UpdateState.INSTALLED, UpdateState.REBOOT_PENDING}:
            self._write_failure_state(original_plan, rollback_artifact.plan, "rollback_installer_result_invalid", {}, started_at)
            raise UpdateRollbackError("update_rollback_installer_result_invalid")

        completed_at = datetime.now(timezone.utc)
        reboot_required = installed.state is UpdateState.REBOOT_PENDING
        data = {
            "rollback_update_id": rollback_artifact.plan.update_id,
            "from_version": original_plan.target_version,
            "restored_version": rollback_artifact.plan.target_version,
            "artifact_sha256": rollback_artifact.artifact_sha256,
            "signing_key_id": rollback_artifact.key_id,
            "reboot_required": reboot_required,
            "installer_result_code": installed.code,
            "started_at": started_at.isoformat().replace("+00:00", "Z"),
            "completed_at": completed_at.isoformat().replace("+00:00", "Z"),
        }
        self._write_state({
            "format": "xaac-update-rollback/v1",
            "update_id": original_plan.update_id,
            "rollback_update_id": rollback_artifact.plan.update_id,
            "component": original_plan.component.value,
            "from_version": original_plan.target_version,
            "to_version": rollback_artifact.plan.target_version,
            "state": "rolled-back",
            "started_at": data["started_at"],
            "completed_at": data["completed_at"],
            "artifact_sha256": rollback_artifact.artifact_sha256,
            "signing_key_id": rollback_artifact.key_id,
            "reboot_required": reboot_required,
        })
        return UpdateResult(
            original_plan.update_id,
            original_plan.component,
            rollback_artifact.plan.target_version,
            UpdateState.ROLLED_BACK,
            code="update_rolled_back_safely",
            data=data,
        )

    def read_state(self) -> dict[str, object] | None:
        try:
            info = self.state_file.lstat()
        except FileNotFoundError:
            return None
        except OSError as error:
            raise UpdateRollbackError("update_rollback_state_unavailable") from error
        if stat.S_ISLNK(info.st_mode):
            raise UpdateRollbackError("update_rollback_state_symlink")
        if not stat.S_ISREG(info.st_mode):
            raise UpdateRollbackError("update_rollback_state_not_regular")
        if info.st_size > self.max_state_bytes:
            raise UpdateRollbackError("update_rollback_state_too_large")
        try:
            payload = json.loads(self.state_file.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError) as error:
            raise UpdateRollbackError("update_rollback_state_invalid") from error
        if not isinstance(payload, dict) or payload.get("format") != "xaac-update-rollback/v1":
            raise UpdateRollbackError("update_rollback_state_invalid")
        return payload

    def clear_state(self) -> None:
        try:
            info = self.state_file.lstat()
        except FileNotFoundError:
            return
        except OSError as error:
            raise UpdateRollbackError("update_rollback_state_unavailable") from error
        if stat.S_ISLNK(info.st_mode) or not stat.S_ISREG(info.st_mode):
            raise UpdateRollbackError("update_rollback_state_unsafe")
        try:
            self.state_file.unlink()
            self._sync_directory(self.state_file.parent)
        except OSError as error:
            raise UpdateRollbackError("update_rollback_state_clear_failed") from error

    def _validate_request(self, original: UpdatePlan, installed: UpdateResult, artifact: VerifiedUpdateArtifact) -> None:
        if not original.rollback_supported:
            raise UpdateRollbackError("update_rollback_not_supported")
        if original.component not in {UpdateComponent.AGENT, UpdateComponent.THIN_CLIENT}:
            raise UpdateRollbackError("update_rollback_component_unsupported")
        if original.current_version is None:
            raise UpdateRollbackError("update_rollback_previous_version_unknown")
        if (
            installed.update_id != original.update_id
            or installed.component is not original.component
            or installed.target_version != original.target_version
        ):
            raise UpdateRollbackError("update_rollback_installation_identity_mismatch")
        if installed.state not in {UpdateState.INSTALLED, UpdateState.REBOOT_PENDING, UpdateState.COMPLETED}:
            raise UpdateRollbackError("update_rollback_installation_not_ready")
        rollback = artifact.plan
        if rollback.component is not original.component:
            raise UpdateRollbackError("update_rollback_component_mismatch")
        if rollback.target_version != original.current_version:
            raise UpdateRollbackError("update_rollback_target_version_mismatch")
        if rollback.current_version != original.target_version:
            raise UpdateRollbackError("update_rollback_source_version_mismatch")
        if rollback.metadata.get("rollback_for_update_id") != original.update_id:
            raise UpdateRollbackError("update_rollback_plan_not_linked")
        if rollback.expires_at is not None and rollback.expires_at <= datetime.now(timezone.utc):
            raise UpdateRollbackError("update_rollback_plan_expired")

    def _installer_for(self, component: UpdateComponent) -> Installer:
        if component is UpdateComponent.AGENT and self.agent_installer is not None:
            return self.agent_installer.install
        if component is UpdateComponent.THIN_CLIENT and self.thin_client_installer is not None:
            return self.thin_client_installer.install
        raise UpdateRollbackError("update_rollback_installer_unavailable")

    def _write_failure_state(
        self,
        original: UpdatePlan,
        rollback: UpdatePlan,
        cause: str,
        details: Mapping[str, object],
        started_at: datetime,
    ) -> None:
        self._write_state({
            "format": "xaac-update-rollback/v1",
            "update_id": original.update_id,
            "rollback_update_id": rollback.update_id,
            "component": original.component.value,
            "from_version": original.target_version,
            "to_version": rollback.target_version,
            "state": "failed",
            "started_at": started_at.isoformat().replace("+00:00", "Z"),
            "completed_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "error_code": cause,
            "error_data": self._safe_error_data(details),
        })

    @staticmethod
    def _safe_error_data(details: Mapping[str, object]) -> dict[str, object]:
        allowed = {"return_code", "package", "package_version", "path"}
        return {key: value for key, value in details.items() if key in allowed and isinstance(value, (str, int, bool))}

    def _write_state(self, payload: Mapping[str, object]) -> None:
        encoded = json.dumps(dict(payload), sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        if len(encoded) > self.max_state_bytes:
            raise UpdateRollbackError("update_rollback_state_too_large")
        parent = self.state_file.parent
        try:
            parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            parent_info = parent.lstat()
        except OSError as error:
            raise UpdateRollbackError("update_rollback_state_directory_unavailable") from error
        if stat.S_ISLNK(parent_info.st_mode) or not stat.S_ISDIR(parent_info.st_mode):
            raise UpdateRollbackError("update_rollback_state_directory_unsafe")
        if self.state_file.exists() or self.state_file.is_symlink():
            info = self.state_file.lstat()
            if stat.S_ISLNK(info.st_mode) or not stat.S_ISREG(info.st_mode):
                raise UpdateRollbackError("update_rollback_state_unsafe")
        descriptor, temporary = tempfile.mkstemp(prefix=f".{self.state_file.name}.", dir=parent)
        try:
            os.fchmod(descriptor, 0o600)
            with os.fdopen(descriptor, "wb") as stream:
                stream.write(encoded)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.state_file)
            self._sync_directory(parent)
        except OSError as error:
            raise UpdateRollbackError("update_rollback_state_write_failed") from error
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)

    @staticmethod
    def _sync_directory(path: Path) -> None:
        descriptor = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)

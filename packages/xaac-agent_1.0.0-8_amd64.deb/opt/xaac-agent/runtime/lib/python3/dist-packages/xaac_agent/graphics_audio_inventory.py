from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from pathlib import Path

_GENERIC = {"", "unknown", "n/a", "none", "not available"}
_CARD_RE = re.compile(r"^\s*(\d+)\s+\[([^\]]+)\]\s*:\s*([^\n]+)$")


def _read_text(path: Path, *, allow_symlink: bool = False) -> str | None:
    try:
        if not allow_symlink and path.is_symlink():
            return None
        if not path.is_file():
            return None
        value = path.read_text(encoding="utf-8", errors="replace").replace("\x00", " ").strip()
    except OSError:
        return None
    if value.lower() in _GENERIC:
        return None
    return " ".join(value.split())


def _read_int(path: Path) -> int | None:
    value = _read_text(path)
    if value is None:
        return None
    try:
        return int(value, 0)
    except ValueError:
        return None


def _driver_name(device_path: Path) -> str | None:
    try:
        target = (device_path / "driver").resolve(strict=True)
    except OSError:
        return None
    return target.name or None


def _hex_id(value: str | None) -> str | None:
    if not value:
        return None
    value = value.lower().removeprefix("0x")
    return value if re.fullmatch(r"[0-9a-f]{4}", value) else None


def _safe_iterdir(path: Path) -> tuple[Path, ...]:
    """Return a stable directory snapshot or an empty tuple when unavailable."""
    try:
        if not path.is_dir():
            return ()
        return tuple(path.iterdir())
    except OSError:
        return ()


@dataclass(frozen=True, slots=True)
class GraphicsAudioInventory:
    graphics: dict[str, object]
    audio: dict[str, object]

    def to_payload(self) -> dict[str, object]:
        return {"graphics": self.graphics, "audio": self.audio}


class GraphicsAudioInventoryCollector:
    """Collect DRM/KMS and ALSA inventory without invoking external commands."""

    def __init__(
        self,
        *,
        drm_root: Path = Path("/sys/class/drm"),
        sound_root: Path = Path("/proc/asound"),
        proc_root: Path = Path("/proc"),
    ) -> None:
        self._drm_root = Path(drm_root)
        self._sound_root = Path(sound_root)
        self._proc_root = Path(proc_root)

    def collect(self) -> GraphicsAudioInventory:
        return GraphicsAudioInventory(self._collect_graphics(), self._collect_audio())

    def _collect_graphics(self) -> dict[str, object]:
        gpus: list[dict[str, object]] = []
        monitors: list[dict[str, object]] = []
        entries = sorted(_safe_iterdir(self._drm_root), key=lambda p: p.name)

        for entry in entries:
            if re.fullmatch(r"card\d+", entry.name):
                gpu = self._collect_gpu(entry)
                if gpu:
                    gpus.append(gpu)
            elif re.fullmatch(r"card\d+-.+", entry.name):
                monitor = self._collect_connector(entry)
                if monitor:
                    monitors.append(monitor)

        return {
            "gpus": gpus,
            "monitors": monitors,
            "gpu_count": len(gpus),
            "connected_monitor_count": sum(1 for item in monitors if item.get("connected") is True),
        }

    def _collect_gpu(self, card: Path) -> dict[str, object] | None:
        device = card / "device"
        try:
            if not device.exists():
                return None
        except OSError:
            return None
        vendor = _hex_id(_read_text(device / "vendor"))
        device_id = _hex_id(_read_text(device / "device"))
        subsystem_vendor = _hex_id(_read_text(device / "subsystem_vendor"))
        subsystem_device = _hex_id(_read_text(device / "subsystem_device"))
        result: dict[str, object] = {"card": card.name}
        for key, value in (
            ("vendor_id", vendor),
            ("device_id", device_id),
            ("subsystem_vendor_id", subsystem_vendor),
            ("subsystem_device_id", subsystem_device),
            ("driver", _driver_name(device)),
        ):
            if value is not None:
                result[key] = value
        boot_vga = _read_int(device / "boot_vga")
        if boot_vga is not None:
            result["boot_vga"] = bool(boot_vga)
        return result

    def _collect_connector(self, connector: Path) -> dict[str, object] | None:
        status = _read_text(connector / "status")
        if status is None:
            return None
        modes_text = _read_text(connector / "modes")
        modes = [] if modes_text is None else [line for line in modes_text.split() if re.fullmatch(r"\d+x\d+", line)]
        result: dict[str, object] = {
            "name": connector.name.split("-", 1)[1],
            "status": status.lower(),
            "connected": status.lower() == "connected",
            "modes": modes,
        }
        enabled = _read_text(connector / "enabled")
        if enabled is not None:
            result["enabled"] = enabled.lower() == "enabled"
        dpms = _read_text(connector / "dpms")
        if dpms is not None:
            result["dpms"] = dpms
        edid = connector / "edid"
        try:
            if edid.is_file() and not edid.is_symlink():
                raw = edid.read_bytes()
                if raw:
                    result["edid_sha256"] = hashlib.sha256(raw).hexdigest()
        except OSError:
            pass
        return result

    def _collect_audio(self) -> dict[str, object]:
        cards = self._parse_alsa_cards()
        pcm_devices = self._parse_pcm_devices()
        services = self._detect_audio_services()
        return {
            "cards": cards,
            "pcm_devices": pcm_devices,
            "card_count": len(cards),
            "services": services,
        }

    def _parse_alsa_cards(self) -> list[dict[str, object]]:
        text = _read_text(self._sound_root / "cards")
        if not text:
            return []
        cards: list[dict[str, object]] = []
        for line in text.splitlines():
            match = _CARD_RE.match(line)
            if not match:
                continue
            index, short_name, description = match.groups()
            cards.append({
                "index": int(index),
                "id": short_name.strip(),
                "description": " ".join(description.split()),
            })
        return cards

    def _parse_pcm_devices(self) -> list[dict[str, object]]:
        text = _read_text(self._sound_root / "pcm")
        if not text:
            return []
        result: list[dict[str, object]] = []
        for line in text.splitlines():
            line = " ".join(line.split())
            match = re.match(r"^(\d+)-(\d+):\s*(.+?)\s*:\s*(.+)$", line)
            if not match:
                continue
            card, device, name, capabilities = match.groups()
            caps = capabilities.lower()
            result.append({
                "card_index": int(card),
                "device_index": int(device),
                "name": name,
                "playback": "playback" in caps,
                "capture": "capture" in caps,
            })
        return result

    def _detect_audio_services(self) -> dict[str, bool]:
        found = {"pipewire": False, "wireplumber": False, "pulseaudio": False}
        for entry in _safe_iterdir(self._proc_root):
            if not entry.name.isdigit():
                continue
            name = _read_text(entry / "comm")
            if name in found:
                found[name] = True
            if all(found.values()):
                break
        return found

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any


class DebianLayoutError(ValueError):
    """Raised when the Debian package layout is unsafe or inconsistent."""


@dataclass(frozen=True, slots=True)
class DebianPackageLayout:
    package: str
    runtime_root: Path
    python_version: str
    application_root: Path
    configuration_root: Path
    state_root: Path
    entry_points: tuple[str, ...]

    @classmethod
    def load(cls, path: Path) -> "DebianPackageLayout":
        try:
            raw: Any = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise DebianLayoutError("debian_layout_invalid") from exc
        if not isinstance(raw, dict) or raw.get("schema_version") != 1:
            raise DebianLayoutError("debian_layout_schema_invalid")
        runtime = raw.get("runtime")
        paths = raw.get("paths")
        entries = raw.get("entry_points")
        if not isinstance(runtime, dict) or not isinstance(paths, dict):
            raise DebianLayoutError("debian_layout_sections_invalid")
        if runtime.get("python_version") != "3.13":
            raise DebianLayoutError("debian_layout_python_version_invalid")
        if runtime.get("isolated") is not True or runtime.get("system_python_modified") is not False:
            raise DebianLayoutError("debian_layout_runtime_not_isolated")
        if not isinstance(entries, list) or not entries or len(entries) != len(set(entries)):
            raise DebianLayoutError("debian_layout_entry_points_invalid")
        required = {
            "application": "/opt/xaac-agent/app",
            "configuration": "/etc/xaac-agent",
            "state": "/var/lib/xaac-agent",
        }
        for key, expected in required.items():
            if paths.get(key) != expected:
                raise DebianLayoutError(f"debian_layout_path_invalid:{key}")
        runtime_root = Path(str(runtime.get("root", "")))
        if runtime_root != Path("/opt/xaac-agent/runtime"):
            raise DebianLayoutError("debian_layout_runtime_root_invalid")
        return cls(
            package=str(raw.get("package", "")),
            runtime_root=runtime_root,
            python_version="3.13",
            application_root=Path(paths["application"]),
            configuration_root=Path(paths["configuration"]),
            state_root=Path(paths["state"]),
            entry_points=tuple(str(item) for item in entries),
        )

    def validate(self) -> None:
        if self.package != "xaac-agent":
            raise DebianLayoutError("debian_layout_package_invalid")
        for value in (self.runtime_root, self.application_root, self.configuration_root, self.state_root):
            if not value.is_absolute() or ".." in value.parts:
                raise DebianLayoutError("debian_layout_path_unsafe")
        if not self.runtime_root.is_relative_to(Path("/opt/xaac-agent")):
            raise DebianLayoutError("debian_layout_runtime_outside_opt")
        for entry in self.entry_points:
            if not entry.startswith("xaac-") or "/" in entry or entry in {"xaac-python", "xaac-pip"}:
                raise DebianLayoutError("debian_layout_entry_point_unsafe")

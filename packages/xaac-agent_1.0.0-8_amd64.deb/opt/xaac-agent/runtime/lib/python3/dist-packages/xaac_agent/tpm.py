from __future__ import annotations

import hashlib
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Sequence


class TpmError(RuntimeError):
    """Raised when TPM support is required but cannot be used safely."""


@dataclass(frozen=True, slots=True)
class TpmPolicy:
    enabled: bool = False
    required: bool = False
    device_path: Path = Path("/dev/tpmrm0")
    pcr_bank: str = "sha256"
    pcrs: tuple[int, ...] = (0, 2, 4, 7)
    command_timeout_seconds: float = 3.0

    def validate(self) -> None:
        if self.required and not self.enabled:
            raise TpmError("TPM required cannot be true when TPM support is disabled")
        if not self.device_path.is_absolute():
            raise TpmError("TPM device path must be absolute")
        if self.pcr_bank not in {"sha1", "sha256", "sha384", "sha512"}:
            raise TpmError("unsupported TPM PCR bank")
        if not self.pcrs or len(self.pcrs) > 24 or any(value < 0 or value > 23 for value in self.pcrs):
            raise TpmError("TPM PCR list must contain unique indexes from 0 to 23")
        if len(set(self.pcrs)) != len(self.pcrs):
            raise TpmError("TPM PCR list contains duplicates")
        if not 0.1 <= self.command_timeout_seconds <= 30:
            raise TpmError("TPM command timeout is outside the permitted range")


class TpmMonitor:
    """Collect a bounded TPM 2.0 status without exposing endorsement material.

    The monitor never reads EK/AK private material. When tpm2-tools is available it
    records selected PCR values and emits only a stable digest plus the public PCR
    map. Missing optional TPM support degrades to an explicit unavailable state.
    """

    def __init__(
        self,
        policy: TpmPolicy,
        *,
        which: Callable[[str], str | None] = shutil.which,
        run: Callable[..., subprocess.CompletedProcess[str]] = subprocess.run,
    ) -> None:
        policy.validate()
        self._policy = policy
        self._which = which
        self._run = run

    def sample(self) -> dict[str, object]:
        if not self._policy.enabled:
            return {"enabled": False, "available": False, "required": self._policy.required, "severity": "normal"}

        device_exists = self._policy.device_path.exists()
        tool = self._which("tpm2_pcrread")
        available = device_exists and tool is not None
        if not available:
            if self._policy.required:
                raise TpmError("required TPM 2.0 device or tpm2_pcrread is unavailable")
            return {
                "enabled": True,
                "available": False,
                "required": False,
                "device": str(self._policy.device_path),
                "reason": "device_missing" if not device_exists else "tpm2_tools_missing",
                "severity": "warning",
            }

        selector = f"{self._policy.pcr_bank}:" + ",".join(str(value) for value in self._policy.pcrs)
        try:
            result = self._run(
                [tool, "--tcti", f"device:{self._policy.device_path}", selector],
                capture_output=True,
                text=True,
                check=False,
                timeout=self._policy.command_timeout_seconds,
            )
        except (OSError, subprocess.TimeoutExpired) as error:
            if self._policy.required:
                raise TpmError(f"required TPM query failed: {error}") from error
            return {"enabled": True, "available": True, "required": False, "reason": "query_failed", "severity": "warning"}
        if result.returncode != 0:
            if self._policy.required:
                raise TpmError("required TPM PCR query returned an error")
            return {"enabled": True, "available": True, "required": False, "reason": "query_failed", "severity": "warning"}

        pcr_values = self._parse_pcr_output(result.stdout)
        expected = {str(value) for value in self._policy.pcrs}
        if set(pcr_values) != expected:
            if self._policy.required:
                raise TpmError("required TPM PCR response is incomplete")
            return {"enabled": True, "available": True, "required": False, "reason": "incomplete_pcr_response", "severity": "warning"}
        canonical = "\n".join(f"{key}:{pcr_values[key]}" for key in sorted(pcr_values, key=int)).encode("ascii")
        return {
            "enabled": True,
            "available": True,
            "required": self._policy.required,
            "device": str(self._policy.device_path),
            "pcr_bank": self._policy.pcr_bank,
            "pcrs": pcr_values,
            "pcr_digest": f"sha256:{hashlib.sha256(canonical).hexdigest()}",
            "severity": "normal",
        }

    @staticmethod
    def _parse_pcr_output(output: str) -> dict[str, str]:
        values: dict[str, str] = {}
        for raw_line in output.splitlines():
            line = raw_line.strip()
            if ":" not in line:
                continue
            index, value = (part.strip() for part in line.split(":", 1))
            if index.isdigit() and value.lower().startswith("0x"):
                hexadecimal = value[2:].lower()
                if hexadecimal and all(character in "0123456789abcdef" for character in hexadecimal):
                    values[index] = f"0x{hexadecimal}"
        return values

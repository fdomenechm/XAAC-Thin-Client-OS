from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping


@dataclass(frozen=True, slots=True)
class AdaptiveDeliveryPolicy:
    enabled: bool = True
    warning_interval_seconds: int = 30
    critical_interval_seconds: int = 10
    normal_relax_after_samples: int = 10
    normal_interval_multiplier: float = 2.0
    reduced_outbox_batch_size: int = 16
    offline_outbox_batch_size: int = 8

    def validate(self) -> None:
        if self.warning_interval_seconds <= 0:
            raise ValueError("warning_interval_seconds ha de ser positiu")
        if self.critical_interval_seconds <= 0:
            raise ValueError("critical_interval_seconds ha de ser positiu")
        if self.critical_interval_seconds > self.warning_interval_seconds:
            raise ValueError("critical_interval_seconds no pot superar warning_interval_seconds")
        if not 1 <= self.normal_relax_after_samples <= 10000:
            raise ValueError("normal_relax_after_samples fora de rang")
        if not 1.0 <= self.normal_interval_multiplier <= 10.0:
            raise ValueError("normal_interval_multiplier fora de rang")
        if self.reduced_outbox_batch_size <= 0 or self.offline_outbox_batch_size <= 0:
            raise ValueError("les mides de lot adaptatives han de ser positives")


@dataclass(frozen=True, slots=True)
class AdaptiveDeliveryDecision:
    interval_seconds: int
    telemetry_profile: str
    outbox_batch_size: int
    critical_only: bool
    reason: str
    normal_streak: int

    def to_payload(self) -> dict[str, object]:
        return {
            "interval_seconds": self.interval_seconds,
            "telemetry_profile": self.telemetry_profile,
            "outbox_batch_size": self.outbox_batch_size,
            "critical_only": self.critical_only,
            "reason": self.reason,
            "normal_streak": self.normal_streak,
        }


class AdaptiveDeliveryController:
    """Decidix freqüència i volum sense alterar els límits locals de seguretat."""

    def __init__(self, policy: AdaptiveDeliveryPolicy) -> None:
        policy.validate()
        self._policy = policy
        self._normal_streak = 0

    @property
    def normal_streak(self) -> int:
        return self._normal_streak

    def decide(
        self,
        *,
        severity: str,
        offline: bool,
        base_interval_seconds: int,
        min_interval_seconds: int,
        max_interval_seconds: int,
        configured_outbox_batch_size: int,
    ) -> AdaptiveDeliveryDecision:
        severity = severity if severity in {"normal", "warning", "critical"} else "warning"
        base = self._bounded(base_interval_seconds, min_interval_seconds, max_interval_seconds)
        if not self._policy.enabled:
            self._normal_streak = 0
            return AdaptiveDeliveryDecision(base, "full", configured_outbox_batch_size, False, "disabled", 0)
        if offline:
            self._normal_streak = 0
            return AdaptiveDeliveryDecision(
                base,
                "critical-only",
                min(configured_outbox_batch_size, self._policy.offline_outbox_batch_size),
                True,
                "offline-recovery",
                0,
            )
        if severity == "critical":
            self._normal_streak = 0
            interval = self._bounded(
                min(base, self._policy.critical_interval_seconds), min_interval_seconds, max_interval_seconds
            )
            return AdaptiveDeliveryDecision(interval, "full", configured_outbox_batch_size, False, "critical", 0)
        if severity == "warning":
            self._normal_streak = 0
            interval = self._bounded(
                min(base, self._policy.warning_interval_seconds), min_interval_seconds, max_interval_seconds
            )
            return AdaptiveDeliveryDecision(
                interval,
                "summary",
                min(configured_outbox_batch_size, self._policy.reduced_outbox_batch_size),
                False,
                "warning",
                0,
            )
        self._normal_streak += 1
        if self._normal_streak >= self._policy.normal_relax_after_samples:
            interval = self._bounded(
                round(base * self._policy.normal_interval_multiplier), min_interval_seconds, max_interval_seconds
            )
            return AdaptiveDeliveryDecision(
                interval,
                "minimal",
                min(configured_outbox_batch_size, self._policy.reduced_outbox_batch_size),
                False,
                "stable-normal",
                self._normal_streak,
            )
        return AdaptiveDeliveryDecision(
            base, "full", configured_outbox_batch_size, False, "normal", self._normal_streak
        )

    @staticmethod
    def shape_monitoring(payload: Mapping[str, object], profile: str) -> dict[str, object]:
        result = dict(payload)
        if profile == "full":
            return result
        if profile == "critical-only":
            return AdaptiveDeliveryController._critical_only(result)
        if profile == "minimal":
            keep = {"severity", "aggregation", "local_alerts", "xms_connectivity", "certificates_credentials"}
            return {key: value for key, value in result.items() if key in keep}
        # summary: conserva els resums, però elimina llistes de cardinalitat variable.
        for component, list_keys in {
            "storage": ("filesystems",),
            "thermal": ("sensors",),
            "processes_services": ("processes", "services"),
            "network": ("interfaces",),
        }.items():
            value = result.get(component)
            if isinstance(value, Mapping):
                summary = dict(value)
                for key in list_keys:
                    summary.pop(key, None)
                result[component] = summary
        aggregation = result.get("aggregation")
        if isinstance(aggregation, Mapping):
            compact = dict(aggregation)
            compact.pop("metrics", None)
            result["aggregation"] = compact
        alerts = result.get("local_alerts")
        if isinstance(alerts, Mapping):
            compact_alerts = dict(alerts)
            compact_alerts.pop("events", None)
            result["local_alerts"] = compact_alerts
        return result

    @staticmethod
    def _critical_only(payload: dict[str, object]) -> dict[str, object]:
        result: dict[str, object] = {"severity": payload.get("severity", "normal")}
        for key, value in payload.items():
            if not isinstance(value, Mapping):
                continue
            severity = value.get("severity")
            if severity == "critical" or key in {"local_alerts", "xms_connectivity", "certificates_credentials"}:
                compact = dict(value)
                for list_key in ("filesystems", "sensors", "processes", "services", "interfaces", "events", "metrics"):
                    compact.pop(list_key, None)
                result[key] = compact
        return result

    @staticmethod
    def _bounded(value: int | float, minimum: int, maximum: int) -> int:
        return max(int(minimum), min(int(round(value)), int(maximum)))

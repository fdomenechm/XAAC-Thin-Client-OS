from __future__ import annotations

import hashlib
import json
import os
import re
import stat
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

from xaac_agent.thin_client_contract import ContractOperation, ThinClientIntegrationContract


class ThinClientConfigurationError(ValueError):
    """Configuració compartida Agent/Thin Client no vàlida o insegura."""


_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$")
_SECRET_KEYS = frozenset({
    "password", "passwd", "secret", "token", "api_key", "apikey", "private_key",
    "client_secret", "access_token", "refresh_token", "credential", "credentials",
})


def _utc_text(value: datetime) -> str:
    if value.tzinfo is None:
        raise ThinClientConfigurationError("configuration_timestamp_requires_timezone")
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _canonical_bytes(payload: Mapping[str, Any]) -> bytes:
    try:
        return json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode("utf-8")
    except (TypeError, ValueError) as error:
        raise ThinClientConfigurationError("configuration_not_json_serializable") from error


def _validate_no_secrets(value: Any, *, path: str = "configuration", depth: int = 0) -> None:
    if depth > 16:
        raise ThinClientConfigurationError("configuration_too_deep")
    if isinstance(value, Mapping):
        for raw_key, child in value.items():
            if not isinstance(raw_key, str) or not raw_key:
                raise ThinClientConfigurationError("invalid_configuration_key")
            normalized = raw_key.lower().replace("-", "_")
            if normalized in _SECRET_KEYS or any(part in _SECRET_KEYS for part in normalized.split(".")):
                raise ThinClientConfigurationError(f"secret_field_forbidden:{path}.{raw_key}")
            _validate_no_secrets(child, path=f"{path}.{raw_key}", depth=depth + 1)
    elif isinstance(value, (list, tuple)):
        for index, child in enumerate(value):
            _validate_no_secrets(child, path=f"{path}[{index}]", depth=depth + 1)
    elif value is None or isinstance(value, (str, int, float, bool)):
        if isinstance(value, str) and len(value) > 65536:
            raise ThinClientConfigurationError("configuration_string_too_large")
    else:
        raise ThinClientConfigurationError("configuration_value_not_json")


@dataclass(frozen=True, slots=True)
class StagedThinClientConfiguration:
    configuration_id: str
    revision: int
    created_at: datetime
    sections: Mapping[str, Any]
    source_policy_id: str | None = None
    source_policy_revision: int | None = None

    def to_payload(self) -> dict[str, Any]:
        if not _ID_RE.fullmatch(self.configuration_id):
            raise ThinClientConfigurationError("invalid_configuration_id")
        if not 1 <= self.revision <= 2_147_483_647:
            raise ThinClientConfigurationError("invalid_configuration_revision")
        if not isinstance(self.sections, Mapping) or not self.sections:
            raise ThinClientConfigurationError("configuration_sections_required")
        _validate_no_secrets(self.sections)
        source: dict[str, Any] | None = None
        if self.source_policy_id is not None or self.source_policy_revision is not None:
            if not isinstance(self.source_policy_id, str) or not _ID_RE.fullmatch(self.source_policy_id):
                raise ThinClientConfigurationError("invalid_source_policy_id")
            if not isinstance(self.source_policy_revision, int) or self.source_policy_revision < 1:
                raise ThinClientConfigurationError("invalid_source_policy_revision")
            source = {"policy_id": self.source_policy_id, "revision": self.source_policy_revision}
        payload: dict[str, Any] = {
            "format": "xaac-configuration/v1",
            "configuration_id": self.configuration_id,
            "revision": self.revision,
            "created_at": _utc_text(self.created_at),
            "sections": dict(self.sections),
            "secrets": {"included": False, "delivery": "out-of-band"},
        }
        if source is not None:
            payload["source_policy"] = source
        digest_payload = dict(payload)
        payload["sha256"] = hashlib.sha256(_canonical_bytes(digest_payload)).hexdigest()
        return payload


@dataclass(frozen=True, slots=True)
class ThinClientConfigurationAck:
    configuration_id: str
    revision: int
    accepted: bool
    checked_at: datetime
    code: str
    message: str = ""
    sha256: str = ""

    @classmethod
    def from_payload(cls, payload: Mapping[str, Any]) -> "ThinClientConfigurationAck":
        allowed = {"format", "configuration_id", "revision", "accepted", "checked_at", "code", "message", "sha256"}
        if set(payload) - allowed or payload.get("format") != "xaac-configuration-ack/v1":
            raise ThinClientConfigurationError("invalid_configuration_ack")
        try:
            checked_at = datetime.fromisoformat(str(payload["checked_at"]).replace("Z", "+00:00"))
        except (KeyError, ValueError, TypeError) as error:
            raise ThinClientConfigurationError("invalid_configuration_ack_timestamp") from error
        value = cls(
            configuration_id=str(payload.get("configuration_id", "")), revision=payload.get("revision"),
            accepted=payload.get("accepted"), checked_at=checked_at, code=str(payload.get("code", "")),
            message=str(payload.get("message", "")), sha256=str(payload.get("sha256", "")),
        )
        if not _ID_RE.fullmatch(value.configuration_id) or not isinstance(value.revision, int) or value.revision < 1:
            raise ThinClientConfigurationError("invalid_configuration_ack_identity")
        if not isinstance(value.accepted, bool) or not _ID_RE.fullmatch(value.code) or len(value.message) > 512:
            raise ThinClientConfigurationError("invalid_configuration_ack_result")
        if value.sha256 and not re.fullmatch(r"[0-9a-f]{64}", value.sha256):
            raise ThinClientConfigurationError("invalid_configuration_ack_digest")
        return value


@dataclass(frozen=True, slots=True)
class ThinClientConfigurationResult:
    state: str
    code: str
    configuration_id: str
    revision: int
    sha256: str
    previous_preserved: bool = False

    def to_payload(self) -> dict[str, Any]:
        return {
            "format": "xaac-configuration-result/v1", "state": self.state, "code": self.code,
            "configuration_id": self.configuration_id, "revision": self.revision,
            "sha256": self.sha256, "previous_preserved": self.previous_preserved,
        }


class ThinClientConfigurationDistributor:
    def __init__(self, *, contract: ThinClientIntegrationContract, max_bytes: int = 262144) -> None:
        if not 1024 <= max_bytes <= 4 * 1024 * 1024:
            raise ThinClientConfigurationError("configuration_max_bytes_out_of_range")
        self.contract = contract
        self.max_bytes = max_bytes
        self.staged_path = contract.config_root / "staged-configuration.json"
        self.ack_path = contract.config_root / "configuration-ack.json"
        self.active_path = contract.config_root / "active-configuration.json"
        self.previous_path = contract.config_root / "previous-configuration.json"
        self.known_good_path = contract.config_root / "known-good-configuration.json"
        self.restore_audit_path = contract.config_root / "configuration-restore.json"

    def stage(self, configuration: StagedThinClientConfiguration) -> ThinClientConfigurationResult:
        self._require(ContractOperation.STAGE_CONFIG)
        payload = configuration.to_payload()
        raw = _canonical_bytes(payload)
        if len(raw) > self.max_bytes:
            raise ThinClientConfigurationError("configuration_too_large")
        self._ensure_root()
        self._atomic_write(self.staged_path, raw)
        self._safe_unlink(self.ack_path)
        return ThinClientConfigurationResult("staged", "thin_client_configuration_staged", configuration.configuration_id, configuration.revision, payload["sha256"])

    def read_staged(self) -> dict[str, Any]:
        self._require(ContractOperation.READ_CONFIG)
        return self._read_configuration(self.staged_path)

    def read_ack(self) -> ThinClientConfigurationAck:
        self._require(ContractOperation.ACK_CONFIG)
        payload = self._read_json(self.ack_path)
        return ThinClientConfigurationAck.from_payload(payload)

    def activate_confirmed(self) -> ThinClientConfigurationResult:
        self._require(ContractOperation.STAGE_CONFIG)
        staged = self._read_configuration(self.staged_path)
        ack = self.read_ack()
        if ack.configuration_id != staged["configuration_id"] or ack.revision != staged["revision"]:
            raise ThinClientConfigurationError("configuration_ack_identity_mismatch")
        if ack.sha256 and ack.sha256 != staged["sha256"]:
            raise ThinClientConfigurationError("configuration_ack_digest_mismatch")
        if not ack.accepted:
            raise ThinClientConfigurationError(f"configuration_rejected:{ack.code}")
        previous_preserved = False
        if self.active_path.exists() or self.active_path.is_symlink():
            active_raw = self._safe_read(self.active_path)
            self._atomic_write(self.previous_path, active_raw)
            previous_preserved = True
        staged_raw = self._safe_read(self.staged_path)
        self._atomic_write(self.active_path, staged_raw)
        # An acknowledged configuration is the last configuration proven usable by the Thin Client.
        self._atomic_write(self.known_good_path, staged_raw)
        self._safe_unlink(self.staged_path)
        self._safe_unlink(self.ack_path)
        return ThinClientConfigurationResult("active", "thin_client_configuration_activated", staged["configuration_id"], staged["revision"], staged["sha256"], previous_preserved)

    def rollback(self) -> ThinClientConfigurationResult:
        self._require(ContractOperation.STAGE_CONFIG)
        previous = self._read_configuration(self.previous_path)
        current_raw = self._safe_read(self.active_path) if self.active_path.exists() else None
        previous_raw = self._safe_read(self.previous_path)
        self._atomic_write(self.active_path, previous_raw)
        if current_raw is not None:
            self._atomic_write(self.previous_path, current_raw)
        return ThinClientConfigurationResult("rolled-back", "thin_client_configuration_rolled_back", previous["configuration_id"], previous["revision"], previous["sha256"], current_raw is not None)

    def restore_known_good(
        self, *, expected_configuration_id: str | None = None, minimum_revision: int | None = None
    ) -> ThinClientConfigurationResult:
        """Restore the last configuration explicitly accepted by the Thin Client.

        Optional identity and revision guards prevent restoring a snapshot that is valid
        cryptographically but no longer compatible with the current deployment intent.
        """
        self._require(ContractOperation.STAGE_CONFIG)
        known_good = self._read_configuration(self.known_good_path)
        if expected_configuration_id is not None:
            if not _ID_RE.fullmatch(expected_configuration_id):
                raise ThinClientConfigurationError("invalid_expected_configuration_id")
            if known_good["configuration_id"] != expected_configuration_id:
                raise ThinClientConfigurationError("known_good_configuration_identity_mismatch")
        if minimum_revision is not None:
            if not isinstance(minimum_revision, int) or minimum_revision < 1:
                raise ThinClientConfigurationError("invalid_minimum_configuration_revision")
            if known_good["revision"] < minimum_revision:
                raise ThinClientConfigurationError("known_good_configuration_too_old")

        current_raw = None
        if self.active_path.exists() or self.active_path.is_symlink():
            try:
                current_raw = self._safe_read(self.active_path)
                self._read_configuration(self.active_path)
            except ThinClientConfigurationError:
                current_raw = None
        known_good_raw = self._safe_read(self.known_good_path)
        self._atomic_write(self.active_path, known_good_raw)
        audit = {
            "format": "xaac-configuration-restore/v1",
            "restored_at": _utc_text(datetime.now(timezone.utc)),
            "configuration_id": known_good["configuration_id"],
            "revision": known_good["revision"],
            "sha256": known_good["sha256"],
            "replaced_valid_active": current_raw is not None,
        }
        self._atomic_write(self.restore_audit_path, _canonical_bytes(audit))
        return ThinClientConfigurationResult(
            "restored", "thin_client_known_good_configuration_restored",
            known_good["configuration_id"], known_good["revision"], known_good["sha256"],
            current_raw is not None,
        )

    def _read_configuration(self, path: Path) -> dict[str, Any]:
        payload = self._read_json(path)
        if payload.get("format") != "xaac-configuration/v1":
            raise ThinClientConfigurationError("invalid_configuration_format")
        required = {"configuration_id", "revision", "created_at", "sections", "secrets", "sha256"}
        if not required.issubset(payload):
            raise ThinClientConfigurationError("incomplete_configuration")
        if payload.get("secrets") != {"included": False, "delivery": "out-of-band"}:
            raise ThinClientConfigurationError("configuration_contains_secrets")
        _validate_no_secrets(payload.get("sections"))
        digest_payload = dict(payload)
        digest = str(digest_payload.pop("sha256", ""))
        expected = hashlib.sha256(_canonical_bytes(digest_payload)).hexdigest()
        if digest != expected:
            raise ThinClientConfigurationError("configuration_digest_mismatch")
        return payload

    def _read_json(self, path: Path) -> dict[str, Any]:
        raw = self._safe_read(path)
        try:
            payload = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise ThinClientConfigurationError("invalid_configuration_json") from error
        if not isinstance(payload, dict):
            raise ThinClientConfigurationError("configuration_document_must_be_object")
        return payload

    def _safe_read(self, path: Path) -> bytes:
        if path.is_symlink():
            raise ThinClientConfigurationError("configuration_path_symlink")
        try:
            fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
        except FileNotFoundError as error:
            raise ThinClientConfigurationError("configuration_file_missing") from error
        except OSError as error:
            raise ThinClientConfigurationError("configuration_read_failed") from error
        try:
            mode = os.fstat(fd).st_mode
            if not stat.S_ISREG(mode):
                raise ThinClientConfigurationError("configuration_path_not_regular")
            raw = os.read(fd, self.max_bytes + 1)
            if len(raw) > self.max_bytes:
                raise ThinClientConfigurationError("configuration_too_large")
            return raw
        finally:
            os.close(fd)

    def _atomic_write(self, path: Path, raw: bytes) -> None:
        if path.is_symlink():
            raise ThinClientConfigurationError("configuration_path_symlink")
        fd, name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
        temp = Path(name)
        try:
            os.fchmod(fd, 0o640)
            with os.fdopen(fd, "wb", closefd=True) as stream:
                stream.write(raw); stream.flush(); os.fsync(stream.fileno())
            os.replace(temp, path)
            directory_fd = os.open(path.parent, os.O_RDONLY)
            try: os.fsync(directory_fd)
            finally: os.close(directory_fd)
        except OSError as error:
            raise ThinClientConfigurationError("configuration_write_failed") from error
        finally:
            if temp.exists(): temp.unlink()

    def _ensure_root(self) -> None:
        self.contract.validate_layout(require_existing=True)
        if self.contract.config_root.is_symlink():
            raise ThinClientConfigurationError("configuration_root_symlink")

    def _safe_unlink(self, path: Path) -> None:
        if path.is_symlink():
            raise ThinClientConfigurationError("configuration_path_symlink")
        try: path.unlink()
        except FileNotFoundError: pass

    def _require(self, operation: ContractOperation) -> None:
        if not self.contract.is_operation_allowed(operation):
            raise ThinClientConfigurationError(f"configuration_operation_denied:{operation.value}")

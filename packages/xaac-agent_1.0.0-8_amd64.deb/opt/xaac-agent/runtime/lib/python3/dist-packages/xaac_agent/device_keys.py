from __future__ import annotations

import hashlib
import os
import stat
from dataclasses import dataclass
from pathlib import Path
from tempfile import NamedTemporaryFile

from cryptography.exceptions import InvalidKey
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey


KEY_ALGORITHM = "Ed25519"


class DeviceKeyError(RuntimeError):
    """Base error for device signing key operations."""


class InvalidDeviceKeyError(DeviceKeyError):
    """Raised when an existing private key cannot be trusted or parsed."""


@dataclass(frozen=True, slots=True)
class DeviceKeyPair:
    """Device signing key pair. Private key material is never exported in payloads."""

    _private_key: Ed25519PrivateKey

    @property
    def algorithm(self) -> str:
        return KEY_ALGORITHM

    @property
    def public_key(self) -> Ed25519PublicKey:
        return self._private_key.public_key()

    @property
    def key_id(self) -> str:
        digest = hashlib.sha256(self.public_key_der()).hexdigest()
        return f"sha256:{digest}"

    def public_key_der(self) -> bytes:
        return self.public_key.public_bytes(
            encoding=serialization.Encoding.DER,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )

    def public_key_pem(self) -> bytes:
        return self.public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )

    def private_key_pem(self) -> bytes:
        return self._private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        )

    def public_payload(self) -> dict[str, str]:
        return {
            "algorithm": self.algorithm,
            "key_id": self.key_id,
            "public_key_pem": self.public_key_pem().decode("ascii"),
        }

    def sign(self, data: bytes) -> bytes:
        return self._private_key.sign(data)


class DeviceKeyStore:
    """Atomically load or create the persistent Ed25519 device private key."""

    def __init__(self, path: Path) -> None:
        self._path = path

    def load_or_create(self) -> DeviceKeyPair:
        try:
            return self.load()
        except FileNotFoundError:
            return self._create_exclusively(DeviceKeyPair(Ed25519PrivateKey.generate()))

    def load(self) -> DeviceKeyPair:
        self._validate_path()
        try:
            data = self._path.read_bytes()
        except FileNotFoundError:
            raise
        except OSError as error:
            raise InvalidDeviceKeyError(f"cannot read device key {self._path}: {error}") from error
        try:
            key = serialization.load_pem_private_key(data, password=None)
        except (ValueError, TypeError, InvalidKey) as error:
            raise InvalidDeviceKeyError("device key is not a valid unencrypted PEM private key") from error
        if not isinstance(key, Ed25519PrivateKey):
            raise InvalidDeviceKeyError("device key must use Ed25519")
        self._ensure_private_permissions()
        return DeviceKeyPair(key)

    def _create_exclusively(self, key_pair: DeviceKeyPair) -> DeviceKeyPair:
        self._prepare_parent_directory()
        temporary_name: str | None = None
        try:
            with NamedTemporaryFile(
                "wb", dir=self._path.parent, prefix=".device-key-", suffix=".tmp", delete=False
            ) as handle:
                temporary_name = handle.name
                handle.write(key_pair.private_key_pem())
                handle.flush()
                os.fsync(handle.fileno())
            os.chmod(temporary_name, 0o600)
            try:
                os.link(temporary_name, self._path)
            except FileExistsError:
                return self.load()
            except OSError as error:
                raise InvalidDeviceKeyError(f"cannot create device key {self._path}: {error}") from error
            self._fsync_directory(self._path.parent)
            self._ensure_private_permissions()
            return key_pair
        finally:
            if temporary_name and os.path.exists(temporary_name):
                os.unlink(temporary_name)

    def _validate_path(self) -> None:
        try:
            metadata = self._path.lstat()
        except FileNotFoundError:
            raise
        except OSError as error:
            raise InvalidDeviceKeyError(f"cannot inspect device key {self._path}: {error}") from error
        if stat.S_ISLNK(metadata.st_mode):
            raise InvalidDeviceKeyError("device key must not be a symbolic link")
        if not stat.S_ISREG(metadata.st_mode):
            raise InvalidDeviceKeyError("device key path must be a regular file")

    def _prepare_parent_directory(self) -> None:
        try:
            self._path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            if self._path.parent.is_symlink():
                raise InvalidDeviceKeyError("device key parent directory must not be a symbolic link")
            if not self._path.parent.is_dir():
                raise InvalidDeviceKeyError("device key parent path must be a directory")
            mode = stat.S_IMODE(self._path.parent.stat().st_mode)
            if mode & 0o077:
                os.chmod(self._path.parent, mode & ~0o077)
        except DeviceKeyError:
            raise
        except OSError as error:
            raise InvalidDeviceKeyError(
                f"cannot prepare device key directory {self._path.parent}: {error}"
            ) from error

    def _ensure_private_permissions(self) -> None:
        try:
            if stat.S_IMODE(self._path.stat().st_mode) != 0o600:
                os.chmod(self._path, 0o600)
        except OSError as error:
            raise InvalidDeviceKeyError(
                f"cannot enforce device key permissions on {self._path}: {error}"
            ) from error

    @staticmethod
    def _fsync_directory(path: Path) -> None:
        flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0)
        descriptor = os.open(path, flags)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)

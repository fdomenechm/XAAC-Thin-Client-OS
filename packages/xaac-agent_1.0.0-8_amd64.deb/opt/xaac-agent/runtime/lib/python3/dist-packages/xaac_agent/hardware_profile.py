from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping

_MAX_DMI_BYTES = 4096
_DELL_NAMES = ("dell", "dell inc.")
_WYSE_3040_MARKERS = ("wyse 3040", "wyse3040", "thin client 3040")


@dataclass(frozen=True, slots=True)
class HardwareProfile:
    profile_id: str
    detected: bool
    manufacturer: str | None
    product_name: str | None
    confidence: str
    resource_class: str
    storage_class: str
    recommended_sampling_profile: str

    def to_payload(self) -> dict[str, object]:
        payload: dict[str, object] = {
            "profile_id": self.profile_id,
            "detected": self.detected,
            "confidence": self.confidence,
            "resource_class": self.resource_class,
            "storage_class": self.storage_class,
            "recommended_sampling_profile": self.recommended_sampling_profile,
        }
        if self.manufacturer is not None:
            payload["manufacturer"] = self.manufacturer
        if self.product_name is not None:
            payload["product_name"] = self.product_name
        return payload


class HardwareProfileDetector:
    """Detect a supported hardware profile using bounded, non-secret DMI facts."""

    def __init__(self, dmi_directory: Path = Path("/sys/class/dmi/id")) -> None:
        self._dmi_directory = dmi_directory

    def detect(self) -> HardwareProfile:
        manufacturer = self._read("sys_vendor")
        product_name = self._read("product_name")
        board_name = self._read("board_name")
        combined = " ".join(value.casefold() for value in (product_name, board_name) if value)
        is_dell = bool(manufacturer and manufacturer.casefold() in _DELL_NAMES)
        is_wyse_3040 = any(marker in combined for marker in _WYSE_3040_MARKERS)

        if is_dell and is_wyse_3040:
            confidence = "high" if product_name and "wyse 3040" in product_name.casefold() else "medium"
            return HardwareProfile(
                profile_id="dell-wyse-3040",
                detected=True,
                manufacturer=manufacturer,
                product_name=product_name,
                confidence=confidence,
                resource_class="constrained",
                storage_class="emmc",
                recommended_sampling_profile="wyse-3040-balanced",
            )
        return HardwareProfile(
            profile_id="generic",
            detected=False,
            manufacturer=manufacturer,
            product_name=product_name,
            confidence="none",
            resource_class="unknown",
            storage_class="unknown",
            recommended_sampling_profile="default",
        )

    def _read(self, name: str) -> str | None:
        path = self._dmi_directory / name
        try:
            if path.is_symlink() or not path.is_file():
                return None
            with path.open("rb") as handle:
                raw = handle.read(_MAX_DMI_BYTES + 1)
        except (FileNotFoundError, PermissionError, OSError):
            return None
        if len(raw) > _MAX_DMI_BYTES:
            return None
        value = raw.decode("utf-8", errors="replace").replace("\x00", " ")
        value = re.sub(r"\s+", " ", value).strip()
        return value or None

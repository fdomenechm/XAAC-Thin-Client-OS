from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Callable


class BootSecurityError(RuntimeError):
    """Raised when the configured boot trust requirements are not satisfied."""


@dataclass(frozen=True, slots=True)
class BootSecurityPolicy:
    enabled: bool = True
    require_uefi: bool = False
    require_secure_boot: bool = False
    efi_variables_path: Path = Path("/sys/firmware/efi/efivars")
    kernel_lockdown_path: Path = Path("/sys/kernel/security/lockdown")

    def validate(self) -> None:
        if self.require_secure_boot and not self.enabled:
            raise BootSecurityError("Secure Boot cannot be required when boot security monitoring is disabled")
        if self.require_secure_boot and not self.require_uefi:
            raise BootSecurityError("Secure Boot requirement also requires UEFI")
        if not self.efi_variables_path.is_absolute() or not self.kernel_lockdown_path.is_absolute():
            raise BootSecurityError("boot security paths must be absolute")


class BootSecurityMonitor:
    """Read bounded, non-secret boot trust state from Linux sysfs/securityfs."""

    _SECURE_BOOT_PREFIX = "SecureBoot-"
    _SETUP_MODE_PREFIX = "SetupMode-"

    def __init__(
        self,
        policy: BootSecurityPolicy,
        *,
        read_bytes: Callable[[Path], bytes] | None = None,
        read_text: Callable[[Path], str] | None = None,
    ) -> None:
        policy.validate()
        self._policy = policy
        self._read_bytes = read_bytes or Path.read_bytes
        self._read_text = read_text or (lambda path: path.read_text(encoding="utf-8", errors="replace"))

    def sample(self) -> dict[str, object]:
        if not self._policy.enabled:
            return {"enabled": False, "firmware": "unknown", "secure_boot": "unknown", "severity": "normal"}

        uefi = self._policy.efi_variables_path.is_dir()
        firmware = "uefi" if uefi else "bios"
        secure_boot = "unavailable"
        setup_mode: bool | None = None
        reason: str | None = None

        if uefi:
            secure_value = self._read_efi_boolean(self._SECURE_BOOT_PREFIX)
            setup_mode = self._read_efi_boolean(self._SETUP_MODE_PREFIX)
            if secure_value is None:
                secure_boot = "unknown"
                reason = "secure_boot_variable_unavailable"
            elif secure_value and setup_mode is not True:
                secure_boot = "enabled"
            else:
                secure_boot = "disabled"

        lockdown = self._read_lockdown_state()
        severity = "normal"
        compliant = True
        if self._policy.require_uefi and not uefi:
            compliant = False
            severity = "critical"
            reason = "uefi_required"
        elif self._policy.require_secure_boot and secure_boot != "enabled":
            compliant = False
            severity = "critical"
            reason = "secure_boot_required"
        elif uefi and secure_boot in {"disabled", "unknown"}:
            severity = "warning"

        result: dict[str, object] = {
            "enabled": True,
            "firmware": firmware,
            "uefi": uefi,
            "secure_boot": secure_boot,
            "kernel_lockdown": lockdown,
            "required_uefi": self._policy.require_uefi,
            "required_secure_boot": self._policy.require_secure_boot,
            "compliant": compliant,
            "severity": severity,
        }
        if setup_mode is not None:
            result["setup_mode"] = setup_mode
        if reason:
            result["reason"] = reason
        if not compliant:
            raise BootSecurityError(reason or "boot security policy is not satisfied")
        return result

    def _read_efi_boolean(self, prefix: str) -> bool | None:
        try:
            matches = sorted(self._policy.efi_variables_path.glob(f"{prefix}*"))
        except OSError:
            return None
        if len(matches) != 1 or not matches[0].is_file():
            return None
        try:
            data = self._read_bytes(matches[0])
        except OSError:
            return None
        # efivarfs prepends the four-byte EFI attributes field.
        if len(data) < 5 or data[4] not in (0, 1):
            return None
        return data[4] == 1

    def _read_lockdown_state(self) -> str:
        path = self._policy.kernel_lockdown_path
        if not path.is_file():
            return "unavailable"
        try:
            value = self._read_text(path).strip()
        except OSError:
            return "unknown"
        for token in value.split():
            if token.startswith("[") and token.endswith("]"):
                state = token[1:-1].strip().lower()
                if state in {"none", "integrity", "confidentiality"}:
                    return state
        return "unknown"

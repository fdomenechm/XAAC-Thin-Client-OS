from __future__ import annotations

import datetime as dt
import re
import uuid
from dataclasses import dataclass
from pathlib import Path


_PLACEHOLDERS = {
    "", "unknown", "n/a", "na", "none", "default string",
    "to be filled by o.e.m.", "to be filled by oem", "not specified",
}


@dataclass(frozen=True, slots=True)
class FirmwareInventory:
    bios_vendor: str | None = None
    bios_version: str | None = None
    bios_date: str | None = None
    boot_mode: str = "legacy"
    uefi: bool = False
    secure_boot: bool | None = None
    secure_boot_setup_mode: bool | None = None
    smbios_uuid: str | None = None

    def to_payload(self) -> dict[str, object]:
        result: dict[str, object] = {
            "boot_mode": self.boot_mode,
            "uefi": self.uefi,
        }
        optional = {
            "bios_vendor": self.bios_vendor,
            "bios_version": self.bios_version,
            "bios_date": self.bios_date,
            "secure_boot": self.secure_boot,
            "secure_boot_setup_mode": self.secure_boot_setup_mode,
            "smbios_uuid": self.smbios_uuid,
        }
        result.update({key: value for key, value in optional.items() if value is not None})
        return result


class FirmwareInventoryCollector:
    """Collect BIOS/UEFI facts from Linux sysfs without external commands."""

    def __init__(
        self,
        dmi_directory: Path = Path("/sys/class/dmi/id"),
        efi_directory: Path = Path("/sys/firmware/efi"),
        efivars_directory: Path = Path("/sys/firmware/efi/efivars"),
    ) -> None:
        self._dmi_directory = dmi_directory
        self._efi_directory = efi_directory
        self._efivars_directory = efivars_directory

    def collect(self) -> FirmwareInventory:
        uefi = self._is_safe_directory(self._efi_directory)
        secure_boot = self._read_efi_boolean("SecureBoot") if uefi else None
        setup_mode = self._read_efi_boolean("SetupMode") if uefi else None
        return FirmwareInventory(
            bios_vendor=self._read_dmi_text("bios_vendor"),
            bios_version=self._read_dmi_text("bios_version"),
            bios_date=_normalise_bios_date(self._read_dmi_text("bios_date")),
            boot_mode="uefi" if uefi else "legacy",
            uefi=uefi,
            secure_boot=secure_boot,
            secure_boot_setup_mode=setup_mode,
            smbios_uuid=_normalise_uuid(self._read_dmi_text("product_uuid")),
        )

    def _read_dmi_text(self, filename: str) -> str | None:
        path = self._dmi_directory / filename
        try:
            if path.is_symlink() or not path.is_file():
                return None
            return _normalise_text(path.read_text(encoding="utf-8", errors="replace"))
        except (FileNotFoundError, PermissionError, IsADirectoryError, OSError):
            return None

    def _read_efi_boolean(self, prefix: str) -> bool | None:
        try:
            if not self._is_safe_directory(self._efivars_directory):
                return None
            candidates = sorted(self._efivars_directory.glob(f"{prefix}-*"))
        except OSError:
            return None
        for path in candidates:
            try:
                if path.is_symlink() or not path.is_file():
                    continue
                data = path.read_bytes()
            except (FileNotFoundError, PermissionError, IsADirectoryError, OSError):
                continue
            # efivarfs prepends a four-byte attributes field to the variable data.
            if len(data) >= 5 and data[4] in (0, 1):
                return bool(data[4])
        return None

    @staticmethod
    def _is_safe_directory(path: Path) -> bool:
        try:
            return not path.is_symlink() and path.is_dir()
        except OSError:
            return False


def _normalise_text(value: str | None) -> str | None:
    if value is None:
        return None
    cleaned = re.sub(r"\s+", " ", value.replace("\x00", " ")).strip()
    if cleaned.casefold() in _PLACEHOLDERS:
        return None
    return cleaned or None


def _normalise_uuid(value: str | None) -> str | None:
    value = _normalise_text(value)
    if value is None:
        return None
    try:
        parsed = uuid.UUID(value)
    except (ValueError, AttributeError):
        return None
    if parsed.int in (0, (1 << 128) - 1):
        return None
    return str(parsed)


def _normalise_bios_date(value: str | None) -> str | None:
    value = _normalise_text(value)
    if value is None:
        return None
    for fmt in ("%m/%d/%Y", "%m/%d/%y", "%Y-%m-%d", "%Y/%m/%d"):
        try:
            parsed = dt.datetime.strptime(value, fmt).date()
            return parsed.isoformat()
        except ValueError:
            pass
    return value

from __future__ import annotations

import hashlib
import json
import os
import stat
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping

from .update_model import UpdatePlan, UpdateResult, UpdateState


class UpdateReportError(ValueError):
    def __init__(self, code: str) -> None:
        super().__init__(code)
        self.code = code


_SENSITIVE = {"password", "token", "secret", "private_key", "authorization", "credentials", "client_secret", "access_token"}
_ALLOWED_DATA = {
    "artifact_sha256", "canonical_sha256", "key_id", "algorithm", "size", "package", "package_version",
    "architecture", "reboot_required", "reboot_scheduled_at", "next_window_at", "return_code",
    "restored_paths", "service_restarted", "previous_version", "installed_version", "rollback_update_id",
    "from_version", "to_version", "path", "filename", "media_type", "packages", "warnings",
}


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _safe_value(value: Any, *, depth: int = 0) -> Any:
    if depth > 4:
        return None
    if value is None or isinstance(value, (bool, int, float)):
        return value
    if isinstance(value, str):
        return value[:1024]
    if isinstance(value, list):
        return [_safe_value(item, depth=depth + 1) for item in value[:64]]
    if isinstance(value, Mapping):
        result: dict[str, Any] = {}
        for key, item in list(value.items())[:64]:
            normalized = str(key).lower()
            if normalized in _SENSITIVE or any(part in normalized for part in _SENSITIVE):
                continue
            result[str(key)[:128]] = _safe_value(item, depth=depth + 1)
        return result
    return str(value)[:1024]


def _safe_result_data(data: Mapping[str, Any]) -> dict[str, Any]:
    return {key: _safe_value(value) for key, value in data.items() if key in _ALLOWED_DATA}


@dataclass(frozen=True, slots=True)
class UpdateReport:
    report_id: str
    update_id: str
    component: str
    target_version: str
    final_state: str
    final_code: str
    generated_at: str
    timeline: tuple[dict[str, Any], ...]
    summary: dict[str, Any]

    def to_payload(self) -> dict[str, Any]:
        return {
            "format": "xaac-update-report/v1",
            "report_id": self.report_id,
            "update_id": self.update_id,
            "component": self.component,
            "target_version": self.target_version,
            "final_state": self.final_state,
            "final_code": self.final_code,
            "generated_at": self.generated_at,
            "timeline": [dict(item) for item in self.timeline],
            "summary": dict(self.summary),
        }


class UpdateReportStore:
    def __init__(self, report_file: Path, *, max_records: int = 128, max_bytes: int = 1_048_576) -> None:
        if max_records < 1 or max_records > 4096:
            raise UpdateReportError("update_report_max_records_invalid")
        if max_bytes < 4096 or max_bytes > 16 * 1024 * 1024:
            raise UpdateReportError("update_report_max_bytes_invalid")
        self.report_file = Path(report_file)
        self.max_records = max_records
        self.max_bytes = max_bytes

    def build(self, plan: UpdatePlan, results: Iterable[UpdateResult], *, reboot: Mapping[str, Any] | None = None, rollback: Mapping[str, Any] | None = None) -> UpdateReport:
        collected = list(results)
        if not collected:
            raise UpdateReportError("update_report_results_missing")
        timeline: list[dict[str, Any]] = []
        for index, result in enumerate(collected, start=1):
            if (result.update_id, result.component.value, result.target_version) != plan.identity:
                raise UpdateReportError("update_report_identity_mismatch")
            item: dict[str, Any] = {
                "sequence": index,
                "state": result.state.value,
                "code": result.code or "update_state_changed",
                "terminal": result.terminal,
            }
            safe_data = _safe_result_data(result.data)
            if safe_data:
                item["data"] = safe_data
            timeline.append(item)
        final = collected[-1]
        if not final.terminal and final.state not in {UpdateState.INSTALLED, UpdateState.REBOOT_PENDING, UpdateState.SCHEDULED}:
            raise UpdateReportError("update_report_final_state_invalid")
        generated = _utc_now()
        digest_source = f"{plan.update_id}:{plan.component.value}:{plan.target_version}:{generated}".encode()
        report_id = hashlib.sha256(digest_source).hexdigest()[:32]
        summary: dict[str, Any] = {
            "issuer": plan.issuer.to_payload(),
            "current_version": plan.current_version,
            "reboot_required": plan.reboot_required,
            "rollback_supported": plan.rollback_supported,
            "artifact_sha256": plan.artifact.sha256,
            "steps": len(timeline),
        }
        if reboot is not None:
            summary["reboot"] = _safe_value(reboot)
        if rollback is not None:
            summary["rollback"] = _safe_value(rollback)
        return UpdateReport(report_id, plan.update_id, plan.component.value, plan.target_version, final.state.value, final.code or "update_result_recorded", generated, tuple(timeline), summary)

    def append(self, report: UpdateReport) -> dict[str, Any]:
        records = self._load_records()
        payload = report.to_payload()
        previous_hash = records[-1]["record_hash"] if records else "0" * 64
        record = {"sequence": (records[-1]["sequence"] + 1) if records else 1, "previous_hash": previous_hash, "report": payload}
        record["record_hash"] = self._hash_record(record)
        records.append(record)
        records = records[-self.max_records :]
        if records and records[0]["sequence"] != 1:
            previous = "0" * 64
            rebuilt = []
            for sequence, old in enumerate(records, start=1):
                new = {"sequence": sequence, "previous_hash": previous, "report": old["report"]}
                new["record_hash"] = self._hash_record(new)
                previous = new["record_hash"]
                rebuilt.append(new)
            records = rebuilt
        document = {"format": "xaac-update-report-store/v1", "records": records}
        self._write(document)
        return payload

    def verify(self) -> bool:
        records = self._load_records()
        previous = "0" * 64
        for expected, record in enumerate(records, start=1):
            if record.get("sequence") != expected or record.get("previous_hash") != previous:
                return False
            if record.get("record_hash") != self._hash_record(record):
                return False
            previous = record["record_hash"]
        return True

    def list_reports(self, *, update_id: str | None = None) -> list[dict[str, Any]]:
        reports = [dict(record["report"]) for record in self._load_records()]
        return [item for item in reports if update_id is None or item.get("update_id") == update_id]

    @staticmethod
    def _hash_record(record: Mapping[str, Any]) -> str:
        body = {key: value for key, value in record.items() if key != "record_hash"}
        encoded = json.dumps(body, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        return hashlib.sha256(encoded).hexdigest()

    def _load_records(self) -> list[dict[str, Any]]:
        if not self.report_file.exists() and not self.report_file.is_symlink():
            return []
        info = self.report_file.lstat()
        if stat.S_ISLNK(info.st_mode) or not stat.S_ISREG(info.st_mode):
            raise UpdateReportError("update_report_file_unsafe")
        if info.st_size > self.max_bytes:
            raise UpdateReportError("update_report_file_too_large")
        try:
            payload = json.loads(self.report_file.read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
            raise UpdateReportError("update_report_file_invalid") from error
        if not isinstance(payload, dict) or payload.get("format") != "xaac-update-report-store/v1" or not isinstance(payload.get("records"), list):
            raise UpdateReportError("update_report_file_invalid")
        return list(payload["records"])

    def _write(self, payload: Mapping[str, Any]) -> None:
        encoded = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        if len(encoded) > self.max_bytes:
            raise UpdateReportError("update_report_store_too_large")
        parent = self.report_file.parent
        parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        info = parent.lstat()
        if stat.S_ISLNK(info.st_mode) or not stat.S_ISDIR(info.st_mode):
            raise UpdateReportError("update_report_directory_unsafe")
        if self.report_file.exists() or self.report_file.is_symlink():
            current = self.report_file.lstat()
            if stat.S_ISLNK(current.st_mode) or not stat.S_ISREG(current.st_mode):
                raise UpdateReportError("update_report_file_unsafe")
        descriptor, temporary = tempfile.mkstemp(prefix=f".{self.report_file.name}.", dir=parent)
        try:
            os.fchmod(descriptor, 0o600)
            with os.fdopen(descriptor, "wb") as stream:
                stream.write(encoded); stream.flush(); os.fsync(stream.fileno())
            os.replace(temporary, self.report_file)
            directory_fd = os.open(parent, os.O_RDONLY | os.O_DIRECTORY)
            try: os.fsync(directory_fd)
            finally: os.close(directory_fd)
        finally:
            if os.path.exists(temporary): os.unlink(temporary)

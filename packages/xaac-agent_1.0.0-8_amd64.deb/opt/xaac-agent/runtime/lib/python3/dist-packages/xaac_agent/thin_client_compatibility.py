from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Iterable, Mapping


class ThinClientCompatibilityError(ValueError):
    """Versions o capacitats Agent/Thin Client incompatibles."""


_VERSION_RE = re.compile(r"^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([0-9A-Za-z.-]+))?$")
_CAPABILITY_RE = re.compile(r"^[a-z][a-z0-9.-]{0,63}$")


@dataclass(frozen=True, order=True, slots=True)
class SemanticVersion:
    major: int
    minor: int
    patch: int
    prerelease: str | None = None

    @classmethod
    def parse(cls, value: str) -> "SemanticVersion":
        if not isinstance(value, str):
            raise ThinClientCompatibilityError("invalid_version")
        match = _VERSION_RE.fullmatch(value.strip())
        if match is None:
            raise ThinClientCompatibilityError("invalid_version")
        return cls(int(match.group(1)), int(match.group(2)), int(match.group(3)), match.group(4))

    def compatible_order_key(self) -> tuple[int, int, int, int, str]:
        return (self.major, self.minor, self.patch, 1 if self.prerelease is None else 0, self.prerelease or "")


@dataclass(frozen=True, slots=True)
class CompatibilityRule:
    min_agent: SemanticVersion
    max_agent: SemanticVersion
    min_thin_client: SemanticVersion
    max_thin_client: SemanticVersion
    contract_versions: tuple[str, ...] = ("xaac-local-integration/v1",)

    def __post_init__(self) -> None:
        if self.min_agent.compatible_order_key() > self.max_agent.compatible_order_key():
            raise ThinClientCompatibilityError("invalid_agent_version_range")
        if self.min_thin_client.compatible_order_key() > self.max_thin_client.compatible_order_key():
            raise ThinClientCompatibilityError("invalid_thin_client_version_range")
        if not self.contract_versions or any(not item.strip() for item in self.contract_versions):
            raise ThinClientCompatibilityError("invalid_contract_versions")


@dataclass(frozen=True, slots=True)
class CompatibilityResult:
    compatible: bool
    code: str
    agent_version: str
    thin_client_version: str
    contract_version: str
    negotiated_capabilities: tuple[str, ...]
    missing_capabilities: tuple[str, ...] = ()
    migration_id: str | None = None

    def to_payload(self) -> dict[str, object]:
        return {
            "format": "xaac-thin-client-compatibility-result/v1",
            "compatible": self.compatible,
            "code": self.code,
            "agent_version": self.agent_version,
            "thin_client_version": self.thin_client_version,
            "contract_version": self.contract_version,
            "negotiated_capabilities": list(self.negotiated_capabilities),
            "missing_capabilities": list(self.missing_capabilities),
            "migration_id": self.migration_id,
        }


class ThinClientCompatibilityManager:
    def __init__(
        self,
        *,
        agent_version: str,
        rule: CompatibilityRule,
        local_capabilities: Iterable[str] = (),
        migrations: Mapping[tuple[int, int], str] | None = None,
    ) -> None:
        self.agent_version_text = agent_version
        self.agent_version = SemanticVersion.parse(agent_version)
        self.rule = rule
        self.local_capabilities = self._normalize_capabilities(local_capabilities)
        self.migrations = dict(migrations or {})

    @staticmethod
    def _normalize_capabilities(values: Iterable[str]) -> tuple[str, ...]:
        normalized: set[str] = set()
        for raw in values:
            if not isinstance(raw, str) or not _CAPABILITY_RE.fullmatch(raw.strip()):
                raise ThinClientCompatibilityError("invalid_capability")
            normalized.add(raw.strip())
        return tuple(sorted(normalized))

    def evaluate(
        self,
        *,
        thin_client_version: str,
        contract_version: str,
        thin_client_capabilities: Iterable[str] = (),
        required_capabilities: Iterable[str] = (),
    ) -> CompatibilityResult:
        tc_version = SemanticVersion.parse(thin_client_version)
        tc_caps = self._normalize_capabilities(thin_client_capabilities)
        required = self._normalize_capabilities(required_capabilities)
        common = tuple(sorted(set(self.local_capabilities).intersection(tc_caps)))

        if not self._in_range(self.agent_version, self.rule.min_agent, self.rule.max_agent):
            return self._result(False, "agent_version_not_supported", thin_client_version, contract_version, common)
        if not self._in_range(tc_version, self.rule.min_thin_client, self.rule.max_thin_client):
            return self._result(False, "thin_client_version_not_supported", thin_client_version, contract_version, common)
        if contract_version not in self.rule.contract_versions:
            return self._result(False, "contract_version_not_supported", thin_client_version, contract_version, common)
        missing = tuple(sorted(set(required) - set(common)))
        if missing:
            return CompatibilityResult(False, "required_capabilities_missing", self.agent_version_text, thin_client_version, contract_version, common, missing)

        migration_id = None
        if (tc_version.major, tc_version.minor) != (self.agent_version.major, self.agent_version.minor):
            migration_id = self.migrations.get((tc_version.major, tc_version.minor))
            if migration_id is None:
                return self._result(False, "controlled_migration_required", thin_client_version, contract_version, common)
        return CompatibilityResult(True, "thin_client_compatible", self.agent_version_text, thin_client_version, contract_version, common, (), migration_id)

    def require_compatible(self, **kwargs: object) -> CompatibilityResult:
        result = self.evaluate(**kwargs)
        if not result.compatible:
            raise ThinClientCompatibilityError(result.code)
        return result

    def _result(self, compatible: bool, code: str, thin_client_version: str, contract_version: str, common: tuple[str, ...]) -> CompatibilityResult:
        return CompatibilityResult(compatible, code, self.agent_version_text, thin_client_version, contract_version, common)

    @staticmethod
    def _in_range(value: SemanticVersion, minimum: SemanticVersion, maximum: SemanticVersion) -> bool:
        key = value.compatible_order_key()
        return minimum.compatible_order_key() <= key <= maximum.compatible_order_key()

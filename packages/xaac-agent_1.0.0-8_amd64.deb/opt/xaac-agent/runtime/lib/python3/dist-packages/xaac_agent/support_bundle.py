from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import stat
import time
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable, Mapping, Sequence

from .data_redaction import DataRedactor, RedactionPolicy, ensure_no_high_risk_secrets


_NAME_RE = re.compile(r"^[a-z][a-z0-9_-]{0,63}$")
_ALLOWED_FORMATS = {
    "xaac-network-diagnostic/v1",
    "xaac-service-diagnostic/v1",
    "xaac-system-diagnostic/v1",
    "xaac-thin-client-rdp-diagnostic/v1",
}
_FIXED_ZIP_TIME = (1980, 1, 1, 0, 0, 0)


class SupportBundleError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class SupportBundlePolicy:
    max_inputs: int = 16
    max_input_bytes: int = 2 * 1024 * 1024
    max_total_bytes: int = 8 * 1024 * 1024

    def validate(self) -> None:
        if not 1 <= self.max_inputs <= 64:
            raise SupportBundleError("support_bundle_max_inputs_out_of_range")
        if not 1024 <= self.max_input_bytes <= 16 * 1024 * 1024:
            raise SupportBundleError("support_bundle_max_input_bytes_out_of_range")
        if self.max_input_bytes > self.max_total_bytes or self.max_total_bytes > 64 * 1024 * 1024:
            raise SupportBundleError("support_bundle_total_size_invalid")


def _canonical_json(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _read_regular_file(path: Path, limit: int) -> bytes:
    try:
        st = path.lstat()
    except OSError as error:
        raise SupportBundleError("support_bundle_input_unavailable") from error
    if stat.S_ISLNK(st.st_mode) or not stat.S_ISREG(st.st_mode):
        raise SupportBundleError("support_bundle_input_not_regular")
    if st.st_size > limit:
        raise SupportBundleError("support_bundle_input_too_large")
    flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NOFOLLOW", 0)
    try:
        fd = os.open(path, flags)
        try:
            data = os.read(fd, limit + 1)
        finally:
            os.close(fd)
    except OSError as error:
        raise SupportBundleError("support_bundle_input_unavailable") from error
    if len(data) > limit:
        raise SupportBundleError("support_bundle_input_too_large")
    return data


def _zip_info(name: str) -> zipfile.ZipInfo:
    info = zipfile.ZipInfo(name, _FIXED_ZIP_TIME)
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = 0o100600 << 16
    info.create_system = 3
    return info


class SupportBundleBuilder:
    def __init__(
        self,
        *,
        policy: SupportBundlePolicy | None = None,
        clock: Callable[[], float] = time.time,
    ) -> None:
        self.policy = policy or SupportBundlePolicy()
        self.policy.validate()
        self.clock = clock

    def build(
        self,
        *,
        output: Path,
        inputs: Mapping[str, Path],
        redaction_policy: RedactionPolicy | None = None,
    ) -> dict[str, object]:
        if not output.is_absolute():
            raise SupportBundleError("support_bundle_output_must_be_absolute")
        if output.exists() and output.is_symlink():
            raise SupportBundleError("support_bundle_output_symlink")
        if not 1 <= len(inputs) <= self.policy.max_inputs:
            raise SupportBundleError("support_bundle_input_count_invalid")

        files: dict[str, bytes] = {}
        total = 0
        formats: list[str] = []
        redaction_totals = {"total": 0, "secret_values": 0, "emails": 0, "mac_addresses": 0, "public_ip_addresses": 0, "url_credentials": 0}
        for name, path in sorted(inputs.items()):
            if not _NAME_RE.fullmatch(name):
                raise SupportBundleError("support_bundle_invalid_input_name")
            raw = _read_regular_file(path, self.policy.max_input_bytes)
            total += len(raw)
            if total > self.policy.max_total_bytes:
                raise SupportBundleError("support_bundle_total_too_large")
            try:
                payload = json.loads(raw.decode("utf-8", errors="strict"))
            except (UnicodeError, json.JSONDecodeError) as error:
                raise SupportBundleError("support_bundle_invalid_json") from error
            if not isinstance(payload, dict) or payload.get("format") not in _ALLOWED_FORMATS:
                raise SupportBundleError("support_bundle_unapproved_format")
            redactor = DataRedactor(policy=redaction_policy or RedactionPolicy())
            payload = redactor.redact(payload)
            ensure_no_high_risk_secrets(payload)
            for field, value in redactor.report.as_dict().items():
                redaction_totals[field] += value
            canonical = _canonical_json(payload)
            files[f"diagnostics/{name}.json"] = canonical
            formats.append(str(payload["format"]))

        metadata = {
            "format": "xaac-support-bundle/v1",
            "generated_at_unix": int(self.clock()),
            "diagnostic_count": len(files),
            "diagnostic_formats": sorted(formats),
            "redaction": {"policy": "xaac-support-redaction/v1", **redaction_totals},
            "privacy": {
                "journal_included": False,
                "process_arguments_included": False,
                "environment_included": False,
                "user_files_included": False,
            },
        }
        files["metadata.json"] = _canonical_json(metadata)
        manifest_entries = [
            {"path": name, "size": len(data), "sha256": hashlib.sha256(data).hexdigest()}
            for name, data in sorted(files.items())
        ]
        manifest = {
            "format": "xaac-support-bundle-manifest/v1",
            "hash_algorithm": "sha256",
            "files": manifest_entries,
        }
        manifest_bytes = _canonical_json(manifest)
        bundle_id = hashlib.sha256(manifest_bytes).hexdigest()
        manifest["bundle_id"] = bundle_id
        manifest_bytes = _canonical_json(manifest)

        output.parent.mkdir(parents=True, exist_ok=True)
        temporary = output.with_name(f".{output.name}.tmp-{os.getpid()}")
        try:
            with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
                for name, data in sorted(files.items()):
                    archive.writestr(_zip_info(name), data)
                archive.writestr(_zip_info("manifest.json"), manifest_bytes)
            os.chmod(temporary, 0o600)
            os.replace(temporary, output)
            directory_fd = os.open(output.parent, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
        finally:
            try:
                temporary.unlink()
            except FileNotFoundError:
                pass
        return {"format": "xaac-support-bundle-result/v1", "bundle_id": bundle_id, "path": str(output), "files": len(files)}


def verify_support_bundle(path: Path, *, max_archive_bytes: int = 16 * 1024 * 1024) -> dict[str, object]:
    raw = _read_regular_file(path, max_archive_bytes)
    try:
        with zipfile.ZipFile(path, "r") as archive:
            names = archive.namelist()
            if len(names) != len(set(names)) or "manifest.json" not in names:
                raise SupportBundleError("support_bundle_archive_invalid")
            if any(name.startswith("/") or ".." in Path(name).parts for name in names):
                raise SupportBundleError("support_bundle_archive_path_invalid")
            manifest = json.loads(archive.read("manifest.json").decode("utf-8"))
            if manifest.get("format") != "xaac-support-bundle-manifest/v1":
                raise SupportBundleError("support_bundle_manifest_invalid")
            entries = manifest.get("files")
            if not isinstance(entries, list):
                raise SupportBundleError("support_bundle_manifest_invalid")
            checked = 0
            for entry in entries:
                if not isinstance(entry, dict):
                    raise SupportBundleError("support_bundle_manifest_invalid")
                name, size, expected = entry.get("path"), entry.get("size"), entry.get("sha256")
                if not isinstance(name, str) or name not in names or name == "manifest.json":
                    raise SupportBundleError("support_bundle_manifest_invalid")
                data = archive.read(name)
                if len(data) != size or hashlib.sha256(data).hexdigest() != expected:
                    raise SupportBundleError("support_bundle_hash_mismatch")
                checked += 1
            if set(names) != {str(item["path"]) for item in entries} | {"manifest.json"}:
                raise SupportBundleError("support_bundle_unmanifested_file")
            base = dict(manifest)
            bundle_id = base.pop("bundle_id", None)
            expected_id = hashlib.sha256(_canonical_json(base)).hexdigest()
            if bundle_id != expected_id:
                raise SupportBundleError("support_bundle_id_mismatch")
            return {"format": "xaac-support-bundle-verification/v1", "valid": True, "bundle_id": bundle_id, "checked_files": checked, "archive_bytes": len(raw)}
    except (OSError, zipfile.BadZipFile, KeyError, UnicodeError, json.JSONDecodeError) as error:
        raise SupportBundleError("support_bundle_archive_invalid") from error


def _parse_inputs(values: Sequence[str]) -> dict[str, Path]:
    result: dict[str, Path] = {}
    for value in values:
        name, separator, raw_path = value.partition("=")
        if not separator or name in result:
            raise SupportBundleError("support_bundle_invalid_input_argument")
        path = Path(raw_path)
        if not path.is_absolute():
            raise SupportBundleError("support_bundle_input_must_be_absolute")
        result[name] = path
    return result


def main(argv: Iterable[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Create or verify a bounded XAAC support bundle")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--input", action="append", default=[], metavar="NAME=/absolute/file.json")
    parser.add_argument("--verify", type=Path)
    parser.add_argument("--redact-private-ip", action="store_true")
    args = parser.parse_args(list(argv) if argv is not None else None)
    try:
        if args.verify:
            if args.output or args.input:
                raise SupportBundleError("support_bundle_cli_mode_conflict")
            result = verify_support_bundle(args.verify)
        else:
            if args.output is None:
                raise SupportBundleError("support_bundle_output_required")
            result = SupportBundleBuilder().build(
                output=args.output,
                inputs=_parse_inputs(args.input),
                redaction_policy=RedactionPolicy(preserve_private_ip=not args.redact_private_ip),
            )
    except SupportBundleError as error:
        print(json.dumps({"format": "xaac-support-bundle-error/v1", "status": "error", "code": str(error)}, sort_keys=True))
        return 2
    print(json.dumps(result, sort_keys=True, separators=(",", ":")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

from __future__ import annotations

import re
import subprocess
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from typing import Protocol, Sequence

from xaac_agent.thin_client_contract import ContractOperation, ThinClientIntegrationContract


class ThinClientSystemdError(ValueError):
    """Configuració o operació systemd local no vàlida."""


class ThinClientServiceAction(str, Enum):
    START = "start"
    STOP = "stop"
    RESTART = "restart"
    STATUS = "status"


class ThinClientServiceResultState(str, Enum):
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    DENIED = "denied"


_UNIT_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.@:-]{0,127}\.service$")


class ThinClientSystemdBackend(Protocol):
    def run(self, argv: Sequence[str], *, timeout_seconds: int) -> subprocess.CompletedProcess[str]: ...


class SubprocessThinClientSystemdBackend:
    """Executa systemctl directament, sense shell, stdin ni arguments remots."""

    def run(self, argv: Sequence[str], *, timeout_seconds: int) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            list(argv),
            check=False,
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
            stdin=subprocess.DEVNULL,
        )


@dataclass(frozen=True, slots=True)
class ThinClientServiceResult:
    action: ThinClientServiceAction
    state: ThinClientServiceResultState
    code: str
    started_at: str
    finished_at: str
    unit: str
    message: str | None = None
    data: dict[str, object] | None = None

    @property
    def succeeded(self) -> bool:
        return self.state is ThinClientServiceResultState.SUCCEEDED

    def to_payload(self) -> dict[str, object]:
        return {
            "format": "xaac-thin-client-service-result/v1",
            "action": self.action.value,
            "state": self.state.value,
            "code": self.code,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "unit": self.unit,
            "message": self.message,
            "data": dict(self.data or {}),
        }


@dataclass(frozen=True, slots=True)
class ThinClientSystemdController:
    contract: ThinClientIntegrationContract
    backend: ThinClientSystemdBackend
    unit: str = "xaac-thin-client.service"
    allowed_actions: tuple[ThinClientServiceAction, ...] = (ThinClientServiceAction.STATUS,)
    timeout_seconds: int = 30
    systemctl_path: str = "/usr/bin/systemctl"

    def __post_init__(self) -> None:
        if not _UNIT_RE.fullmatch(self.unit):
            raise ThinClientSystemdError("invalid_thin_client_systemd_unit")
        if not 1 <= self.timeout_seconds <= 300:
            raise ThinClientSystemdError("invalid_thin_client_systemd_timeout")
        if not self.systemctl_path.startswith("/"):
            raise ThinClientSystemdError("systemctl_path_must_be_absolute")
        if len(set(self.allowed_actions)) != len(self.allowed_actions):
            raise ThinClientSystemdError("duplicate_thin_client_systemd_action")

    @classmethod
    def system_default(
        cls,
        *,
        contract: ThinClientIntegrationContract,
        unit: str = "xaac-thin-client.service",
        allowed_actions: Sequence[str | ThinClientServiceAction] = (ThinClientServiceAction.STATUS,),
        timeout_seconds: int = 30,
    ) -> "ThinClientSystemdController":
        return cls(
            contract=contract,
            backend=SubprocessThinClientSystemdBackend(),
            unit=unit,
            allowed_actions=parse_thin_client_service_actions(allowed_actions),
            timeout_seconds=timeout_seconds,
        )

    def execute(self, action: str | ThinClientServiceAction) -> ThinClientServiceResult:
        try:
            parsed = action if isinstance(action, ThinClientServiceAction) else ThinClientServiceAction(action)
        except ValueError as error:
            raise ThinClientSystemdError("unsupported_thin_client_service_action") from error

        started_at = _utc_now()
        required_operation = (
            ContractOperation.QUERY_SERVICE
            if parsed is ThinClientServiceAction.STATUS
            else ContractOperation.CONTROL_SERVICE
        )
        if not self.contract.is_operation_allowed(required_operation) or parsed not in self.allowed_actions:
            return self._result(
                parsed,
                ThinClientServiceResultState.DENIED,
                "thin_client_service_action_denied",
                started_at,
            )

        argv = self._argv(parsed)
        try:
            completed = self.backend.run(argv, timeout_seconds=self.timeout_seconds)
        except subprocess.TimeoutExpired:
            return self._result(
                parsed,
                ThinClientServiceResultState.FAILED,
                "thin_client_service_timeout",
                started_at,
            )
        except OSError as error:
            return self._result(
                parsed,
                ThinClientServiceResultState.FAILED,
                "thin_client_service_backend_error",
                started_at,
                message=_safe_detail(str(error)),
            )

        if parsed is ThinClientServiceAction.STATUS:
            return self._status_result(started_at, completed)
        if completed.returncode != 0:
            return self._result(
                parsed,
                ThinClientServiceResultState.FAILED,
                "thin_client_service_action_failed",
                started_at,
                message=_safe_detail(completed.stderr or completed.stdout),
                data={"returncode": completed.returncode},
            )
        return self._result(
            parsed,
            ThinClientServiceResultState.SUCCEEDED,
            "thin_client_service_action_completed",
            started_at,
        )

    def _argv(self, action: ThinClientServiceAction) -> tuple[str, ...]:
        if action is ThinClientServiceAction.STATUS:
            return (
                self.systemctl_path,
                "show",
                self.unit,
                "--property=LoadState,ActiveState,SubState,UnitFileState,MainPID",
                "--value",
                "--no-pager",
            )
        return (self.systemctl_path, action.value, self.unit, "--no-pager")

    def _status_result(
        self,
        started_at: str,
        completed: subprocess.CompletedProcess[str],
    ) -> ThinClientServiceResult:
        if completed.returncode != 0:
            return self._result(
                ThinClientServiceAction.STATUS,
                ThinClientServiceResultState.FAILED,
                "thin_client_service_status_unavailable",
                started_at,
                message=_safe_detail(completed.stderr or completed.stdout),
                data={"returncode": completed.returncode},
            )
        values = [line.strip() for line in completed.stdout.splitlines()]
        values.extend([""] * (5 - len(values)))
        load_state, active_state, sub_state, unit_file_state, main_pid = values[:5]
        return self._result(
            ThinClientServiceAction.STATUS,
            ThinClientServiceResultState.SUCCEEDED,
            "thin_client_service_status_collected",
            started_at,
            data={
                "load_state": load_state or "unknown",
                "active_state": active_state or "unknown",
                "sub_state": sub_state or "unknown",
                "unit_file_state": unit_file_state or "unknown",
                "main_pid": _safe_pid(main_pid),
            },
        )

    def _result(
        self,
        action: ThinClientServiceAction,
        state: ThinClientServiceResultState,
        code: str,
        started_at: str,
        *,
        message: str | None = None,
        data: dict[str, object] | None = None,
    ) -> ThinClientServiceResult:
        return ThinClientServiceResult(
            action=action,
            state=state,
            code=code,
            started_at=started_at,
            finished_at=_utc_now(),
            unit=self.unit,
            message=message,
            data=data,
        )


def parse_thin_client_service_actions(
    values: Sequence[str | ThinClientServiceAction],
) -> tuple[ThinClientServiceAction, ...]:
    parsed: set[ThinClientServiceAction] = set()
    for value in values:
        try:
            parsed.add(value if isinstance(value, ThinClientServiceAction) else ThinClientServiceAction(value.strip().lower()))
        except (AttributeError, ValueError) as error:
            raise ThinClientSystemdError("unsupported_thin_client_service_action") from error
    return tuple(sorted(parsed, key=lambda item: item.value))


def _safe_pid(value: str) -> int | None:
    try:
        pid = int(value)
    except (TypeError, ValueError):
        return None
    return pid if pid > 0 else None


def _safe_detail(value: str | None) -> str | None:
    if not value:
        return None
    compact = " ".join(value.replace("\x00", "").split())
    return compact[:512] or None


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

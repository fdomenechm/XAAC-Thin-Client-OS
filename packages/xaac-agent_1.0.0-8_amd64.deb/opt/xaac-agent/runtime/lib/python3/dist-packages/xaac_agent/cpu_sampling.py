from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Mapping

from xaac_agent.hardware_profile import HardwareProfile

_MAX_TEXT_BYTES = 4096


def _read_text(path: Path) -> str | None:
    try:
        if path.is_symlink() or not path.is_file():
            return None
        with path.open("rb") as handle:
            raw = handle.read(_MAX_TEXT_BYTES + 1)
    except OSError:
        return None
    if len(raw) > _MAX_TEXT_BYTES:
        return None
    value = raw.decode("utf-8", errors="replace").strip()
    return value or None


def _read_positive_int(path: Path) -> int | None:
    value = _read_text(path)
    if value is None:
        return None
    try:
        parsed = int(value)
    except ValueError:
        return None
    return parsed if parsed > 0 else None


@dataclass(frozen=True, slots=True)
class CpuSamplingPolicy:
    profile_id: str
    normal_interval_multiplier: int
    warning_interval_multiplier: int
    critical_interval_multiplier: int
    minimum_frequency_ratio_warning: float

    @classmethod
    def for_profile(cls, profile: HardwareProfile) -> "CpuSamplingPolicy":
        if profile.profile_id == "dell-wyse-3040":
            return cls(profile.profile_id, 2, 1, 1, 0.35)
        return cls(profile.profile_id, 1, 1, 1, 0.20)

    def recommended_multiplier(self, severity: str) -> int:
        if severity == "critical":
            return self.critical_interval_multiplier
        if severity == "warning":
            return self.warning_interval_multiplier
        return self.normal_interval_multiplier


class CpuSamplingMonitor:
    """Bounded CPU frequency telemetry and sampling recommendation.

    It reads cpufreq sysfs directly and never changes governors or frequencies.
    """

    def __init__(
        self,
        policy: CpuSamplingPolicy,
        *,
        cpu_root: Path = Path("/sys/devices/system/cpu"),
    ) -> None:
        self._policy = policy
        self._cpu_root = cpu_root

    def sample(self, *, resource_severity: str = "normal") -> dict[str, object]:
        frequencies: list[int] = []
        minimums: list[int] = []
        maximums: list[int] = []
        governors: set[str] = set()
        checked = 0
        for cpu_index in range(256):
            cpufreq = self._cpu_root / f"cpu{cpu_index}" / "cpufreq"
            if not cpufreq.is_dir() or cpufreq.is_symlink():
                continue
            checked += 1
            current = _read_positive_int(cpufreq / "scaling_cur_freq")
            minimum = _read_positive_int(cpufreq / "scaling_min_freq")
            maximum = _read_positive_int(cpufreq / "scaling_max_freq")
            governor = _read_text(cpufreq / "scaling_governor")
            if current is not None:
                frequencies.append(current)
            if minimum is not None:
                minimums.append(minimum)
            if maximum is not None:
                maximums.append(maximum)
            if governor and len(governor) <= 64:
                governors.add(governor)

        payload: dict[str, object] = {
            "profile_id": self._policy.profile_id,
            "severity": "normal",
            "cpus_checked": checked,
            "sampling": {
                "recommended_interval_multiplier": self._policy.recommended_multiplier(resource_severity),
                "reason": resource_severity if resource_severity in {"warning", "critical"} else "profile_default",
            },
        }
        frequency: dict[str, object] = {}
        if frequencies:
            frequency["current_min_khz"] = min(frequencies)
            frequency["current_max_khz"] = max(frequencies)
            frequency["current_average_khz"] = round(sum(frequencies) / len(frequencies))
        if minimums:
            frequency["configured_min_khz"] = min(minimums)
        if maximums:
            frequency["configured_max_khz"] = max(maximums)
        if governors:
            frequency["governors"] = sorted(governors)
        if frequency:
            payload["frequency"] = frequency

        configured_max = frequency.get("configured_max_khz")
        current_average = frequency.get("current_average_khz")
        if isinstance(configured_max, int) and isinstance(current_average, int) and configured_max > 0:
            ratio = current_average / configured_max
            payload["frequency_ratio"] = round(ratio, 3)
            if resource_severity in {"warning", "critical"} and ratio < self._policy.minimum_frequency_ratio_warning:
                payload["severity"] = "warning"
                payload["signal"] = "frequency_throttled_under_load"
        return payload

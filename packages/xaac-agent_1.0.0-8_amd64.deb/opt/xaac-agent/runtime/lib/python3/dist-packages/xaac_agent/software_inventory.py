from __future__ import annotations

import importlib.metadata
import platform
import re
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Mapping, Sequence

from xaac_agent import __version__

_GENERIC = {"", "unknown", "n/a", "none"}
_VERSION_RE = re.compile(r"(?i)(?:freerdp|version)?\s*v?(\d+(?:\.\d+){1,3}(?:[-+~._a-z0-9]*)?)")


@dataclass(frozen=True, slots=True)
class SoftwareInventory:
    agent: Mapping[str, object]
    python: Mapping[str, object]
    thinclient: Mapping[str, object]
    freerdp: Mapping[str, object]
    dependencies: tuple[Mapping[str, object], ...]
    configuration: Mapping[str, object]

    def to_payload(self) -> dict[str, object]:
        return {
            "agent": dict(self.agent),
            "python": dict(self.python),
            "xaac_thinclient": dict(self.thinclient),
            "freerdp": dict(self.freerdp),
            "dependencies": [dict(item) for item in self.dependencies],
            "configuration": dict(self.configuration),
        }


class SoftwareInventoryCollector:
    def __init__(
        self,
        *,
        dpkg_status_file: Path = Path("/var/lib/dpkg/status"),
        executable_finder: Callable[[str], str | None] = shutil.which,
        command_runner: Callable[[Sequence[str]], str | None] | None = None,
        package_version_reader: Callable[[str], str | None] | None = None,
        thinclient_version_files: tuple[Path, ...] = (
            Path("/usr/share/xaac-thinclient/VERSION"),
            Path("/opt/xaac-thinclient/VERSION"),
            Path("/etc/xaac-thinclient/version"),
        ),
        configuration_summary: Mapping[str, object] | None = None,
    ) -> None:
        self._dpkg_status_file = dpkg_status_file
        self._find = executable_finder
        self._run = command_runner or self._default_run
        self._package_version_reader = package_version_reader or self._metadata_version
        self._thinclient_version_files = thinclient_version_files
        self._configuration_summary = dict(configuration_summary or {})

    def collect(self) -> SoftwareInventory:
        packages = self._read_dpkg_packages()
        return SoftwareInventory(
            agent={"name": "xaac-agent", "version": __version__},
            python={
                "implementation": platform.python_implementation(),
                "version": platform.python_version(),
                "executable_architecture": platform.machine() or "unknown",
            },
            thinclient=self._collect_thinclient(packages),
            freerdp=self._collect_freerdp(packages),
            dependencies=self._collect_dependencies(packages),
            configuration=self._configuration_summary,
        )

    def _collect_thinclient(self, packages: Mapping[str, str]) -> dict[str, object]:
        version = self._package_version_reader("xaac-thinclient")
        source = "python-package" if version else None
        if not version:
            version = packages.get("xaac-thinclient")
            source = "debian-package" if version else None
        if not version:
            for path in self._thinclient_version_files:
                value = self._safe_text(path)
                if value:
                    version, source = value, "version-file"
                    break
        executable = self._find("xaac-thinclient")
        installed = bool(version or executable or packages.get("xaac-thinclient"))
        result: dict[str, object] = {"installed": installed}
        if version:
            result["version"] = version
        if source:
            result["version_source"] = source
        if executable:
            result["executable"] = executable
        return result

    def _collect_freerdp(self, packages: Mapping[str, str]) -> dict[str, object]:
        executable = None
        version = None
        for name in ("xfreerdp3", "xfreerdp"):
            candidate = self._find(name)
            if not candidate:
                continue
            executable = candidate
            output = self._run((candidate, "/version"))
            version = self._extract_version(output or "")
            break
        relevant = {
            name: value for name, value in packages.items()
            if "freerdp" in name.lower() and value
        }
        if not version and relevant:
            preferred = ("freerdp3-x11", "libfreerdp3-3", "freerdp2-x11")
            for name in preferred:
                if name in relevant:
                    version = relevant[name]
                    break
            version = version or next(iter(relevant.values()))
        result: dict[str, object] = {"installed": bool(executable or relevant)}
        if version:
            result["version"] = version
        if executable:
            result["executable"] = executable
        if relevant:
            result["packages"] = dict(sorted(relevant.items()))
        return result

    def _collect_dependencies(self, packages: Mapping[str, str]) -> tuple[Mapping[str, object], ...]:
        values: list[Mapping[str, object]] = []
        for name in ("cryptography",):
            version = self._package_version_reader(name)
            if not version:
                version = packages.get(f"python3-{name}")
            item: dict[str, object] = {"name": name, "available": bool(version)}
            if version:
                item["version"] = version
            values.append(item)
        return tuple(values)

    def _read_dpkg_packages(self) -> dict[str, str]:
        text = self._safe_text(self._dpkg_status_file, allow_large=True)
        if not text:
            return {}
        result: dict[str, str] = {}
        for paragraph in text.split("\n\n"):
            fields: dict[str, str] = {}
            for line in paragraph.splitlines():
                if ":" in line and not line.startswith((" ", "\t")):
                    key, value = line.split(":", 1)
                    fields[key.strip()] = value.strip()
            if fields.get("Status") == "install ok installed" and fields.get("Package") and fields.get("Version"):
                result[fields["Package"]] = fields["Version"]
        return result

    @staticmethod
    def _metadata_version(name: str) -> str | None:
        try:
            return importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            return None

    @staticmethod
    def _default_run(command: Sequence[str]) -> str | None:
        try:
            completed = subprocess.run(
                list(command), capture_output=True, text=True, timeout=3, check=False,
                stdin=subprocess.DEVNULL,
            )
        except (OSError, subprocess.SubprocessError):
            return None
        return (completed.stdout or completed.stderr or "").strip() or None

    @staticmethod
    def _extract_version(text: str) -> str | None:
        match = _VERSION_RE.search(text)
        return match.group(1) if match else None

    @staticmethod
    def _safe_text(path: Path, *, allow_large: bool = False) -> str | None:
        try:
            if path.is_symlink() or not path.is_file():
                return None
            if not allow_large and path.stat().st_size > 4096:
                return None
            value = path.read_text(encoding="utf-8", errors="replace").strip().replace("\x00", "")
        except OSError:
            return None
        return value if value.lower() not in _GENERIC else None

from __future__ import annotations

import json
import os
import stat
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from xaac_agent.xms_address import XmsAddressError, _normalise_url


class XmsFailoverError(ValueError):
    """Estat o política de servidor alternatiu no vàlids."""


@dataclass(frozen=True, slots=True)
class XmsFailoverState:
    active_url: str
    primary_url: str
    consecutive_failures: int = 0
    switched_at: str | None = None
    reason: str | None = None


class XmsFailoverStore:
    schema = "xaac-xms-failover/v1"

    def __init__(
        self,
        path: Path,
        *,
        primary_url: str,
        alternate_urls: tuple[str, ...] = (),
        failure_threshold: int = 3,
        require_https: bool = True,
        max_bytes: int = 32768,
    ) -> None:
        if not 1 <= failure_threshold <= 100:
            raise XmsFailoverError("xms_failover_threshold_invalid")
        try:
            self.primary_url = _normalise_url(primary_url, require_https=require_https)
            normalised = tuple(_normalise_url(url, require_https=require_https) for url in alternate_urls)
        except XmsAddressError as error:
            raise XmsFailoverError(str(error)) from error
        if self.primary_url in normalised or len(set(normalised)) != len(normalised):
            raise XmsFailoverError("xms_failover_authorized_servers_invalid")
        self.path = path
        self.alternate_urls = normalised
        self.failure_threshold = failure_threshold
        self.require_https = require_https
        self.max_bytes = max_bytes

    @property
    def authorized_urls(self) -> tuple[str, ...]:
        return (self.primary_url, *self.alternate_urls)

    def load(self) -> XmsFailoverState:
        if not self.path.exists():
            return XmsFailoverState(self.primary_url, self.primary_url)
        info = self.path.lstat()
        if stat.S_ISLNK(info.st_mode) or not stat.S_ISREG(info.st_mode):
            raise XmsFailoverError("xms_failover_state_unsafe_file")
        if info.st_size > self.max_bytes:
            raise XmsFailoverError("xms_failover_state_too_large")
        try:
            payload = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError) as error:
            raise XmsFailoverError("xms_failover_state_corrupt") from error
        if not isinstance(payload, dict) or payload.get("schema") != self.schema:
            raise XmsFailoverError("xms_failover_state_invalid_schema")
        active = payload.get("active_url")
        primary = payload.get("primary_url")
        if active not in self.authorized_urls or primary != self.primary_url:
            if not self.alternate_urls:
                state = XmsFailoverState(self.primary_url, self.primary_url)
                self._write(state)
                return state
            raise XmsFailoverError("xms_failover_state_unauthorized_server")
        failures = payload.get("consecutive_failures", 0)
        if not isinstance(failures, int) or failures < 0 or failures > 1000000:
            raise XmsFailoverError("xms_failover_state_invalid_failures")
        switched_at = payload.get("switched_at")
        reason = payload.get("reason")
        if switched_at is not None and not isinstance(switched_at, str):
            raise XmsFailoverError("xms_failover_state_invalid_timestamp")
        if reason is not None and (not isinstance(reason, str) or len(reason) > 128):
            raise XmsFailoverError("xms_failover_state_invalid_reason")
        return XmsFailoverState(active, primary, failures, switched_at, reason)

    def record_failure(self, *, active_url: str, reason: str) -> XmsFailoverState:
        state = self.load()
        if active_url != state.active_url or active_url not in self.authorized_urls:
            raise XmsFailoverError("xms_failover_active_server_mismatch")
        failures = state.consecutive_failures + 1
        target = state.active_url
        switched_at = state.switched_at
        if failures >= self.failure_threshold and self.alternate_urls:
            candidates = self.authorized_urls
            index = candidates.index(state.active_url)
            target = candidates[(index + 1) % len(candidates)]
            failures = 0
            switched_at = _utc_now()
        updated = XmsFailoverState(target, self.primary_url, failures, switched_at, reason[:128])
        self._write(updated)
        return updated

    def record_success(self, *, active_url: str) -> XmsFailoverState:
        state = self.load()
        if active_url != state.active_url or active_url not in self.authorized_urls:
            raise XmsFailoverError("xms_failover_active_server_mismatch")
        updated = XmsFailoverState(active_url, self.primary_url, 0, state.switched_at, None)
        self._write(updated)
        return updated

    def prefer_primary(self) -> XmsFailoverState:
        state = XmsFailoverState(self.primary_url, self.primary_url, 0, _utc_now(), "primary_recovered")
        self._write(state)
        return state

    def _write(self, state: XmsFailoverState) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "schema": self.schema,
            "active_url": state.active_url,
            "primary_url": state.primary_url,
            "consecutive_failures": state.consecutive_failures,
            "switched_at": state.switched_at,
            "reason": state.reason,
        }
        data = (json.dumps(payload, sort_keys=True, separators=(",", ":")) + "\n").encode()
        if len(data) > self.max_bytes:
            raise XmsFailoverError("xms_failover_state_too_large")
        fd, temporary = tempfile.mkstemp(prefix=f".{self.path.name}.", dir=self.path.parent)
        try:
            os.fchmod(fd, 0o600)
            with os.fdopen(fd, "wb", closefd=True) as stream:
                stream.write(data)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.path)
            directory_fd = os.open(self.path.parent, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
        finally:
            try:
                os.unlink(temporary)
            except FileNotFoundError:
                pass


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

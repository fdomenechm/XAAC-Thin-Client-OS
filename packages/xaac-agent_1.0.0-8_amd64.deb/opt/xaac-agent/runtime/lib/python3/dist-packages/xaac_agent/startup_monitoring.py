from __future__ import annotations

import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from xaac_agent.hardware_profile import HardwareProfile

_MAX_READ_BYTES = 16384


def _read_text(path: Path) -> str | None:
    try:
        if path.is_symlink() or not path.is_file():
            return None
        with path.open("rb") as handle:
            raw = handle.read(_MAX_READ_BYTES + 1)
    except OSError:
        return None
    if len(raw) > _MAX_READ_BYTES:
        return None
    return raw.decode("utf-8", errors="replace").strip() or None


def _uptime_seconds(path: Path) -> float | None:
    value = _read_text(path)
    if value is None:
        return None
    try:
        parsed = float(value.split()[0])
    except (ValueError, IndexError):
        return None
    return parsed if parsed >= 0 else None


def _process_start_seconds(path: Path, clock_ticks: int) -> float | None:
    value = _read_text(path)
    if value is None or clock_ticks <= 0:
        return None
    # /proc/<pid>/stat field 2 is enclosed in parentheses and may contain spaces.
    closing = value.rfind(")")
    if closing < 0:
        return None
    fields = value[closing + 2 :].split()
    # After removing pid and comm, starttime (field 22) is index 19.
    if len(fields) <= 19:
        return None
    try:
        ticks = int(fields[19])
    except ValueError:
        return None
    return ticks / clock_ticks if ticks >= 0 else None


@dataclass(frozen=True, slots=True)
class StartupPolicy:
    profile_id: str
    startup_warning_seconds: float
    startup_critical_seconds: float
    readiness_warning_seconds: float
    readiness_critical_seconds: float

    @classmethod
    def for_profile(cls, profile: HardwareProfile) -> "StartupPolicy":
        if profile.profile_id == "dell-wyse-3040":
            return cls(profile.profile_id, 45.0, 120.0, 15.0, 45.0)
        return cls(profile.profile_id, 90.0, 240.0, 30.0, 90.0)


class StartupMonitor:
    """Passive boot and agent startup timing telemetry.

    Reads bounded procfs files and uses a monotonic clock. It never invokes
    systemd tools and does not alter boot or service configuration.
    """

    def __init__(
        self,
        policy: StartupPolicy,
        *,
        uptime_path: Path = Path("/proc/uptime"),
        process_stat_path: Path = Path("/proc/self/stat"),
        monotonic: Callable[[], float] = time.monotonic,
        clock_ticks: int | None = None,
    ) -> None:
        self._policy = policy
        self._uptime_path = uptime_path
        self._process_stat_path = process_stat_path
        self._monotonic = monotonic
        self._created_at = monotonic()
        self._first_sample_elapsed: float | None = None
        if clock_ticks is None:
            try:
                clock_ticks = int(os.sysconf("SC_CLK_TCK"))
            except (OSError, ValueError, TypeError):
                clock_ticks = 100
        self._clock_ticks = max(1, clock_ticks)

    def sample(self) -> dict[str, object]:
        now = self._monotonic()
        elapsed = max(0.0, now - self._created_at)
        if self._first_sample_elapsed is None:
            self._first_sample_elapsed = elapsed

        payload: dict[str, object] = {
            "profile_id": self._policy.profile_id,
            "availability": "unavailable",
            "severity": "normal",
            "readiness_elapsed_seconds": round(self._first_sample_elapsed, 3),
            "thresholds": {
                "startup_warning_seconds": self._policy.startup_warning_seconds,
                "startup_critical_seconds": self._policy.startup_critical_seconds,
                "readiness_warning_seconds": self._policy.readiness_warning_seconds,
                "readiness_critical_seconds": self._policy.readiness_critical_seconds,
            },
            "recommendations": {
                "external_commands_executed": False,
                "boot_configuration_changed": False,
            },
        }
        uptime = _uptime_seconds(self._uptime_path)
        process_start = _process_start_seconds(self._process_stat_path, self._clock_ticks)
        if uptime is None or process_start is None or process_start > uptime:
            return payload

        startup_delay = max(0.0, process_start)
        process_uptime = max(0.0, uptime - process_start)
        payload.update(
            {
                "availability": "available",
                "system_uptime_seconds": round(uptime, 3),
                "agent_uptime_seconds": round(process_uptime, 3),
                "agent_start_after_boot_seconds": round(startup_delay, 3),
            }
        )
        readiness = self._first_sample_elapsed
        severity = "normal"
        signal: str | None = None
        if startup_delay >= self._policy.startup_critical_seconds:
            severity, signal = "critical", "agent_startup_delay"
        elif startup_delay >= self._policy.startup_warning_seconds:
            severity, signal = "warning", "agent_startup_delay"
        if readiness >= self._policy.readiness_critical_seconds:
            severity, signal = "critical", "agent_readiness_delay"
        elif readiness >= self._policy.readiness_warning_seconds and severity == "normal":
            severity, signal = "warning", "agent_readiness_delay"
        payload["severity"] = severity
        if signal is not None:
            payload["signal"] = signal
        return payload

from __future__ import annotations

import re
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping


_DMI_FIELDS: Mapping[str, str] = {
    "manufacturer": "sys_vendor",
    "product_name": "product_name",
    "product_version": "product_version",
    "product_serial": "product_serial",
    "smbios_uuid": "product_uuid",
    "board_manufacturer": "board_vendor",
    "board_name": "board_name",
    "board_serial": "board_serial",
    "chassis_type": "chassis_type",
    "chassis_serial": "chassis_serial",
    "asset_tag": "chassis_asset_tag",
}

_PLACEHOLDER_VALUES = {
    "",
    "none",
    "not applicable",
    "not available",
    "not specified",
    "no asset tag",
    "system serial number",
    "system product name",
    "system manufacturer",
    "default string",
    "to be filled by o.e.m.",
    "to be filled by oem",
    "unknown",
    "n/a",
    "na",
    "0",
}


@dataclass(frozen=True, slots=True)
class HardwareIdentifiers:
    """Normalised hardware facts, separate from the logical agent identity."""

    manufacturer: str | None = None
    product_name: str | None = None
    product_version: str | None = None
    product_serial: str | None = None
    smbios_uuid: str | None = None
    board_manufacturer: str | None = None
    board_name: str | None = None
    board_serial: str | None = None
    chassis_type: str | None = None
    chassis_serial: str | None = None
    asset_tag: str | None = None
    dell_service_tag: str | None = None

    def to_payload(self) -> dict[str, str]:
        values = {
            "manufacturer": self.manufacturer,
            "product_name": self.product_name,
            "product_version": self.product_version,
            "product_serial": self.product_serial,
            "smbios_uuid": self.smbios_uuid,
            "board_manufacturer": self.board_manufacturer,
            "board_name": self.board_name,
            "board_serial": self.board_serial,
            "chassis_type": self.chassis_type,
            "chassis_serial": self.chassis_serial,
            "asset_tag": self.asset_tag,
            "dell_service_tag": self.dell_service_tag,
        }
        return {key: value for key, value in values.items() if value is not None}


class HardwareIdentityCollector:
    """Read non-secret DMI/SMBIOS identifiers from Linux sysfs.

    Missing, unreadable and firmware-placeholder values are intentionally
    omitted. The collector never reads ``/etc/machine-id`` because that value
    is an operating-system installation identifier, not hardware identity.
    """

    def __init__(self, dmi_directory: Path = Path("/sys/class/dmi/id")) -> None:
        self._dmi_directory = dmi_directory

    def collect(self) -> HardwareIdentifiers:
        values = {
            target: self._read_value(filename)
            for target, filename in _DMI_FIELDS.items()
        }
        values["smbios_uuid"] = _normalise_uuid(values["smbios_uuid"])
        manufacturer = values["manufacturer"]
        product_serial = values["product_serial"]
        values["dell_service_tag"] = (
            product_serial if manufacturer and "dell" in manufacturer.casefold() else None
        )
        return HardwareIdentifiers(**values)

    def _read_value(self, filename: str) -> str | None:
        path = self._dmi_directory / filename
        try:
            value = path.read_text(encoding="utf-8", errors="replace")
        except (FileNotFoundError, PermissionError, IsADirectoryError, OSError):
            return None
        return _normalise_text(value)


def _normalise_text(value: str | None) -> str | None:
    if value is None:
        return None
    # Firmware strings occasionally include NUL bytes and irregular spacing.
    cleaned = value.replace("\x00", " ")
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    if cleaned.casefold() in _PLACEHOLDER_VALUES:
        return None
    return cleaned or None


def _normalise_uuid(value: str | None) -> str | None:
    value = _normalise_text(value)
    if value is None:
        return None
    try:
        parsed = uuid.UUID(value)
    except (ValueError, AttributeError):
        return None
    if parsed.int == 0 or parsed.int == (1 << 128) - 1:
        return None
    return str(parsed)

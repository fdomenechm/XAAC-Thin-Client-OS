from __future__ import annotations

import hashlib
import json
import os
import stat
import tempfile
import urllib.error
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import BinaryIO, Protocol

from xaac_agent.policy_model import Policy, PolicyState, PolicyValidationError


class PolicyCacheError(ValueError):
    def __init__(self, code: str) -> None:
        super().__init__(code)
        self.code = code


class PolicyDownloadBackend(Protocol):
    def open(self, url: str, *, timeout_seconds: int) -> BinaryIO: ...


class HttpsPolicyDownloadBackend:
    def open(self, url: str, *, timeout_seconds: int) -> BinaryIO:
        if not isinstance(url, str) or not url.lower().startswith("https://"):
            raise PolicyCacheError("insecure_policy_url")
        request = urllib.request.Request(url, headers={"User-Agent": "XAAC-Agent/0.7.2"})
        response = urllib.request.urlopen(request, timeout=timeout_seconds)
        final_url = response.geturl()
        if not isinstance(final_url, str) or not final_url.lower().startswith("https://"):
            response.close()
            raise PolicyCacheError("insecure_policy_redirect")
        return response


@dataclass(frozen=True, slots=True)
class PolicyDownloadRequest:
    source_url: str
    sha256: str
    size_bytes: int

    def __post_init__(self) -> None:
        if not isinstance(self.source_url, str) or not self.source_url.lower().startswith("https://"):
            raise PolicyCacheError("insecure_policy_url")
        digest = self.sha256.lower()
        if len(digest) != 64 or any(char not in "0123456789abcdef" for char in digest):
            raise PolicyCacheError("invalid_policy_digest")
        if isinstance(self.size_bytes, bool) or not isinstance(self.size_bytes, int) or self.size_bytes < 2:
            raise PolicyCacheError("invalid_policy_size")
        object.__setattr__(self, "sha256", digest)


@dataclass(frozen=True, slots=True)
class CachedPolicy:
    policy: Policy
    path: Path
    sha256: str
    size_bytes: int
    cached_at: datetime
    reused: bool = False

    @property
    def state(self) -> PolicyState:
        return PolicyState.CACHED

    def to_payload(self) -> dict[str, object]:
        return {
            "policy_id": self.policy.policy_id,
            "revision": self.policy.revision,
            "state": self.state.value,
            "sha256": self.sha256,
            "size_bytes": self.size_bytes,
            "cached_at": self.cached_at.isoformat().replace("+00:00", "Z"),
            "reused": self.reused,
        }


@dataclass(frozen=True, slots=True)
class PolicyCache:
    directory: Path
    backend: PolicyDownloadBackend
    max_policy_bytes: int = 2 * 1024 * 1024
    timeout_seconds: int = 30
    max_entries: int = 32

    @classmethod
    def system_default(
        cls,
        directory: Path,
        *,
        max_policy_bytes: int = 2 * 1024 * 1024,
        timeout_seconds: int = 30,
        max_entries: int = 32,
    ) -> "PolicyCache":
        return cls(
            directory=directory,
            backend=HttpsPolicyDownloadBackend(),
            max_policy_bytes=max_policy_bytes,
            timeout_seconds=timeout_seconds,
            max_entries=max_entries,
        )

    def download(self, request: PolicyDownloadRequest) -> CachedPolicy:
        if request.size_bytes > self.max_policy_bytes:
            raise PolicyCacheError("policy_too_large")
        self._prepare_directory()
        existing = self._find_by_digest(request.sha256)
        if existing is not None:
            cached = self._load_cached(existing, expected_digest=request.sha256, expected_size=request.size_bytes)
            return CachedPolicy(cached.policy, cached.path, cached.sha256, cached.size_bytes, cached.cached_at, True)

        try:
            with self.backend.open(request.source_url, timeout_seconds=self.timeout_seconds) as source:
                temporary, digest, size = self._download_temporary(source, expected_size=request.size_bytes)
        except PolicyCacheError:
            raise
        except TimeoutError as error:
            raise PolicyCacheError("policy_download_timeout") from error
        except (urllib.error.URLError, OSError) as error:
            raise PolicyCacheError("policy_download_failed") from error

        try:
            if size != request.size_bytes:
                raise PolicyCacheError("policy_size_mismatch")
            if digest != request.sha256:
                raise PolicyCacheError("policy_digest_mismatch")
            policy = self._parse_policy(temporary)
            destination = self._entry_path(policy, digest)
            if destination.exists():
                cached = self._load_cached(destination, expected_digest=digest, expected_size=size)
                temporary.unlink(missing_ok=True)
                return CachedPolicy(cached.policy, cached.path, cached.sha256, cached.size_bytes, cached.cached_at, True)
            self._validate_entry_destination(destination)
            os.replace(temporary, destination)
            _fsync_directory(self.directory)
            cached_at = datetime.now(timezone.utc)
            self._prune(keep=destination)
            return CachedPolicy(policy, destination, digest, size, cached_at)
        except Exception:
            temporary.unlink(missing_ok=True)
            raise

    def load(self, policy_id: str, revision: int) -> CachedPolicy | None:
        self._prepare_directory()
        prefix = f"{_safe_component(policy_id)}--{revision}--"
        matches = sorted(self.directory.glob(f"{prefix}*.json"))
        if not matches:
            return None
        if len(matches) > 1:
            raise PolicyCacheError("ambiguous_cached_policy")
        return self._load_cached(matches[0])

    def _prepare_directory(self) -> None:
        try:
            info = self.directory.lstat()
            if stat.S_ISLNK(info.st_mode):
                raise PolicyCacheError("policy_cache_symlink")
            if not stat.S_ISDIR(info.st_mode):
                raise PolicyCacheError("policy_cache_not_directory")
        except FileNotFoundError:
            self.directory.mkdir(parents=True, mode=0o700)
        os.chmod(self.directory, 0o700)

    def _find_by_digest(self, digest: str) -> Path | None:
        matches = list(self.directory.glob(f"*--{digest}.json"))
        if not matches:
            return None
        if len(matches) > 1:
            raise PolicyCacheError("duplicate_cached_digest")
        return matches[0]

    def _download_temporary(self, source: BinaryIO, *, expected_size: int) -> tuple[Path, str, int]:
        digest = hashlib.sha256()
        written = 0
        fd, raw_path = tempfile.mkstemp(prefix=".policy-", suffix=".part", dir=self.directory)
        temporary = Path(raw_path)
        try:
            os.fchmod(fd, 0o600)
            with os.fdopen(fd, "wb") as output:
                while True:
                    chunk = source.read(64 * 1024)
                    if not chunk:
                        break
                    if not isinstance(chunk, bytes):
                        raise PolicyCacheError("invalid_policy_stream")
                    written += len(chunk)
                    if written > expected_size or written > self.max_policy_bytes:
                        raise PolicyCacheError("policy_size_exceeded")
                    digest.update(chunk)
                    output.write(chunk)
                output.flush()
                os.fsync(output.fileno())
        except Exception:
            try:
                os.close(fd)
            except OSError:
                pass
            temporary.unlink(missing_ok=True)
            raise
        return temporary, digest.hexdigest(), written

    @staticmethod
    def _parse_policy(path: Path) -> Policy:
        try:
            raw = path.read_bytes()
            payload = json.loads(raw.decode("utf-8"))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
            raise PolicyCacheError("invalid_policy_document") from error
        if not isinstance(payload, dict):
            raise PolicyCacheError("invalid_policy_document")
        try:
            return Policy.from_payload(payload)
        except PolicyValidationError as error:
            raise PolicyCacheError(error.code) from error

    def _load_cached(
        self,
        path: Path,
        *,
        expected_digest: str | None = None,
        expected_size: int | None = None,
    ) -> CachedPolicy:
        info = path.lstat()
        if stat.S_ISLNK(info.st_mode):
            raise PolicyCacheError("cached_policy_symlink")
        if not stat.S_ISREG(info.st_mode):
            raise PolicyCacheError("cached_policy_not_regular")
        raw = path.read_bytes()
        size = len(raw)
        digest = hashlib.sha256(raw).hexdigest()
        if expected_size is not None and size != expected_size:
            raise PolicyCacheError("cached_policy_size_mismatch")
        if expected_digest is not None and digest != expected_digest:
            raise PolicyCacheError("cached_policy_digest_mismatch")
        policy = self._parse_policy(path)
        cached_at = datetime.fromtimestamp(info.st_mtime, timezone.utc)
        return CachedPolicy(policy, path, digest, size, cached_at)

    def _entry_path(self, policy: Policy, digest: str) -> Path:
        return self.directory / f"{_safe_component(policy.policy_id)}--{policy.revision}--{digest}.json"

    @staticmethod
    def _validate_entry_destination(path: Path) -> None:
        try:
            info = path.lstat()
        except FileNotFoundError:
            return
        if stat.S_ISLNK(info.st_mode):
            raise PolicyCacheError("cached_policy_symlink")
        if not stat.S_ISREG(info.st_mode):
            raise PolicyCacheError("cached_policy_not_regular")

    def _prune(self, *, keep: Path) -> None:
        if self.max_entries < 1:
            raise PolicyCacheError("invalid_policy_cache_limit")
        entries = []
        for path in self.directory.glob("*.json"):
            try:
                info = path.lstat()
            except OSError:
                continue
            if stat.S_ISREG(info.st_mode) and not stat.S_ISLNK(info.st_mode):
                entries.append((info.st_mtime_ns, path))
        entries.sort(reverse=True)
        for _, path in entries[self.max_entries :]:
            if path != keep:
                path.unlink(missing_ok=True)
        _fsync_directory(self.directory)


def _safe_component(value: str) -> str:
    return "".join(char if char.isalnum() or char in "._-" else "_" for char in value)


def _fsync_directory(directory: Path) -> None:
    flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0)
    fd = os.open(directory, flags)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)

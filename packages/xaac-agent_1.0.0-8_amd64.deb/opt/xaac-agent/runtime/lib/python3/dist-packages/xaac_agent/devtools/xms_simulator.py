from __future__ import annotations

import argparse
import base64
import gzip
import json
import logging
import socket
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Mapping

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from xaac_agent.enrollment import canonical_json, utc_now

logger = logging.getLogger(__name__)

XMP_BASE_PATH = "/api/xmp/v1"
ADMIN_BASE_PATH = "/__simulator__"
MAX_REQUEST_BYTES = 1024 * 1024


class SimulatorRequestError(ValueError):
    """La petició rebuda pel simulador no és vàlida."""


@dataclass(slots=True)
class FaultPlan:
    status: int | None = None
    delay_seconds: float = 0.0
    malformed_json: bool = False
    drop_connection: bool = False
    remaining: int = 0

    def validate(self) -> None:
        if self.status is not None and not 100 <= self.status <= 599:
            raise SimulatorRequestError("status fora de rang")
        if not 0.0 <= self.delay_seconds <= 30.0:
            raise SimulatorRequestError("delay_seconds fora de rang")
        if not 0 <= self.remaining <= 1000:
            raise SimulatorRequestError("remaining fora de rang")

    def active_copy(self) -> "FaultPlan | None":
        if self.remaining <= 0:
            return None
        self.remaining -= 1
        return FaultPlan(
            status=self.status,
            delay_seconds=self.delay_seconds,
            malformed_json=self.malformed_json,
            drop_connection=self.drop_connection,
            remaining=1,
        )


@dataclass(slots=True)
class SimulatorState:
    enrollment_token: str | None = None
    credential_lifetime_seconds: int = 86400
    requests: list[dict[str, Any]] = field(default_factory=list)
    enrollments: dict[str, dict[str, Any]] = field(default_factory=dict)
    credentials: dict[str, str] = field(default_factory=dict)
    revoked_devices: dict[str, str] = field(default_factory=dict)
    heartbeats: list[dict[str, Any]] = field(default_factory=list)
    last_heartbeats: dict[str, dict[str, Any]] = field(default_factory=dict)
    commands: list[dict[str, Any]] = field(default_factory=list)
    command_acknowledgements: list[dict[str, Any]] = field(default_factory=list)
    policies: list[dict[str, Any]] = field(default_factory=list)
    fault_plan: FaultPlan = field(default_factory=FaultPlan)
    seen_nonces: dict[str, float] = field(default_factory=dict)
    authentication_window_seconds: int = 300
    allow_legacy_bearer_auth: bool = False
    next_heartbeat_seconds: int | None = None
    _lock: threading.RLock = field(default_factory=threading.RLock, repr=False)

    def record_request(self, method: str, path: str, payload: Any) -> None:
        with self._lock:
            self.requests.append(
                {
                    "method": method,
                    "path": path,
                    "payload": payload,
                    "received_at": time.time(),
                }
            )

    def next_fault(self) -> FaultPlan | None:
        with self._lock:
            return self.fault_plan.active_copy()

    def replace_fault(self, plan: FaultPlan) -> None:
        plan.validate()
        with self._lock:
            self.fault_plan = plan

    def reset(self) -> None:
        with self._lock:
            self.requests.clear()
            self.enrollments.clear()
            self.credentials.clear()
            self.revoked_devices.clear()
            self.heartbeats.clear()
            self.last_heartbeats.clear()
            self.commands.clear()
            self.command_acknowledgements.clear()
            self.policies.clear()
            self.fault_plan = FaultPlan()
            self.seen_nonces.clear()

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return {
                "request_count": len(self.requests),
                "requests": list(self.requests),
                "enrollments": dict(self.enrollments),
                "heartbeats": list(self.heartbeats),
                "last_heartbeats": dict(self.last_heartbeats),
                "credential_count": len(self.credentials),
                "revoked_devices": dict(self.revoked_devices),
                "commands": list(self.commands),
                "command_acknowledgements": list(self.command_acknowledgements),
                "policies": list(self.policies),
                "fault_plan": asdict(self.fault_plan),
                "seen_nonce_count": len(self.seen_nonces),
                "next_heartbeat_seconds": self.next_heartbeat_seconds,
            }

    def queue_command(self, payload: Mapping[str, Any]) -> dict[str, Any]:
        command = dict(payload)
        command.setdefault("command_id", str(uuid.uuid4()))
        command.setdefault("type", "noop")
        with self._lock:
            self.commands.append(command)
        return command

    def queue_policy(self, payload: Mapping[str, Any]) -> dict[str, Any]:
        policy = dict(payload)
        policy.setdefault("policy_id", str(uuid.uuid4()))
        policy.setdefault("version", 1)
        with self._lock:
            self.policies.append(policy)
        return policy

    def accept_heartbeat(self, payload: Mapping[str, Any]) -> dict[str, Any]:
        heartbeat = dict(payload)
        with self._lock:
            self.heartbeats.append(heartbeat)
            device_id = heartbeat.get("device_id")
            if isinstance(device_id, str) and device_id:
                self.last_heartbeats[device_id] = heartbeat
            acknowledgements = heartbeat.get("command_acknowledgements", [])
            acknowledged_ids: set[str] = set()
            if isinstance(acknowledgements, list):
                for acknowledgement in acknowledgements:
                    if not isinstance(acknowledgement, dict):
                        continue
                    command_id = acknowledgement.get("command_id")
                    if isinstance(command_id, str) and command_id:
                        acknowledged_ids.add(command_id)
                        self.command_acknowledgements.append(dict(acknowledgement))
            if acknowledged_ids:
                self.commands[:] = [
                    command for command in self.commands
                    if command.get("command_id") not in acknowledged_ids
                ]
            commands = list(self.commands)
            policies = list(self.policies)
            if self.allow_legacy_bearer_auth:
                self.commands.clear()
            self.policies.clear()
        response = {
            "accepted": True,
            "server_time": time.time(),
            "commands": commands,
            "policies": policies,
        }
        if self.next_heartbeat_seconds is not None:
            response["next_heartbeat_seconds"] = self.next_heartbeat_seconds
        return response

    def enroll(self, payload: Mapping[str, Any]) -> dict[str, Any]:
        _verify_enrollment_signature(payload)
        requested_id = str(payload.get("device_id") or "")
        if not requested_id:
            raise SimulatorRequestError("device_id obligatori")
        with self._lock:
            existing = self.enrollments.get(requested_id)
            if existing is not None:
                return dict(existing)
            credential = f"sim-{uuid.uuid4()}"
            issued = datetime.now(timezone.utc)
            record = {
                "schema_version": 1,
                "device_id": requested_id,
                "credential": credential,
                "issued_at": issued.isoformat().replace("+00:00", "Z"),
                "expires_at": (
                    issued + timedelta(seconds=self.credential_lifetime_seconds)
                ).isoformat().replace("+00:00", "Z"),
                "status": "enrolled",
                "public_key": dict(payload.get("public_key") or {}),
            }
            self.enrollments[requested_id] = record
            self.credentials[credential] = requested_id
        return dict(record)

    def revoke_device(self, device_id: str, reason: str = "administrator_revocation") -> bool:
        with self._lock:
            if device_id not in self.enrollments:
                return False
            self.revoked_devices[device_id] = reason
            for credential, owner in list(self.credentials.items()):
                if owner == device_id:
                    self.credentials.pop(credential, None)
            return True

    def unenroll(self, payload: Mapping[str, Any], authorization: str | None) -> dict[str, Any]:
        device_id = self.credential_device_id(authorization)
        if device_id is None:
            raise SimulatorRequestError("invalid_credential")
        if payload.get("device_id") != device_id:
            raise SimulatorRequestError("device_id mismatch")
        with self._lock:
            enrollment = self.enrollments.get(device_id)
            if enrollment is None:
                raise SimulatorRequestError("device not enrolled")
            public = enrollment.get("public_key")
        _verify_signed_payload(payload, public)
        with self._lock:
            for credential, owner in list(self.credentials.items()):
                if owner == device_id:
                    self.credentials.pop(credential, None)
            self.enrollments.pop(device_id, None)
            self.revoked_devices.pop(device_id, None)
        return {"accepted": True, "device_id": device_id, "status": "unenrolled"}

    def authorization_error(self, authorization: str | None) -> str | None:
        if not authorization or not authorization.startswith("Bearer "):
            return "invalid_credential"
        credential = authorization.removeprefix("Bearer ")
        with self._lock:
            device_id = self.credentials.get(credential)
            if device_id is not None:
                return None
            for revoked_device in self.revoked_devices:
                enrollment = self.enrollments.get(revoked_device, {})
                if enrollment.get("credential") == credential:
                    return "credential_revoked"
        return "invalid_credential"

    def credential_device_id(self, authorization: str | None) -> str | None:
        if not authorization or not authorization.startswith("Bearer "):
            return None
        credential = authorization.removeprefix("Bearer ")
        with self._lock:
            return self.credentials.get(credential)

    def renew(
        self, payload: Mapping[str, Any], authorization: str | None
    ) -> dict[str, Any]:
        device_id = self.credential_device_id(authorization)
        if device_id is None:
            raise SimulatorRequestError("invalid_credential")
        if payload.get("device_id") != device_id:
            raise SimulatorRequestError("device_id mismatch")
        with self._lock:
            enrollment = self.enrollments.get(device_id)
            if enrollment is None:
                raise SimulatorRequestError("device not enrolled")
            public = enrollment.get("public_key")
        _verify_signed_payload(payload, public)
        issued = datetime.now(timezone.utc)
        new_credential = f"sim-{uuid.uuid4()}"
        renewed = {
            "schema_version": 1,
            "device_id": device_id,
            "credential": new_credential,
            "issued_at": issued.isoformat().replace("+00:00", "Z"),
            "expires_at": (
                issued + timedelta(seconds=self.credential_lifetime_seconds)
            ).isoformat().replace("+00:00", "Z"),
            "status": "renewed",
        }
        old_credential = authorization.removeprefix("Bearer ") if authorization else ""
        with self._lock:
            self.credentials.pop(old_credential, None)
            self.credentials[new_credential] = device_id
            enrollment.update(renewed)
            enrollment["public_key"] = public
        return renewed


    def authenticate_request(self, payload: Mapping[str, Any], authorization: str | None) -> tuple[str, str]:
        auth_error = self.authorization_error(authorization)
        if auth_error:
            raise SimulatorRequestError(auth_error)
        device_id = self.credential_device_id(authorization)
        auth = payload.get("xmp_authentication")
        if not isinstance(auth, Mapping):
            if self.allow_legacy_bearer_auth:
                return device_id or "", str(uuid.uuid4())
            raise SimulatorRequestError("authentication_required")
        if device_id is None or auth.get("device_id") != device_id:
            raise SimulatorRequestError("authentication_failed")
        request_id = auth.get("request_id")
        nonce = auth.get("nonce")
        sent_at = auth.get("sent_at")
        signature = auth.get("signature")
        if not all(isinstance(value, str) and value for value in (request_id, nonce, sent_at, signature)):
            raise SimulatorRequestError("authentication_failed")
        try:
            timestamp = datetime.fromisoformat(sent_at.replace("Z", "+00:00")).astimezone(timezone.utc)
        except ValueError as error:
            raise SimulatorRequestError("authentication_failed") from error
        if abs((datetime.now(timezone.utc) - timestamp).total_seconds()) > self.authentication_window_seconds:
            raise SimulatorRequestError("timestamp_out_of_window")
        with self._lock:
            if nonce in self.seen_nonces:
                raise SimulatorRequestError("replay_detected")
            enrollment = self.enrollments.get(device_id)
            if enrollment is None:
                raise SimulatorRequestError("authentication_failed")
            public = enrollment.get("public_key")
        unsigned_auth = {k: auth[k] for k in ("schema_version", "request_id", "nonce", "sent_at", "device_id", "key_id") if k in auth}
        unsigned_payload = dict(payload)
        unsigned_payload.pop("xmp_authentication", None)
        try:
            _verify_signature({"authentication": unsigned_auth, "payload": unsigned_payload}, signature, public)
        except SimulatorRequestError as error:
            raise SimulatorRequestError("authentication_failed") from error
        with self._lock:
            self.seen_nonces[nonce] = time.time()
        return device_id, request_id

    def credential_is_valid(self, authorization: str | None) -> bool:
        if not authorization or not authorization.startswith("Bearer "):
            return False
        credential = authorization.removeprefix("Bearer ")
        with self._lock:
            return credential in self.credentials


class SimulatorHttpServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, address: tuple[str, int], state: SimulatorState) -> None:
        self.state = state
        super().__init__(address, SimulatorRequestHandler)


class SimulatorRequestHandler(BaseHTTPRequestHandler):
    server: SimulatorHttpServer
    protocol_version = "HTTP/1.1"

    def log_message(self, format: str, *args: object) -> None:
        logger.debug("xms_simulator_http " + format, *args)

    def do_GET(self) -> None:  # noqa: N802
        if self.path == f"{ADMIN_BASE_PATH}/state":
            self._send_json(HTTPStatus.OK, self.server.state.snapshot())
            return
        if self.path == f"{ADMIN_BASE_PATH}/health":
            self._send_json(HTTPStatus.OK, {"status": "ok"})
            return
        self._send_json(HTTPStatus.NOT_FOUND, {"error": "not_found"})

    def do_DELETE(self) -> None:  # noqa: N802
        if self.path == f"{ADMIN_BASE_PATH}/state":
            self.server.state.reset()
            self._send_json(HTTPStatus.OK, {"reset": True})
            return
        self._send_json(HTTPStatus.NOT_FOUND, {"error": "not_found"})

    def do_POST(self) -> None:  # noqa: N802
        try:
            payload = self._read_json()
        except SimulatorRequestError as error:
            self._send_json(HTTPStatus.BAD_REQUEST, {"error": str(error)})
            return

        self.server.state.record_request("POST", self.path, payload)
        fault = self.server.state.next_fault()
        if fault is not None and self._apply_fault(fault):
            return

        if self.path == f"{XMP_BASE_PATH}/heartbeats":
            if not isinstance(payload, dict):
                self._send_json(HTTPStatus.BAD_REQUEST, {"error": "object_required"})
                return
            try:
                _device_id, request_id = self.server.state.authenticate_request(payload, self.headers.get("Authorization"))
            except SimulatorRequestError as error:
                code = str(error)
                status = HTTPStatus.FORBIDDEN if code == "credential_revoked" else HTTPStatus.UNAUTHORIZED
                self._send_json(status, {"error": code})
                return
            response = self.server.state.accept_heartbeat(payload)
            response["request_id"] = request_id
            self._send_json(HTTPStatus.ACCEPTED, response)
            return

        if self.path == f"{XMP_BASE_PATH}/credentials/renew":
            if not isinstance(payload, dict):
                self._send_json(HTTPStatus.BAD_REQUEST, {"error": "object_required"})
                return
            try:
                _device_id, request_id = self.server.state.authenticate_request(payload, self.headers.get("Authorization"))
                response = self.server.state.renew(
                    payload, self.headers.get("Authorization")
                )
                response["request_id"] = request_id
            except SimulatorRequestError as error:
                status = (
                    HTTPStatus.UNAUTHORIZED
                    if str(error) == "invalid_credential"
                    else HTTPStatus.BAD_REQUEST
                )
                self._send_json(status, {"error": str(error)})
                return
            self._send_json(HTTPStatus.OK, response)
            return

        if self.path == f"{XMP_BASE_PATH}/devices/unenroll":
            if not isinstance(payload, dict):
                self._send_json(HTTPStatus.BAD_REQUEST, {"error": "object_required"})
                return
            try:
                _device_id, request_id = self.server.state.authenticate_request(payload, self.headers.get("Authorization"))
                response = self.server.state.unenroll(payload, self.headers.get("Authorization"))
                response["request_id"] = request_id
            except SimulatorRequestError as error:
                status = HTTPStatus.UNAUTHORIZED if str(error) == "invalid_credential" else HTTPStatus.BAD_REQUEST
                self._send_json(status, {"error": str(error)})
                return
            self._send_json(HTTPStatus.OK, response)
            return

        if self.path == f"{XMP_BASE_PATH}/enrollments":
            if not self._authorized():
                self._send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_token"})
                return
            if not isinstance(payload, dict):
                self._send_json(HTTPStatus.BAD_REQUEST, {"error": "object_required"})
                return
            try:
                response = self.server.state.enroll(payload)
            except SimulatorRequestError as error:
                self._send_json(HTTPStatus.BAD_REQUEST, {"error": str(error)})
                return
            self._send_json(HTTPStatus.CREATED, response)
            return

        if self.path == f"{ADMIN_BASE_PATH}/heartbeat-settings":
            if not isinstance(payload, dict):
                self._send_json(HTTPStatus.BAD_REQUEST, {"error": "object_required"})
                return
            value = payload.get("next_heartbeat_seconds")
            if value is not None and (isinstance(value, bool) or not isinstance(value, int)):
                self._send_json(HTTPStatus.BAD_REQUEST, {"error": "invalid_interval"})
                return
            self.server.state.next_heartbeat_seconds = value
            self._send_json(HTTPStatus.OK, {"next_heartbeat_seconds": value})
            return

        if self.path == f"{ADMIN_BASE_PATH}/commands":
            if not isinstance(payload, dict):
                self._send_json(HTTPStatus.BAD_REQUEST, {"error": "object_required"})
                return
            self._send_json(HTTPStatus.CREATED, self.server.state.queue_command(payload))
            return

        if self.path == f"{ADMIN_BASE_PATH}/policies":
            if not isinstance(payload, dict):
                self._send_json(HTTPStatus.BAD_REQUEST, {"error": "object_required"})
                return
            self._send_json(HTTPStatus.CREATED, self.server.state.queue_policy(payload))
            return

        if self.path == f"{ADMIN_BASE_PATH}/revocations":
            if not isinstance(payload, dict) or not isinstance(payload.get("device_id"), str):
                self._send_json(HTTPStatus.BAD_REQUEST, {"error": "device_id_required"})
                return
            reason = str(payload.get("reason") or "administrator_revocation")
            revoked = self.server.state.revoke_device(payload["device_id"], reason)
            self._send_json(HTTPStatus.OK if revoked else HTTPStatus.NOT_FOUND, {"revoked": revoked, "device_id": payload["device_id"], "reason": reason})
            return

        if self.path == f"{ADMIN_BASE_PATH}/faults":
            if not isinstance(payload, dict):
                self._send_json(HTTPStatus.BAD_REQUEST, {"error": "object_required"})
                return
            try:
                plan = FaultPlan(
                    status=_optional_int(payload.get("status")),
                    delay_seconds=float(payload.get("delay_seconds", 0.0)),
                    malformed_json=bool(payload.get("malformed_json", False)),
                    drop_connection=bool(payload.get("drop_connection", False)),
                    remaining=int(payload.get("remaining", 1)),
                )
                self.server.state.replace_fault(plan)
            except (TypeError, ValueError, SimulatorRequestError) as error:
                self._send_json(HTTPStatus.BAD_REQUEST, {"error": str(error)})
                return
            self._send_json(HTTPStatus.OK, asdict(plan))
            return

        self._send_json(HTTPStatus.NOT_FOUND, {"error": "not_found"})

    def _authorized(self) -> bool:
        expected = self.server.state.enrollment_token
        if not expected:
            return True
        return self.headers.get("Authorization") == f"Bearer {expected}"

    def _read_json(self) -> Any:
        length_header = self.headers.get("Content-Length")
        if length_header is None:
            raise SimulatorRequestError("Content-Length obligatori")
        try:
            length = int(length_header)
        except ValueError as error:
            raise SimulatorRequestError("Content-Length no vàlid") from error
        if length < 0 or length > MAX_REQUEST_BYTES:
            raise SimulatorRequestError("cos de petició massa gran")
        body = self.rfile.read(length)
        encoding = self.headers.get("Content-Encoding", "").strip().lower()
        if encoding:
            if encoding != "gzip":
                raise SimulatorRequestError("Content-Encoding no suportat")
            try:
                body = gzip.decompress(body)
            except (OSError, EOFError) as error:
                raise SimulatorRequestError("gzip no vàlid") from error
            if len(body) > MAX_REQUEST_BYTES:
                raise SimulatorRequestError("cos de petició descomprimit massa gran")
        try:
            return json.loads(body.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise SimulatorRequestError("JSON no vàlid") from error

    def _apply_fault(self, fault: FaultPlan) -> bool:
        if fault.delay_seconds:
            time.sleep(fault.delay_seconds)
        if fault.drop_connection:
            try:
                self.connection.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            self.connection.close()
            return True
        if fault.malformed_json:
            body = b"{malformed"
            self.send_response(fault.status or HTTPStatus.OK)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return True
        if fault.status is not None:
            self._send_json(fault.status, {"error": "simulated_fault"})
            return True
        return False

    def _send_json(self, status: int | HTTPStatus, payload: Mapping[str, Any]) -> None:
        body = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
        use_gzip = "gzip" in self.headers.get("Accept-Encoding", "").lower() and len(body) >= 128
        if use_gzip:
            body = gzip.compress(body, mtime=0)
        self.send_response(int(status))
        self.send_header("Content-Type", "application/json")
        if use_gzip:
            self.send_header("Content-Encoding", "gzip")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(body)


def _verify_signature(
    unsigned: Mapping[str, Any], signature_text: str, public: Mapping[str, Any] | None
) -> None:
    if not isinstance(public, Mapping) or public.get("algorithm") != "Ed25519":
        raise SimulatorRequestError("clau pública absent o no suportada")
    pem = public.get("public_key_pem")
    if not isinstance(pem, str):
        raise SimulatorRequestError("clau pública absent")
    try:
        key = serialization.load_pem_public_key(pem.encode("ascii"))
        signature = base64.b64decode(signature_text, validate=True)
        if not isinstance(key, Ed25519PublicKey):
            raise SimulatorRequestError("la clau pública no és Ed25519")
        key.verify(signature, canonical_json(unsigned))
    except (ValueError, TypeError, InvalidSignature, UnicodeEncodeError) as error:
        raise SimulatorRequestError("signatura no vàlida") from error


def _verify_signed_payload(
    payload: Mapping[str, Any], public: Mapping[str, Any] | None
) -> None:
    signature_text = payload.get("signature")
    if not isinstance(signature_text, str) or not isinstance(public, Mapping):
        raise SimulatorRequestError("signatura o clau pública absent")
    if public.get("algorithm") != "Ed25519":
        raise SimulatorRequestError("algoritme de clau no suportat")
    pem = public.get("public_key_pem")
    if not isinstance(pem, str):
        raise SimulatorRequestError("clau pública absent")
    unsigned = dict(payload)
    unsigned.pop("signature", None)
    try:
        key = serialization.load_pem_public_key(pem.encode("ascii"))
        signature = base64.b64decode(signature_text, validate=True)
        if not isinstance(key, Ed25519PublicKey):
            raise SimulatorRequestError("la clau pública no és Ed25519")
        key.verify(signature, canonical_json(unsigned))
    except (ValueError, TypeError, InvalidSignature, UnicodeEncodeError) as error:
        raise SimulatorRequestError("signatura no vàlida") from error


def _verify_enrollment_signature(payload: Mapping[str, Any]) -> None:
    public = payload.get("public_key")
    _verify_signed_payload(payload, public if isinstance(public, Mapping) else None)


def _optional_int(value: Any) -> int | None:
    if value is None:
        return None
    return int(value)


class XmsSimulator:
    """Servidor XMP local reutilitzable en proves i desenvolupament."""

    def __init__(
        self,
        host: str = "127.0.0.1",
        port: int = 0,
        *,
        enrollment_token: str | None = None,
        credential_lifetime_seconds: int = 86400,
        allow_legacy_bearer_auth: bool = False,
    ) -> None:
        self.state = SimulatorState(
            enrollment_token=enrollment_token,
            credential_lifetime_seconds=credential_lifetime_seconds,
            allow_legacy_bearer_auth=allow_legacy_bearer_auth,
        )
        self._server = SimulatorHttpServer((host, port), self.state)
        self._thread: threading.Thread | None = None

    @property
    def host(self) -> str:
        return str(self._server.server_address[0])

    @property
    def port(self) -> int:
        return int(self._server.server_address[1])

    @property
    def base_url(self) -> str:
        return f"http://{self.host}:{self.port}"

    def start(self) -> "XmsSimulator":
        if self._thread is not None:
            return self
        self._thread = threading.Thread(
            target=self._server.serve_forever,
            name="xaac-xms-simulator",
            daemon=True,
        )
        self._thread.start()
        return self

    def stop(self) -> None:
        if self._thread is None:
            return
        self._server.shutdown()
        self._server.server_close()
        self._thread.join(timeout=5)
        self._thread = None

    def __enter__(self) -> "XmsSimulator":
        return self.start()

    def __exit__(self, exc_type: object, exc: object, traceback: object) -> None:
        del exc_type, exc, traceback
        self.stop()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Simulador local de XAAC Management Server")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8088)
    parser.add_argument("--enrollment-token")
    parser.add_argument("--ready-file", type=Path)
    parser.add_argument(
        "--log-level",
        default="INFO",
        choices=("DEBUG", "INFO", "WARNING", "ERROR"),
    )
    return parser


def main() -> int:
    args = build_parser().parse_args()
    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )
    simulator = XmsSimulator(
        args.host,
        args.port,
        enrollment_token=args.enrollment_token,
    )
    try:
        simulator.start()
        if args.ready_file is not None:
            args.ready_file.parent.mkdir(parents=True, exist_ok=True)
            args.ready_file.write_text(simulator.base_url + "\n", encoding="utf-8")
        logger.info("xms_simulator_started url=%s", simulator.base_url)
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        logger.info("xms_simulator_stop_requested")
    finally:
        simulator.stop()
        if args.ready_file is not None:
            args.ready_file.unlink(missing_ok=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

from __future__ import annotations

import random
import time
from dataclasses import dataclass
from typing import Callable


Clock = Callable[[], float]
RandomSource = Callable[[], float]


@dataclass(frozen=True, slots=True)
class RetryDecision:
    allowed: bool
    delay_seconds: float
    consecutive_failures: int
    circuit_open: bool


class RetryController:
    """Backoff exponencial amb jitter i tallacircuits monotònic."""

    def __init__(
        self,
        *,
        base_delay_seconds: float,
        max_delay_seconds: float,
        jitter_ratio: float,
        circuit_failure_threshold: int,
        circuit_open_seconds: float,
        clock: Clock = time.monotonic,
        random_source: RandomSource = random.random,
    ) -> None:
        self._base = base_delay_seconds
        self._maximum = max_delay_seconds
        self._jitter_ratio = jitter_ratio
        self._threshold = circuit_failure_threshold
        self._open_seconds = circuit_open_seconds
        self._clock = clock
        self._random = random_source
        self._failures = 0
        self._next_attempt_at = 0.0
        self._circuit_open_until = 0.0

    @property
    def consecutive_failures(self) -> int:
        return self._failures

    @property
    def circuit_open(self) -> bool:
        return self._clock() < self._circuit_open_until

    def before_attempt(self) -> RetryDecision:
        now = self._clock()
        blocked_until = max(self._next_attempt_at, self._circuit_open_until)
        delay = max(0.0, blocked_until - now)
        return RetryDecision(
            allowed=delay <= 0.0,
            delay_seconds=delay,
            consecutive_failures=self._failures,
            circuit_open=now < self._circuit_open_until,
        )

    def restore(self, *, consecutive_failures: int, delay_seconds: float) -> None:
        """Restaura el backoff persistent després d'un reinici del procés."""
        self._failures = max(0, int(consecutive_failures))
        self._next_attempt_at = self._clock() + max(0.0, float(delay_seconds))
        self._circuit_open_until = 0.0

    def record_success(self) -> None:
        self._failures = 0
        self._next_attempt_at = 0.0
        self._circuit_open_until = 0.0

    def record_failure(self, *, retryable: bool, retry_after_seconds: float | None = None) -> RetryDecision:
        now = self._clock()
        if not retryable:
            self._failures = 0
            self._next_attempt_at = 0.0
            return RetryDecision(True, 0.0, 0, self.circuit_open)

        self._failures += 1
        exponential = min(self._maximum, self._base * (2 ** (self._failures - 1)))
        jitter = exponential * self._jitter_ratio * ((self._random() * 2.0) - 1.0)
        delay = max(0.0, exponential + jitter)
        if retry_after_seconds is not None:
            delay = max(delay, min(float(retry_after_seconds), self._maximum))
        self._next_attempt_at = now + delay

        if self._failures >= self._threshold:
            self._circuit_open_until = max(self._circuit_open_until, now + self._open_seconds)
            delay = max(delay, self._open_seconds)

        return RetryDecision(False, delay, self._failures, self.circuit_open)

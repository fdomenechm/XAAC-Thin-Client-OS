from __future__ import annotations

from collections import Counter, deque
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Callable, Mapping


_SEVERITIES = ("normal", "warning", "critical")


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


@dataclass(frozen=True, slots=True)
class MonitoringSnapshot:
    sampled_at: datetime
    payload: dict[str, object]


class MonitoringAggregator:
    """Manté una finestra limitada i genera resums compactes de telemetria."""

    def __init__(
        self,
        *,
        window_samples: int = 60,
        now: Callable[[], datetime] = _utc_now,
    ) -> None:
        if not 1 <= window_samples <= 1440:
            raise ValueError("window_samples fora de rang")
        self._snapshots: deque[MonitoringSnapshot] = deque(maxlen=window_samples)
        self._now = now

    @property
    def sample_count(self) -> int:
        return len(self._snapshots)

    def reset(self) -> None:
        self._snapshots.clear()

    def add(self, payload: Mapping[str, object]) -> dict[str, object]:
        snapshot = MonitoringSnapshot(self._now(), dict(payload))
        self._snapshots.append(snapshot)
        return self.summary()

    def summary(self) -> dict[str, object]:
        if not self._snapshots:
            return {
                "sample_count": 0,
                "window_capacity": self._snapshots.maxlen or 0,
                "metrics": {},
                "severity_counts": {},
            }
        metrics: dict[str, list[float]] = {}
        severities: Counter[str] = Counter()
        for snapshot in self._snapshots:
            self._collect_numeric(snapshot.payload, "", metrics)
            self._collect_severities(snapshot.payload, severities)
        metric_summary = {
            path: {
                "minimum": round(min(values), 3),
                "average": round(sum(values) / len(values), 3),
                "maximum": round(max(values), 3),
                "samples": len(values),
            }
            for path, values in sorted(metrics.items())
            if values
        }
        first = self._snapshots[0].sampled_at
        last = self._snapshots[-1].sampled_at
        return {
            "sample_count": len(self._snapshots),
            "window_capacity": self._snapshots.maxlen or 0,
            "first_sample_at": _iso(first),
            "last_sample_at": _iso(last),
            "window_seconds": max(0.0, round((last - first).total_seconds(), 3)),
            "metrics": metric_summary,
            "severity_counts": {key: severities[key] for key in _SEVERITIES if severities[key]},
        }

    @classmethod
    def _collect_numeric(
        cls,
        value: object,
        path: str,
        result: dict[str, list[float]],
    ) -> None:
        if isinstance(value, bool):
            return
        if isinstance(value, (int, float)):
            if path and cls._is_metric_path(path):
                result.setdefault(path, []).append(float(value))
            return
        if isinstance(value, Mapping):
            for key, child in value.items():
                if not isinstance(key, str):
                    continue
                child_path = f"{path}.{key}" if path else key
                cls._collect_numeric(child, child_path, result)
        # Les llistes de dispositius no s'agreguen per evitar cardinalitat variable.

    @staticmethod
    def _is_metric_path(path: str) -> bool:
        excluded_suffixes = (
            "_count", "_bytes", "_pid", "_pids", "port", "logical_cpus",
            "sample_count", "window_capacity", "samples",
        )
        return not path.endswith(excluded_suffixes)

    @classmethod
    def _collect_severities(cls, value: object, result: Counter[str]) -> None:
        if isinstance(value, Mapping):
            severity = value.get("severity")
            if isinstance(severity, str) and severity in _SEVERITIES:
                result[severity] += 1
            for child in value.values():
                cls._collect_severities(child, result)

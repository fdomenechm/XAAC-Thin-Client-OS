from __future__ import annotations

import re
import subprocess
from dataclasses import dataclass
from datetime import datetime, timezone
from types import MappingProxyType
from typing import Mapping, Protocol

from xaac_agent.command_model import Command, CommandResult, CommandState


@dataclass(frozen=True, slots=True)
class LogSource:
    source_id: str
    journal_args: tuple[str, ...]


class LogBackend(Protocol):
    def run(self, argv: list[str], *, timeout: int) -> subprocess.CompletedProcess[str]: ...


class SubprocessLogBackend:
    def run(self, argv: list[str], *, timeout: int) -> subprocess.CompletedProcess[str]:
        return subprocess.run(argv, capture_output=True, text=True, timeout=timeout, check=False)


_DEFAULT_SOURCES: Mapping[str, LogSource] = MappingProxyType({
    "agent": LogSource("agent", ("--unit=xaac-agent.service",)),
    "kernel": LogSource("kernel", ("--dmesg",)),
})
_SECRET_PATTERNS = (
    re.compile(r"(?i)\b(authorization\s*[:=]\s*bearer\s+)[^\s,;]+"),
    re.compile(r"(?i)\b(password|passwd|secret|token|api[_-]?key)\s*[:=]\s*[^\s,;]+"),
)


def _redact(line: str) -> str:
    value = line.replace("\x00", "")
    value = _SECRET_PATTERNS[0].sub(r"\1[REDACTED]", value)
    value = _SECRET_PATTERNS[1].sub(lambda match: f"{match.group(1)}=[REDACTED]", value)
    return value[:2048]


class LogCollectionCommandExecutor:
    def __init__(
        self,
        backend: LogBackend | None = None,
        sources: Mapping[str, LogSource] | None = None,
        *,
        max_lines: int = 500,
        max_bytes: int = 65536,
        max_since_seconds: int = 86400,
    ) -> None:
        self._backend = backend or SubprocessLogBackend()
        self._sources = dict(sources or _DEFAULT_SOURCES)
        self._max_lines = max_lines
        self._max_bytes = max_bytes
        self._max_since_seconds = max_since_seconds

    @classmethod
    def system_default(cls, **kwargs: object) -> "LogCollectionCommandExecutor":
        return cls(**kwargs)

    def execute(self, command: Command) -> CommandResult:
        started = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        parameters = command.parameters
        source_ids = parameters["source_ids"]
        lines_limit = min(int(parameters.get("max_lines", self._max_lines)), self._max_lines)
        bytes_limit = min(int(parameters.get("max_bytes", self._max_bytes)), self._max_bytes)
        since_seconds = min(int(parameters.get("since_seconds", 3600)), self._max_since_seconds)
        timeout = int(parameters.get("timeout_seconds", 30))
        entries: list[str] = []
        used_bytes = 0
        truncated = False

        try:
            for source_id in source_ids:
                source = self._sources.get(source_id)
                if source is None:
                    return self._result(command, started, CommandState.FAILED, "log_source_unavailable", {"source_id": source_id})
                argv = [
                    "/usr/bin/journalctl", "--no-pager", "--output=short-iso", "--quiet",
                    f"--since=-{since_seconds} seconds", f"--lines={lines_limit}", *source.journal_args,
                ]
                completed = self._backend.run(argv, timeout=timeout)
                if completed.returncode != 0:
                    return self._result(command, started, CommandState.FAILED, "log_collection_failed", {
                        "source_id": source_id, "returncode": completed.returncode,
                        "error": _redact((completed.stderr or "journalctl failed").strip())[:512],
                    })
                for raw_line in completed.stdout.splitlines():
                    line = _redact(raw_line)
                    size = len(line.encode("utf-8")) + 1
                    if len(entries) >= lines_limit or used_bytes + size > bytes_limit:
                        truncated = True
                        break
                    entries.append(line)
                    used_bytes += size
                if truncated:
                    break
        except subprocess.TimeoutExpired:
            return self._result(command, started, CommandState.FAILED, "log_collection_timeout", {})
        except (OSError, ValueError) as error:
            return self._result(command, started, CommandState.FAILED, "log_collection_backend_error", {"error": _redact(str(error))[:512]})

        return self._result(command, started, CommandState.SUCCEEDED, "logs_collected", {
            "source_ids": list(source_ids), "entries": entries, "line_count": len(entries),
            "byte_count": used_bytes, "truncated": truncated, "redacted": True,
        })

    @staticmethod
    def _result(command: Command, started: str, state: CommandState, code: str, data: dict[str, object]) -> CommandResult:
        return CommandResult(
            command_id=command.command_id, state=state, started_at=started,
            finished_at=datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"), code=code, data=data,
        )

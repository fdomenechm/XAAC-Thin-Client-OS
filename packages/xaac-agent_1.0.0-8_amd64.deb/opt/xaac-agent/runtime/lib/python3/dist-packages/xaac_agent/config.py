from __future__ import annotations

from configparser import ConfigParser
from dataclasses import dataclass, fields, replace
from pathlib import Path


class AgentConfigurationError(ValueError):
    """Configuració local de l'agent no vàlida."""


RESTART_REQUIRED_FIELDS = frozenset(
    {
        "enrollment_token_file",
        "device_identity_file",
        "device_private_key_file",
        "device_credentials_file",
        "outbox_file",
        "xms_address_state_file",
        "xms_failover_state_file",
        "safe_mode_state_file",
        "runtime_directory",
        "state_directory",
        "cache_directory",
        "log_directory",
        "policy_cache_directory",
        "update_cache_directory",
        "update_rollback_state_file",
            "update_report_file",
        "policy_application_directory",
        "policy_local_overlay_file",
        "policy_audit_file",
        "local_audit_file",
        "thin_client_runtime_directory",
        "thin_client_state_directory",
        "thin_client_config_directory",
        "thin_client_command_directory",
    }
)


@dataclass(frozen=True, slots=True)
class AgentSettings:
    server_url: str = ""
    enrollment_token_file: Path = Path("var/dev/enrollment.token")
    device_identity_file: Path = Path("var/dev/state/device.json")
    device_private_key_file: Path = Path("var/dev/state/device-key.pem")
    device_credentials_file: Path = Path("var/dev/state/device-credentials.json")
    outbox_file: Path = Path("var/dev/state/outbox.json")
    outbox_max_messages: int = 512
    outbox_max_bytes: int = 4194304
    outbox_batch_size: int = 64
    outbox_default_ttl_seconds: int = 604800
    critical_message_priority: int = 80
    runtime_directory: Path = Path("var/dev/runtime")
    state_directory: Path = Path("var/dev/state")
    cache_directory: Path = Path("var/dev/cache")
    log_directory: Path = Path("var/dev/logs")
    heartbeat_interval_seconds: int = 60
    heartbeat_min_interval_seconds: int = 10
    heartbeat_max_interval_seconds: int = 86400
    inventory_full_interval_heartbeats: int = 1440
    monitoring_enabled: bool = True
    monitoring_window_samples: int = 5
    monitoring_aggregation_window_samples: int = 60
    adaptive_delivery_enabled: bool = True
    adaptive_warning_interval_seconds: int = 30
    adaptive_critical_interval_seconds: int = 10
    adaptive_normal_relax_after_samples: int = 10
    adaptive_normal_interval_multiplier: float = 2.0
    adaptive_reduced_outbox_batch_size: int = 16
    adaptive_offline_outbox_batch_size: int = 8
    local_alerts_enabled: bool = True
    local_alert_recovery_enabled: bool = True
    local_alert_ttl_seconds: int = 604800
    local_alert_warning_priority: int = 70
    local_alert_critical_priority: int = 90
    cpu_warning_percent: float = 80.0
    cpu_critical_percent: float = 95.0
    memory_warning_percent: float = 80.0
    memory_critical_percent: float = 95.0
    load_warning_per_cpu: float = 1.0
    load_critical_per_cpu: float = 2.0
    monitoring_hysteresis_percent: float = 5.0
    disk_warning_percent: float = 80.0
    disk_critical_percent: float = 95.0
    temperature_warning_celsius: float = 75.0
    temperature_critical_celsius: float = 90.0
    temperature_hysteresis_celsius: float = 3.0
    critical_processes: tuple[str, ...] = ()
    critical_services: tuple[str, ...] = ()
    service_check_timeout_seconds: float = 2.0
    network_warning_error_percent: float = 1.0
    network_critical_error_percent: float = 5.0
    network_hysteresis_percent: float = 0.5
    connectivity_check_enabled: bool = False
    connectivity_timeout_seconds: float = 2.0
    connectivity_warning_latency_ms: float = 500.0
    connectivity_critical_latency_ms: float = 2000.0
    connectivity_hysteresis_ms: float = 100.0
    certificate_monitoring_enabled: bool = False
    tpm_enabled: bool = False
    tpm_required: bool = False
    tpm_device_path: Path = Path("/dev/tpmrm0")
    tpm_pcr_bank: str = "sha256"
    tpm_pcrs: tuple[int, ...] = (0, 2, 4, 7)
    tpm_command_timeout_seconds: float = 3.0
    boot_security_enabled: bool = True
    boot_require_uefi: bool = False
    boot_require_secure_boot: bool = False
    boot_efi_variables_path: Path = Path("/sys/firmware/efi/efivars")
    boot_kernel_lockdown_path: Path = Path("/sys/kernel/security/lockdown")
    file_integrity_enabled: bool = False
    file_integrity_required: bool = False
    file_integrity_manifest_path: Path = Path("/usr/share/xaac-agent/integrity-manifest.json")
    file_integrity_max_manifest_bytes: int = 262144
    file_integrity_max_files: int = 512
    file_integrity_max_file_bytes: int = 33554432
    compromise_response_enabled: bool = False
    compromise_automatic_quarantine: bool = False
    compromise_state_file: Path = Path("/var/lib/xaac-agent/compromise-state.json")
    compromise_block_remote_commands: bool = True
    compromise_block_updates: bool = True
    compromise_allow_heartbeat: bool = True
    compromise_max_state_bytes: int = 65536
    certificate_check_timeout_seconds: float = 2.0
    certificate_warning_days: int = 30
    certificate_critical_days: int = 7
    request_timeout_seconds: float = 5.0
    max_response_bytes: int = 1048576
    max_decompressed_response_bytes: int = 4194304
    compression_enabled: bool = True
    compression_threshold_bytes: int = 1024
    proxy_url: str = ""
    tls_ca_file: Path | None = None
    tls_minimum_version: str = "TLSv1.2"
    tls_maximum_version: str = ""
    tls_ciphers: str = ""
    tls_certificate_pins: tuple[str, ...] = ()
    retry_base_delay_seconds: float = 5.0
    retry_max_delay_seconds: float = 300.0
    retry_jitter_ratio: float = 0.20
    circuit_failure_threshold: int = 5
    circuit_open_seconds: float = 120.0
    offline_prolonged_threshold_seconds: int = 3600
    xms_address_state_file: Path = Path("var/dev/state/xms-address.json")
    xms_address_require_https: bool = True
    xms_authorized_alternate_urls: tuple[str, ...] = ()
    xms_failover_state_file: Path = Path("var/dev/state/xms-failover.json")
    xms_failover_failure_threshold: int = 3
    safe_mode_state_file: Path = Path("var/dev/state/safe-mode.json")
    credential_renew_before_seconds: int = 3600
    credential_clock_skew_tolerance_seconds: int = 300
    command_allowed_types: tuple[str, ...] = ()
    command_local_capabilities: tuple[str, ...] = ()
    command_allowed_issuer_kinds: tuple[str, ...] = ("xms",)
    command_agent_user: str = "xaac-agent"
    command_privileged_helper_user: str = "xaac-command-helper"
    command_allowed_services: tuple[str, ...] = ()
    command_allowed_tasks: tuple[str, ...] = ()
    command_allowed_file_targets: tuple[str, ...] = ()
    command_allowed_log_sources: tuple[str, ...] = ()
    command_allowed_signed_scripts: tuple[str, ...] = ()
    command_trusted_script_keys: tuple[str, ...] = ()
    command_max_script_bytes: int = 1048576
    command_max_log_lines: int = 500
    command_max_log_bytes: int = 65536
    command_max_log_since_seconds: int = 86400
    command_max_file_bytes: int = 16777216
    command_max_delay_seconds: int = 300
    command_max_timeout_seconds: int = 300
    command_max_lifetime_seconds: int = 86400
    command_replay_window_seconds: int = 900
    command_clock_skew_seconds: int = 300
    command_require_nonce: bool = False
    command_reject_id_reuse: bool = False
    command_max_per_response: int = 32
    command_audit_max_records: int = 1024
    local_audit_enabled: bool = True
    local_audit_file: Path = Path("var/dev/state/local-audit.json")
    local_audit_max_records: int = 2048
    local_audit_max_bytes: int = 2097152
    policy_cache_directory: Path = Path("var/dev/cache/policies")
    update_cache_directory: Path = Path("var/dev/cache/updates")
    update_max_artifact_bytes: int = 536870912
    update_download_timeout_seconds: int = 60
    update_cache_max_entries: int = 8
    update_trusted_keys: tuple[str, ...] = ()
    update_allowed_issuer_kinds: tuple[str, ...] = ("xms",)
    update_allowed_components: tuple[str, ...] = ("agent", "thin-client", "debian-packages", "system-component")
    update_agent_package_name: str = "xaac-agent"
    update_agent_timeout_seconds: int = 180
    update_agent_protected_paths: tuple[Path, ...] = ()
    update_thin_client_package_name: str = "xaac-thinclient"
    update_thin_client_systemd_unit: str = "xaac-thin-client.service"
    update_thin_client_timeout_seconds: int = 180
    update_thin_client_protected_paths: tuple[Path, ...] = ()
    update_debian_allowed_packages: tuple[str, ...] = ()
    update_debian_timeout_seconds: int = 900
    update_debian_max_packages: int = 32
    update_debian_allow_new_packages: bool = False
    update_debian_allow_removals: bool = False
    update_maintenance_timezone: str = "UTC"
    update_maintenance_windows: tuple[str, ...] = ()
    update_maintenance_allow_when_unconfigured: bool = False
    update_maintenance_max_schedule_ahead_seconds: int = 604800
    update_reboot_state_file: Path = Path("var/dev/state/update-reboot.json")
    update_reboot_timeout_seconds: int = 30
    update_reboot_delay_seconds: int = 30
    update_reboot_stop_thin_client: bool = True
    update_rollback_state_file: Path = Path("var/dev/state/update-rollback.json")
    update_rollback_max_state_bytes: int = 65536
    update_report_file: Path = Path("var/dev/state/update-reports.json")
    update_report_max_records: int = 128
    update_report_max_bytes: int = 1048576
    policy_application_directory: Path = Path("var/dev/state/policies")
    policy_local_overlay_file: Path = Path("var/dev/state/local-policy.json")
    policy_audit_file: Path = Path("var/dev/state/policy-audit.json")
    policy_audit_max_records: int = 512
    policy_protected_paths: tuple[str, ...] = ()
    policy_max_bytes: int = 2097152
    policy_download_timeout_seconds: int = 30
    policy_cache_max_entries: int = 32
    policy_trusted_keys: tuple[str, ...] = ()
    policy_allowed_issuer_kinds: tuple[str, ...] = ("xms",)
    policy_local_capabilities: tuple[str, ...] = ()
    thin_client_runtime_directory: Path = Path("/run/xaac/thin-client")
    thin_client_state_directory: Path = Path("/var/lib/xaac/thin-client/state")
    thin_client_config_directory: Path = Path("/var/lib/xaac/thin-client/config")
    thin_client_command_directory: Path = Path("/run/xaac/commands")
    thin_client_user: str = "xaac-kiosk"
    thin_client_shared_group: str = "xaac-ipc"
    thin_client_allowed_operations: tuple[str, ...] = ()
    thin_client_state_max_bytes: int = 65536
    thin_client_state_max_age_seconds: int = 180
    thin_client_systemd_unit: str = "xaac-thin-client.service"
    thin_client_systemd_allowed_actions: tuple[str, ...] = ()
    thin_client_systemd_timeout_seconds: int = 30
    thin_client_runtime_max_bytes: int = 65536
    thin_client_runtime_max_events: int = 128
    thin_client_heartbeat_max_age_seconds: int = 180
    thin_client_configuration_max_bytes: int = 262144
    thin_client_diagnostic_directory: Path = Path("/var/lib/xaac-agent/diagnostics/thin-client")
    thin_client_diagnostic_max_log_lines: int = 300
    thin_client_diagnostic_max_log_bytes: int = 65536
    thin_client_diagnostic_max_package_bytes: int = 1048576
    thin_client_diagnostic_timeout_seconds: int = 15
    thin_client_compatibility_min_version: str = "1.0.0"
    thin_client_compatibility_max_version: str = "1.0.99"
    thin_client_contract_versions: tuple[str, ...] = ("xaac-local-integration/v1",)
    thin_client_local_capabilities: tuple[str, ...] = ("state-v2", "supervisor-v1", "runtime-events-v1", "config-v1", "diagnostics-v1")
    allow_http: bool = False
    production_profile_mode: str = "auto"
    enabled: bool = False

    @classmethod
    def load(cls, path: Path) -> "AgentSettings":
        parser = ConfigParser()
        if not path.is_file():
            raise AgentConfigurationError(f"No existeix la configuració: {path}")
        try:
            read_files = parser.read(path, encoding="utf-8")
            if not read_files or "agent" not in parser:
                raise AgentConfigurationError("Falta la secció [agent]")
            section = parser["agent"]
            defaults = cls()
            settings = cls(
                server_url=section.get("server_url", defaults.server_url).strip().rstrip("/"),
                production_profile_mode=section.get("production_profile_mode", defaults.production_profile_mode).strip().lower(),
                enrollment_token_file=Path(section.get("enrollment_token_file", str(defaults.enrollment_token_file))),
                device_identity_file=Path(section.get("device_identity_file", str(defaults.device_identity_file))),
                device_private_key_file=Path(section.get("device_private_key_file", str(defaults.device_private_key_file))),
                device_credentials_file=Path(section.get("device_credentials_file", str(defaults.device_credentials_file))),
                outbox_file=Path(section.get("outbox_file", str(defaults.outbox_file))),
                outbox_max_messages=section.getint("outbox_max_messages", defaults.outbox_max_messages),
                outbox_max_bytes=section.getint("outbox_max_bytes", defaults.outbox_max_bytes),
                outbox_batch_size=section.getint("outbox_batch_size", defaults.outbox_batch_size),
                outbox_default_ttl_seconds=section.getint("outbox_default_ttl_seconds", defaults.outbox_default_ttl_seconds),
                critical_message_priority=section.getint("critical_message_priority", defaults.critical_message_priority),
                runtime_directory=Path(section.get("runtime_directory", str(defaults.runtime_directory))),
                state_directory=Path(section.get("state_directory", str(defaults.state_directory))),
                cache_directory=Path(section.get("cache_directory", str(defaults.cache_directory))),
                log_directory=Path(section.get("log_directory", str(defaults.log_directory))),
                heartbeat_interval_seconds=section.getint("heartbeat_interval_seconds", defaults.heartbeat_interval_seconds),
                heartbeat_min_interval_seconds=section.getint("heartbeat_min_interval_seconds", defaults.heartbeat_min_interval_seconds),
                heartbeat_max_interval_seconds=section.getint("heartbeat_max_interval_seconds", defaults.heartbeat_max_interval_seconds),
                inventory_full_interval_heartbeats=section.getint("inventory_full_interval_heartbeats", defaults.inventory_full_interval_heartbeats),
                monitoring_enabled=section.getboolean("monitoring_enabled", defaults.monitoring_enabled),
                monitoring_window_samples=section.getint("monitoring_window_samples", defaults.monitoring_window_samples),
                monitoring_aggregation_window_samples=section.getint("monitoring_aggregation_window_samples", defaults.monitoring_aggregation_window_samples),
                adaptive_delivery_enabled=section.getboolean("adaptive_delivery_enabled", defaults.adaptive_delivery_enabled),
                adaptive_warning_interval_seconds=section.getint("adaptive_warning_interval_seconds", defaults.adaptive_warning_interval_seconds),
                adaptive_critical_interval_seconds=section.getint("adaptive_critical_interval_seconds", defaults.adaptive_critical_interval_seconds),
                adaptive_normal_relax_after_samples=section.getint("adaptive_normal_relax_after_samples", defaults.adaptive_normal_relax_after_samples),
                adaptive_normal_interval_multiplier=section.getfloat("adaptive_normal_interval_multiplier", defaults.adaptive_normal_interval_multiplier),
                adaptive_reduced_outbox_batch_size=section.getint("adaptive_reduced_outbox_batch_size", defaults.adaptive_reduced_outbox_batch_size),
                adaptive_offline_outbox_batch_size=section.getint("adaptive_offline_outbox_batch_size", defaults.adaptive_offline_outbox_batch_size),
                local_alerts_enabled=section.getboolean("local_alerts_enabled", defaults.local_alerts_enabled),
                local_alert_recovery_enabled=section.getboolean("local_alert_recovery_enabled", defaults.local_alert_recovery_enabled),
                local_alert_ttl_seconds=section.getint("local_alert_ttl_seconds", defaults.local_alert_ttl_seconds),
                local_alert_warning_priority=section.getint("local_alert_warning_priority", defaults.local_alert_warning_priority),
                local_alert_critical_priority=section.getint("local_alert_critical_priority", defaults.local_alert_critical_priority),
                cpu_warning_percent=section.getfloat("cpu_warning_percent", defaults.cpu_warning_percent),
                cpu_critical_percent=section.getfloat("cpu_critical_percent", defaults.cpu_critical_percent),
                memory_warning_percent=section.getfloat("memory_warning_percent", defaults.memory_warning_percent),
                memory_critical_percent=section.getfloat("memory_critical_percent", defaults.memory_critical_percent),
                load_warning_per_cpu=section.getfloat("load_warning_per_cpu", defaults.load_warning_per_cpu),
                load_critical_per_cpu=section.getfloat("load_critical_per_cpu", defaults.load_critical_per_cpu),
                monitoring_hysteresis_percent=section.getfloat("monitoring_hysteresis_percent", defaults.monitoring_hysteresis_percent),
                disk_warning_percent=section.getfloat("disk_warning_percent", defaults.disk_warning_percent),
                disk_critical_percent=section.getfloat("disk_critical_percent", defaults.disk_critical_percent),
                temperature_warning_celsius=section.getfloat("temperature_warning_celsius", defaults.temperature_warning_celsius),
                temperature_critical_celsius=section.getfloat("temperature_critical_celsius", defaults.temperature_critical_celsius),
                temperature_hysteresis_celsius=section.getfloat("temperature_hysteresis_celsius", defaults.temperature_hysteresis_celsius),
                critical_processes=tuple(value.strip() for value in section.get("critical_processes", "").split(",") if value.strip()),
                critical_services=tuple(value.strip() for value in section.get("critical_services", "").split(",") if value.strip()),
                service_check_timeout_seconds=section.getfloat("service_check_timeout_seconds", defaults.service_check_timeout_seconds),
                network_warning_error_percent=section.getfloat("network_warning_error_percent", defaults.network_warning_error_percent),
                network_critical_error_percent=section.getfloat("network_critical_error_percent", defaults.network_critical_error_percent),
                network_hysteresis_percent=section.getfloat("network_hysteresis_percent", defaults.network_hysteresis_percent),
                connectivity_check_enabled=section.getboolean("connectivity_check_enabled", defaults.connectivity_check_enabled),
                connectivity_timeout_seconds=section.getfloat("connectivity_timeout_seconds", defaults.connectivity_timeout_seconds),
                connectivity_warning_latency_ms=section.getfloat("connectivity_warning_latency_ms", defaults.connectivity_warning_latency_ms),
                connectivity_critical_latency_ms=section.getfloat("connectivity_critical_latency_ms", defaults.connectivity_critical_latency_ms),
                connectivity_hysteresis_ms=section.getfloat("connectivity_hysteresis_ms", defaults.connectivity_hysteresis_ms),
                certificate_monitoring_enabled=section.getboolean("certificate_monitoring_enabled", defaults.certificate_monitoring_enabled),
                tpm_enabled=section.getboolean("tpm_enabled", defaults.tpm_enabled),
                tpm_required=section.getboolean("tpm_required", defaults.tpm_required),
                tpm_device_path=Path(section.get("tpm_device_path", str(defaults.tpm_device_path))),
                tpm_pcr_bank=section.get("tpm_pcr_bank", defaults.tpm_pcr_bank).strip().lower(),
                tpm_pcrs=tuple(int(value.strip()) for value in section.get("tpm_pcrs", ",".join(str(v) for v in defaults.tpm_pcrs)).split(",") if value.strip()),
                tpm_command_timeout_seconds=section.getfloat("tpm_command_timeout_seconds", defaults.tpm_command_timeout_seconds),
                boot_security_enabled=section.getboolean("boot_security_enabled", defaults.boot_security_enabled),
                boot_require_uefi=section.getboolean("boot_require_uefi", defaults.boot_require_uefi),
                boot_require_secure_boot=section.getboolean("boot_require_secure_boot", defaults.boot_require_secure_boot),
                boot_efi_variables_path=Path(section.get("boot_efi_variables_path", str(defaults.boot_efi_variables_path))),
                boot_kernel_lockdown_path=Path(section.get("boot_kernel_lockdown_path", str(defaults.boot_kernel_lockdown_path))),
                file_integrity_enabled=section.getboolean("file_integrity_enabled", defaults.file_integrity_enabled),
                file_integrity_required=section.getboolean("file_integrity_required", defaults.file_integrity_required),
                file_integrity_manifest_path=Path(section.get("file_integrity_manifest_path", str(defaults.file_integrity_manifest_path))),
                file_integrity_max_manifest_bytes=section.getint("file_integrity_max_manifest_bytes", defaults.file_integrity_max_manifest_bytes),
                file_integrity_max_files=section.getint("file_integrity_max_files", defaults.file_integrity_max_files),
                file_integrity_max_file_bytes=section.getint("file_integrity_max_file_bytes", defaults.file_integrity_max_file_bytes),
                compromise_response_enabled=section.getboolean("compromise_response_enabled", defaults.compromise_response_enabled),
                compromise_automatic_quarantine=section.getboolean("compromise_automatic_quarantine", defaults.compromise_automatic_quarantine),
                compromise_state_file=Path(section.get("compromise_state_file", str(defaults.compromise_state_file))),
                compromise_block_remote_commands=section.getboolean("compromise_block_remote_commands", defaults.compromise_block_remote_commands),
                compromise_block_updates=section.getboolean("compromise_block_updates", defaults.compromise_block_updates),
                compromise_allow_heartbeat=section.getboolean("compromise_allow_heartbeat", defaults.compromise_allow_heartbeat),
                compromise_max_state_bytes=section.getint("compromise_max_state_bytes", defaults.compromise_max_state_bytes),
                certificate_check_timeout_seconds=section.getfloat("certificate_check_timeout_seconds", defaults.certificate_check_timeout_seconds),
                certificate_warning_days=section.getint("certificate_warning_days", defaults.certificate_warning_days),
                certificate_critical_days=section.getint("certificate_critical_days", defaults.certificate_critical_days),
                request_timeout_seconds=section.getfloat("request_timeout_seconds", defaults.request_timeout_seconds),
                max_response_bytes=section.getint("max_response_bytes", defaults.max_response_bytes),
                max_decompressed_response_bytes=section.getint(
                    "max_decompressed_response_bytes", defaults.max_decompressed_response_bytes
                ),
                compression_enabled=section.getboolean("compression_enabled", defaults.compression_enabled),
                compression_threshold_bytes=section.getint(
                    "compression_threshold_bytes", defaults.compression_threshold_bytes
                ),
                proxy_url=section.get("proxy_url", defaults.proxy_url).strip(),
                tls_ca_file=(Path(value) if (value := section.get("tls_ca_file", "").strip()) else None),
                tls_minimum_version=section.get("tls_minimum_version", defaults.tls_minimum_version).strip(),
                tls_maximum_version=section.get("tls_maximum_version", defaults.tls_maximum_version).strip(),
                tls_ciphers=section.get("tls_ciphers", defaults.tls_ciphers).strip(),
                tls_certificate_pins=tuple(value.strip() for value in section.get("tls_certificate_pins", "").split(",") if value.strip()),
                retry_base_delay_seconds=section.getfloat("retry_base_delay_seconds", defaults.retry_base_delay_seconds),
                retry_max_delay_seconds=section.getfloat("retry_max_delay_seconds", defaults.retry_max_delay_seconds),
                retry_jitter_ratio=section.getfloat("retry_jitter_ratio", defaults.retry_jitter_ratio),
                circuit_failure_threshold=section.getint("circuit_failure_threshold", defaults.circuit_failure_threshold),
                circuit_open_seconds=section.getfloat("circuit_open_seconds", defaults.circuit_open_seconds),
                offline_prolonged_threshold_seconds=section.getint("offline_prolonged_threshold_seconds", defaults.offline_prolonged_threshold_seconds),
                xms_address_state_file=Path(section.get("xms_address_state_file", str(defaults.xms_address_state_file))),
                xms_address_require_https=section.getboolean("xms_address_require_https", defaults.xms_address_require_https),
                xms_authorized_alternate_urls=tuple(value.strip().rstrip("/") for value in section.get("xms_authorized_alternate_urls", "").split(",") if value.strip()),
                xms_failover_state_file=Path(section.get("xms_failover_state_file", str(defaults.xms_failover_state_file))),
                xms_failover_failure_threshold=section.getint("xms_failover_failure_threshold", defaults.xms_failover_failure_threshold),
                safe_mode_state_file=Path(section.get("safe_mode_state_file", str(defaults.safe_mode_state_file))),
                credential_renew_before_seconds=section.getint(
                    "credential_renew_before_seconds", defaults.credential_renew_before_seconds
                ),
                credential_clock_skew_tolerance_seconds=section.getint(
                    "credential_clock_skew_tolerance_seconds",
                    defaults.credential_clock_skew_tolerance_seconds,
                ),
                command_allowed_types=tuple(value.strip() for value in section.get("command_allowed_types", "").split(",") if value.strip()),
                command_local_capabilities=tuple(value.strip() for value in section.get("command_local_capabilities", "").split(",") if value.strip()),
                command_allowed_issuer_kinds=tuple(value.strip().lower() for value in section.get("command_allowed_issuer_kinds", "xms").split(",") if value.strip()),
                command_agent_user=section.get("command_agent_user", defaults.command_agent_user).strip(),
                command_privileged_helper_user=section.get("command_privileged_helper_user", defaults.command_privileged_helper_user).strip(),
                command_allowed_services=tuple(value.strip() for value in section.get("command_allowed_services", "").split(",") if value.strip()),
                command_allowed_tasks=tuple(value.strip() for value in section.get("command_allowed_tasks", "").split(",") if value.strip()),
                command_allowed_file_targets=tuple(value.strip() for value in section.get("command_allowed_file_targets", "").split(",") if value.strip()),
                command_allowed_log_sources=tuple(value.strip() for value in section.get("command_allowed_log_sources", "").split(",") if value.strip()),
                command_allowed_signed_scripts=tuple(value.strip() for value in section.get("command_allowed_signed_scripts", "").split(",") if value.strip()),
                command_trusted_script_keys=tuple(value.strip() for value in section.get("command_trusted_script_keys", "").split(",") if value.strip()),
                command_max_script_bytes=section.getint("command_max_script_bytes", defaults.command_max_script_bytes),
                command_max_log_lines=section.getint("command_max_log_lines", defaults.command_max_log_lines),
                command_max_log_bytes=section.getint("command_max_log_bytes", defaults.command_max_log_bytes),
                command_max_log_since_seconds=section.getint("command_max_log_since_seconds", defaults.command_max_log_since_seconds),
                command_max_file_bytes=section.getint("command_max_file_bytes", defaults.command_max_file_bytes),
                command_max_delay_seconds=section.getint("command_max_delay_seconds", defaults.command_max_delay_seconds),
                command_max_timeout_seconds=section.getint("command_max_timeout_seconds", defaults.command_max_timeout_seconds),
                command_max_lifetime_seconds=section.getint("command_max_lifetime_seconds", defaults.command_max_lifetime_seconds),
                command_replay_window_seconds=section.getint("command_replay_window_seconds", defaults.command_replay_window_seconds),
                command_clock_skew_seconds=section.getint("command_clock_skew_seconds", defaults.command_clock_skew_seconds),
                command_require_nonce=section.getboolean("command_require_nonce", defaults.command_require_nonce),
                command_reject_id_reuse=section.getboolean("command_reject_id_reuse", defaults.command_reject_id_reuse),
                command_max_per_response=section.getint("command_max_per_response", defaults.command_max_per_response),
                command_audit_max_records=section.getint("command_audit_max_records", defaults.command_audit_max_records),
                local_audit_enabled=section.getboolean("local_audit_enabled", defaults.local_audit_enabled),
                local_audit_file=Path(section.get("local_audit_file", str(defaults.local_audit_file))),
                local_audit_max_records=section.getint("local_audit_max_records", defaults.local_audit_max_records),
                local_audit_max_bytes=section.getint("local_audit_max_bytes", defaults.local_audit_max_bytes),
                policy_cache_directory=Path(section.get("policy_cache_directory", str(defaults.policy_cache_directory))),
                update_cache_directory=Path(section.get("update_cache_directory", str(defaults.update_cache_directory))),
                update_max_artifact_bytes=section.getint("update_max_artifact_bytes", defaults.update_max_artifact_bytes),
                update_download_timeout_seconds=section.getint("update_download_timeout_seconds", defaults.update_download_timeout_seconds),
                update_cache_max_entries=section.getint("update_cache_max_entries", defaults.update_cache_max_entries),
                update_trusted_keys=tuple(value.strip() for value in section.get("update_trusted_keys", "").split(",") if value.strip()),
                update_allowed_issuer_kinds=tuple(value.strip().lower() for value in section.get("update_allowed_issuer_kinds", "xms").split(",") if value.strip()),
                update_allowed_components=tuple(value.strip().lower() for value in section.get("update_allowed_components", "agent,thin-client,debian-packages,system-component").split(",") if value.strip()),
                update_agent_package_name=section.get("update_agent_package_name", defaults.update_agent_package_name).strip(),
                update_agent_timeout_seconds=section.getint("update_agent_timeout_seconds", defaults.update_agent_timeout_seconds),
                update_agent_protected_paths=tuple(Path(value.strip()) for value in section.get("update_agent_protected_paths", "").split(",") if value.strip()),
                update_thin_client_package_name=section.get("update_thin_client_package_name", defaults.update_thin_client_package_name).strip(),
                update_thin_client_systemd_unit=section.get("update_thin_client_systemd_unit", defaults.update_thin_client_systemd_unit).strip(),
                update_thin_client_timeout_seconds=section.getint("update_thin_client_timeout_seconds", defaults.update_thin_client_timeout_seconds),
                update_thin_client_protected_paths=tuple(Path(value.strip()) for value in section.get("update_thin_client_protected_paths", "").split(",") if value.strip()),
                update_debian_allowed_packages=tuple(value.strip().lower() for value in section.get("update_debian_allowed_packages", "").split(",") if value.strip()),
                update_debian_timeout_seconds=section.getint("update_debian_timeout_seconds", defaults.update_debian_timeout_seconds),
                update_debian_max_packages=section.getint("update_debian_max_packages", defaults.update_debian_max_packages),
                update_debian_allow_new_packages=section.getboolean("update_debian_allow_new_packages", defaults.update_debian_allow_new_packages),
                update_debian_allow_removals=section.getboolean("update_debian_allow_removals", defaults.update_debian_allow_removals),
                update_maintenance_timezone=section.get("update_maintenance_timezone", defaults.update_maintenance_timezone).strip(),
                update_maintenance_windows=tuple(value.strip() for value in section.get("update_maintenance_windows", "").split(";") if value.strip()),
                update_maintenance_allow_when_unconfigured=section.getboolean("update_maintenance_allow_when_unconfigured", defaults.update_maintenance_allow_when_unconfigured),
                update_maintenance_max_schedule_ahead_seconds=section.getint("update_maintenance_max_schedule_ahead_seconds", defaults.update_maintenance_max_schedule_ahead_seconds),
                update_reboot_state_file=Path(section.get("update_reboot_state_file", str(defaults.update_reboot_state_file))),
                update_reboot_timeout_seconds=section.getint("update_reboot_timeout_seconds", defaults.update_reboot_timeout_seconds),
                update_reboot_delay_seconds=section.getint("update_reboot_delay_seconds", defaults.update_reboot_delay_seconds),
                update_reboot_stop_thin_client=section.getboolean("update_reboot_stop_thin_client", defaults.update_reboot_stop_thin_client),
                update_rollback_state_file=Path(section.get("update_rollback_state_file", str(defaults.update_rollback_state_file))),
                update_rollback_max_state_bytes=section.getint("update_rollback_max_state_bytes", defaults.update_rollback_max_state_bytes),
                update_report_file=Path(section.get("update_report_file", str(defaults.update_report_file))),
                update_report_max_records=section.getint("update_report_max_records", defaults.update_report_max_records),
                update_report_max_bytes=section.getint("update_report_max_bytes", defaults.update_report_max_bytes),
                policy_application_directory=Path(section.get("policy_application_directory", str(defaults.policy_application_directory))),
                policy_local_overlay_file=Path(section.get("policy_local_overlay_file", str(defaults.policy_local_overlay_file))),
                policy_audit_file=Path(section.get("policy_audit_file", str(defaults.policy_audit_file))),
                policy_audit_max_records=section.getint("policy_audit_max_records", defaults.policy_audit_max_records),
                policy_protected_paths=tuple(value.strip().lower() for value in section.get("policy_protected_paths", "").split(",") if value.strip()),
                policy_max_bytes=section.getint("policy_max_bytes", defaults.policy_max_bytes),
                policy_download_timeout_seconds=section.getint("policy_download_timeout_seconds", defaults.policy_download_timeout_seconds),
                policy_cache_max_entries=section.getint("policy_cache_max_entries", defaults.policy_cache_max_entries),
                policy_trusted_keys=tuple(value.strip() for value in section.get("policy_trusted_keys", "").split(",") if value.strip()),
                policy_allowed_issuer_kinds=tuple(value.strip().lower() for value in section.get("policy_allowed_issuer_kinds", "xms").split(",") if value.strip()),
                policy_local_capabilities=tuple(value.strip() for value in section.get("policy_local_capabilities", "").split(",") if value.strip()),
                thin_client_runtime_directory=Path(section.get("thin_client_runtime_directory", str(defaults.thin_client_runtime_directory))),
                thin_client_state_directory=Path(section.get("thin_client_state_directory", str(defaults.thin_client_state_directory))),
                thin_client_config_directory=Path(section.get("thin_client_config_directory", str(defaults.thin_client_config_directory))),
                thin_client_command_directory=Path(section.get("thin_client_command_directory", str(defaults.thin_client_command_directory))),
                thin_client_user=section.get("thin_client_user", defaults.thin_client_user).strip(),
                thin_client_shared_group=section.get("thin_client_shared_group", defaults.thin_client_shared_group).strip(),
                thin_client_allowed_operations=tuple(value.strip() for value in section.get("thin_client_allowed_operations", "").split(",") if value.strip()),
                thin_client_state_max_bytes=section.getint("thin_client_state_max_bytes", defaults.thin_client_state_max_bytes),
                thin_client_state_max_age_seconds=section.getint("thin_client_state_max_age_seconds", defaults.thin_client_state_max_age_seconds),
                thin_client_systemd_unit=section.get("thin_client_systemd_unit", defaults.thin_client_systemd_unit).strip(),
                thin_client_systemd_allowed_actions=tuple(value.strip().lower() for value in section.get("thin_client_systemd_allowed_actions", ",".join(defaults.thin_client_systemd_allowed_actions)).split(",") if value.strip()),
                thin_client_systemd_timeout_seconds=section.getint("thin_client_systemd_timeout_seconds", defaults.thin_client_systemd_timeout_seconds),
                thin_client_runtime_max_bytes=section.getint("thin_client_runtime_max_bytes", defaults.thin_client_runtime_max_bytes),
                thin_client_runtime_max_events=section.getint("thin_client_runtime_max_events", defaults.thin_client_runtime_max_events),
                thin_client_heartbeat_max_age_seconds=section.getint("thin_client_heartbeat_max_age_seconds", defaults.thin_client_heartbeat_max_age_seconds),
                thin_client_configuration_max_bytes=section.getint("thin_client_configuration_max_bytes", defaults.thin_client_configuration_max_bytes),
                thin_client_diagnostic_directory=Path(section.get("thin_client_diagnostic_directory", str(defaults.thin_client_diagnostic_directory))),
                thin_client_diagnostic_max_log_lines=section.getint("thin_client_diagnostic_max_log_lines", defaults.thin_client_diagnostic_max_log_lines),
                thin_client_diagnostic_max_log_bytes=section.getint("thin_client_diagnostic_max_log_bytes", defaults.thin_client_diagnostic_max_log_bytes),
                thin_client_diagnostic_max_package_bytes=section.getint("thin_client_diagnostic_max_package_bytes", defaults.thin_client_diagnostic_max_package_bytes),
                thin_client_diagnostic_timeout_seconds=section.getint("thin_client_diagnostic_timeout_seconds", defaults.thin_client_diagnostic_timeout_seconds),
                thin_client_compatibility_min_version=section.get("thin_client_compatibility_min_version", defaults.thin_client_compatibility_min_version).strip(),
                thin_client_compatibility_max_version=section.get("thin_client_compatibility_max_version", defaults.thin_client_compatibility_max_version).strip(),
                thin_client_contract_versions=tuple(value.strip() for value in section.get("thin_client_contract_versions", ",".join(defaults.thin_client_contract_versions)).split(",") if value.strip()),
                thin_client_local_capabilities=tuple(value.strip() for value in section.get("thin_client_local_capabilities", ",".join(defaults.thin_client_local_capabilities)).split(",") if value.strip()),
                allow_http=section.getboolean("allow_http", defaults.allow_http),
                enabled=section.getboolean("enabled", defaults.enabled),
            )
        except AgentConfigurationError:
            raise
        except (KeyError, ValueError) as error:
            raise AgentConfigurationError(f"Configuració no vàlida: {error}") from error
        settings.validate()
        return settings

    @property
    def process_lock_file(self) -> Path:
        return self.runtime_directory / "xaac-agent.lock"

    @property
    def local_alert_state_file(self) -> Path:
        return self.state_directory / "local-alert-state.json"

    @property
    def health_file(self) -> Path:
        return self.runtime_directory / "health.json"

    @property
    def heartbeat_state_file(self) -> Path:
        return self.state_directory / "heartbeat-state.json"

    @property
    def inventory_state_file(self) -> Path:
        return self.state_directory / "inventory-state.json"

    @property
    def last_failure_file(self) -> Path:
        return self.state_directory / "last-failure.json"

    @property
    def recovery_state_file(self) -> Path:
        return self.state_directory / "recovery-state.json"

    @property
    def registration_state_file(self) -> Path:
        return self.state_directory / "registration-state.json"

    @property
    def command_journal_file(self) -> Path:
        return self.state_directory / "command-journal.json"

    @property
    def command_audit_file(self) -> Path:
        return self.state_directory / "command-audit.json"

    @property
    def offline_state_file(self) -> Path:
        return self.state_directory / "offline-state.json"

    def validate(self) -> None:
        if self.enabled and not self.server_url:
            raise AgentConfigurationError("server_url és obligatori quan l'agent està habilitat")
        if self.server_url and not self.server_url.startswith("https://"):
            if not (self.allow_http and self.server_url.startswith("http://")):
                raise AgentConfigurationError("server_url ha d'utilitzar HTTPS")
        if not 10 <= self.heartbeat_min_interval_seconds <= 86400:
            raise AgentConfigurationError("heartbeat_min_interval_seconds fora de rang")
        if not self.heartbeat_min_interval_seconds <= self.heartbeat_max_interval_seconds <= 86400:
            raise AgentConfigurationError("heartbeat_max_interval_seconds fora de rang")
        if not self.heartbeat_min_interval_seconds <= self.heartbeat_interval_seconds <= self.heartbeat_max_interval_seconds:
            raise AgentConfigurationError("heartbeat_interval_seconds fora de rang")
        if not 1 <= self.inventory_full_interval_heartbeats <= 1000000:
            raise AgentConfigurationError("inventory_full_interval_heartbeats fora de rang")
        if not 1 <= self.monitoring_window_samples <= 120:
            raise AgentConfigurationError("monitoring_window_samples fora de rang")
        if not 1 <= self.monitoring_aggregation_window_samples <= 1440:
            raise AgentConfigurationError("monitoring_aggregation_window_samples fora de rang")
        if not self.heartbeat_min_interval_seconds <= self.adaptive_critical_interval_seconds <= self.heartbeat_max_interval_seconds:
            raise AgentConfigurationError("adaptive_critical_interval_seconds fora de rang")
        if not self.adaptive_critical_interval_seconds <= self.adaptive_warning_interval_seconds <= self.heartbeat_max_interval_seconds:
            raise AgentConfigurationError("adaptive_warning_interval_seconds fora de rang")
        if not 1 <= self.adaptive_normal_relax_after_samples <= 10000:
            raise AgentConfigurationError("adaptive_normal_relax_after_samples fora de rang")
        if not 1.0 <= self.adaptive_normal_interval_multiplier <= 10.0:
            raise AgentConfigurationError("adaptive_normal_interval_multiplier fora de rang")
        if not 1 <= self.adaptive_reduced_outbox_batch_size <= self.outbox_batch_size:
            raise AgentConfigurationError("adaptive_reduced_outbox_batch_size fora de rang")
        if not 1 <= self.adaptive_offline_outbox_batch_size <= self.outbox_batch_size:
            raise AgentConfigurationError("adaptive_offline_outbox_batch_size fora de rang")
        if not 60 <= self.local_alert_ttl_seconds <= 90 * 86400:
            raise AgentConfigurationError("local_alert_ttl_seconds fora de rang")
        if not 0 <= self.local_alert_warning_priority <= 100:
            raise AgentConfigurationError("local_alert_warning_priority fora de rang")
        if not 0 <= self.local_alert_critical_priority <= 100:
            raise AgentConfigurationError("local_alert_critical_priority fora de rang")
        if self.local_alert_warning_priority > self.local_alert_critical_priority:
            raise AgentConfigurationError("les prioritats d’alerta no són coherents")
        for warning_name, critical_name in (("cpu_warning_percent", "cpu_critical_percent"), ("memory_warning_percent", "memory_critical_percent"), ("disk_warning_percent", "disk_critical_percent")):
            warning = getattr(self, warning_name)
            critical = getattr(self, critical_name)
            if not 0 < warning < critical <= 100:
                raise AgentConfigurationError(f"{warning_name}/{critical_name} fora de rang")
        if not 0 < self.load_warning_per_cpu < self.load_critical_per_cpu <= 100:
            raise AgentConfigurationError("llindars de càrrega fora de rang")
        if not 0 <= self.monitoring_hysteresis_percent <= 25:
            raise AgentConfigurationError("monitoring_hysteresis_percent fora de rang")
        if not -20 < self.temperature_warning_celsius < self.temperature_critical_celsius <= 200:
            raise AgentConfigurationError("llindars de temperatura fora de rang")
        if not 0 <= self.temperature_hysteresis_celsius <= 25:
            raise AgentConfigurationError("temperature_hysteresis_celsius fora de rang")
        if not 0 < self.network_warning_error_percent < self.network_critical_error_percent <= 100:
            raise AgentConfigurationError("llindars d’errors de xarxa fora de rang")
        if not 0 <= self.network_hysteresis_percent <= 25:
            raise AgentConfigurationError("network_hysteresis_percent fora de rang")
        if not 0.1 <= self.connectivity_timeout_seconds <= 30:
            raise AgentConfigurationError("connectivity_timeout_seconds fora de rang")
        if not 0 < self.connectivity_warning_latency_ms < self.connectivity_critical_latency_ms <= 60000:
            raise AgentConfigurationError("llindars de latència amb XMS fora de rang")
        if not 0 <= self.connectivity_hysteresis_ms <= self.connectivity_warning_latency_ms:
            raise AgentConfigurationError("connectivity_hysteresis_ms fora de rang")
        if not 0.1 <= self.certificate_check_timeout_seconds <= 30:
            raise AgentConfigurationError("certificate_check_timeout_seconds fora de rang")
        if not 1 <= self.certificate_critical_days < self.certificate_warning_days <= 3650:
            raise AgentConfigurationError("llindars de caducitat de certificats fora de rang")
        if not 0.1 <= self.service_check_timeout_seconds <= 30:
            raise AgentConfigurationError("service_check_timeout_seconds fora de rang")
        import re
        if any(not re.fullmatch(r"[A-Za-z0-9_.@+-]{1,128}", value) for value in self.critical_processes):
            raise AgentConfigurationError("critical_processes conté un nom no vàlid")
        if any(not re.fullmatch(r"[A-Za-z0-9_.@:-]{1,200}\.service", value) for value in self.critical_services):
            raise AgentConfigurationError("critical_services conté un nom no vàlid")
        if not 1 <= self.outbox_max_messages <= 10000:
            raise AgentConfigurationError("outbox_max_messages fora de rang")
        if not 4096 <= self.outbox_max_bytes <= 64 * 1024 * 1024:
            raise AgentConfigurationError("outbox_max_bytes fora de rang")
        if not 1 <= self.outbox_batch_size <= self.outbox_max_messages:
            raise AgentConfigurationError("outbox_batch_size fora de rang")
        if not 60 <= self.outbox_default_ttl_seconds <= 90 * 86400:
            raise AgentConfigurationError("outbox_default_ttl_seconds fora de rang")
        if not 0 <= self.critical_message_priority <= 100:
            raise AgentConfigurationError("critical_message_priority fora de rang")
        if not 0.1 <= self.request_timeout_seconds <= 60:
            raise AgentConfigurationError("request_timeout_seconds fora de rang")
        if not 1024 <= self.max_response_bytes <= 16 * 1024 * 1024:
            raise AgentConfigurationError("max_response_bytes fora de rang")
        if not self.max_response_bytes <= self.max_decompressed_response_bytes <= 64 * 1024 * 1024:
            raise AgentConfigurationError("max_decompressed_response_bytes fora de rang")
        if not 256 <= self.compression_threshold_bytes <= 1024 * 1024:
            raise AgentConfigurationError("compression_threshold_bytes fora de rang")
        if self.production_profile_mode not in {"auto", "generic", "dell-wyse-3040"}:
            raise AgentConfigurationError("production_profile_mode no vàlid")
        if self.proxy_url and not self.proxy_url.startswith(("http://", "https://")):
            raise AgentConfigurationError("proxy_url ha d'utilitzar HTTP o HTTPS")
        if self.tls_ca_file is not None and not str(self.tls_ca_file).strip():
            raise AgentConfigurationError("tls_ca_file no pot ser buit")
        from xaac_agent.tls_policy import TlsPolicy, TlsPolicyError
        try:
            TlsPolicy(
                minimum_version=self.tls_minimum_version,
                maximum_version=self.tls_maximum_version,
                ciphers=self.tls_ciphers,
                certificate_pins=self.tls_certificate_pins,
            ).validate()
        except TlsPolicyError as error:
            raise AgentConfigurationError(f"configuració TLS no vàlida: {error}") from error
        if self.tls_certificate_pins and (not self.server_url.startswith("https://")):
            raise AgentConfigurationError("tls_certificate_pins requereix HTTPS")
        if not 0.1 <= self.retry_base_delay_seconds <= 3600:
            raise AgentConfigurationError("retry_base_delay_seconds fora de rang")
        if not self.retry_base_delay_seconds <= self.retry_max_delay_seconds <= 86400:
            raise AgentConfigurationError("retry_max_delay_seconds fora de rang")
        if not 0.0 <= self.retry_jitter_ratio <= 1.0:
            raise AgentConfigurationError("retry_jitter_ratio fora de rang")
        if not 1 <= self.circuit_failure_threshold <= 100:
            raise AgentConfigurationError("circuit_failure_threshold fora de rang")
        if not 1 <= self.circuit_open_seconds <= 86400:
            raise AgentConfigurationError("circuit_open_seconds fora de rang")
        if not 60 <= self.offline_prolonged_threshold_seconds <= 30 * 86400:
            raise AgentConfigurationError("offline_prolonged_threshold_seconds fora de rang")
        if not 1 <= self.xms_failover_failure_threshold <= 100:
            raise AgentConfigurationError("xms_failover_failure_threshold fora de rang")
        if len(set(self.xms_authorized_alternate_urls)) != len(self.xms_authorized_alternate_urls):
            raise AgentConfigurationError("xms_authorized_alternate_urls conté duplicats")
        if self.server_url in self.xms_authorized_alternate_urls:
            raise AgentConfigurationError("el servidor principal no pot ser alternatiu")
        for alternate_url in self.xms_authorized_alternate_urls:
            if not alternate_url.startswith("https://") and not (self.allow_http and alternate_url.startswith("http://")):
                raise AgentConfigurationError("els servidors XMS alternatius han d’utilitzar HTTPS")
        if not 60 <= self.credential_renew_before_seconds <= 30 * 86400:
            raise AgentConfigurationError("credential_renew_before_seconds fora de rang")
        if not 0 <= self.credential_clock_skew_tolerance_seconds <= 3600:
            raise AgentConfigurationError(
                "credential_clock_skew_tolerance_seconds fora de rang"
            )
        from xaac_agent.command_authorization import CommandAuthorizationPolicy
        if not 60 <= self.command_max_lifetime_seconds <= 7 * 86400:
            raise AgentConfigurationError("command_max_lifetime_seconds fora de rang")
        from xaac_agent.tpm import TpmError, TpmPolicy
        try:
            TpmPolicy(enabled=self.tpm_enabled, required=self.tpm_required, device_path=self.tpm_device_path, pcr_bank=self.tpm_pcr_bank, pcrs=self.tpm_pcrs, command_timeout_seconds=self.tpm_command_timeout_seconds).validate()
        except TpmError as error:
            raise AgentConfigurationError(str(error)) from error
        from xaac_agent.boot_security import BootSecurityError, BootSecurityPolicy
        try:
            BootSecurityPolicy(enabled=self.boot_security_enabled, require_uefi=self.boot_require_uefi, require_secure_boot=self.boot_require_secure_boot, efi_variables_path=self.boot_efi_variables_path, kernel_lockdown_path=self.boot_kernel_lockdown_path).validate()
        except BootSecurityError as error:
            raise AgentConfigurationError(str(error)) from error
        from xaac_agent.file_integrity import FileIntegrityError, FileIntegrityPolicy
        try:
            FileIntegrityPolicy(enabled=self.file_integrity_enabled, required=self.file_integrity_required, manifest_path=self.file_integrity_manifest_path, max_manifest_bytes=self.file_integrity_max_manifest_bytes, max_files=self.file_integrity_max_files, max_file_bytes=self.file_integrity_max_file_bytes).validate()
        except FileIntegrityError as error:
            raise AgentConfigurationError(str(error)) from error
        from xaac_agent.compromise_response import CompromiseResponseError, CompromiseResponsePolicy
        try:
            CompromiseResponsePolicy(enabled=self.compromise_response_enabled, automatic_quarantine=self.compromise_automatic_quarantine, state_file=self.compromise_state_file, block_remote_commands=self.compromise_block_remote_commands, block_updates=self.compromise_block_updates, allow_heartbeat=self.compromise_allow_heartbeat, max_state_bytes=self.compromise_max_state_bytes).validate()
        except CompromiseResponseError as error:
            raise AgentConfigurationError(str(error)) from error
        if not 60 <= self.command_replay_window_seconds <= 7 * 86400:
            raise AgentConfigurationError("command_replay_window_seconds fora de rang")
        if not 0 <= self.command_clock_skew_seconds <= 3600:
            raise AgentConfigurationError("command_clock_skew_seconds fora de rang")
        if not 1 <= self.command_max_per_response <= 256:
            raise AgentConfigurationError("command_max_per_response fora de rang")
        if not 32 <= self.command_audit_max_records <= 100000:
            raise AgentConfigurationError("command_audit_max_records fora de rang")
        if not 32 <= self.local_audit_max_records <= 100000:
            raise AgentConfigurationError("local_audit_max_records fora de rang")
        if not 65536 <= self.local_audit_max_bytes <= 64 * 1024 * 1024:
            raise AgentConfigurationError("local_audit_max_bytes fora de rang")
        if not 32 <= self.policy_audit_max_records <= 100000:
            raise AgentConfigurationError("policy_audit_max_records fora de rang")
        contract_paths = (self.thin_client_runtime_directory, self.thin_client_state_directory, self.thin_client_config_directory, self.thin_client_command_directory)
        if any(not path.is_absolute() for path in contract_paths):
            raise AgentConfigurationError("els directoris d’integració amb XAAC Thin Client han de ser absoluts")
        if len({str(path) for path in contract_paths}) != len(contract_paths):
            raise AgentConfigurationError("els directoris d’integració amb XAAC Thin Client han de ser diferents")
        if not self.thin_client_user or not self.thin_client_shared_group:
            raise AgentConfigurationError("usuari i grup de XAAC Thin Client són obligatoris")
        if not 1024 <= self.thin_client_state_max_bytes <= 1024 * 1024:
            raise AgentConfigurationError("thin_client_state_max_bytes fora de rang")
        if not 1 <= self.thin_client_state_max_age_seconds <= 86400:
            raise AgentConfigurationError("thin_client_state_max_age_seconds fora de rang")
        if not 1024 <= self.thin_client_runtime_max_bytes <= 1024 * 1024:
            raise AgentConfigurationError("thin_client_runtime_max_bytes fora de rang")
        if not 1 <= self.thin_client_runtime_max_events <= 4096:
            raise AgentConfigurationError("thin_client_runtime_max_events fora de rang")
        if not 1 <= self.thin_client_heartbeat_max_age_seconds <= 86400:
            raise AgentConfigurationError("thin_client_heartbeat_max_age_seconds fora de rang")
        if not 1024 <= self.thin_client_configuration_max_bytes <= 4 * 1024 * 1024:
            raise AgentConfigurationError("thin_client_configuration_max_bytes fora de rang")
        if not self.thin_client_diagnostic_directory.is_absolute():
            raise AgentConfigurationError("thin_client_diagnostic_directory ha de ser absolut")
        if not 1 <= self.thin_client_diagnostic_max_log_lines <= 5000:
            raise AgentConfigurationError("thin_client_diagnostic_max_log_lines fora de rang")
        if not 1024 <= self.thin_client_diagnostic_max_log_bytes <= 4 * 1024 * 1024:
            raise AgentConfigurationError("thin_client_diagnostic_max_log_bytes fora de rang")
        if not 4096 <= self.thin_client_diagnostic_max_package_bytes <= 16 * 1024 * 1024:
            raise AgentConfigurationError("thin_client_diagnostic_max_package_bytes fora de rang")
        if not 1 <= self.thin_client_diagnostic_timeout_seconds <= 120:
            raise AgentConfigurationError("thin_client_diagnostic_timeout_seconds fora de rang")
        try:
            from xaac_agent.thin_client_compatibility import SemanticVersion
            minimum = SemanticVersion.parse(self.thin_client_compatibility_min_version)
            maximum = SemanticVersion.parse(self.thin_client_compatibility_max_version)
            if minimum.compatible_order_key() > maximum.compatible_order_key():
                raise AgentConfigurationError("rang de versions Thin Client invertit")
            if not self.thin_client_contract_versions or not self.thin_client_local_capabilities:
                raise AgentConfigurationError("compatibilitat Thin Client incompleta")
        except ValueError as error:
            raise AgentConfigurationError("configuració de compatibilitat Thin Client no vàlida") from error
        try:
            from xaac_agent.thin_client_systemd import ThinClientSystemdController, parse_thin_client_service_actions
            actions = parse_thin_client_service_actions(self.thin_client_systemd_allowed_actions)
            ThinClientSystemdController(
                contract=__import__("xaac_agent.thin_client_contract", fromlist=["ThinClientIntegrationContract"]).ThinClientIntegrationContract.build(
                    runtime_root=self.thin_client_runtime_directory,
                    state_root=self.thin_client_state_directory,
                    config_root=self.thin_client_config_directory,
                    command_root=self.thin_client_command_directory,
                    thin_client_user=self.thin_client_user,
                    shared_group=self.thin_client_shared_group,
                    allowed_operations=self.thin_client_allowed_operations,
                ),
                backend=__import__("xaac_agent.thin_client_systemd", fromlist=["SubprocessThinClientSystemdBackend"]).SubprocessThinClientSystemdBackend(),
                unit=self.thin_client_systemd_unit,
                allowed_actions=actions,
                timeout_seconds=self.thin_client_systemd_timeout_seconds,
            )
        except ValueError as error:
            raise AgentConfigurationError(str(error)) from error
        if not 1024 <= self.policy_max_bytes <= 16 * 1024 * 1024:
            raise AgentConfigurationError("policy_max_bytes fora de rang")
        if not 1 <= self.policy_download_timeout_seconds <= 300:
            raise AgentConfigurationError("policy_download_timeout_seconds fora de rang")
        if not 1 <= self.policy_cache_max_entries <= 1024:
            raise AgentConfigurationError("policy_cache_max_entries fora de rang")
        try:
            from xaac_agent.policy_conflicts import parse_protected_paths
            parse_protected_paths(self.policy_protected_paths)
        except ValueError as error:
            raise AgentConfigurationError(str(error)) from error
        if not self.policy_allowed_issuer_kinds:
            raise AgentConfigurationError("policy_allowed_issuer_kinds no pot ser buit")
        try:
            from xaac_agent.policy_trust import parse_trusted_policy_keys
            parse_trusted_policy_keys(self.policy_trusted_keys)
        except ValueError as error:
            raise AgentConfigurationError(f"claus de confiança de polítiques no vàlides: {error}") from error
        try:
            CommandAuthorizationPolicy.from_strings(
                allowed_types=self.command_allowed_types,
                local_capabilities=self.command_local_capabilities,
                allowed_issuer_kinds=self.command_allowed_issuer_kinds,
                agent_user=self.command_agent_user,
                privileged_helper_user=self.command_privileged_helper_user,
                allowed_services=self.command_allowed_services,
                allowed_tasks=self.command_allowed_tasks,
                allowed_file_targets=tuple(value.partition("=")[0].strip() for value in self.command_allowed_file_targets),
                allowed_log_sources=self.command_allowed_log_sources,
                allowed_signed_scripts=tuple(value.partition("=")[0].strip() for value in self.command_allowed_signed_scripts),
                trusted_script_keys=tuple(value.partition("=")[0].strip() for value in self.command_trusted_script_keys),
                max_script_bytes=self.command_max_script_bytes,
                max_log_lines=self.command_max_log_lines,
                max_log_bytes=self.command_max_log_bytes,
                max_log_since_seconds=self.command_max_log_since_seconds,
                max_file_bytes=self.command_max_file_bytes,
                max_delay_seconds=self.command_max_delay_seconds,
                max_timeout_seconds=self.command_max_timeout_seconds,
            )
        except ValueError as error:
            raise AgentConfigurationError(f"política local d’ordres no vàlida: {error}") from error
        for field_name in (
            "runtime_directory",
            "state_directory",
            "cache_directory",
            "log_directory",
        "policy_cache_directory",
            "update_cache_directory",
        "update_rollback_state_file",
            "update_report_file",
            "enrollment_token_file",
            "device_identity_file",
            "device_private_key_file",
            "device_credentials_file",
            "outbox_file",
        ):
            if not str(getattr(self, field_name)).strip():
                raise AgentConfigurationError(f"{field_name} no pot ser buit")

    def changed_fields(self, other: "AgentSettings") -> frozenset[str]:
        return frozenset(
            field.name
            for field in fields(self)
            if getattr(self, field.name) != getattr(other, field.name)
        )

    def preserve_restart_required_from(self, current: "AgentSettings") -> "AgentSettings":
        values = {name: getattr(current, name) for name in RESTART_REQUIRED_FIELDS}
        return replace(self, **values)


@dataclass(frozen=True, slots=True)
class ConfigurationReloadResult:
    settings: AgentSettings
    changed_fields: frozenset[str]
    applied_fields: frozenset[str]
    restart_required_fields: frozenset[str]

    @property
    def changed(self) -> bool:
        return bool(self.changed_fields)

    @property
    def restart_required(self) -> bool:
        return bool(self.restart_required_fields)


def reload_settings(path: Path, current: AgentSettings) -> ConfigurationReloadResult:
    """Carrega i valida una configuració nova sense alterar l'estat actual."""

    candidate = AgentSettings.load(path)
    changed = current.changed_fields(candidate)
    restart_required = changed & RESTART_REQUIRED_FIELDS
    applied = changed - restart_required
    effective = candidate.preserve_restart_required_from(current)
    return ConfigurationReloadResult(
        settings=effective,
        changed_fields=changed,
        applied_fields=applied,
        restart_required_fields=restart_required,
    )

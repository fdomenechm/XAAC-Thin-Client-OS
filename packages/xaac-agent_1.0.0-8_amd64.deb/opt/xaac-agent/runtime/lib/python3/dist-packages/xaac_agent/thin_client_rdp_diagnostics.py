from __future__ import annotations

import argparse
import json
import os
import re
import socket
import stat
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence
from urllib.parse import urlparse


class ThinClientRdpDiagnosticError(ValueError):
    """Diagnòstic segur de XAAC Thin Client/RDP no vàlid."""


_SECRET_KEYS = re.compile(r"(?i)(password|passwd|secret|token|credential|authorization|private[_-]?key)")
_PROCESS_NAMES = frozenset({"xaac-thin-client", "xfreerdp", "xfreerdp3", "wlfreerdp"})


def _safe_json(path: Path, *, max_bytes: int = 1024 * 1024) -> Mapping[str, Any] | None:
    if path.is_symlink() or not path.exists():
        return None
    info = path.stat(follow_symlinks=False)
    if not stat.S_ISREG(info.st_mode) or info.st_size > max_bytes:
        return None
    value = json.loads(path.read_text(encoding="utf-8"))
    return value if isinstance(value, Mapping) else None


def _redacted_keys(value: Any, *, depth: int = 0) -> Any:
    if depth > 12:
        return "[TRUNCATED]"
    if isinstance(value, Mapping):
        result: dict[str, Any] = {}
        for key, child in value.items():
            name = str(key)
            result[name] = "[REDACTED]" if _SECRET_KEYS.search(name) else _redacted_keys(child, depth=depth + 1)
        return result
    if isinstance(value, list):
        return [_redacted_keys(item, depth=depth + 1) for item in value[:128]]
    if isinstance(value, str):
        return value[:1024]
    if value is None or isinstance(value, (bool, int, float)):
        return value
    return str(value)[:256]


def _find_rdp_target(configuration: Mapping[str, Any] | None) -> tuple[str | None, int]:
    if configuration is None:
        return None, 3389
    sections = configuration.get("sections")
    if not isinstance(sections, Mapping):
        sections = configuration
    candidates: list[Mapping[str, Any]] = [sections]
    for name in ("rdp", "connection", "server", "session"):
        child = sections.get(name) if isinstance(sections, Mapping) else None
        if isinstance(child, Mapping):
            candidates.append(child)
    for item in candidates:
        host = item.get("host") or item.get("server") or item.get("hostname") or item.get("address")
        port = item.get("port", 3389)
        if isinstance(host, str) and host.strip():
            parsed = urlparse(host if "://" in host else f"rdp://{host}")
            normalized = parsed.hostname or host.strip()
            try:
                parsed_port = int(parsed.port or port)
            except (TypeError, ValueError):
                parsed_port = 3389
            if 1 <= parsed_port <= 65535:
                return normalized[:255], parsed_port
    return None, 3389


def _process_snapshot(proc_root: Path) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    if proc_root.is_symlink() or not proc_root.is_dir():
        return results
    for entry in sorted(proc_root.iterdir(), key=lambda p: p.name):
        if not entry.name.isdigit() or len(results) >= 32:
            continue
        try:
            comm = (entry / "comm").read_text(encoding="utf-8").strip()
            if comm not in _PROCESS_NAMES:
                continue
            status = (entry / "status").read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        state = None
        threads = None
        for line in status.splitlines():
            if line.startswith("State:"):
                state = line.split(":", 1)[1].strip()[:64]
            elif line.startswith("Threads:"):
                try:
                    threads = int(line.split(":", 1)[1].strip())
                except ValueError:
                    pass
        results.append({"name": comm, "pid": int(entry.name), "state": state, "threads": threads})
    return results


@dataclass(slots=True)
class ThinClientRdpDiagnostics:
    config_path: Path = Path("/var/lib/xaac/thin-client/config/active-configuration.json")
    state_path: Path = Path("/var/lib/xaac/thin-client/state/state.json")
    proc_root: Path = Path("/proc")
    timeout_seconds: float = 3.0

    def __post_init__(self) -> None:
        for path in (self.config_path, self.state_path, self.proc_root):
            if not Path(path).is_absolute():
                raise ThinClientRdpDiagnosticError("diagnostic_path_must_be_absolute")
        if not 0.1 <= self.timeout_seconds <= 30:
            raise ThinClientRdpDiagnosticError("diagnostic_timeout_out_of_range")

    def collect(self) -> dict[str, Any]:
        checks: list[dict[str, Any]] = []
        try:
            configuration = _safe_json(Path(self.config_path))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError):
            configuration = None
        checks.append({
            "name": "configuration",
            "status": "ok" if configuration is not None else "warning",
            "present": configuration is not None,
            "summary": _redacted_keys(configuration) if configuration is not None else None,
        })

        try:
            state = _safe_json(Path(self.state_path))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError):
            state = None
        checks.append({
            "name": "thin_client_state",
            "status": "ok" if state is not None else "warning",
            "present": state is not None,
            "state": _redacted_keys(state) if state is not None else None,
        })

        processes = _process_snapshot(Path(self.proc_root))
        checks.append({
            "name": "processes",
            "status": "ok" if processes else "warning",
            "count": len(processes),
            "items": processes,
        })

        host, port = _find_rdp_target(configuration)
        endpoint: dict[str, Any] = {"name": "rdp_endpoint", "configured": host is not None, "port": port}
        if host is None:
            endpoint["status"] = "warning"
            endpoint["code"] = "rdp_target_not_configured"
        else:
            started = time.monotonic()
            try:
                with socket.create_connection((host, port), timeout=self.timeout_seconds):
                    endpoint["status"] = "ok"
                    endpoint["code"] = "rdp_tcp_reachable"
            except (OSError, socket.timeout):
                endpoint["status"] = "critical"
                endpoint["code"] = "rdp_tcp_unreachable"
            endpoint["latency_ms"] = round((time.monotonic() - started) * 1000, 2)
            endpoint["host"] = host
        checks.append(endpoint)

        statuses = {str(item["status"]) for item in checks}
        overall = "critical" if "critical" in statuses else "warning" if "warning" in statuses else "ok"
        return {
            "format": "xaac-thin-client-rdp-diagnostic/v1",
            "status": overall,
            "checks": checks,
            "privacy": {
                "command_lines_collected": False,
                "environment_collected": False,
                "credentials_collected": False,
            },
        }


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Diagnòstic segur de XAAC Thin Client i RDP")
    parser.add_argument("--config-path", type=Path, default=ThinClientRdpDiagnostics.config_path)
    parser.add_argument("--state-path", type=Path, default=ThinClientRdpDiagnostics.state_path)
    parser.add_argument("--proc-root", type=Path, default=ThinClientRdpDiagnostics.proc_root)
    parser.add_argument("--timeout", type=float, default=3.0)
    args = parser.parse_args(argv)
    try:
        payload = ThinClientRdpDiagnostics(args.config_path, args.state_path, args.proc_root, args.timeout).collect()
    except ThinClientRdpDiagnosticError as error:
        print(json.dumps({"format": "xaac-thin-client-rdp-diagnostic/v1", "status": "error", "code": str(error)}, sort_keys=True))
        return 2
    print(json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False))
    return 1 if payload["status"] == "critical" else 0


if __name__ == "__main__":
    raise SystemExit(main())

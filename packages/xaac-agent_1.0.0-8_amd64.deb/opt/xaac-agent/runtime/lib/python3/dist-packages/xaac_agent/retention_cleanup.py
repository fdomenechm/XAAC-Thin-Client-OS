from __future__ import annotations

import argparse
import json
import os
import stat
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Callable, Iterable, Sequence


class RetentionCleanupError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class RetentionPolicy:
    max_age_seconds: int = 7 * 24 * 3600
    max_files: int = 32
    max_total_bytes: int = 64 * 1024 * 1024
    stale_temporary_age_seconds: int = 24 * 3600
    allowed_suffixes: tuple[str, ...] = (".json", ".zip")

    def validate(self) -> None:
        if not 60 <= self.max_age_seconds <= 365 * 24 * 3600:
            raise RetentionCleanupError("retention_max_age_out_of_range")
        if not 1 <= self.max_files <= 4096:
            raise RetentionCleanupError("retention_max_files_out_of_range")
        if not 1024 <= self.max_total_bytes <= 4 * 1024 * 1024 * 1024:
            raise RetentionCleanupError("retention_max_total_bytes_out_of_range")
        if not 60 <= self.stale_temporary_age_seconds <= self.max_age_seconds:
            raise RetentionCleanupError("retention_temporary_age_invalid")
        if not self.allowed_suffixes or any(not item.startswith(".") or "/" in item for item in self.allowed_suffixes):
            raise RetentionCleanupError("retention_suffixes_invalid")


@dataclass(frozen=True, slots=True)
class CleanupEntry:
    path: str
    bytes: int
    reason: str


@dataclass(frozen=True, slots=True)
class CleanupReport:
    format: str
    dry_run: bool
    scanned_files: int
    retained_files: int
    retained_bytes: int
    removed_files: int
    removed_bytes: int
    skipped_entries: int
    removals: tuple[CleanupEntry, ...]

    def to_dict(self) -> dict[str, object]:
        value = asdict(self)
        value["removals"] = [asdict(item) for item in self.removals]
        return value


def _is_temporary(name: str) -> bool:
    return name.startswith(".") and (".tmp-" in name or name.endswith(".tmp"))


def _safe_unlink(path: Path, *, dry_run: bool) -> None:
    if dry_run:
        return
    try:
        current = path.lstat()
    except FileNotFoundError:
        return
    if stat.S_ISLNK(current.st_mode) or not stat.S_ISREG(current.st_mode):
        raise RetentionCleanupError("retention_target_changed")
    path.unlink()


def cleanup_directory(
    directory: Path,
    *,
    policy: RetentionPolicy | None = None,
    dry_run: bool = False,
    clock: Callable[[], float] = time.time,
) -> CleanupReport:
    policy = policy or RetentionPolicy()
    policy.validate()
    if not directory.is_absolute():
        raise RetentionCleanupError("retention_directory_must_be_absolute")
    try:
        root_stat = directory.lstat()
    except OSError as error:
        raise RetentionCleanupError("retention_directory_unavailable") from error
    if stat.S_ISLNK(root_stat.st_mode) or not stat.S_ISDIR(root_stat.st_mode):
        raise RetentionCleanupError("retention_directory_invalid")

    now = float(clock())
    candidates: list[tuple[Path, os.stat_result]] = []
    skipped = 0
    removals: list[CleanupEntry] = []

    try:
        entries = sorted(directory.iterdir(), key=lambda item: item.name)
    except OSError as error:
        raise RetentionCleanupError("retention_directory_unavailable") from error

    for path in entries:
        try:
            item_stat = path.lstat()
        except OSError:
            skipped += 1
            continue
        if stat.S_ISLNK(item_stat.st_mode) or not stat.S_ISREG(item_stat.st_mode):
            skipped += 1
            continue
        age = max(0.0, now - item_stat.st_mtime)
        if _is_temporary(path.name):
            if age >= policy.stale_temporary_age_seconds:
                _safe_unlink(path, dry_run=dry_run)
                removals.append(CleanupEntry(path.name, item_stat.st_size, "stale_temporary"))
            continue
        if path.suffix.lower() not in policy.allowed_suffixes:
            skipped += 1
            continue
        candidates.append((path, item_stat))

    retained: list[tuple[Path, os.stat_result]] = []
    for path, item_stat in candidates:
        if max(0.0, now - item_stat.st_mtime) >= policy.max_age_seconds:
            _safe_unlink(path, dry_run=dry_run)
            removals.append(CleanupEntry(path.name, item_stat.st_size, "expired"))
        else:
            retained.append((path, item_stat))

    retained.sort(key=lambda item: (item[1].st_mtime, item[0].name), reverse=True)
    keep = retained[: policy.max_files]
    for path, item_stat in retained[policy.max_files :]:
        _safe_unlink(path, dry_run=dry_run)
        removals.append(CleanupEntry(path.name, item_stat.st_size, "file_limit"))

    total = sum(item[1].st_size for item in keep)
    while keep and total > policy.max_total_bytes:
        path, item_stat = keep.pop()
        _safe_unlink(path, dry_run=dry_run)
        removals.append(CleanupEntry(path.name, item_stat.st_size, "size_limit"))
        total -= item_stat.st_size

    removed_bytes = sum(item.bytes for item in removals)
    return CleanupReport(
        format="xaac-retention-cleanup/v1",
        dry_run=dry_run,
        scanned_files=len(candidates),
        retained_files=len(keep),
        retained_bytes=sum(item[1].st_size for item in keep),
        removed_files=len(removals),
        removed_bytes=removed_bytes,
        skipped_entries=skipped,
        removals=tuple(removals),
    )


def main(argv: Iterable[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Apply bounded retention to XAAC diagnostic and support artifacts")
    parser.add_argument("--directory", type=Path, required=True)
    parser.add_argument("--max-age-seconds", type=int, default=7 * 24 * 3600)
    parser.add_argument("--max-files", type=int, default=32)
    parser.add_argument("--max-total-bytes", type=int, default=64 * 1024 * 1024)
    parser.add_argument("--stale-temporary-age-seconds", type=int, default=24 * 3600)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args(list(argv) if argv is not None else None)
    try:
        report = cleanup_directory(
            args.directory,
            policy=RetentionPolicy(
                max_age_seconds=args.max_age_seconds,
                max_files=args.max_files,
                max_total_bytes=args.max_total_bytes,
                stale_temporary_age_seconds=args.stale_temporary_age_seconds,
            ),
            dry_run=args.dry_run,
        )
    except RetentionCleanupError as error:
        print(json.dumps({"format": "xaac-retention-cleanup/v1", "status": "error", "error": str(error)}, sort_keys=True, separators=(",", ":")))
        return 2
    print(json.dumps(report.to_dict(), sort_keys=True, separators=(",", ":")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

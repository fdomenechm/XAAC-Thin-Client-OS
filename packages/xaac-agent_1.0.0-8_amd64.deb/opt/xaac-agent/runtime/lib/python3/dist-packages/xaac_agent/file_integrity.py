from __future__ import annotations

import hashlib
import json
import os
import stat
from dataclasses import dataclass
from pathlib import Path


class FileIntegrityError(RuntimeError):
    """Raised when the integrity policy or manifest cannot be trusted."""


@dataclass(frozen=True, slots=True)
class FileIntegrityPolicy:
    enabled: bool = False
    required: bool = False
    manifest_path: Path = Path("/usr/share/xaac-agent/integrity-manifest.json")
    max_manifest_bytes: int = 262144
    max_files: int = 512
    max_file_bytes: int = 32 * 1024 * 1024

    def validate(self) -> None:
        if self.required and not self.enabled:
            raise FileIntegrityError("file integrity cannot be required when disabled")
        if not self.manifest_path.is_absolute():
            raise FileIntegrityError("integrity manifest path must be absolute")
        if not 1024 <= self.max_manifest_bytes <= 4 * 1024 * 1024:
            raise FileIntegrityError("integrity manifest size limit is invalid")
        if not 1 <= self.max_files <= 4096:
            raise FileIntegrityError("integrity file count limit is invalid")
        if not 1024 <= self.max_file_bytes <= 256 * 1024 * 1024:
            raise FileIntegrityError("integrity file size limit is invalid")


class FileIntegrityMonitor:
    """Verify a bounded SHA-256 manifest without following symbolic links."""

    def __init__(self, policy: FileIntegrityPolicy) -> None:
        policy.validate()
        self._policy = policy

    def sample(self) -> dict[str, object]:
        if not self._policy.enabled:
            return {"enabled": False, "severity": "normal", "compliant": True}
        try:
            entries = self._load_manifest()
            failures = self._verify(entries)
        except FileIntegrityError as error:
            if self._policy.required:
                raise
            return {
                "enabled": True,
                "required": False,
                "compliant": False,
                "severity": "warning",
                "reason": str(error),
            }

        compliant = not failures
        result: dict[str, object] = {
            "enabled": True,
            "required": self._policy.required,
            "manifest_version": 1,
            "checked_files": len(entries),
            "failed_files": len(failures),
            "compliant": compliant,
            "severity": "normal" if compliant else ("critical" if self._policy.required else "warning"),
        }
        if failures:
            # Paths are operational metadata, never file contents or expected hashes.
            result["failures"] = failures[:32]
            if self._policy.required:
                raise FileIntegrityError("critical file integrity verification failed")
        return result

    def _load_manifest(self) -> list[dict[str, object]]:
        path = self._policy.manifest_path
        try:
            info = path.lstat()
        except OSError as error:
            raise FileIntegrityError("integrity manifest unavailable") from error
        if not stat.S_ISREG(info.st_mode) or stat.S_ISLNK(info.st_mode):
            raise FileIntegrityError("integrity manifest must be a regular file")
        if info.st_size > self._policy.max_manifest_bytes:
            raise FileIntegrityError("integrity manifest exceeds size limit")
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError) as error:
            raise FileIntegrityError("integrity manifest is invalid") from error
        if not isinstance(payload, dict) or payload.get("version") != 1:
            raise FileIntegrityError("unsupported integrity manifest version")
        entries = payload.get("files")
        if not isinstance(entries, list) or not entries or len(entries) > self._policy.max_files:
            raise FileIntegrityError("integrity manifest file list is invalid")
        seen: set[str] = set()
        normalized: list[dict[str, object]] = []
        for entry in entries:
            if not isinstance(entry, dict):
                raise FileIntegrityError("integrity manifest entry is invalid")
            raw_path = entry.get("path")
            digest = entry.get("sha256")
            required = entry.get("required", True)
            if not isinstance(raw_path, str) or not Path(raw_path).is_absolute():
                raise FileIntegrityError("integrity file path must be absolute")
            if raw_path in seen:
                raise FileIntegrityError("integrity manifest contains duplicate paths")
            if not isinstance(digest, str) or len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
                raise FileIntegrityError("integrity SHA-256 digest is invalid")
            if not isinstance(required, bool):
                raise FileIntegrityError("integrity required flag is invalid")
            seen.add(raw_path)
            normalized.append({"path": raw_path, "sha256": digest, "required": required})
        return normalized

    def _verify(self, entries: list[dict[str, object]]) -> list[dict[str, str]]:
        failures: list[dict[str, str]] = []
        for entry in entries:
            path = Path(str(entry["path"]))
            required = bool(entry["required"])
            try:
                info = path.lstat()
            except OSError:
                if required:
                    failures.append({"path": str(path), "reason": "missing"})
                continue
            if stat.S_ISLNK(info.st_mode) or not stat.S_ISREG(info.st_mode):
                failures.append({"path": str(path), "reason": "not_regular"})
                continue
            if info.st_size > self._policy.max_file_bytes:
                failures.append({"path": str(path), "reason": "too_large"})
                continue
            try:
                fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_CLOEXEC", 0))
                with os.fdopen(fd, "rb") as stream:
                    digest = hashlib.file_digest(stream, "sha256").hexdigest()
            except OSError:
                failures.append({"path": str(path), "reason": "unreadable"})
                continue
            if digest != entry["sha256"]:
                failures.append({"path": str(path), "reason": "digest_mismatch"})
        return failures

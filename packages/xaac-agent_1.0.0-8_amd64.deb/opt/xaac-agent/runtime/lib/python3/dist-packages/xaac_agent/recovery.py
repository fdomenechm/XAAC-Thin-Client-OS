from __future__ import annotations

import json
import os
import tempfile
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

from xaac_agent.heartbeat_state import read_boot_id
from xaac_agent.state_recovery import KnownGoodState, StateRecoveryError


class RecoveryStateError(ValueError):
    """Persistent lifecycle state is invalid or unsafe."""


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass(frozen=True, slots=True)
class RecoveryEvent:
    event: str
    boot_id: str
    previous_boot_id: str | None
    previous_status: str | None
    recovery_count: int
    detected_at: str

    @property
    def unexpected(self) -> bool:
        return self.event in {"unexpected_reboot", "unexpected_process_restart"}

    def to_payload(self) -> dict[str, object]:
        return {
            "schema_version": 1,
            "event": self.event,
            "unexpected": self.unexpected,
            "boot_id": self.boot_id,
            "previous_boot_id": self.previous_boot_id,
            "previous_status": self.previous_status,
            "recovery_count": self.recovery_count,
            "detected_at": self.detected_at,
        }


class RecoveryStateStore:
    """Tracks clean and unexpected service termination across boots.

    The store never modifies identity, credentials, queues, or configuration. It
    only records a small lifecycle marker in the persistent state directory.
    """

    _MAX_BYTES = 16_384

    def __init__(
        self,
        path: Path,
        *,
        boot_id_provider: Callable[[], str] = read_boot_id,
        run_id_provider: Callable[[], str] = lambda: str(uuid.uuid4()),
    ) -> None:
        self.path = path
        self._boot_id_provider = boot_id_provider
        self._run_id_provider = run_id_provider
        self._active_run_id: str | None = None
        self._event: RecoveryEvent | None = None
        self._known_good = KnownGoodState(path)

    @property
    def event(self) -> RecoveryEvent | None:
        return self._event

    def begin_startup(self) -> RecoveryEvent:
        previous = self._load_optional()
        boot_id = self._boot_id_provider().strip() or "unknown"
        run_id = self._run_id_provider().strip()
        if not run_id or len(run_id) > 128:
            raise RecoveryStateError("invalid recovery run_id")

        previous_status = previous.get("status") if previous else None
        previous_boot_id = previous.get("boot_id") if previous else None
        recovery_count = int(previous.get("recovery_count", 0)) if previous else 0

        if previous is None:
            event = "first_start"
        elif previous_status == "stopped":
            event = "clean_restart"
        elif previous_boot_id == boot_id:
            event = "unexpected_process_restart"
            recovery_count += 1
        else:
            event = "unexpected_reboot"
            recovery_count += 1

        detected_at = _utc_now()
        self._active_run_id = run_id
        self._event = RecoveryEvent(
            event=event,
            boot_id=boot_id,
            previous_boot_id=previous_boot_id,
            previous_status=previous_status,
            recovery_count=recovery_count,
            detected_at=detected_at,
        )
        self._save(
            {
                "schema_version": 1,
                "status": "running",
                "boot_id": boot_id,
                "run_id": run_id,
                "started_at": detected_at,
                "stopped_at": None,
                "recovery_count": recovery_count,
                "last_event": event,
            }
        )
        return self._event

    def mark_clean_shutdown(self) -> None:
        if self._active_run_id is None:
            return
        current = self._load_required()
        if current.get("run_id") != self._active_run_id:
            raise RecoveryStateError("recovery state belongs to another process run")
        current.update({"status": "stopped", "stopped_at": _utc_now()})
        self._save(current)

    def telemetry(self) -> dict[str, object]:
        if self._event is None:
            return {
                "schema_version": 1,
                "event": "not_started",
                "unexpected": False,
                "recovery_count": 0,
            }
        return self._event.to_payload()

    def _load_optional(self) -> dict[str, object] | None:
        try:
            if self.path.is_symlink() or (self.path.exists() and not self.path.is_file()):
                raise RecoveryStateError("recovery state path must be a regular file")
            if self.path.stat().st_size > self._MAX_BYTES:
                raise RecoveryStateError("recovery state exceeds size limit")
            raw = json.loads(self.path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return None
        except (OSError, json.JSONDecodeError) as error:
            try:
                self._known_good.restore()
                raw = json.loads(self.path.read_text(encoding="utf-8"))
            except (StateRecoveryError, OSError, json.JSONDecodeError) as recovery_error:
                raise RecoveryStateError("recovery state is corrupt and has no recoverable known-good copy") from recovery_error
        self._validate(raw)
        return raw

    def _load_required(self) -> dict[str, object]:
        state = self._load_optional()
        if state is None:
            raise RecoveryStateError("recovery state is missing")
        return state

    @staticmethod
    def _validate(raw: object) -> None:
        if not isinstance(raw, dict) or raw.get("schema_version") != 1:
            raise RecoveryStateError("unsupported recovery state schema")
        if raw.get("status") not in {"running", "stopped"}:
            raise RecoveryStateError("invalid recovery status")
        for field in ("boot_id", "run_id", "started_at", "last_event"):
            value = raw.get(field)
            if not isinstance(value, str) or not value or len(value) > 256:
                raise RecoveryStateError(f"invalid recovery field: {field}")
        stopped_at = raw.get("stopped_at")
        if stopped_at is not None and (not isinstance(stopped_at, str) or len(stopped_at) > 256):
            raise RecoveryStateError("invalid recovery stopped_at")
        count = raw.get("recovery_count")
        if not isinstance(count, int) or isinstance(count, bool) or count < 0:
            raise RecoveryStateError("invalid recovery count")

    def _save(self, payload: dict[str, object]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if self.path.parent.is_symlink():
            raise RecoveryStateError("recovery state directory must not be a symlink")
        descriptor, name = tempfile.mkstemp(prefix=f".{self.path.name}.", dir=self.path.parent)
        temporary = Path(name)
        try:
            os.fchmod(descriptor, 0o600)
            with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, ensure_ascii=False, sort_keys=True)
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, self.path)
            self._known_good.snapshot()
            directory_fd = os.open(self.path.parent, os.O_RDONLY)
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
        finally:
            temporary.unlink(missing_ok=True)

from __future__ import annotations

import json
import os
import stat
import subprocess
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Protocol, Sequence

from xaac_agent.maintenance_windows import MaintenanceDecision, MaintenanceWindowEvaluator
from xaac_agent.update_model import UpdatePlan, UpdateResult, UpdateState


class RebootBackend(Protocol):
    def run(self, argv: Sequence[str], *, timeout_seconds: int) -> subprocess.CompletedProcess[str]: ...


class SubprocessRebootBackend:
    def run(self, argv: Sequence[str], *, timeout_seconds: int) -> subprocess.CompletedProcess[str]:
        return subprocess.run(list(argv), check=False, capture_output=True, text=True,
                              timeout=timeout_seconds, stdin=subprocess.DEVNULL)


@dataclass(frozen=True, slots=True)
class CoordinatedRebootManager:
    state_file: Path
    maintenance: MaintenanceWindowEvaluator
    backend: RebootBackend
    systemctl_path: str = "/usr/bin/systemctl"
    systemd_run_path: str = "/usr/bin/systemd-run"
    thin_client_unit: str = "xaac-thin-client.service"
    timeout_seconds: int = 30
    delay_seconds: int = 30
    stop_thin_client: bool = True

    @classmethod
    def system_default(cls, *, state_file: Path, maintenance: MaintenanceWindowEvaluator) -> "CoordinatedRebootManager":
        return cls(state_file=state_file, maintenance=maintenance, backend=SubprocessRebootBackend())

    def coordinate(self, plan: UpdatePlan, installation: UpdateResult, *, now: datetime | None = None) -> UpdateResult:
        if installation.update_id != plan.update_id or installation.component != plan.component or installation.target_version != plan.target_version:
            return self._result(plan, UpdateState.REJECTED, "reboot_installation_identity_mismatch")
        if installation.state not in {UpdateState.INSTALLED, UpdateState.REBOOT_PENDING}:
            return self._result(plan, UpdateState.REJECTED, "reboot_installation_not_ready")
        if not plan.reboot_required and installation.state is not UpdateState.REBOOT_PENDING:
            return self._result(plan, UpdateState.COMPLETED, "reboot_not_required")

        decision = self.maintenance.evaluate(plan, now=now)
        if not decision.allowed:
            self._persist(plan, "scheduled", decision)
            data = self._decision_data(decision)
            return self._result(plan, UpdateState.SCHEDULED, "reboot_scheduled", data=data)

        try:
            if self.stop_thin_client:
                stopped = self.backend.run((self.systemctl_path, "stop", self.thin_client_unit), timeout_seconds=self.timeout_seconds)
                if stopped.returncode != 0:
                    return self._result(plan, UpdateState.FAILED, "reboot_service_stop_failed", _detail(stopped))
            self._persist(plan, "requested", decision)
            argv = (self.systemd_run_path, "--quiet", "--collect", f"--on-active={self.delay_seconds}s",
                    "--property=Type=oneshot", "--", self.systemctl_path, "reboot")
            completed = self.backend.run(argv, timeout_seconds=self.timeout_seconds)
        except subprocess.TimeoutExpired:
            return self._result(plan, UpdateState.FAILED, "reboot_backend_timeout")
        except OSError as error:
            return self._result(plan, UpdateState.FAILED, "reboot_backend_error", message=str(error))
        if completed.returncode != 0:
            return self._result(plan, UpdateState.FAILED, "reboot_request_failed", _detail(completed))
        return self._result(plan, UpdateState.REBOOT_PENDING, "coordinated_reboot_requested", data={
            "delay_seconds": self.delay_seconds, "thin_client_stopped": self.stop_thin_client,
            "state_file": str(self.state_file), **self._decision_data(decision),
        })

    def read_pending(self) -> dict[str, object] | None:
        if not self.state_file.exists():
            return None
        if self.state_file.is_symlink() or not stat.S_ISREG(self.state_file.stat().st_mode):
            raise ValueError("invalid_reboot_state_file")
        return json.loads(self.state_file.read_text(encoding="utf-8"))

    def clear_pending(self) -> None:
        if self.state_file.is_symlink():
            raise ValueError("invalid_reboot_state_file")
        self.state_file.unlink(missing_ok=True)

    def _persist(self, plan: UpdatePlan, status: str, decision: MaintenanceDecision) -> None:
        parent = self.state_file.parent
        parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        if parent.is_symlink() or (self.state_file.exists() and self.state_file.is_symlink()):
            raise ValueError("invalid_reboot_state_path")
        payload = {"schema": "xaac-update-reboot/v1", "update_id": plan.update_id,
                   "component": plan.component.value, "target_version": plan.target_version,
                   "status": status, "recorded_at": _utc_now(), **self._decision_data(decision)}
        fd, tmp = tempfile.mkstemp(prefix=".reboot-", dir=parent)
        try:
            os.fchmod(fd, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as stream:
                json.dump(payload, stream, sort_keys=True, separators=(",", ":")); stream.flush(); os.fsync(stream.fileno())
            os.replace(tmp, self.state_file)
            os.chmod(self.state_file, 0o600)
        finally:
            try: os.unlink(tmp)
            except FileNotFoundError: pass

    @staticmethod
    def _decision_data(decision: MaintenanceDecision) -> dict[str, object]:
        data: dict[str, object] = {"maintenance_code": decision.code, "timezone": decision.timezone_name,
                                  "evaluated_at": decision.evaluated_at.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")}
        if decision.next_window_at is not None:
            data["next_reboot_at"] = decision.next_window_at.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
        return data

    @staticmethod
    def _result(plan: UpdatePlan, state: UpdateState, code: str, completed=None, message=None, data=None) -> UpdateResult:
        return UpdateResult(plan.update_id, plan.component, plan.target_version, state, code=code,
                            message=message, data=data or {})


def _detail(completed: subprocess.CompletedProcess[str]) -> str | None:
    value = completed.stderr or completed.stdout
    return " ".join(value.split())[:512] if value else None


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

from __future__ import annotations

import json
import os
import stat
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable


class OfflineStateError(RuntimeError):
    """L'estat offline persistent és invàlid o insegur."""


UtcClock = Callable[[], datetime]


def _utc_now_datetime() -> datetime:
    return datetime.now(timezone.utc)


def _format_utc(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat().replace('+00:00', 'Z')


def _parse_utc(value: str | None) -> datetime | None:
    if value is None:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
    except ValueError as error:
        raise OfflineStateError("marca temporal offline invàlida") from error
    if parsed.tzinfo is None:
        raise OfflineStateError("marca temporal offline sense zona horària")
    return parsed.astimezone(timezone.utc)


@dataclass(frozen=True, slots=True)
class OfflineState:
    status: str = "online"
    offline_since: str | None = None
    last_online_at: str | None = None
    last_failure_at: str | None = None
    retry_not_before: str | None = None
    consecutive_failures: int = 0
    next_retry_seconds: float = 0.0
    reason: str | None = None
    prolonged: bool = False

    @property
    def offline(self) -> bool:
        return self.status == "offline"

    def outage_seconds(self, *, now: datetime | None = None) -> float:
        started = _parse_utc(self.offline_since)
        if not self.offline or started is None:
            return 0.0
        current = (now or _utc_now_datetime()).astimezone(timezone.utc)
        return max(0.0, (current - started).total_seconds())

    def remaining_retry_seconds(self, *, now: datetime | None = None) -> float:
        retry_at = _parse_utc(self.retry_not_before)
        if retry_at is None:
            return max(0.0, self.next_retry_seconds)
        current = (now or _utc_now_datetime()).astimezone(timezone.utc)
        return max(0.0, (retry_at - current).total_seconds())

    def to_payload(self, *, now: datetime | None = None) -> dict[str, object]:
        payload = asdict(self)
        payload["outage_seconds"] = round(self.outage_seconds(now=now), 3)
        payload["next_retry_seconds"] = round(self.remaining_retry_seconds(now=now), 3)
        return payload


class OfflineStateStore:
    SCHEMA_VERSION = 2

    def __init__(
        self,
        path: Path,
        *,
        prolonged_threshold_seconds: float = 3600.0,
        clock: UtcClock = _utc_now_datetime,
    ) -> None:
        self.path = path
        self._threshold = max(1.0, float(prolonged_threshold_seconds))
        self._clock = clock

    def load(self) -> OfflineState:
        if not self.path.exists():
            return OfflineState()
        try:
            mode = self.path.lstat().st_mode
            if stat.S_ISLNK(mode) or not stat.S_ISREG(mode):
                raise OfflineStateError("l'estat offline ha de ser un fitxer regular")
            payload = json.loads(self.path.read_text(encoding="utf-8"))
        except OfflineStateError:
            raise
        except (OSError, json.JSONDecodeError) as error:
            raise OfflineStateError("estat offline no llegible o JSON invàlid") from error
        if not isinstance(payload, dict) or payload.get("schema_version") not in {1, self.SCHEMA_VERSION}:
            raise OfflineStateError("esquema d'estat offline no compatible")
        status = payload.get("status")
        if status not in {"online", "offline"}:
            raise OfflineStateError("status offline invàlid")
        failures = payload.get("consecutive_failures", 0)
        retry = payload.get("next_retry_seconds", 0.0)
        if isinstance(failures, bool) or not isinstance(failures, int) or failures < 0:
            raise OfflineStateError("consecutive_failures invàlid")
        if isinstance(retry, bool) or not isinstance(retry, (int, float)) or retry < 0:
            raise OfflineStateError("next_retry_seconds invàlid")
        for name in ("offline_since", "last_online_at", "last_failure_at", "retry_not_before", "reason"):
            value = payload.get(name)
            if value is not None and not isinstance(value, str):
                raise OfflineStateError(f"{name} invàlid")
            if name != "reason" and value is not None:
                _parse_utc(value)
        prolonged = payload.get("prolonged", False)
        if not isinstance(prolonged, bool):
            raise OfflineStateError("prolonged invàlid")
        state = OfflineState(
            status=status,
            offline_since=payload.get("offline_since"),
            last_online_at=payload.get("last_online_at"),
            last_failure_at=payload.get("last_failure_at"),
            retry_not_before=payload.get("retry_not_before"),
            consecutive_failures=failures,
            next_retry_seconds=float(retry),
            reason=payload.get("reason"),
            prolonged=prolonged,
        )
        if state.offline and state.outage_seconds(now=self._clock()) >= self._threshold and not state.prolonged:
            state = OfflineState(**{**asdict(state), "prolonged": True})
        return state

    def mark_offline(self, reason: str, *, retry_seconds: float = 0.0) -> OfflineState:
        current = self.load()
        now = self._clock().astimezone(timezone.utc)
        started = current.offline_since or _format_utc(now)
        retry = max(0.0, float(retry_seconds))
        prolonged = current.prolonged or (
            now - (_parse_utc(started) or now)
        ).total_seconds() >= self._threshold
        state = OfflineState(
            status="offline",
            offline_since=started,
            last_online_at=current.last_online_at,
            last_failure_at=_format_utc(now),
            retry_not_before=_format_utc(now + timedelta(seconds=retry)) if retry > 0 else None,
            consecutive_failures=current.consecutive_failures + 1,
            next_retry_seconds=retry,
            reason=str(reason).strip() or "communication_failure",
            prolonged=prolonged,
        )
        self._write(state)
        return state

    def mark_online(self) -> OfflineState:
        state = OfflineState(status="online", last_online_at=_format_utc(self._clock()))
        self._write(state)
        return state

    def _write(self, state: OfflineState) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_name(f".{self.path.name}.{os.getpid()}.tmp")
        payload: dict[str, Any] = {"schema_version": self.SCHEMA_VERSION, **asdict(state)}
        try:
            descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
                json.dump(payload, stream, ensure_ascii=False, sort_keys=True)
                stream.write("\n")
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.path)
            os.chmod(self.path, 0o600)
            directory = os.open(self.path.parent, os.O_RDONLY)
            try:
                os.fsync(directory)
            finally:
                os.close(directory)
        finally:
            temporary.unlink(missing_ok=True)

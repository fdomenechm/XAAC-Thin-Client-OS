from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any


class DebianPackageUpgradeError(ValueError):
    """Raised when the Debian package-upgrade policy is unsafe."""


@dataclass(frozen=True, slots=True)
class DebianPackageUpgradePolicy:
    package: str
    runtime_python: Path
    required_version: str
    system_python_modified: bool
    config_path: Path
    backup_path: Path
    migration_command: Path
    rollback_on_failure: bool
    preserve_existing: bool
    service_unit: str
    socket_unit: str
    active_marker: Path
    stop_before_unpack: bool
    restore_previous_state: bool
    start_when_previously_inactive: bool
    preserve_paths: tuple[Path, ...]
    purge_during_upgrade: bool

    @classmethod
    def load(cls, path: Path) -> "DebianPackageUpgradePolicy":
        try:
            raw: Any = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise DebianPackageUpgradeError("debian_package_upgrade_invalid") from exc
        if not isinstance(raw, dict) or raw.get("schema_version") != 1:
            raise DebianPackageUpgradeError("debian_package_upgrade_schema_invalid")
        runtime = raw.get("runtime")
        config = raw.get("configuration")
        service = raw.get("service")
        state = raw.get("state")
        if not all(isinstance(item, dict) for item in (runtime, config, service, state)):
            raise DebianPackageUpgradeError("debian_package_upgrade_sections_invalid")
        preserve_paths = state.get("preserve_paths")
        if not isinstance(preserve_paths, list):
            raise DebianPackageUpgradeError("debian_package_upgrade_preserve_paths_invalid")
        return cls(
            package=str(raw.get("package", "")),
            runtime_python=Path(str(runtime.get("python", ""))),
            required_version=str(runtime.get("required_version", "")),
            system_python_modified=runtime.get("system_python_modified") is True,
            config_path=Path(str(config.get("path", ""))),
            backup_path=Path(str(config.get("backup_path", ""))),
            migration_command=Path(str(config.get("migration_command", ""))),
            rollback_on_failure=config.get("rollback_on_failure") is True,
            preserve_existing=config.get("preserve_existing") is True,
            service_unit=str(service.get("unit", "")),
            socket_unit=str(service.get("socket_unit", "")),
            active_marker=Path(str(service.get("active_marker", ""))),
            stop_before_unpack=service.get("stop_before_unpack") is True,
            restore_previous_state=service.get("restore_previous_state") is True,
            start_when_previously_inactive=service.get("start_when_previously_inactive") is True,
            preserve_paths=tuple(Path(str(value)) for value in preserve_paths),
            purge_during_upgrade=state.get("purge_during_upgrade") is True,
        )

    def validate(self) -> None:
        if self.package != "xaac-agent":
            raise DebianPackageUpgradeError("debian_package_upgrade_package_invalid")
        if self.runtime_python != Path("/opt/xaac-agent/runtime/bin/python3.13") or self.required_version != "3.13":
            raise DebianPackageUpgradeError("debian_package_upgrade_runtime_invalid")
        if self.system_python_modified:
            raise DebianPackageUpgradeError("debian_package_upgrade_system_python_invalid")
        if self.config_path != Path("/etc/xaac-agent/agent.ini") or not self.preserve_existing:
            raise DebianPackageUpgradeError("debian_package_upgrade_configuration_invalid")
        if self.backup_path != Path("/var/lib/xaac-agent/upgrade/agent.ini.before-upgrade"):
            raise DebianPackageUpgradeError("debian_package_upgrade_backup_invalid")
        if self.migration_command != Path("/opt/xaac-agent/runtime/bin/xaac-config-migrate"):
            raise DebianPackageUpgradeError("debian_package_upgrade_migration_invalid")
        if not self.rollback_on_failure:
            raise DebianPackageUpgradeError("debian_package_upgrade_rollback_invalid")
        if self.service_unit != "xaac-agent.service" or self.socket_unit != "xaac-privileged-helper.socket":
            raise DebianPackageUpgradeError("debian_package_upgrade_units_invalid")
        if self.active_marker != Path("/run/xaac-agent/upgrade-was-active"):
            raise DebianPackageUpgradeError("debian_package_upgrade_marker_invalid")
        if not self.stop_before_unpack or not self.restore_previous_state or self.start_when_previously_inactive:
            raise DebianPackageUpgradeError("debian_package_upgrade_service_policy_invalid")
        expected = {
            Path("/var/lib/xaac-agent"),
            Path("/var/cache/xaac-agent"),
            Path("/var/log/xaac-agent"),
        }
        if set(self.preserve_paths) != expected or len(self.preserve_paths) != len(expected) or self.purge_during_upgrade:
            raise DebianPackageUpgradeError("debian_package_upgrade_state_policy_invalid")
        for path in (*self.preserve_paths, self.backup_path, self.active_marker, self.migration_command):
            if not path.is_absolute() or ".." in path.parts:
                raise DebianPackageUpgradeError("debian_package_upgrade_path_unsafe")

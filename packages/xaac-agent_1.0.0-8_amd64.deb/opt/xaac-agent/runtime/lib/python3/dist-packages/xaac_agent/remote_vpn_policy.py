from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from xaac_agent.policy_application import PolicyApplicationError, PolicyTransactionApplier
from xaac_agent.policy_audit import PolicyAuditError, PolicyAuditJournal
from xaac_agent.policy_compatibility import PolicyCompatibilityChecker, PolicyCompatibilityError
from xaac_agent.policy_conflicts import PolicyConflictError, PolicyConflictResolver, load_local_policy_overlay
from xaac_agent.policy_model import Policy, PolicyResult, PolicyState, PolicyType, PolicyValidationError
from xaac_agent.policy_schema import PolicySchemaError, PolicySchemaRegistry
from xaac_agent.policy_trust import PolicyTrustError, PolicyTrustVerifier, parse_trusted_policy_keys
from xaac_agent.vpn_policy import VALID_VPN_POLICIES, VpnPolicyController, VpnPolicyError

logger = logging.getLogger(__name__)


@dataclass(slots=True)
class RemoteVpnPolicyProcessor:
    verifier: PolicyTrustVerifier
    schema_registry: PolicySchemaRegistry
    compatibility: PolicyCompatibilityChecker
    conflict_resolver: PolicyConflictResolver
    local_overlay_file: Path
    applier: PolicyTransactionApplier
    audit: PolicyAuditJournal
    vpn: VpnPolicyController

    @classmethod
    def from_settings(cls, settings: object, *, vpn: VpnPolicyController | None = None) -> "RemoteVpnPolicyProcessor":
        trusted = parse_trusted_policy_keys(tuple(getattr(settings, "policy_trusted_keys")))
        return cls(
            verifier=PolicyTrustVerifier(
                trusted,
                allowed_issuer_kinds=tuple(getattr(settings, "policy_allowed_issuer_kinds")),
                allowed_policy_types=(PolicyType.SYSTEM,),
            ),
            schema_registry=PolicySchemaRegistry(),
            compatibility=PolicyCompatibilityChecker(
                local_capabilities=tuple(getattr(settings, "policy_local_capabilities")),
            ),
            conflict_resolver=PolicyConflictResolver(tuple(getattr(settings, "policy_protected_paths"))),
            local_overlay_file=Path(getattr(settings, "policy_local_overlay_file")),
            applier=PolicyTransactionApplier(Path(getattr(settings, "policy_application_directory"))),
            audit=PolicyAuditJournal(
                Path(getattr(settings, "policy_audit_file")),
                max_records=int(getattr(settings, "policy_audit_max_records")),
            ),
            vpn=vpn or VpnPolicyController.system_default(),
        )

    def process(self, document: Mapping[str, Any]) -> PolicyResult:
        policy = self._parse_identity(document)
        self._audit_policy("received", policy, state=PolicyState.RECEIVED.value)
        try:
            verified = self.verifier.verify(document)
            policy = verified.policy
            validated = self.schema_registry.validate(policy)
            if validated.schema_id != "xaac-system-policy" or validated.schema_revision != 2:
                raise PolicySchemaError(
                    "vpn_policy_requires_system_schema_v2",
                    path="metadata.content_schema_revision",
                )
            if set(validated.normalized_sections) != {"vpn"}:
                raise PolicySchemaError("vpn_policy_contains_unsupported_sections", path="sections")
            compatible = self.compatibility.check(policy)
            local = load_local_policy_overlay(self.local_overlay_file)
            resolved = self.conflict_resolver.resolve(validated, local)
            vpn_section = resolved.normalized_sections.get("vpn")
            mode = vpn_section.get("mode") if isinstance(vpn_section, Mapping) else None
            if mode not in VALID_VPN_POLICIES:
                raise PolicySchemaError("vpn_policy_mode_unavailable", path="sections.vpn.mode")
            self._reject_stale(policy)
        except (PolicyTrustError, PolicySchemaError, PolicyCompatibilityError, PolicyConflictError) as error:
            result = PolicyResult(
                policy.policy_id,
                policy.revision,
                PolicyState.REJECTED,
                code=getattr(error, "code", str(error)),
                data=self._error_data(error),
            )
            self._audit_result("rejected", result)
            return result

        before = None
        changed = False
        try:
            before = self.vpn.status()
            if before.policy != mode:
                self.vpn.apply(str(mode))
                changed = True
            applied = self.applier.apply(resolved, verified, compatible)
        except (VpnPolicyError, PolicyApplicationError) as error:
            rollback_failed = False
            if changed and before is not None:
                try:
                    self.vpn.apply(before.policy)
                except VpnPolicyError:
                    rollback_failed = True
            code = getattr(error, "code", str(error))
            if rollback_failed:
                code = f"{code}_vpn_rollback_failed"
            result = PolicyResult(
                policy.policy_id,
                policy.revision,
                PolicyState.FAILED,
                code=code,
                data={"vpn_mode": str(mode), "rollback_failed": rollback_failed},
            )
            self._audit_result("failed", result)
            return result

        result = PolicyResult(
            policy.policy_id,
            policy.revision,
            PolicyState.APPLIED,
            code="vpn_policy_applied",
            data={
                "vpn_mode": str(mode),
                "previous_vpn_mode": before.policy if before is not None else None,
                "changed": changed,
                "sha256": applied.sha256,
                "previous_preserved": applied.previous_preserved,
                "schema_id": resolved.schema_id,
                "schema_revision": resolved.schema_revision,
            },
        )
        self._audit_result("applied", result)
        return result

    def _reject_stale(self, policy: Policy) -> None:
        active = self.applier.load_active()
        if not active or active.get("policy_id") != policy.policy_id:
            return
        revision = active.get("revision")
        if isinstance(revision, int) and not isinstance(revision, bool) and revision >= policy.revision:
            raise PolicyCompatibilityError("policy_revision_not_newer", detail=str(revision))

    @staticmethod
    def _parse_identity(document: Mapping[str, Any]) -> Policy:
        try:
            return Policy.from_payload(document)
        except PolicyValidationError:
            # The service only calls this processor for object-like policies. A malformed
            # identity cannot be acknowledged safely because XMS could not correlate it.
            raise

    @staticmethod
    def _error_data(error: object) -> dict[str, object]:
        data: dict[str, object] = {}
        path = getattr(error, "path", None)
        detail = getattr(error, "detail", None)
        message = getattr(error, "message", None)
        if isinstance(path, str) and path:
            data["path"] = path
        if isinstance(detail, str) and detail:
            data["detail"] = detail[:512]
        elif isinstance(message, str) and message:
            data["detail"] = message[:512]
        return data

    def _audit_policy(self, event: str, policy: Policy, *, state: str | None = None) -> None:
        try:
            self.audit.append_policy(event, policy, state=state)
        except PolicyAuditError as error:
            logger.error("vpn_policy_audit_failed event=%s error=%s", event, error)

    def _audit_result(self, event: str, result: PolicyResult) -> None:
        try:
            self.audit.append_result(event, result)
        except PolicyAuditError as error:
            logger.error("vpn_policy_audit_failed event=%s error=%s", event, error)

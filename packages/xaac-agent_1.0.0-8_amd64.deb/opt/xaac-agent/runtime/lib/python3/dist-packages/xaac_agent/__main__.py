from __future__ import annotations

import argparse
import logging
from pathlib import Path

from xaac_agent.config import AgentConfigurationError, AgentSettings
from xaac_agent.enrollment import EnrollmentError
from xaac_agent.transport import AgentTransportError
from xaac_agent.process_lock import AgentAlreadyRunningError, InvalidLockFileError
from xaac_agent.service import AgentService
from xaac_agent.secrets import redact_text
from xaac_agent.structured_logging import configure_logging


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="XAAC management agent")
    parser.add_argument("--config", type=Path, default=Path("/etc/xaac-agent/agent.ini"))
    action = parser.add_mutually_exclusive_group()
    action.add_argument("--once", action="store_true", help="executa un únic heartbeat")
    action.add_argument("--unenroll", action="store_true", help="desenrola el dispositiu de XMS")
    action.add_argument(
        "--authorize-reenrollment",
        action="store_true",
        help="autoritza localment un únic reenrolament controlat",
    )
    parser.add_argument(
        "--reason",
        default="administrator_request",
        help="motiu auditable per al desenrolament",
    )
    parser.add_argument("--log-level", default="INFO", choices=("DEBUG", "INFO", "WARNING", "ERROR"))
    parser.add_argument(
        "--log-format",
        default="json",
        choices=("json", "text"),
        help="format d'eixida del registre; json és el valor segur per defecte",
    )
    return parser


def main() -> int:
    args = build_parser().parse_args()
    configure_logging(level=args.log_level, output_format=args.log_format)
    try:
        settings = AgentSettings.load(args.config)
    except AgentConfigurationError as error:
        logging.getLogger(__name__).error("configuration_error error=%s", redact_text(error))
        return 2
    service = AgentService(settings, config_path=args.config)
    try:
        if args.unenroll:
            return 0 if service.unenroll(reason=args.reason) else 1
        if args.authorize_reenrollment:
            service.authorize_reenrollment()
            return 0
        if args.once:
            return 0 if service.run_once() else 1
        return service.run_forever()
    except AgentAlreadyRunningError as error:
        logging.getLogger(__name__).error("agent_already_running error=%s", redact_text(error))
        return 3
    except InvalidLockFileError as error:
        logging.getLogger(__name__).error("process_lock_error error=%s", redact_text(error))
        return 4
    except (EnrollmentError, AgentTransportError) as error:
        logging.getLogger(__name__).error("device_registration_action_failed error=%s", redact_text(error))
        return 5


if __name__ == "__main__":
    raise SystemExit(main())

from __future__ import annotations

import re
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, Mapping

from xaac_agent.command_model import Command, CommandType


_SERVICE_PATTERN = re.compile(r"^[A-Za-z0-9_.@:-]{1,200}\.service$")
_TASK_PATTERN = re.compile(r"^[a-z0-9][a-z0-9._-]{0,127}$")
_USER_PATTERN = re.compile(r"^[a-z_][a-z0-9_-]{0,31}$")
_TARGET_PATTERN = re.compile(r"^[a-z0-9][a-z0-9._-]{0,127}$")
_SHA256_PATTERN = re.compile(r"^[a-fA-F0-9]{64}$")
_BASE64_PATTERN = re.compile(r"^[A-Za-z0-9+/]+={0,2}$")


_REQUIRED_LOCAL_CAPABILITIES: Mapping[CommandType, frozenset[str]] = MappingProxyType({
    CommandType.NOOP: frozenset({"command-noop"}),
    CommandType.REBOOT: frozenset({"command-reboot", "system-power"}),
    CommandType.POWEROFF: frozenset({"command-poweroff", "system-power"}),
    CommandType.SERVICE: frozenset({"command-service"}),
    CommandType.TASK: frozenset({"command-task"}),
    CommandType.FILE_TRANSFER: frozenset({"command-file-transfer"}),
    CommandType.COLLECT_LOGS: frozenset({"command-collect-logs"}),
    CommandType.SIGNED_SCRIPT: frozenset({"command-signed-script"}),
    CommandType.CANCEL: frozenset({"command-cancel"}),
})

_PRIVILEGED_TYPES = frozenset({
    CommandType.REBOOT,
    CommandType.POWEROFF,
    CommandType.SERVICE,
    CommandType.SIGNED_SCRIPT,
})


@dataclass(frozen=True, slots=True)
class AuthorizationDecision:
    allowed: bool
    code: str
    effective_user: str
    privilege_separation_required: bool = False
    detail: str | None = None


@dataclass(frozen=True, slots=True)
class CommandAuthorizationPolicy:
    """Política local immutable. Una ordre només s'admet si supera totes les capes."""

    allowed_types: frozenset[CommandType] = frozenset()
    local_capabilities: frozenset[str] = frozenset()
    allowed_issuer_kinds: frozenset[str] = frozenset({"xms"})
    agent_user: str = "xaac-agent"
    privileged_helper_user: str = "xaac-command-helper"
    allowed_services: frozenset[str] = frozenset()
    allowed_tasks: frozenset[str] = frozenset()
    allowed_file_targets: frozenset[str] = frozenset()
    allowed_log_sources: frozenset[str] = frozenset()
    allowed_signed_scripts: frozenset[str] = frozenset()
    trusted_script_keys: frozenset[str] = frozenset()
    max_script_bytes: int = 1024 * 1024
    max_log_lines: int = 500
    max_log_bytes: int = 65536
    max_log_since_seconds: int = 86400
    max_file_bytes: int = 16 * 1024 * 1024
    max_delay_seconds: int = 300
    max_timeout_seconds: int = 300
    restrictions: Mapping[str, bool] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not _USER_PATTERN.fullmatch(self.agent_user):
            raise ValueError("invalid_agent_user")
        if not _USER_PATTERN.fullmatch(self.privileged_helper_user):
            raise ValueError("invalid_privileged_helper_user")
        if self.agent_user == self.privileged_helper_user:
            raise ValueError("privilege_users_must_differ")
        if not 1 <= self.max_log_lines <= 10000:
            raise ValueError("invalid_max_log_lines")
        if not 1024 <= self.max_log_bytes <= 4 * 1024 * 1024:
            raise ValueError("invalid_max_log_bytes")
        if not 60 <= self.max_log_since_seconds <= 30 * 86400:
            raise ValueError("invalid_max_log_since_seconds")
        if not 1 <= self.max_script_bytes <= 64 * 1024 * 1024:
            raise ValueError("invalid_max_script_bytes")
        if not 1 <= self.max_file_bytes <= 1024 * 1024 * 1024:
            raise ValueError("invalid_max_file_bytes")
        if not 0 <= self.max_delay_seconds <= 3600:
            raise ValueError("invalid_max_delay_seconds")
        if not 1 <= self.max_timeout_seconds <= 3600:
            raise ValueError("invalid_max_timeout_seconds")

    @classmethod
    def from_strings(
        cls,
        *,
        allowed_types: tuple[str, ...] = (),
        local_capabilities: tuple[str, ...] = (),
        allowed_issuer_kinds: tuple[str, ...] = ("xms",),
        agent_user: str = "xaac-agent",
        privileged_helper_user: str = "xaac-command-helper",
        allowed_services: tuple[str, ...] = (),
        allowed_tasks: tuple[str, ...] = (),
        allowed_file_targets: tuple[str, ...] = (),
        allowed_log_sources: tuple[str, ...] = (),
        allowed_signed_scripts: tuple[str, ...] = (),
        trusted_script_keys: tuple[str, ...] = (),
        max_script_bytes: int = 1024 * 1024,
        max_log_lines: int = 500,
        max_log_bytes: int = 65536,
        max_log_since_seconds: int = 86400,
        max_file_bytes: int = 16 * 1024 * 1024,
        max_delay_seconds: int = 300,
        max_timeout_seconds: int = 300,
    ) -> "CommandAuthorizationPolicy":
        parsed_types: set[CommandType] = set()
        for value in allowed_types:
            try:
                parsed_types.add(CommandType(value.strip().lower()))
            except ValueError as error:
                raise ValueError(f"unsupported_allowed_command_type:{value}") from error
        return cls(
            allowed_types=frozenset(parsed_types),
            local_capabilities=frozenset(value.strip() for value in local_capabilities if value.strip()),
            allowed_issuer_kinds=frozenset(value.strip().lower() for value in allowed_issuer_kinds if value.strip()),
            agent_user=agent_user.strip(),
            privileged_helper_user=privileged_helper_user.strip(),
            allowed_services=frozenset(value.strip() for value in allowed_services if value.strip()),
            allowed_tasks=frozenset(value.strip() for value in allowed_tasks if value.strip()),
            allowed_file_targets=frozenset(value.strip() for value in allowed_file_targets if value.strip()),
            allowed_log_sources=frozenset(value.strip() for value in allowed_log_sources if value.strip()),
            allowed_signed_scripts=frozenset(value.strip() for value in allowed_signed_scripts if value.strip()),
            trusted_script_keys=frozenset(value.strip() for value in trusted_script_keys if value.strip()),
            max_script_bytes=max_script_bytes,
            max_log_lines=max_log_lines, max_log_bytes=max_log_bytes, max_log_since_seconds=max_log_since_seconds,
            max_file_bytes=max_file_bytes,
            max_delay_seconds=max_delay_seconds,
            max_timeout_seconds=max_timeout_seconds,
        )

    def authorize(self, command: Command) -> AuthorizationDecision:
        privileged = command.command_type in _PRIVILEGED_TYPES
        effective_user = self.privileged_helper_user if privileged else self.agent_user

        if command.command_type not in self.allowed_types:
            return self._deny("command_type_not_allowed", effective_user, privileged)
        if command.issuer.kind not in self.allowed_issuer_kinds:
            return self._deny("issuer_kind_not_allowed", effective_user, privileged)

        required_local = _REQUIRED_LOCAL_CAPABILITIES[command.command_type]
        missing_local = sorted(required_local - self.local_capabilities)
        if missing_local:
            return self._deny("local_capability_missing", effective_user, privileged, ",".join(missing_local))
        undeclared = sorted(required_local - set(command.required_capabilities))
        if undeclared:
            return self._deny("required_capability_not_declared", effective_user, privileged, ",".join(undeclared))
        unsupported = sorted(set(command.required_capabilities) - self.local_capabilities)
        if unsupported:
            return self._deny("required_capability_unavailable", effective_user, privileged, ",".join(unsupported))

        parameter_error = self._validate_parameters(command)
        if parameter_error is not None:
            code, detail = parameter_error
            return self._deny(code, effective_user, privileged, detail)

        return AuthorizationDecision(
            allowed=True,
            code="authorized",
            effective_user=effective_user,
            privilege_separation_required=privileged,
        )

    def _validate_parameters(self, command: Command) -> tuple[str, str | None] | None:
        parameters = command.parameters
        forbidden = {"command", "shell", "argv", "executable", "effective_user", "run_as", "sudo"}
        present_forbidden = sorted(forbidden & parameters.keys())
        if present_forbidden:
            return "forbidden_parameter", present_forbidden[0]

        if command.command_type is CommandType.NOOP:
            return self._only(parameters, set())
        if command.command_type is CommandType.CANCEL:
            error = self._only(parameters, {"target_command_id", "reason"})
            if error:
                return error
            target = parameters.get("target_command_id")
            if not isinstance(target, str) or not _TASK_PATTERN.fullmatch(target):
                return "invalid_target_command_id", None
            if target == command.command_id:
                return "cannot_cancel_self", None
            reason = parameters.get("reason")
            if reason is not None and (not isinstance(reason, str) or not reason.strip() or len(reason) > 512):
                return "invalid_reason", None
            return None
        if command.command_type in {CommandType.REBOOT, CommandType.POWEROFF}:
            error = self._only(parameters, {"delay_seconds", "force", "reason"})
            if error:
                return error
            delay = parameters.get("delay_seconds", 0)
            if isinstance(delay, bool) or not isinstance(delay, int) or not 0 <= delay <= self.max_delay_seconds:
                return "invalid_delay_seconds", None
            force = parameters.get("force", False)
            if not isinstance(force, bool):
                return "invalid_force", None
            reason = parameters.get("reason")
            if reason is not None and (not isinstance(reason, str) or not reason.strip() or len(reason) > 512):
                return "invalid_reason", None
            return None
        if command.command_type is CommandType.SERVICE:
            error = self._only(parameters, {"service", "action", "timeout_seconds"})
            if error:
                return error
            service = parameters.get("service")
            action = parameters.get("action")
            if not isinstance(service, str) or not _SERVICE_PATTERN.fullmatch(service):
                return "invalid_service", None
            if service not in self.allowed_services:
                return "service_not_allowed", service
            if action not in {"start", "stop", "restart", "reload", "status"}:
                return "invalid_service_action", None
            return self._validate_timeout(parameters)
        if command.command_type is CommandType.FILE_TRANSFER:
            error = self._only(parameters, {"source_url", "target_id", "sha256", "size_bytes", "overwrite", "timeout_seconds"})
            if error:
                return error
            source_url = parameters.get("source_url")
            target_id = parameters.get("target_id")
            digest = parameters.get("sha256")
            size_bytes = parameters.get("size_bytes")
            overwrite = parameters.get("overwrite", False)
            if not isinstance(source_url, str) or not source_url.startswith("https://") or len(source_url) > 2048:
                return "invalid_source_url", None
            if not isinstance(target_id, str) or not _TARGET_PATTERN.fullmatch(target_id):
                return "invalid_file_target", None
            if target_id not in self.allowed_file_targets:
                return "file_target_not_allowed", target_id
            if not isinstance(digest, str) or not _SHA256_PATTERN.fullmatch(digest):
                return "invalid_file_sha256", None
            if isinstance(size_bytes, bool) or not isinstance(size_bytes, int) or not 1 <= size_bytes <= self.max_file_bytes:
                return "invalid_file_size", None
            if not isinstance(overwrite, bool):
                return "invalid_overwrite", None
            return self._validate_timeout(parameters)
        if command.command_type is CommandType.COLLECT_LOGS:
            error = self._only(parameters, {"source_ids", "since_seconds", "max_lines", "max_bytes", "timeout_seconds"})
            if error:
                return error
            source_ids = parameters.get("source_ids")
            if not isinstance(source_ids, list) or not source_ids or len(source_ids) > 8:
                return "invalid_log_sources", None
            for source_id in source_ids:
                if not isinstance(source_id, str) or not _TARGET_PATTERN.fullmatch(source_id):
                    return "invalid_log_source", None
                if source_id not in self.allowed_log_sources:
                    return "log_source_not_allowed", source_id
            since = parameters.get("since_seconds", 3600)
            lines = parameters.get("max_lines", self.max_log_lines)
            size = parameters.get("max_bytes", self.max_log_bytes)
            if isinstance(since, bool) or not isinstance(since, int) or not 60 <= since <= self.max_log_since_seconds:
                return "invalid_log_since_seconds", None
            if isinstance(lines, bool) or not isinstance(lines, int) or not 1 <= lines <= self.max_log_lines:
                return "invalid_log_max_lines", None
            if isinstance(size, bool) or not isinstance(size, int) or not 1024 <= size <= self.max_log_bytes:
                return "invalid_log_max_bytes", None
            return self._validate_timeout(parameters)
        if command.command_type is CommandType.SIGNED_SCRIPT:
            error = self._only(parameters, {"script_id", "key_id", "sha256", "signature", "timeout_seconds"})
            if error:
                return error
            script_id, key_id = parameters.get("script_id"), parameters.get("key_id")
            digest, signature = parameters.get("sha256"), parameters.get("signature")
            if not isinstance(script_id, str) or not _TASK_PATTERN.fullmatch(script_id):
                return "invalid_script_id", None
            if script_id not in self.allowed_signed_scripts:
                return "signed_script_not_allowed", script_id
            if not isinstance(key_id, str) or not _TASK_PATTERN.fullmatch(key_id):
                return "invalid_script_key_id", None
            if key_id not in self.trusted_script_keys:
                return "script_signing_key_untrusted", key_id
            if not isinstance(digest, str) or not _SHA256_PATTERN.fullmatch(digest):
                return "invalid_script_sha256", None
            if not isinstance(signature, str) or len(signature) > 256 or not _BASE64_PATTERN.fullmatch(signature):
                return "invalid_script_signature", None
            return self._validate_timeout(parameters)
        if command.command_type is CommandType.TASK:
            error = self._only(parameters, {"task_id", "arguments", "timeout_seconds"})
            if error:
                return error
            task_id = parameters.get("task_id")
            if not isinstance(task_id, str) or not _TASK_PATTERN.fullmatch(task_id):
                return "invalid_task_id", None
            if task_id not in self.allowed_tasks:
                return "task_not_allowed", task_id
            arguments = parameters.get("arguments", {})
            if not isinstance(arguments, dict):
                return "invalid_task_arguments", None
            return self._validate_timeout(parameters)

        # Les fases posteriors definiran els esquemes concrets. Fins aleshores no
        # es poden autoritzar encara que el tipus aparega accidentalment a la llista.
        return "command_type_not_implemented", command.command_type.value

    def _validate_timeout(self, parameters: Mapping[str, Any]) -> tuple[str, str | None] | None:
        timeout = parameters.get("timeout_seconds", self.max_timeout_seconds)
        if isinstance(timeout, bool) or not isinstance(timeout, int) or not 1 <= timeout <= self.max_timeout_seconds:
            return "invalid_timeout_seconds", None
        return None

    @staticmethod
    def _only(parameters: Mapping[str, Any], allowed: set[str]) -> tuple[str, str | None] | None:
        unknown = sorted(set(parameters) - allowed)
        if unknown:
            return "unknown_parameter", unknown[0]
        return None

    @staticmethod
    def _deny(code: str, user: str, privileged: bool, detail: str | None = None) -> AuthorizationDecision:
        return AuthorizationDecision(
            allowed=False,
            code=code,
            effective_user=user,
            privilege_separation_required=privileged,
            detail=detail,
        )

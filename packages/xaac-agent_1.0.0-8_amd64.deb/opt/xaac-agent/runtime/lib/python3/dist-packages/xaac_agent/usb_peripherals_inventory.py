from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

_GENERIC = {"", "unknown", "n/a", "none", "default string", "to be filled by o.e.m."}
_CLASS_NAMES = {
    0x01: "audio", 0x02: "communications", 0x03: "hid", 0x06: "imaging",
    0x07: "printer", 0x08: "mass-storage", 0x09: "hub", 0x0B: "smartcard",
    0x0E: "video", 0xE0: "wireless", 0xEF: "miscellaneous", 0xFF: "vendor-specific",
}
_PERIPHERAL_FLAGS = {
    0x07: "printer", 0x08: "storage", 0x0B: "smartcard", 0x0E: "camera",
}


def _safe_entries(path: Path) -> tuple[Path, ...]:
    try:
        if not path.is_dir():
            return ()
        return tuple(path.iterdir())
    except OSError:
        return ()


def _read(path: Path) -> str | None:
    try:
        if not path.is_file() or path.is_symlink():
            return None
        value = " ".join(path.read_text(encoding="utf-8", errors="replace").replace("\x00", " ").split())
    except OSError:
        return None
    return None if value.lower() in _GENERIC else value


def _hex(value: str | None, width: int = 2) -> str | None:
    if value is None or not re.fullmatch(r"(?:0x)?[0-9a-fA-F]{1,%d}" % width, value):
        return None
    return f"{int(value, 16):0{width}x}"


def _integer(value: str | None) -> int | None:
    try:
        return int(value) if value is not None else None
    except ValueError:
        return None


@dataclass(frozen=True, slots=True)
class UsbPeripheralsInventory:
    payload: dict[str, object]

    def to_payload(self) -> dict[str, object]:
        return self.payload


class UsbPeripheralsInventoryCollector:
    def __init__(self, *, usb_root: Path = Path("/sys/bus/usb/devices")) -> None:
        self._usb_root = Path(usb_root)

    def collect(self) -> UsbPeripheralsInventory:
        devices: list[dict[str, object]] = []
        counts = {"printer": 0, "storage": 0, "smartcard": 0, "camera": 0}
        for entry in sorted(_safe_entries(self._usb_root), key=lambda p: p.name):
            # Physical USB devices expose idVendor/idProduct; interface entries do not.
            vid = _hex(_read(entry / "idVendor"), 4)
            pid = _hex(_read(entry / "idProduct"), 4)
            if vid is None or pid is None:
                continue
            item = self._collect_device(entry, vid, pid)
            devices.append(item)
            for kind in item.get("peripheral_types", []):
                if kind in counts:
                    counts[kind] += 1
        return UsbPeripheralsInventory({
            "device_count": len(devices),
            "devices": devices,
            "printer_count": counts["printer"],
            "storage_count": counts["storage"],
            "smartcard_count": counts["smartcard"],
            "camera_count": counts["camera"],
        })

    def _collect_device(self, entry: Path, vid: str, pid: str) -> dict[str, object]:
        classes: set[int] = set()
        device_class = _hex(_read(entry / "bDeviceClass"))
        if device_class is not None and int(device_class, 16) != 0:
            classes.add(int(device_class, 16))
        prefix = entry.name + ":"
        for child in _safe_entries(self._usb_root):
            if child.name.startswith(prefix):
                value = _hex(_read(child / "bInterfaceClass"))
                if value is not None:
                    classes.add(int(value, 16))

        result: dict[str, object] = {
            "sysfs_name": entry.name,
            "vendor_id": vid,
            "product_id": pid,
            "classes": [_CLASS_NAMES.get(code, f"class-{code:02x}") for code in sorted(classes)],
            "peripheral_types": sorted({_PERIPHERAL_FLAGS[c] for c in classes if c in _PERIPHERAL_FLAGS}),
        }
        for key, filename in (("manufacturer", "manufacturer"), ("product", "product")):
            value = _read(entry / filename)
            if value:
                result[key] = value[:256]
        # Serial values are deliberately not exported; only presence is reported.
        if _read(entry / "serial") is not None:
            result["serial_present"] = True
        for key, filename in (("bus_number", "busnum"), ("device_number", "devnum"), ("speed_mbps", "speed")):
            value = _integer(_read(entry / filename))
            if value is not None and value >= 0:
                result[key] = value
        removable = _read(entry / "removable")
        if removable:
            result["removable"] = removable.lower() not in {"fixed", "0", "no"}
        return result

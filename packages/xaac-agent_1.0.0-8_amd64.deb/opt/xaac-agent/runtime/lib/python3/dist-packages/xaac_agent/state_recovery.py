from __future__ import annotations

import os
import shutil
import stat
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path


class StateRecoveryError(RuntimeError):
    """A known-good state copy is missing, invalid, or unsafe."""


@dataclass(frozen=True, slots=True)
class StateRecoveryEvent:
    recovered: bool
    source: str | None = None
    quarantine: str | None = None

    def to_payload(self) -> dict[str, object]:
        return {
            "schema_version": 1,
            "recovered": self.recovered,
            "source": self.source,
            "quarantine": self.quarantine,
        }


class KnownGoodState:
    """Maintains a private last-known-good copy beside a persistent file."""

    def __init__(self, path: Path) -> None:
        self.path = path
        self.backup_path = path.with_name(f"{path.name}.known-good")
        self.last_event = StateRecoveryEvent(False)

    def snapshot(self) -> None:
        self._assert_regular(self.path, required=True)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.backup_path.with_name(f".{self.backup_path.name}.{os.getpid()}.tmp")
        try:
            with self.path.open("rb") as source:
                fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
                with os.fdopen(fd, "wb") as target:
                    shutil.copyfileobj(source, target)
                    target.flush()
                    os.fsync(target.fileno())
            os.replace(temporary, self.backup_path)
            os.chmod(self.backup_path, 0o600)
            self._fsync_directory()
        finally:
            temporary.unlink(missing_ok=True)

    def restore(self) -> StateRecoveryEvent:
        self._assert_regular(self.backup_path, required=True)
        quarantine = self._quarantine_current()
        temporary = self.path.with_name(f".{self.path.name}.restore.{os.getpid()}.tmp")
        try:
            with self.backup_path.open("rb") as source:
                fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
                with os.fdopen(fd, "wb") as target:
                    shutil.copyfileobj(source, target)
                    target.flush()
                    os.fsync(target.fileno())
            os.replace(temporary, self.path)
            os.chmod(self.path, 0o600)
            self._fsync_directory()
        finally:
            temporary.unlink(missing_ok=True)
        self.last_event = StateRecoveryEvent(True, str(self.backup_path), str(quarantine) if quarantine else None)
        return self.last_event

    def _quarantine_current(self) -> Path | None:
        if not self.path.exists() and not self.path.is_symlink():
            return None
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        quarantine = self.path.with_name(f"{self.path.name}.corrupt-{timestamp}")
        os.replace(self.path, quarantine)
        os.chmod(quarantine, 0o600)
        return quarantine

    @staticmethod
    def _assert_regular(path: Path, *, required: bool) -> None:
        try:
            mode = path.lstat().st_mode
        except FileNotFoundError:
            if required:
                raise StateRecoveryError(f"known-good state missing: {path}")
            return
        except OSError as error:
            raise StateRecoveryError(f"cannot inspect state: {path}") from error
        if stat.S_ISLNK(mode) or not stat.S_ISREG(mode):
            raise StateRecoveryError(f"state path is not a regular file: {path}")

    def _fsync_directory(self) -> None:
        descriptor = os.open(self.path.parent, os.O_RDONLY)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)

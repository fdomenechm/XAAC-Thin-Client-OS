from __future__ import annotations

import argparse
import json
import os
import re
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Callable, Iterable, Mapping, Sequence


_PATH_RE = re.compile(r"^/[\x21-\x7e]{0,4095}$")
_MEMINFO_KEYS = {"MemTotal", "MemAvailable", "SwapTotal", "SwapFree"}
_PRESSURE_RESOURCES = ("cpu", "memory", "io")


class SystemDiagnosticError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class SystemDiagnosticPolicy:
    max_paths: int = 16
    max_proc_bytes: int = 65536
    disk_warning_percent: float = 85.0
    disk_critical_percent: float = 95.0
    inode_warning_percent: float = 85.0
    inode_critical_percent: float = 95.0
    memory_warning_percent: float = 85.0
    memory_critical_percent: float = 95.0

    def validate(self) -> None:
        if not 1 <= self.max_paths <= 128:
            raise SystemDiagnosticError("system_diagnostic_max_paths_out_of_range")
        if not 1024 <= self.max_proc_bytes <= 1048576:
            raise SystemDiagnosticError("system_diagnostic_max_proc_bytes_out_of_range")
        for warning, critical, name in (
            (self.disk_warning_percent, self.disk_critical_percent, "disk"),
            (self.inode_warning_percent, self.inode_critical_percent, "inode"),
            (self.memory_warning_percent, self.memory_critical_percent, "memory"),
        ):
            if not 1.0 <= warning < critical <= 100.0:
                raise SystemDiagnosticError(f"system_diagnostic_{name}_thresholds_invalid")


@dataclass(frozen=True, slots=True)
class SystemDiagnosticResult:
    format: str
    generated_at_unix: int
    status: str
    system: dict[str, object]
    filesystems: tuple[dict[str, object], ...]
    findings: tuple[str, ...]

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def _normalise_paths(values: Iterable[str], limit: int) -> tuple[str, ...]:
    result: list[str] = []
    for value in values:
        path = value.strip()
        if not _PATH_RE.fullmatch(path) or "\x00" in path:
            raise SystemDiagnosticError("system_diagnostic_invalid_path")
        normalised = os.path.normpath(path)
        if not normalised.startswith("/"):
            raise SystemDiagnosticError("system_diagnostic_invalid_path")
        if normalised not in result:
            result.append(normalised)
        if len(result) > limit:
            raise SystemDiagnosticError("system_diagnostic_too_many_paths")
    if not result:
        raise SystemDiagnosticError("system_diagnostic_no_paths")
    return tuple(result)


def _safe_read_text(path: Path, max_bytes: int) -> str | None:
    try:
        flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NOFOLLOW", 0)
        fd = os.open(path, flags)
        try:
            data = os.read(fd, max_bytes + 1)
        finally:
            os.close(fd)
    except OSError:
        return None
    if len(data) > max_bytes:
        return None
    try:
        return data.decode("ascii", errors="strict")
    except UnicodeDecodeError:
        return None


def _parse_meminfo(text: str | None) -> dict[str, int]:
    if text is None:
        return {}
    result: dict[str, int] = {}
    for line in text.splitlines():
        key, sep, rest = line.partition(":")
        if not sep or key not in _MEMINFO_KEYS:
            continue
        parts = rest.strip().split()
        if not parts or not parts[0].isdigit():
            continue
        multiplier = 1024 if len(parts) > 1 and parts[1] == "kB" else 1
        result[key] = int(parts[0]) * multiplier
    return result


def _parse_pressure(text: str | None) -> dict[str, float]:
    if text is None:
        return {}
    result: dict[str, float] = {}
    for line in text.splitlines():
        parts = line.split()
        if not parts or parts[0] not in {"some", "full"}:
            continue
        for token in parts[1:]:
            key, sep, value = token.partition("=")
            if sep and key in {"avg10", "avg60", "avg300"}:
                try:
                    number = float(value)
                except ValueError:
                    continue
                if 0.0 <= number <= 100.0:
                    result[f"{parts[0]}_{key}"] = round(number, 2)
    return result


def _percent_used(total: int, available: int) -> float | None:
    if total <= 0 or available < 0 or available > total:
        return None
    return round((total - available) * 100.0 / total, 2)


class SystemDiagnosticCollector:
    def __init__(
        self,
        *,
        policy: SystemDiagnosticPolicy | None = None,
        proc_root: Path = Path("/proc"),
        statvfs_reader: Callable[[str], os.statvfs_result] = os.statvfs,
        clock: Callable[[], float] = time.time,
        uname_reader: Callable[[], os.uname_result] = os.uname,
    ) -> None:
        self.policy = policy or SystemDiagnosticPolicy()
        self.policy.validate()
        self.proc_root = proc_root
        self.statvfs_reader = statvfs_reader
        self.clock = clock
        self.uname_reader = uname_reader

    def collect(self, *, paths: Sequence[str]) -> SystemDiagnosticResult:
        names = _normalise_paths(paths, self.policy.max_paths)
        system, system_findings = self._collect_system()
        filesystems = tuple(self._collect_filesystem(path) for path in names)
        findings = list(system_findings)
        for item in filesystems:
            code = item.get("code")
            severity = item.get("severity")
            if severity in {"warning", "critical"} and isinstance(code, str):
                findings.append(code)
        critical = bool(system.get("severity") == "critical" or any(item["severity"] == "critical" for item in filesystems))
        warning = bool(system.get("severity") == "warning" or any(item["severity"] == "warning" for item in filesystems))
        status = "critical" if critical else ("warning" if warning else "ok")
        return SystemDiagnosticResult(
            format="xaac-system-diagnostic/v1",
            generated_at_unix=int(self.clock()),
            status=status,
            system=system,
            filesystems=filesystems,
            findings=tuple(dict.fromkeys(findings)),
        )

    def _collect_system(self) -> tuple[dict[str, object], tuple[str, ...]]:
        mem = _parse_meminfo(_safe_read_text(self.proc_root / "meminfo", self.policy.max_proc_bytes))
        uptime_text = _safe_read_text(self.proc_root / "uptime", 256)
        load_text = _safe_read_text(self.proc_root / "loadavg", 256)
        findings: list[str] = []
        result: dict[str, object] = {"severity": "normal"}
        try:
            uname = self.uname_reader()
            result["kernel_release"] = str(uname.release)[:128]
            result["machine"] = str(uname.machine)[:64]
        except OSError:
            findings.append("uname_unavailable")

        if uptime_text:
            try:
                uptime = float(uptime_text.split()[0])
                if uptime >= 0:
                    result["uptime_seconds"] = int(uptime)
            except (ValueError, IndexError):
                findings.append("uptime_unavailable")
        else:
            findings.append("uptime_unavailable")

        if load_text:
            parts = load_text.split()
            try:
                loads = [round(float(value), 2) for value in parts[:3]]
                if len(loads) == 3 and all(value >= 0 for value in loads):
                    result["load_average"] = {"1m": loads[0], "5m": loads[1], "15m": loads[2]}
            except ValueError:
                findings.append("load_average_unavailable")
        else:
            findings.append("load_average_unavailable")

        total = mem.get("MemTotal", 0)
        available = mem.get("MemAvailable", 0)
        memory_used = _percent_used(total, available)
        if memory_used is not None:
            result["memory"] = {
                "total_bytes": total,
                "available_bytes": available,
                "used_percent": memory_used,
            }
            if memory_used >= self.policy.memory_critical_percent:
                result["severity"] = "critical"
                findings.append("memory_usage_critical")
            elif memory_used >= self.policy.memory_warning_percent:
                result["severity"] = "warning"
                findings.append("memory_usage_warning")
        else:
            findings.append("memory_information_unavailable")

        swap_total = mem.get("SwapTotal", 0)
        swap_free = mem.get("SwapFree", 0)
        swap_used = _percent_used(swap_total, swap_free) if swap_total else 0.0
        result["swap"] = {"total_bytes": swap_total, "free_bytes": swap_free, "used_percent": swap_used}

        pressure: dict[str, Mapping[str, float]] = {}
        for resource in _PRESSURE_RESOURCES:
            values = _parse_pressure(_safe_read_text(self.proc_root / "pressure" / resource, 4096))
            if values:
                pressure[resource] = values
        if pressure:
            result["pressure"] = pressure
        return result, tuple(findings)

    def _collect_filesystem(self, path: str) -> dict[str, object]:
        try:
            stats = self.statvfs_reader(path)
        except OSError:
            return {"path": path, "severity": "critical", "code": "filesystem_unavailable"}
        block_size = stats.f_frsize or stats.f_bsize
        total = int(stats.f_blocks) * int(block_size)
        available = int(stats.f_bavail) * int(block_size)
        used_percent = _percent_used(total, available)
        inode_percent = _percent_used(int(stats.f_files), int(stats.f_favail)) if stats.f_files else None
        severity = "normal"
        code = "filesystem_normal"
        if used_percent is None:
            severity, code = "critical", "filesystem_invalid_statistics"
        elif used_percent >= self.policy.disk_critical_percent:
            severity, code = "critical", "filesystem_space_critical"
        elif used_percent >= self.policy.disk_warning_percent:
            severity, code = "warning", "filesystem_space_warning"
        if inode_percent is not None:
            if inode_percent >= self.policy.inode_critical_percent:
                severity, code = "critical", "filesystem_inodes_critical"
            elif inode_percent >= self.policy.inode_warning_percent and severity == "normal":
                severity, code = "warning", "filesystem_inodes_warning"
        result: dict[str, object] = {
            "path": path,
            "severity": severity,
            "code": code,
            "total_bytes": total,
            "available_bytes": available,
            "used_percent": used_percent,
        }
        if inode_percent is not None:
            result["inode_used_percent"] = inode_percent
        return result


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="XAAC disk and system diagnostic")
    parser.add_argument("--path", action="append", dest="paths", default=[])
    parser.add_argument("--disk-warning-percent", type=float, default=85.0)
    parser.add_argument("--disk-critical-percent", type=float, default=95.0)
    parser.add_argument("--memory-warning-percent", type=float, default=85.0)
    parser.add_argument("--memory-critical-percent", type=float, default=95.0)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    paths = args.paths or ["/", "/var/lib/xaac-agent"]
    try:
        policy = SystemDiagnosticPolicy(
            disk_warning_percent=args.disk_warning_percent,
            disk_critical_percent=args.disk_critical_percent,
            memory_warning_percent=args.memory_warning_percent,
            memory_critical_percent=args.memory_critical_percent,
        )
        result = SystemDiagnosticCollector(policy=policy).collect(paths=paths)
    except SystemDiagnosticError as error:
        print(json.dumps({"format": "xaac-system-diagnostic/v1", "status": "error", "code": str(error)}, sort_keys=True))
        return 2
    print(json.dumps(result.to_dict(), sort_keys=True, separators=(",", ":")))
    return 0 if result.status == "ok" else 1


if __name__ == "__main__":
    raise SystemExit(main())

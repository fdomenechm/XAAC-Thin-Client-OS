from __future__ import annotations

import fcntl
import ipaddress
import socket
import struct
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Iterable, Mapping


_SIOCGIFADDR = 0x8915


def _read_text(path: Path, *, allow_symlink: bool = False, max_bytes: int = 131072) -> str | None:
    try:
        candidate = path.resolve(strict=True) if allow_symlink else path
        if not allow_symlink and path.is_symlink():
            return None
        if not candidate.is_file():
            return None
        if candidate.stat().st_size > max_bytes:
            return None
        return candidate.read_text(encoding="utf-8", errors="replace").strip()
    except OSError:
        return None


def _clean(value: str | None) -> str | None:
    if value is None:
        return None
    result = " ".join(value.replace("\x00", " ").split())
    return result or None


def _int_value(path: Path, *, minimum: int = 0) -> int | None:
    value = _read_text(path)
    try:
        parsed = int(value) if value is not None else None
    except ValueError:
        return None
    return parsed if parsed is not None and parsed >= minimum else None


def _bool_value(path: Path) -> bool | None:
    value = _int_value(path)
    return None if value is None else bool(value)


def _normalise_mac(value: str | None) -> str | None:
    value = _clean(value)
    if value is None:
        return None
    parts = value.lower().split(":")
    if len(parts) != 6 or any(len(part) != 2 for part in parts):
        return None
    try:
        bytes(int(part, 16) for part in parts)
    except ValueError:
        return None
    return ":".join(parts)


@dataclass(frozen=True, slots=True)
class NetworkAddress:
    address: str
    prefix_length: int
    family: str
    scope: str | None = None

    def to_payload(self) -> dict[str, object]:
        payload: dict[str, object] = {
            "address": self.address,
            "prefix_length": self.prefix_length,
            "family": self.family,
        }
        if self.scope:
            payload["scope"] = self.scope
        return payload


@dataclass(frozen=True, slots=True)
class NetworkInterface:
    name: str
    mac_address: str | None = None
    operational_state: str | None = None
    carrier: bool | None = None
    mtu: int | None = None
    speed_mbps: int | None = None
    interface_type: str = "unknown"
    addresses: tuple[NetworkAddress, ...] = field(default_factory=tuple)
    vlan_id: int | None = None
    vlan_parent: str | None = None

    def to_payload(self) -> dict[str, object]:
        payload: dict[str, object] = {
            "name": self.name,
            "interface_type": self.interface_type,
            "addresses": [address.to_payload() for address in self.addresses],
        }
        for key in ("mac_address", "operational_state", "carrier", "mtu", "speed_mbps", "vlan_id", "vlan_parent"):
            value = getattr(self, key)
            if value is not None:
                payload[key] = value
        return payload


@dataclass(frozen=True, slots=True)
class DefaultRoute:
    family: str
    interface: str
    gateway: str | None = None
    metric: int | None = None

    def to_payload(self) -> dict[str, object]:
        payload: dict[str, object] = {"family": self.family, "interface": self.interface}
        if self.gateway is not None:
            payload["gateway"] = self.gateway
        if self.metric is not None:
            payload["metric"] = self.metric
        return payload


@dataclass(frozen=True, slots=True)
class NetworkInventory:
    interfaces: tuple[NetworkInterface, ...] = field(default_factory=tuple)
    default_routes: tuple[DefaultRoute, ...] = field(default_factory=tuple)
    dns_servers: tuple[str, ...] = field(default_factory=tuple)
    search_domains: tuple[str, ...] = field(default_factory=tuple)
    hostname: str | None = None

    def to_payload(self) -> dict[str, object]:
        payload: dict[str, object] = {
            "interfaces": [interface.to_payload() for interface in self.interfaces],
            "default_routes": [route.to_payload() for route in self.default_routes],
            "dns_servers": list(self.dns_servers),
            "search_domains": list(self.search_domains),
        }
        if self.hostname:
            payload["hostname"] = self.hostname
        return payload


AddressProvider = Callable[[], Mapping[str, Iterable[NetworkAddress]]]


class NetworkInventoryCollector:
    def __init__(
        self,
        sys_net_path: Path = Path("/sys/class/net"),
        ipv4_route_path: Path = Path("/proc/net/route"),
        ipv6_route_path: Path = Path("/proc/net/ipv6_route"),
        ipv6_address_path: Path = Path("/proc/net/if_inet6"),
        vlan_config_path: Path = Path("/proc/net/vlan/config"),
        resolv_conf_path: Path = Path("/etc/resolv.conf"),
        address_provider: AddressProvider | None = None,
        hostname_provider: Callable[[], str] = socket.gethostname,
    ) -> None:
        self._sys_net_path = sys_net_path
        self._ipv4_route_path = ipv4_route_path
        self._ipv6_route_path = ipv6_route_path
        self._ipv6_address_path = ipv6_address_path
        self._vlan_config_path = vlan_config_path
        self._resolv_conf_path = resolv_conf_path
        self._address_provider = address_provider or self._collect_addresses
        self._hostname_provider = hostname_provider

    def collect(self) -> NetworkInventory:
        try:
            addresses = {name: tuple(values) for name, values in self._address_provider().items()}
        except (OSError, ValueError):
            addresses = {}
        vlans = self._collect_vlans()
        interfaces = self._collect_interfaces(addresses, vlans)
        dns_servers, search_domains = self._collect_dns()
        try:
            hostname = _clean(self._hostname_provider())
        except OSError:
            hostname = None
        return NetworkInventory(
            interfaces=interfaces,
            default_routes=self._collect_default_routes(),
            dns_servers=dns_servers,
            search_domains=search_domains,
            hostname=hostname,
        )

    def _collect_interfaces(
        self,
        addresses: Mapping[str, tuple[NetworkAddress, ...]],
        vlans: Mapping[str, tuple[int, str | None]],
    ) -> tuple[NetworkInterface, ...]:
        try:
            entries = sorted(self._sys_net_path.iterdir(), key=lambda item: item.name)
        except OSError:
            return ()
        values: list[NetworkInterface] = []
        for entry in entries:
            name = entry.name
            vlan = vlans.get(name)
            values.append(NetworkInterface(
                name=name,
                mac_address=_normalise_mac(_read_text(entry / "address")),
                operational_state=_clean(_read_text(entry / "operstate")),
                carrier=_bool_value(entry / "carrier"),
                mtu=_int_value(entry / "mtu", minimum=1),
                speed_mbps=_int_value(entry / "speed", minimum=0),
                interface_type=self._interface_type(name, entry, vlan is not None),
                addresses=tuple(sorted(addresses.get(name, ()), key=lambda item: (item.family, item.address, item.prefix_length))),
                vlan_id=vlan[0] if vlan else None,
                vlan_parent=vlan[1] if vlan else None,
            ))
        return tuple(values)

    @staticmethod
    def _interface_type(name: str, entry: Path, is_vlan: bool) -> str:
        if is_vlan:
            return "vlan"
        if name == "lo":
            return "loopback"
        if (entry / "wireless").exists() or name.startswith(("wl", "wifi")):
            return "wireless"
        if name.startswith(("br", "virbr")) or (entry / "bridge").exists():
            return "bridge"
        if name.startswith(("tun", "tap", "wg")):
            return "tunnel"
        if name.startswith(("veth", "docker")):
            return "virtual"
        if name.startswith(("en", "eth")):
            return "ethernet"
        return "unknown"

    def _collect_addresses(self) -> Mapping[str, tuple[NetworkAddress, ...]]:
        values: dict[str, list[NetworkAddress]] = {}
        for _, name in socket.if_nameindex():
            address = self._ipv4_address(name)
            if address:
                values.setdefault(name, []).append(NetworkAddress(address, 32, "ipv4"))
        text = _read_text(self._ipv6_address_path)
        if text:
            for line in text.splitlines():
                fields = line.split()
                if len(fields) != 6:
                    continue
                raw, _, prefix_hex, scope_hex, _, name = fields
                try:
                    address = str(ipaddress.IPv6Address(int(raw, 16)))
                    prefix = int(prefix_hex, 16)
                    scope = self._ipv6_scope(int(scope_hex, 16))
                except ValueError:
                    continue
                values.setdefault(name, []).append(NetworkAddress(address, prefix, "ipv6", scope))
        return {name: tuple(items) for name, items in values.items()}

    @staticmethod
    def _ipv4_address(name: str) -> str | None:
        if len(name.encode("utf-8")) >= 16:
            return None
        request = struct.pack("256s", name.encode("utf-8")[:15])
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
                result = fcntl.ioctl(sock.fileno(), _SIOCGIFADDR, request)
            return socket.inet_ntoa(result[20:24])
        except OSError:
            return None

    @staticmethod
    def _ipv6_scope(value: int) -> str:
        return {0x00: "global", 0x20: "link", 0x40: "site", 0x80: "host"}.get(value, f"0x{value:02x}")

    def _collect_vlans(self) -> dict[str, tuple[int, str | None]]:
        text = _read_text(self._vlan_config_path)
        result: dict[str, tuple[int, str | None]] = {}
        if not text:
            return result
        for line in text.splitlines():
            if "|" not in line or line.lstrip().startswith(("VLAN", "Name-Type")):
                continue
            fields = [field.strip() for field in line.split("|")]
            if len(fields) < 3:
                continue
            try:
                vlan_id = int(fields[1])
            except ValueError:
                continue
            if 1 <= vlan_id <= 4094:
                result[fields[0]] = (vlan_id, fields[2] or None)
        return result

    def _collect_default_routes(self) -> tuple[DefaultRoute, ...]:
        routes = list(self._collect_ipv4_routes())
        routes.extend(self._collect_ipv6_routes())
        return tuple(sorted(routes, key=lambda route: (route.family, route.metric if route.metric is not None else 2**31, route.interface)))

    def _collect_ipv4_routes(self) -> tuple[DefaultRoute, ...]:
        text = _read_text(self._ipv4_route_path)
        if not text:
            return ()
        routes: list[DefaultRoute] = []
        for line in text.splitlines()[1:]:
            fields = line.split()
            if len(fields) < 8 or fields[1] != "00000000":
                continue
            try:
                gateway = socket.inet_ntoa(struct.pack("<I", int(fields[2], 16)))
                flags = int(fields[3], 16)
                metric = int(fields[6])
            except (ValueError, OSError, struct.error):
                continue
            if not flags & 0x1:
                continue
            routes.append(DefaultRoute("ipv4", fields[0], None if gateway == "0.0.0.0" else gateway, metric))
        return tuple(routes)

    def _collect_ipv6_routes(self) -> tuple[DefaultRoute, ...]:
        text = _read_text(self._ipv6_route_path)
        if not text:
            return ()
        routes: list[DefaultRoute] = []
        for line in text.splitlines():
            fields = line.split()
            if len(fields) < 10 or fields[0] != "0" * 32 or fields[1] != "00":
                continue
            try:
                gateway = str(ipaddress.IPv6Address(int(fields[4], 16)))
                metric = int(fields[5], 16)
            except ValueError:
                continue
            routes.append(DefaultRoute("ipv6", fields[-1], None if gateway == "::" else gateway, metric))
        return tuple(routes)

    def _collect_dns(self) -> tuple[tuple[str, ...], tuple[str, ...]]:
        text = _read_text(self._resolv_conf_path, allow_symlink=True)
        servers: list[str] = []
        domains: list[str] = []
        if not text:
            return (), ()
        for raw_line in text.splitlines():
            line = raw_line.split("#", 1)[0].strip()
            if not line:
                continue
            fields = line.split()
            if len(fields) >= 2 and fields[0] == "nameserver":
                try:
                    server = str(ipaddress.ip_address(fields[1]))
                except ValueError:
                    continue
                if server not in servers:
                    servers.append(server)
            elif len(fields) >= 2 and fields[0] in {"search", "domain"}:
                for domain in fields[1:]:
                    cleaned = domain.rstrip(".").lower()
                    if cleaned and cleaned not in domains:
                        domains.append(cleaned)
        return tuple(servers), tuple(domains)

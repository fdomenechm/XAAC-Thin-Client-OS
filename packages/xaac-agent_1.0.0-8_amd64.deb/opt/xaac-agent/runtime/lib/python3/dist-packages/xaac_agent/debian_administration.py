from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any


class DebianAdministrationDocumentationError(ValueError):
    """Raised when the administration documentation is incomplete or unsafe."""


@dataclass(frozen=True, slots=True)
class DebianAdministrationDocumentation:
    package: str
    version: str
    language: str
    guide: Path
    quick_reference: Path
    debian_notes: Path
    installed_directory: Path
    required_topics: tuple[str, ...]
    required_commands: tuple[str, ...]
    private_python: Path
    system_python_modified: bool

    @classmethod
    def load(cls, path: Path) -> "DebianAdministrationDocumentation":
        try:
            raw: Any = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise DebianAdministrationDocumentationError("administration_documentation_invalid") from exc
        if not isinstance(raw, dict) or raw.get("schema_version") != 1:
            raise DebianAdministrationDocumentationError("administration_documentation_schema_invalid")
        documents = raw.get("documents")
        if not isinstance(documents, dict):
            raise DebianAdministrationDocumentationError("administration_documentation_documents_invalid")
        topics = raw.get("required_topics")
        commands = raw.get("required_commands")
        if not isinstance(topics, list) or not isinstance(commands, list):
            raise DebianAdministrationDocumentationError("administration_documentation_requirements_invalid")
        return cls(
            package=str(raw.get("package", "")),
            version=str(raw.get("version", "")),
            language=str(raw.get("language", "")),
            guide=Path(str(documents.get("guide", ""))),
            quick_reference=Path(str(documents.get("quick_reference", ""))),
            debian_notes=Path(str(documents.get("debian_notes", ""))),
            installed_directory=Path(str(raw.get("installed_directory", ""))),
            required_topics=tuple(str(item) for item in topics),
            required_commands=tuple(str(item) for item in commands),
            private_python=Path(str(raw.get("private_python", ""))),
            system_python_modified=raw.get("system_python_modified") is True,
        )

    def validate(self, project_root: Path) -> None:
        if self.package != "xaac-agent" or self.version != "1.0.0" or self.language != "ca":
            raise DebianAdministrationDocumentationError("administration_documentation_identity_invalid")
        if self.installed_directory != Path("/usr/share/doc/xaac-agent"):
            raise DebianAdministrationDocumentationError("administration_documentation_install_path_invalid")
        if self.private_python != Path("/opt/xaac-agent/runtime/bin/python3.13") or self.system_python_modified:
            raise DebianAdministrationDocumentationError("administration_documentation_runtime_invalid")
        documents = (self.guide, self.quick_reference, self.debian_notes)
        for document in documents:
            if document.is_absolute() or ".." in document.parts:
                raise DebianAdministrationDocumentationError("administration_documentation_path_unsafe")
            if not (project_root / document).is_file():
                raise DebianAdministrationDocumentationError("administration_documentation_missing")
        required_topics = {
            "installation", "configuration", "enrollment", "systemd", "logging", "backup", "upgrade",
            "removal", "safe_mode", "xms_failover", "wyse_3040", "security", "troubleshooting",
        }
        if set(self.required_topics) != required_topics or len(self.required_topics) != len(required_topics):
            raise DebianAdministrationDocumentationError("administration_documentation_topics_invalid")
        required_commands = {
            "xaac-agent-admin", "systemctl", "journalctl", "xaac-production-profile-validate", "xaac-config-migrate",
            "xaac-local-recovery", "xaac-attack-surface-audit",
        }
        if set(self.required_commands) != required_commands or len(self.required_commands) != len(required_commands):
            raise DebianAdministrationDocumentationError("administration_documentation_commands_invalid")
        guide_text = (project_root / self.guide).read_text(encoding="utf-8")
        for command in required_commands:
            if command not in guide_text:
                raise DebianAdministrationDocumentationError("administration_documentation_command_undocumented")
        for required_path in (
            "/etc/xaac-agent/agent.ini", "/var/lib/xaac-agent", "/opt/xaac-agent/runtime/bin/python3.13",
            "/usr/bin/python3", "/usr/share/doc/xaac-agent",
        ):
            if required_path not in guide_text:
                raise DebianAdministrationDocumentationError("administration_documentation_path_undocumented")

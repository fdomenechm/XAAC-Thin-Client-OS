from __future__ import annotations

from enum import Enum


class ConfigurationScope(Enum):
    """Àmbit autoritzat per modificar un valor de configuració."""

    SYSTEM = "system"
    USER = "user"
    REMOTE = "remote"


class ConfigurationValueSource(Enum):
    """Origen efectiu d'un valor després de combinar les capes."""

    SYSTEM = "system"
    USER = "user"
    REMOTE = "remote"
    CACHE = "cache"

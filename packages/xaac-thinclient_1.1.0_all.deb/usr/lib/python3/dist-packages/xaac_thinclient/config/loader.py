from __future__ import annotations

import configparser
from pathlib import Path

from xaac_thinclient.config.models import (
    ApplicationConfig,
    ApplicationMode,
    AudioRedirectionConfig,
    ClipboardDirection,
    ClipboardProfile,
    ClipboardRedirectionConfig,
    VideoRedirectionConfig,
    CertificateMode,
    DeviceConfig,
    DriveRedirectionConfig,
    MultimonMode,
    KeyboardConfig,
    NetworkProfile,
    PerformanceProfile,
    PrinterRedirectionConfig,
    NetworkConfig,
    RdpConfig,
    RdpServerConfig,
    SecurityMode,
    SmartCardConfig,
    SystemConfig,
    ThinClientConfig,
    UsbConfig,
)
from xaac_thinclient.config.validator import (
    ConfigurationError,
    validate_config,
)
from xaac_thinclient.paths import CONFIG_FILE, DEVICE_FILE, SERVERS_FILE


def _read_ini(path: Path) -> configparser.ConfigParser:
    if not path.is_file():
        raise ConfigurationError(
            f"No s'ha trobat el fitxer de configuració: {path}"
        )

    parser = configparser.ConfigParser(
        interpolation=None,
    )

    try:
        loaded_files = parser.read(
            path,
            encoding="utf-8",
        )
    except configparser.Error as error:
        raise ConfigurationError(
            f"No s'ha pogut llegir {path}: {error}"
        ) from error

    if not loaded_files:
        raise ConfigurationError(
            f"No s'ha pogut carregar el fitxer: {path}"
        )

    return parser


def _read_enum(
    parser: configparser.ConfigParser,
    section: str,
    option: str,
    enum_type: type,
):
    value = parser.get(section, option).strip().lower()

    try:
        return enum_type(value)
    except ValueError as error:
        allowed = ", ".join(item.value for item in enum_type)

        raise ConfigurationError(
            f"Valor incorrecte en [{section}] {option}: "
            f"{value}. Valors admesos: {allowed}"
        ) from error



def _read_csv_tuple(
    parser: configparser.ConfigParser,
    section: str,
    option: str,
) -> tuple[str, ...]:
    raw = parser.get(section, option, fallback="")
    return tuple(
        item.strip().lower()
        for item in raw.split(",")
        if item.strip()
    )


def _read_csv_paths(
    parser: configparser.ConfigParser,
    section: str,
    option: str,
) -> tuple[str, ...]:
    raw = parser.get(section, option, fallback="")
    return tuple(
        item.strip()
        for item in raw.split(",")
        if item.strip()
    )



def _load_servers(path: Path, *, legacy_host: str, legacy_port: int, legacy_domain: str) -> tuple[tuple[RdpServerConfig, ...], str]:
    if not path.is_file():
        legacy = RdpServerConfig(
            server_id="legacy-default", name=legacy_host, host=legacy_host,
            port=legacy_port, domain=legacy_domain, enabled=True,
        )
        return ((legacy,) if legacy_host else ()), legacy.server_id if legacy_host else ""

    parser = _read_ini(path)
    default_id = parser.get("servers", "default", fallback="").strip()
    items: list[RdpServerConfig] = []
    seen: set[str] = set()
    for section in parser.sections():
        if not section.lower().startswith("server:"):
            continue
        server_id = section.split(":", 1)[1].strip()
        if not server_id or server_id in seen:
            raise ConfigurationError(f"Identificador de servidor duplicat o buit: {server_id}")
        seen.add(server_id)
        enabled = parser.getboolean(section, "enabled", fallback=True)
        host = parser.get(section, "host", fallback="").strip()
        if not host and enabled:
            raise ConfigurationError(f"Servidor sense host en [{section}]")
        if not host:
            continue
        port = parser.getint(section, "port", fallback=legacy_port)
        if not 1 <= port <= 65535:
            raise ConfigurationError(f"Port incorrecte en [{section}]: {port}")
        items.append(RdpServerConfig(
            server_id=server_id,
            name=parser.get(section, "name", fallback=host).strip() or host,
            host=host, port=port,
            domain=parser.get(section, "domain", fallback=legacy_domain).strip(),
            enabled=enabled,
        ))
    enabled_items = tuple(item for item in items if item.enabled)
    if not enabled_items and legacy_host:
        legacy = RdpServerConfig("legacy-default", legacy_host, legacy_host, legacy_port, legacy_domain, True)
        return (legacy,), legacy.server_id
    ids = {item.server_id for item in enabled_items}
    if default_id not in ids:
        default_id = enabled_items[0].server_id if enabled_items else ""
    return enabled_items, default_id

def load_config(
    config_path: Path = CONFIG_FILE,
    device_path: Path = DEVICE_FILE,
    servers_path: Path = SERVERS_FILE,
) -> ThinClientConfig:
    general = _read_ini(config_path)
    device = _read_ini(device_path)
    if servers_path == SERVERS_FILE and config_path != CONFIG_FILE:
        servers_path = config_path.parent / "servers.ini"

    try:
        legacy_server = device.get("device", "server", fallback="").strip()
        legacy_port = general.getint("rdp", "port", fallback=3389)
        legacy_domain = general.get("rdp", "domain", fallback="XAAC").strip()
        servers, default_server_id = _load_servers(
            servers_path, legacy_host=legacy_server, legacy_port=legacy_port, legacy_domain=legacy_domain
        )
        selected_server = next((item for item in servers if item.server_id == default_server_id), None)
        result = ThinClientConfig(
            application=ApplicationConfig(
                title=general.get(
                    "application",
                    "title",
                    fallback="XAAC Thin Client Sessió Remota",
                ).strip(),
                language=general.get(
                    "application",
                    "language",
                    fallback="ca",
                ).strip(),
                remember_username=general.getboolean(
                    "application",
                    "remember_username",
                    fallback=True,
                ),
                author=general.get(
                    "application",
                    "author",
                    fallback="Ajuntament de Canals",
                ).strip(),
                logo=general.get(
                    "application",
                    "logo",
                    fallback="xaac-thinclient-logo.png",
                ).strip() or "xaac-thinclient-logo.png",
                mode=(
                    _read_enum(
                        general,
                        "application",
                        "mode",
                        ApplicationMode,
                    )
                    if general.has_option("application", "mode")
                    else ApplicationMode.DEVELOPMENT
                ),
            ),
            rdp=RdpConfig(
                domain=(selected_server.domain if selected_server else legacy_domain),
                port=(selected_server.port if selected_server else legacy_port),
                fullscreen=general.getboolean(
                    "rdp",
                    "fullscreen",
                    fallback=True,
                ),
                multimon=_read_enum(
                    general,
                    "rdp",
                    "multimon",
                    MultimonMode,
                ),
                clipboard=general.getboolean(
                    "rdp",
                    "clipboard",
                    fallback=True,
                ),
                audio=general.getboolean(
                    "rdp",
                    "audio",
                    fallback=False,
                ),
                microphone=general.getboolean(
                    "rdp",
                    "microphone",
                    fallback=False,
                ),
                smartcard=general.getboolean(
                    "rdp",
                    "smartcard",
                    fallback=False,
                ),
                printers=general.getboolean(
                    "rdp",
                    "printers",
                    fallback=False,
                ),
                certificate_mode=_read_enum(
                    general,
                    "rdp",
                    "certificate_mode",
                    CertificateMode,
                ),
                security_mode=_read_enum(
                    general,
                    "rdp",
                    "security_mode",
                    SecurityMode,
                ),
                certificate_name=general.get(
                    "rdp", "certificate_name", fallback=""
                ).strip(),
                width=general.getint(
                    "rdp",
                    "width",
                    fallback=1280,
                ),
                height=general.getint(
                    "rdp",
                    "height",
                    fallback=720,
                ),
                dynamic_resolution=general.getboolean(
                    "rdp",
                    "dynamic_resolution",
                    fallback=False,
                ),
                smart_sizing=general.getboolean(
                    "rdp",
                    "smart_sizing",
                    fallback=False,
                ),
                color_depth=general.getint(
                    "rdp",
                    "color_depth",
                    fallback=32,
                ),
                performance_profile=(
                    _read_enum(
                        general,
                        "rdp",
                        "performance_profile",
                        PerformanceProfile,
                    )
                    if general.has_option("rdp", "performance_profile")
                    else PerformanceProfile.AUTO
                ),
                network_profile=_read_enum(
                    general,
                    "rdp",
                    "network_profile",
                    NetworkProfile,
                ),
                font_smoothing=general.getboolean(
                    "rdp",
                    "font_smoothing",
                    fallback=True,
                ),
                desktop_composition=general.getboolean(
                    "rdp",
                    "desktop_composition",
                    fallback=False,
                ),
                wallpaper=general.getboolean(
                    "rdp",
                    "wallpaper",
                    fallback=False,
                ),
                menu_animations=general.getboolean(
                    "rdp",
                    "menu_animations",
                    fallback=False,
                ),
                window_drag=general.getboolean(
                    "rdp",
                    "window_drag",
                    fallback=False,
                ),
                themes=general.getboolean(
                    "rdp",
                    "themes",
                    fallback=True,
                ),
                bitmap_cache=general.getboolean(
                    "rdp",
                    "bitmap_cache",
                    fallback=True,
                ),
                desktop_scale_percent=general.getint(
                    "rdp", "desktop_scale_percent", fallback=100
                ),
                device_scale_percent=general.getint(
                    "rdp", "device_scale_percent", fallback=100
                ),
                reconnect_enabled=general.getboolean(
                    "rdp", "reconnect_enabled", fallback=False
                ),
                reconnect_max_attempts=general.getint(
                    "rdp", "reconnect_max_attempts", fallback=3
                ),
                reconnect_initial_delay=general.getfloat(
                    "rdp", "reconnect_initial_delay", fallback=1.0
                ),
                reconnect_max_delay=general.getfloat(
                    "rdp", "reconnect_max_delay", fallback=8.0
                ),
            ),
            smartcard=SmartCardConfig(
                enabled=general.getboolean(
                    "smartcard",
                    "enabled",
                    fallback=general.getboolean(
                        "rdp", "smartcard", fallback=False
                    ),
                ),
                required=general.getboolean(
                    "smartcard", "required", fallback=False
                ),
                share=general.getboolean(
                    "smartcard", "share", fallback=True
                ),
                preferred_reader=general.get(
                    "smartcard", "preferred_reader", fallback=""
                ).strip(),
                pkcs11_module=general.get(
                    "smartcard", "pkcs11_module", fallback=""
                ).strip(),
            ),
            usb=UsbConfig(
                enabled=general.getboolean(
                    "usb", "enabled", fallback=False
                ),
                allowed_devices=_read_csv_tuple(
                    general, "usb", "allowed_devices"
                ),
                blocked_devices=_read_csv_tuple(
                    general, "usb", "blocked_devices"
                ),
            ),
            drives=DriveRedirectionConfig(
                enabled=general.getboolean(
                    "drives", "enabled", fallback=False
                ),
                include_existing=general.getboolean(
                    "drives", "include_existing", fallback=True
                ),
                hotplug=general.getboolean(
                    "drives", "hotplug", fallback=True
                ),
                allowed_roots=_read_csv_paths(
                    general, "drives", "allowed_roots"
                ) or ("/media", "/run/media"),
            ),
            printers=PrinterRedirectionConfig(
                enabled=general.getboolean(
                    "printers", "enabled",
                    fallback=general.getboolean("rdp", "printers", fallback=False),
                ),
                allowed_printers=_read_csv_paths(
                    general, "printers", "allowed_printers"
                ),
                default_only=general.getboolean(
                    "printers", "default_only", fallback=False
                ),
                required=general.getboolean(
                    "printers", "required", fallback=False
                ),
            ),
            audio=AudioRedirectionConfig(
                playback_enabled=general.getboolean(
                    "audio", "playback_enabled",
                    fallback=general.getboolean("rdp", "audio", fallback=False),
                ),
                recording_enabled=general.getboolean(
                    "audio", "recording_enabled",
                    fallback=general.getboolean("rdp", "microphone", fallback=False),
                ),
                playback_required=general.getboolean(
                    "audio", "playback_required", fallback=False
                ),
                recording_required=general.getboolean(
                    "audio", "recording_required", fallback=False
                ),
            ),
            video=VideoRedirectionConfig(
                enabled=general.getboolean(
                    "video", "enabled",
                    fallback=general.getboolean("rdp", "webcam", fallback=False),
                ),
                required=general.getboolean(
                    "video", "required", fallback=False
                ),
            ),
            clipboard=ClipboardRedirectionConfig(
                enabled=general.getboolean(
                    "clipboard", "enabled",
                    fallback=general.getboolean("rdp", "clipboard", fallback=True),
                ),
                profile=_read_enum(
                    general, "clipboard", "profile", ClipboardProfile
                ) if general.has_option("clipboard", "profile") else ClipboardProfile.CUSTOM,
                direction=_read_enum(
                    general, "clipboard", "direction", ClipboardDirection
                ) if general.has_option("clipboard", "direction") else ClipboardDirection.ALL,
                files=_read_enum(
                    general, "clipboard", "files", ClipboardDirection
                ) if general.has_option("clipboard", "files") else ClipboardDirection.ALL,
            ),
            keyboard=KeyboardConfig(
                layout=general.get("keyboard", "layout", fallback="auto").strip(),
            ),
            system=SystemConfig(
                autostart_enabled=general.getboolean(
                    "system", "autostart_enabled", fallback=False
                ),
                autostart_delay_seconds=general.getint(
                    "system", "autostart_delay_seconds", fallback=0
                ),
                dedicated_session_enabled=general.getboolean(
                    "system", "dedicated_session_enabled", fallback=False
                ),
                dedicated_session_name=general.get(
                    "system", "dedicated_session_name", fallback="XAAC Thin Client Remote"
                ).strip(),
                kiosk_enabled=general.getboolean(
                    "system", "kiosk_enabled", fallback=False
                ),
                kiosk_emergency_exit_enabled=general.getboolean(
                    "system", "kiosk_emergency_exit_enabled", fallback=True
                ),
                kiosk_power_actions_enabled=general.getboolean(
                    "system", "kiosk_power_actions_enabled", fallback=False
                ),
                kiosk_auto_restart=general.getboolean(
                    "system", "kiosk_auto_restart", fallback=True
                ),
                kiosk_restart_limit=general.getint(
                    "system", "kiosk_restart_limit", fallback=5
                ),
                kiosk_restart_window_seconds=general.getint(
                    "system", "kiosk_restart_window_seconds", fallback=300
                ),
                kiosk_restart_backoff_seconds=general.getfloat(
                    "system", "kiosk_restart_backoff_seconds", fallback=5.0
                ),
            ),
            network=NetworkConfig(
                connect_timeout=general.getfloat(
                    "network",
                    "connect_timeout",
                    fallback=3.0,
                ),
                retry_interval=general.getfloat(
                    "network",
                    "retry_interval",
                    fallback=5.0,
                ),
            ),
            device=DeviceConfig(
                device_name=device.get(
                    "device",
                    "device_name",
                ).strip(),
                server=(selected_server.host if selected_server else legacy_server),
                description=device.get(
                    "device",
                    "description",
                    fallback="",
                ).strip(),
            ),
            servers=servers,
            default_server_id=default_server_id,
        )
    except (
        configparser.Error,
        KeyError,
        ValueError,
    ) as error:
        raise ConfigurationError(
            f"La configuració no és vàlida: {error}"
        ) from error

    validate_config(result)

    return result
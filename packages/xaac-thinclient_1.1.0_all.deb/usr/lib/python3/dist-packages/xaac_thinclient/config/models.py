from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class ApplicationMode(Enum):
    DEVELOPMENT = "development"
    PRODUCTION = "production"


class MultimonMode(Enum):
    AUTO = "auto"
    ENABLED = "enabled"
    DISABLED = "disabled"


class CertificateMode(Enum):
    TOFU = "tofu"
    IGNORE = "ignore"
    STRICT = "strict"


class SecurityMode(Enum):
    NLA = "nla"
    TLS = "tls"
    NEGOTIATE = "negotiate"


class ClipboardDirection(Enum):
    ALL = "all"
    LOCAL = "local"
    REMOTE = "remote"
    OFF = "off"


class ClipboardProfile(Enum):
    CUSTOM = "custom"
    FULL = "full"
    TEXT_ONLY = "text-only"
    LOCAL_TO_REMOTE = "local-to-remote"
    REMOTE_TO_LOCAL = "remote-to-local"
    DISABLED = "disabled"


class PerformanceProfile(Enum):
    AUTO = "auto"
    LAN = "lan"
    WAN = "wan"
    LOW_BANDWIDTH = "low-bandwidth"
    QUALITY = "quality"


class NetworkProfile(Enum):
    AUTO = "auto"
    MODEM = "modem"
    BROADBAND = "broadband"
    BROADBAND_LOW = "broadband-low"
    BROADBAND_HIGH = "broadband-high"
    WAN = "wan"
    LAN = "lan"


@dataclass(frozen=True, slots=True)
class ApplicationConfig:
    title: str
    language: str
    remember_username: bool
    author: str
    logo: str = "xaac-thinclient-logo.png"
    mode: ApplicationMode = ApplicationMode.DEVELOPMENT


@dataclass(frozen=True, slots=True)
class RdpConfig:
    domain: str
    port: int
    fullscreen: bool
    multimon: MultimonMode
    clipboard: bool
    audio: bool
    microphone: bool
    smartcard: bool
    printers: bool
    certificate_mode: CertificateMode
    security_mode: SecurityMode
    width: int
    height: int
    dynamic_resolution: bool
    smart_sizing: bool
    color_depth: int
    network_profile: NetworkProfile
    font_smoothing: bool
    desktop_composition: bool
    wallpaper: bool
    menu_animations: bool
    window_drag: bool
    themes: bool
    bitmap_cache: bool
    performance_profile: PerformanceProfile = PerformanceProfile.AUTO
    desktop_scale_percent: int = 100
    device_scale_percent: int = 100
    reconnect_enabled: bool = False
    reconnect_max_attempts: int = 3
    reconnect_initial_delay: float = 1.0
    reconnect_max_delay: float = 8.0
    certificate_name: str = ""


@dataclass(frozen=True, slots=True)
class SmartCardConfig:
    """Configuració base del subsistema de targeta intel·ligent.

    ``enabled`` activa la detecció local PC/SC. ``required`` converteix la
    presència d'una targeta en prerequisit de connexió i ``share`` permet la
    redirecció cap a la sessió RDP. La redirecció mai no és efectiva quan el
    subsistema està desactivat, encara que ``share`` conserve el valor de la
    política configurada.
    """

    enabled: bool
    required: bool
    share: bool
    preferred_reader: str
    pkcs11_module: str = ""

    @property
    def pkcs11_enabled(self) -> bool:
        """Indica si hi ha un mòdul PKCS#11 declarat per política."""
        return self.enabled and bool(self.pkcs11_module)

    @property
    def redirection_enabled(self) -> bool:
        return self.enabled and self.share

    @property
    def card_required(self) -> bool:
        return self.enabled and self.required


@dataclass(frozen=True, slots=True)
class UsbConfig:
    enabled: bool
    allowed_devices: tuple[str, ...]
    blocked_devices: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class DriveRedirectionConfig:
    enabled: bool
    include_existing: bool
    hotplug: bool
    allowed_roots: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class PrinterRedirectionConfig:
    enabled: bool = False
    allowed_printers: tuple[str, ...] = ()
    default_only: bool = False
    required: bool = False


@dataclass(frozen=True, slots=True)
class AudioRedirectionConfig:
    playback_enabled: bool = False
    recording_enabled: bool = False
    playback_required: bool = False
    recording_required: bool = False


@dataclass(frozen=True, slots=True)
class ClipboardRedirectionConfig:
    enabled: bool = True
    profile: ClipboardProfile = ClipboardProfile.CUSTOM
    direction: ClipboardDirection = ClipboardDirection.ALL
    files: ClipboardDirection = ClipboardDirection.ALL


@dataclass(frozen=True, slots=True)
class KeyboardConfig:
    layout: str = "auto"


@dataclass(frozen=True, slots=True)
class VideoRedirectionConfig:
    enabled: bool = False
    required: bool = False


@dataclass(frozen=True, slots=True)
class SystemConfig:
    autostart_enabled: bool = False
    autostart_delay_seconds: int = 0
    dedicated_session_enabled: bool = False
    dedicated_session_name: str = "XAAC Thin Client Remote"
    kiosk_enabled: bool = False
    kiosk_emergency_exit_enabled: bool = True
    kiosk_power_actions_enabled: bool = False
    kiosk_auto_restart: bool = True
    kiosk_restart_limit: int = 5
    kiosk_restart_window_seconds: int = 300
    kiosk_restart_backoff_seconds: float = 5.0


@dataclass(frozen=True, slots=True)
class NetworkConfig:
    connect_timeout: float
    retry_interval: float


@dataclass(frozen=True, slots=True)
class RdpServerConfig:
    server_id: str
    name: str
    host: str
    port: int = 3389
    domain: str = ""
    enabled: bool = True


@dataclass(frozen=True, slots=True)
class DeviceConfig:
    device_name: str
    server: str
    description: str


@dataclass(frozen=True, slots=True)
class UserPreferences:
    username: str = ""
    remember_username: bool = False
    last_server_id: str = ""

@dataclass(frozen=True, slots=True)
class ThinClientConfig:
    application: ApplicationConfig
    rdp: RdpConfig
    smartcard: SmartCardConfig
    usb: UsbConfig
    drives: DriveRedirectionConfig
    network: NetworkConfig
    device: DeviceConfig
    servers: tuple[RdpServerConfig, ...] = ()
    default_server_id: str = ""
    printers: PrinterRedirectionConfig = PrinterRedirectionConfig()
    audio: AudioRedirectionConfig = AudioRedirectionConfig()
    video: VideoRedirectionConfig = VideoRedirectionConfig()
    clipboard: ClipboardRedirectionConfig = ClipboardRedirectionConfig()
    keyboard: KeyboardConfig = KeyboardConfig()
    system: SystemConfig = SystemConfig()

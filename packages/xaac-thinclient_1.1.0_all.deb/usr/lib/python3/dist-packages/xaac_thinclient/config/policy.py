from __future__ import annotations

from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Mapping

from xaac_thinclient.config.scope import (
    ConfigurationScope,
    ConfigurationValueSource,
)

S = ConfigurationScope.SYSTEM
U = ConfigurationScope.USER
R = ConfigurationScope.REMOTE

# Única font de veritat sobre qui pot modificar cada camp.
_CONFIG_POLICY: dict[str, frozenset[ConfigurationScope]] = {
    "application.title": frozenset({S, R}),
    "application.language": frozenset({S, R}),
    "application.remember_username": frozenset({S, U}),
    "application.author": frozenset({S}),
    "application.logo": frozenset({S}),
    "device.device_name": frozenset({S}),
    "device.server": frozenset({S, R}),
    "device.description": frozenset({S, R}),
    "rdp.domain": frozenset({S, R}),
    "rdp.port": frozenset({S, R}),
    "rdp.fullscreen": frozenset({S, R}),
    "rdp.multimon": frozenset({S, R}),
    "rdp.clipboard": frozenset({S, R}),
    "clipboard.enabled": frozenset({S, R}),
    "clipboard.profile": frozenset({S, R}),
    "clipboard.direction": frozenset({S, R}),
    "clipboard.files": frozenset({S, R}),
    "keyboard.layout": frozenset({S, R}),
    "rdp.audio": frozenset({S, R}),
    "rdp.microphone": frozenset({S, R}),
    "audio.playback_enabled": frozenset({S, R}),
    "audio.recording_enabled": frozenset({S, R}),
    "audio.playback_required": frozenset({S, R}),
    "audio.recording_required": frozenset({S, R}),
    "rdp.smartcard": frozenset({S}),
    "smartcard.enabled": frozenset({S, R}),
    "smartcard.required": frozenset({S, R}),
    "smartcard.share": frozenset({S, R}),
    "smartcard.preferred_reader": frozenset({S, R}),
    "smartcard.pkcs11_module": frozenset({S, R}),
    "usb.enabled": frozenset({S, R}),
    "usb.allowed_devices": frozenset({S, R}),
    "usb.blocked_devices": frozenset({S, R}),
    "drives.enabled": frozenset({S, R}),
    "drives.include_existing": frozenset({S, R}),
    "drives.hotplug": frozenset({S, R}),
    "drives.allowed_roots": frozenset({S}),
    "rdp.printers": frozenset({S, R}),
    "video.enabled": frozenset({S, R}),
    "video.required": frozenset({S, R}),
    "printers.enabled": frozenset({S, R}),
    "printers.allowed_printers": frozenset({S, R}),
    "printers.default_only": frozenset({S, R}),
    "printers.required": frozenset({S, R}),
    "rdp.certificate_mode": frozenset({S, R}),
    "rdp.certificate_name": frozenset({S, R}),
    "rdp.security_mode": frozenset({S, R}),
    "rdp.width": frozenset({S, R}),
    "rdp.height": frozenset({S, R}),
    "rdp.dynamic_resolution": frozenset({S, R}),
    "rdp.smart_sizing": frozenset({S, R}),
    "rdp.color_depth": frozenset({S, R}),
    "rdp.performance_profile": frozenset({S, R}),
    "rdp.network_profile": frozenset({S, R}),
    "rdp.font_smoothing": frozenset({S, R}),
    "rdp.desktop_composition": frozenset({S, R}),
    "rdp.wallpaper": frozenset({S, R}),
    "rdp.menu_animations": frozenset({S, R}),
    "rdp.window_drag": frozenset({S, R}),
    "rdp.themes": frozenset({S, R}),
    "rdp.bitmap_cache": frozenset({S, R}),
    "rdp.desktop_scale_percent": frozenset({S, R}),
    "rdp.device_scale_percent": frozenset({S, R}),
    "rdp.reconnect_enabled": frozenset({S, R}),
    "rdp.reconnect_max_attempts": frozenset({S, R}),
    "rdp.reconnect_initial_delay": frozenset({S, R}),
    "rdp.reconnect_max_delay": frozenset({S, R}),
    "system.autostart_enabled": frozenset({S, R}),
    "system.autostart_delay_seconds": frozenset({S, R}),
    "system.dedicated_session_enabled": frozenset({S, R}),
    "system.dedicated_session_name": frozenset({S, R}),
    "system.kiosk_enabled": frozenset({S, R}),
    "system.kiosk_emergency_exit_enabled": frozenset({S}),
    "system.kiosk_power_actions_enabled": frozenset({S, R}),
    "system.kiosk_auto_restart": frozenset({S, R}),
    "system.kiosk_restart_limit": frozenset({S, R}),
    "system.kiosk_restart_window_seconds": frozenset({S, R}),
    "system.kiosk_restart_backoff_seconds": frozenset({S, R}),
    "network.connect_timeout": frozenset({S, R}),
    "network.retry_interval": frozenset({S, R}),
    "remote_config.enabled": frozenset({S}),
    "remote_config.url": frozenset({S}),
    "remote_config.timeout": frozenset({S}),
    "remote_config.allow_http": frozenset({S}),
    "user.username": frozenset({U}),
    "user.remember_username": frozenset({U}),
}

CONFIG_POLICY: Mapping[str, frozenset[ConfigurationScope]] = MappingProxyType(
    _CONFIG_POLICY
)


def is_allowed(path: str, scope: ConfigurationScope) -> bool:
    """Indica si un àmbit pot modificar el camp indicat."""

    return scope in CONFIG_POLICY.get(path, frozenset())


def remote_allowed_paths() -> frozenset[str]:
    return frozenset(
        path
        for path, scopes in CONFIG_POLICY.items()
        if ConfigurationScope.REMOTE in scopes
    )


@dataclass(frozen=True, slots=True)
class ConfigurationMetadata:
    """Metadades no sensibles sobre l'origen de la configuració efectiva."""

    remote_source: ConfigurationValueSource = ConfigurationValueSource.SYSTEM
    origins: Mapping[str, ConfigurationValueSource] = field(
        default_factory=lambda: MappingProxyType({})
    )
    applied_remote_keys: tuple[str, ...] = ()
    rejected_remote_keys: tuple[str, ...] = ()
    warning: str | None = None

    @classmethod
    def system_defaults(cls) -> "ConfigurationMetadata":
        return cls(
            origins=MappingProxyType(
                {
                    path: ConfigurationValueSource.SYSTEM
                    for path in CONFIG_POLICY
                    if not path.startswith("user.")
                }
            )
        )

    def source_for(self, path: str) -> ConfigurationValueSource:
        return self.origins.get(path, ConfigurationValueSource.SYSTEM)

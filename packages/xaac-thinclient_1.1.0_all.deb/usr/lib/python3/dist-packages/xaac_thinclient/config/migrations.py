from __future__ import annotations

import configparser
import os
import shutil
import stat
import tempfile
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Callable


CURRENT_CONFIG_SCHEMA_VERSION = 1
_SCHEMA_SECTION = "xaac"
_SCHEMA_OPTION = "schema_version"


class MigrationStatus(str, Enum):
    UNCHANGED = "unchanged"
    MIGRATED = "migrated"
    INVALID = "invalid"
    UNSUPPORTED = "unsupported"


@dataclass(frozen=True, slots=True)
class MigrationAuditEvent:
    event: str
    source_version: int | None
    target_version: int
    changed: bool


@dataclass(frozen=True, slots=True)
class MigrationResult:
    status: MigrationStatus
    source_version: int | None
    target_version: int
    changed: bool
    backup_path: Path | None
    diagnostic: str
    audit: MigrationAuditEvent


class ConfigurationMigrationError(RuntimeError):
    """Error segur i esperable durant una migració de configuració."""


MigrationStep = Callable[[str], str]


def _parse_schema_version(text: str) -> int:
    parser = configparser.ConfigParser(interpolation=None, strict=True)
    try:
        parser.read_string(text)
    except configparser.Error as error:
        raise ConfigurationMigrationError("invalid-ini") from error

    if not parser.has_section(_SCHEMA_SECTION):
        return 0
    raw = parser.get(_SCHEMA_SECTION, _SCHEMA_OPTION, fallback="").strip()
    if not raw or not raw.isdecimal():
        raise ConfigurationMigrationError("invalid-schema-version")
    return int(raw)


def _migrate_v0_to_v1(text: str) -> str:
    """Afig metadades de versió sense alterar opcions ni comentaris existents."""
    prefix = f"[{_SCHEMA_SECTION}]\n{_SCHEMA_OPTION} = 1\n\n"
    return prefix + text.lstrip("\ufeff")


_MIGRATIONS: dict[int, MigrationStep] = {0: _migrate_v0_to_v1}


def migrate_text(
    text: str,
    *,
    target_version: int = CURRENT_CONFIG_SCHEMA_VERSION,
) -> tuple[str, int, bool]:
    if target_version < 0 or target_version > CURRENT_CONFIG_SCHEMA_VERSION:
        raise ConfigurationMigrationError("unsupported-target-version")

    source_version = _parse_schema_version(text)
    if source_version > CURRENT_CONFIG_SCHEMA_VERSION or source_version > target_version:
        raise ConfigurationMigrationError("newer-schema-version")

    migrated = text
    version = source_version
    while version < target_version:
        step = _MIGRATIONS.get(version)
        if step is None:
            raise ConfigurationMigrationError("missing-migration-step")
        migrated = step(migrated)
        version += 1

    # La sortida també ha de ser un INI vàlid i declarar la versió final.
    if _parse_schema_version(migrated) != target_version:
        raise ConfigurationMigrationError("migration-verification-failed")
    return migrated, source_version, migrated != text


def _secure_regular_file(path: Path) -> os.stat_result:
    try:
        info = path.lstat()
    except OSError as error:
        raise ConfigurationMigrationError("configuration-unreadable") from error
    if stat.S_ISLNK(info.st_mode) or not stat.S_ISREG(info.st_mode):
        raise ConfigurationMigrationError("configuration-not-regular")
    return info


def _write_atomic(path: Path, content: str, mode: int) -> None:
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".migrating", dir=path.parent
    )
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="") as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temporary, stat.S_IMODE(mode))
        os.replace(temporary, path)
        directory_fd = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
    finally:
        temporary.unlink(missing_ok=True)


def migrate_file(
    path: Path,
    *,
    target_version: int = CURRENT_CONFIG_SCHEMA_VERSION,
    create_backup: bool = True,
) -> MigrationResult:
    path = Path(path)
    try:
        info = _secure_regular_file(path)
        original = path.read_text(encoding="utf-8")
        migrated, source_version, changed = migrate_text(
            original, target_version=target_version
        )
    except (OSError, UnicodeError, ConfigurationMigrationError) as error:
        diagnostic = str(error) or error.__class__.__name__
        status = (
            MigrationStatus.UNSUPPORTED
            if diagnostic in {"newer-schema-version", "unsupported-target-version"}
            else MigrationStatus.INVALID
        )
        return MigrationResult(
            status=status,
            source_version=None,
            target_version=target_version,
            changed=False,
            backup_path=None,
            diagnostic=diagnostic,
            audit=MigrationAuditEvent(
                event=f"configuration-migration-{status.value}",
                source_version=None,
                target_version=target_version,
                changed=False,
            ),
        )

    if not changed:
        return MigrationResult(
            status=MigrationStatus.UNCHANGED,
            source_version=source_version,
            target_version=target_version,
            changed=False,
            backup_path=None,
            diagnostic="already-current",
            audit=MigrationAuditEvent(
                event="configuration-migration-unchanged",
                source_version=source_version,
                target_version=target_version,
                changed=False,
            ),
        )

    backup_path: Path | None = None
    try:
        if create_backup:
            backup_path = path.with_name(f"{path.name}.pre-v{source_version}.bak")
            if not backup_path.exists():
                shutil.copyfile(path, backup_path, follow_symlinks=False)
                os.chmod(backup_path, stat.S_IMODE(info.st_mode))
        _write_atomic(path, migrated, info.st_mode)
    except OSError:
        return MigrationResult(
            status=MigrationStatus.INVALID,
            source_version=source_version,
            target_version=target_version,
            changed=False,
            backup_path=backup_path,
            diagnostic="atomic-write-failed",
            audit=MigrationAuditEvent(
                event="configuration-migration-invalid",
                source_version=source_version,
                target_version=target_version,
                changed=False,
            ),
        )

    return MigrationResult(
        status=MigrationStatus.MIGRATED,
        source_version=source_version,
        target_version=target_version,
        changed=True,
        backup_path=backup_path,
        diagnostic="migration-completed",
        audit=MigrationAuditEvent(
            event="configuration-migration-completed",
            source_version=source_version,
            target_version=target_version,
            changed=True,
        ),
    )

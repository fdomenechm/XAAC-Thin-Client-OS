from __future__ import annotations

import re
from pathlib import Path

from xaac_thinclient.config.models import ThinClientConfig
from xaac_thinclient.i18n import _
from xaac_thinclient.services.keyboard import KeyboardService


_USB_ID_PATTERN = re.compile(r"^[0-9a-fA-F]{4}:[0-9a-fA-F]{4}$")


_HOSTNAME_PATTERN = re.compile(
    r"^(?=.{1,253}$)"
    r"(?:[a-zA-Z0-9]"
    r"(?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?"
    r"\.)*"
    r"[a-zA-Z0-9]"
    r"(?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?$"
)


class ConfigurationError(ValueError):
    """La configuració del thin client és incorrecta."""


def validate_config(config: ThinClientConfig) -> None:
    if not config.application.title.strip():
        raise ConfigurationError(
            _("The application title cannot be empty.")
        )

    if not config.application.author.strip():
        raise ConfigurationError(
            _("The application author cannot be empty.")
        )

    if not config.device.device_name.strip():
        raise ConfigurationError(
            _("The device name cannot be empty.")
        )

    server = config.device.server.strip()

    if not server:
        raise ConfigurationError(
            _("The RDP server cannot be empty.")
        )

    if not _HOSTNAME_PATTERN.fullmatch(server):
        raise ConfigurationError(
            _("Invalid RDP server: {server}").format(server=server)
        )

    if not config.rdp.domain.strip():
        raise ConfigurationError(
            _("The RDP domain cannot be empty.")
        )

    if not 1 <= config.rdp.port <= 65535:
        raise ConfigurationError(
            _("The RDP port must be between 1 and 65535.")
        )

    if not 320 <= config.rdp.width <= 16384:
        raise ConfigurationError(
            _("The RDP width must be between 320 and 16384 pixels.")
        )

    if not 200 <= config.rdp.height <= 16384:
        raise ConfigurationError(
            _("The RDP height must be between 200 and 16384 pixels.")
        )

    if not 100 <= config.rdp.desktop_scale_percent <= 500:
        raise ConfigurationError(_("Desktop scaling must be between 100 and 500 percent."))

    if config.rdp.device_scale_percent not in {100, 140, 180}:
        raise ConfigurationError(_("Device scaling must be 100, 140 or 180 percent."))

    if not 0 <= config.rdp.reconnect_max_attempts <= 20:
        raise ConfigurationError(_("RDP reconnect attempts must be between 0 and 20."))

    if not 0 <= config.rdp.reconnect_initial_delay <= 300:
        raise ConfigurationError(_("RDP reconnect initial delay must be between 0 and 300 seconds."))

    if not config.rdp.reconnect_initial_delay <= config.rdp.reconnect_max_delay <= 900:
        raise ConfigurationError(_("RDP reconnect maximum delay must be between the initial delay and 900 seconds."))

    if config.rdp.color_depth not in {16, 24, 32}:
        raise ConfigurationError(
            _("The RDP color depth must be 16, 24 or 32 bits.")
        )

    if config.rdp.fullscreen and config.rdp.smart_sizing:
        raise ConfigurationError(
            _("Smart sizing is only available in windowed mode.")
        )

    try:
        KeyboardService().resolve(config.keyboard.layout, config.application.language)
    except ValueError as error:
        raise ConfigurationError(str(error)) from error

    if config.smartcard.required and not config.smartcard.enabled:
        raise ConfigurationError(
            _("A smart card cannot be required while smart card support is disabled.")
        )

    preferred_reader = config.smartcard.preferred_reader
    if len(preferred_reader) > 255:
        raise ConfigurationError(
            _("The preferred smart card reader name is too long.")
        )
    if any(ord(character) < 32 for character in preferred_reader):
        raise ConfigurationError(
            _("The preferred smart card reader name contains invalid characters.")
        )

    pkcs11_module = config.smartcard.pkcs11_module
    if len(pkcs11_module) > 4096:
        raise ConfigurationError(
            _("The PKCS#11 module path is too long.")
        )
    if any(ord(character) < 32 for character in pkcs11_module):
        raise ConfigurationError(
            _("The PKCS#11 module path contains invalid characters.")
        )
    if pkcs11_module and not Path(pkcs11_module).is_absolute():
        raise ConfigurationError(
            _("The PKCS#11 module path must be absolute.")
        )

    if not 0 <= config.system.autostart_delay_seconds <= 300:
        raise ConfigurationError(
            _("The automatic startup delay must be between 0 and 300 seconds.")
        )

    session_name = config.system.dedicated_session_name
    if not session_name or len(session_name) > 64:
        raise ConfigurationError(
            _("The dedicated session name must contain between 1 and 64 characters.")
        )
    if any(ord(character) < 32 for character in session_name):
        raise ConfigurationError(
            _("The dedicated session name contains invalid characters.")
        )

    if not 1 <= config.system.kiosk_restart_limit <= 100:
        raise ConfigurationError(
            _("The kiosk restart limit must be between 1 and 100.")
        )
    if not 10 <= config.system.kiosk_restart_window_seconds <= 86400:
        raise ConfigurationError(
            _("The kiosk restart window must be between 10 and 86400 seconds.")
        )
    if not 0.1 <= config.system.kiosk_restart_backoff_seconds <= 3600:
        raise ConfigurationError(
            _("The kiosk restart backoff must be between 0.1 and 3600 seconds.")
        )

    if config.network.connect_timeout <= 0:
        raise ConfigurationError(
            _("The connection timeout must be greater than zero.")
        )

    if config.network.retry_interval <= 0:
        raise ConfigurationError(
            _("The retry interval must be greater than zero.")
        )
    for device_id in (*config.usb.allowed_devices, *config.usb.blocked_devices):
        if not _USB_ID_PATTERN.fullmatch(device_id):
            raise ConfigurationError(
                _("Invalid USB device identifier: {device_id}. Expected VID:PID.").format(
                    device_id=device_id
                )
            )

    overlapping_devices = set(config.usb.allowed_devices) & set(
        config.usb.blocked_devices
    )
    if overlapping_devices:
        raise ConfigurationError(
            _("A USB device cannot be both allowed and blocked: {device_id}").format(
                device_id=sorted(overlapping_devices)[0]
            )
        )
    for root in config.drives.allowed_roots:
        if not root.startswith("/"):
            raise ConfigurationError(
                _("Drive redirection roots must be absolute paths.")
            )
        if root == "/":
            raise ConfigurationError(
                _("The filesystem root cannot be shared through RDP.")
            )


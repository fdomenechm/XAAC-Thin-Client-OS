"""Public, stable contracts for the XAAC RDP planning subsystem.

The package exposes immutable preparation and adaptation artefacts. Process
execution remains deliberately isolated in :mod:`xaac_thinclient.services.rdp_execution`.
"""

from xaac_thinclient.rdp.credentials import (
    RdpCredentialError, RdpCredentialPolicy, RdpCredentialSecret,
)
from xaac_thinclient.rdp.command_builder import (
    FreeRdpArgumentNormalizer,
    FreeRdpCommandBuilder,
    RdpCommand,
    RdpCommandRequest,
)
from xaac_thinclient.rdp.display import RdpDisplayPlan, RdpDisplayPlanner
from xaac_thinclient.rdp.graphics import (
    RdpGraphicsMode,
    RdpGraphicsSelection,
    RdpGraphicsSelector,
)
from xaac_thinclient.rdp.hardening import (
    RdpCommandHardener, RdpCommandHardeningError,
    RdpCommandHardeningPolicy, RdpCommandHardeningReport,
)
from xaac_thinclient.rdp.hardware import (
    RdpDisplayGeometry,
    RdpHardwareDetector,
    RdpHardwareInventory,
)
from xaac_thinclient.rdp.network_quality import (
    RdpNetworkQuality,
    RdpNetworkQualityDetector,
    RdpNetworkQualitySnapshot,
)
from xaac_thinclient.rdp.performance import (
    RdpPerformanceProfileResolver,
    RdpPerformanceResolution,
)
from xaac_thinclient.rdp.preflight import (
    PreflightStatus,
    RdpPreflightCheck,
    RdpPreflightReport,
)
from xaac_thinclient.rdp.reconnect import RdpReconnectPolicy, RdpReconnectReport
from xaac_thinclient.rdp.tls import RdpTlsPolicy, RdpTlsPolicyError, RdpTlsPolicyResolver
from xaac_thinclient.rdp.security import (
    RdpSecurityPolicy, RdpSecurityPolicyError, RdpSecurityPolicyResolver,
)
from xaac_thinclient.rdp.session import (
    RdpSessionDiagnostic,
    RdpSessionPlan,
    RdpSessionPlanError,
    RdpSessionWarning,
    canonical_strings,
)

__all__ = (
    "FreeRdpArgumentNormalizer",
    "FreeRdpCommandBuilder",
    "PreflightStatus",
    "RdpCommand",
    "RdpCommandRequest",
    "RdpCredentialError",
    "RdpCredentialPolicy",
    "RdpCredentialSecret",
    "RdpDisplayGeometry",
    "RdpDisplayPlan",
    "RdpDisplayPlanner",
    "RdpGraphicsMode",
    "RdpGraphicsSelection",
    "RdpGraphicsSelector",
    "RdpHardwareDetector",
    "RdpHardwareInventory",
    "RdpNetworkQuality",
    "RdpNetworkQualityDetector",
    "RdpNetworkQualitySnapshot",
    "RdpPerformanceProfileResolver",
    "RdpPerformanceResolution",
    "RdpPreflightCheck",
    "RdpPreflightReport",
    "RdpReconnectPolicy",
    "RdpReconnectReport",
    "RdpSecurityPolicy",
    "RdpSecurityPolicyError",
    "RdpSecurityPolicyResolver",
    "RdpSessionDiagnostic",
    "RdpSessionPlan",
    "RdpSessionPlanError",
    "RdpSessionWarning",
    "RdpTlsPolicy",
    "RdpTlsPolicyError",
    "RdpTlsPolicyResolver",
    "canonical_strings",
)

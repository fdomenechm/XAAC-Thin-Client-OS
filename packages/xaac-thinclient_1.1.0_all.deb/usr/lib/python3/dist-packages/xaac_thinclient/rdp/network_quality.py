from __future__ import annotations

import re
import subprocess
from dataclasses import dataclass
from enum import Enum
from typing import Callable


class RdpNetworkQuality(str, Enum):
    UNKNOWN = "unknown"
    EXCELLENT = "excellent"
    GOOD = "good"
    FAIR = "fair"
    POOR = "poor"


@dataclass(frozen=True, slots=True)
class RdpNetworkQualitySnapshot:
    """Immutable, sanitised network observations for one RDP target."""

    quality: RdpNetworkQuality
    latency_ms: float | None = None
    packet_loss_percent: float | None = None
    samples_sent: int = 0
    samples_received: int = 0
    warnings: tuple[str, ...] = ()

    @property
    def reachable(self) -> bool | None:
        if self.samples_sent <= 0:
            return None
        return self.samples_received > 0


class RdpNetworkQualityDetector:
    """Best-effort ICMP quality detector with injectable command execution.

    Failure to run or parse ``ping`` never blocks an RDP session. No target
    address or user data is retained in the immutable snapshot.
    """

    _PACKETS = re.compile(
        r"(?P<sent>\d+)\s+packets transmitted,\s+(?P<received>\d+)\s+(?:packets )?received,.*?(?P<loss>[\d.,]+)%\s+packet loss",
        re.IGNORECASE,
    )
    _RTT = re.compile(
        r"(?:rtt|round-trip)\s+min/avg/max/(?:mdev|stddev)\s*=\s*[\d.,]+/(?P<avg>[\d.,]+)/",
        re.IGNORECASE,
    )

    def __init__(
        self,
        run_command: Callable[[tuple[str, ...]], str] | None = None,
        sample_count: int = 4,
        timeout_seconds: int = 1,
    ) -> None:
        self._run_command = run_command or self._default_run_command
        self._sample_count = max(1, int(sample_count))
        self._timeout_seconds = max(1, int(timeout_seconds))

    @staticmethod
    def _default_run_command(command: tuple[str, ...]) -> str:
        completed = subprocess.run(
            command,
            check=False,
            capture_output=True,
            text=True,
            timeout=8.0,
        )
        return "\n".join(part for part in (completed.stdout, completed.stderr) if part)

    def detect(self, server: str) -> RdpNetworkQualitySnapshot:
        target = server.strip()
        if not target:
            return RdpNetworkQualitySnapshot(
                quality=RdpNetworkQuality.UNKNOWN,
                warnings=("network-target-empty",),
            )
        command = (
            "ping", "-n", "-c", str(self._sample_count),
            "-W", str(self._timeout_seconds), "--", target,
        )
        try:
            output = self._run_command(command)
        except FileNotFoundError:
            return RdpNetworkQualitySnapshot(
                quality=RdpNetworkQuality.UNKNOWN,
                warnings=("ping-unavailable",),
            )
        except (OSError, subprocess.SubprocessError):
            return RdpNetworkQualitySnapshot(
                quality=RdpNetworkQuality.UNKNOWN,
                warnings=("network-measurement-failed",),
            )

        packet_match = self._PACKETS.search(output)
        if packet_match is None:
            return RdpNetworkQualitySnapshot(
                quality=RdpNetworkQuality.UNKNOWN,
                warnings=("network-measurement-unparseable",),
            )

        sent = int(packet_match.group("sent"))
        received = int(packet_match.group("received"))
        loss = self._number(packet_match.group("loss"))
        rtt_match = self._RTT.search(output)
        latency = self._number(rtt_match.group("avg")) if rtt_match else None
        warnings: list[str] = []
        if received == 0:
            warnings.append("network-target-unreachable")
        elif latency is None:
            warnings.append("network-latency-unavailable")

        return RdpNetworkQualitySnapshot(
            quality=self.classify(latency, loss),
            latency_ms=latency,
            packet_loss_percent=loss,
            samples_sent=sent,
            samples_received=received,
            warnings=tuple(warnings),
        )

    @staticmethod
    def _number(value: str) -> float:
        return float(value.replace(",", "."))

    @staticmethod
    def classify(latency_ms: float | None, packet_loss_percent: float | None) -> RdpNetworkQuality:
        if packet_loss_percent is None:
            return RdpNetworkQuality.UNKNOWN
        if packet_loss_percent >= 20 or latency_ms is None:
            return RdpNetworkQuality.POOR
        if packet_loss_percent <= 0 and latency_ms <= 30:
            return RdpNetworkQuality.EXCELLENT
        if packet_loss_percent <= 1 and latency_ms <= 80:
            return RdpNetworkQuality.GOOD
        if packet_loss_percent <= 5 and latency_ms <= 180:
            return RdpNetworkQuality.FAIR
        return RdpNetworkQuality.POOR

from __future__ import annotations

from dataclasses import dataclass, replace

from xaac_thinclient.config.models import NetworkProfile, PerformanceProfile, ThinClientConfig


@dataclass(frozen=True, slots=True)
class RdpPerformanceResolution:
    requested: PerformanceProfile
    effective: PerformanceProfile
    config: ThinClientConfig
    changed_fields: tuple[str, ...] = ()


class RdpPerformanceProfileResolver:
    """Resolve one immutable performance profile into effective RDP settings.

    AUTO deliberately preserves the configured fine-grained values in this
    phase. Hardware and network driven AUTO selection are introduced in 4.12.2
    and 4.12.3 without changing this public contract.
    """

    _VALUES = {
        PerformanceProfile.LAN: dict(
            network_profile=NetworkProfile.LAN, color_depth=32,
            font_smoothing=True, desktop_composition=True, wallpaper=True,
            menu_animations=True, window_drag=True, themes=True, bitmap_cache=True,
        ),
        PerformanceProfile.WAN: dict(
            network_profile=NetworkProfile.WAN, color_depth=24,
            font_smoothing=True, desktop_composition=False, wallpaper=False,
            menu_animations=False, window_drag=False, themes=True, bitmap_cache=True,
        ),
        PerformanceProfile.LOW_BANDWIDTH: dict(
            network_profile=NetworkProfile.BROADBAND_LOW, color_depth=16,
            font_smoothing=False, desktop_composition=False, wallpaper=False,
            menu_animations=False, window_drag=False, themes=False, bitmap_cache=True,
        ),
        PerformanceProfile.QUALITY: dict(
            network_profile=NetworkProfile.LAN, color_depth=32,
            font_smoothing=True, desktop_composition=True, wallpaper=True,
            menu_animations=True, window_drag=True, themes=True, bitmap_cache=True,
        ),
    }

    def resolve(self, config: ThinClientConfig) -> RdpPerformanceResolution:
        requested = config.rdp.performance_profile
        if requested is PerformanceProfile.AUTO:
            return RdpPerformanceResolution(requested, requested, config)

        values = self._VALUES[requested]
        changed = tuple(sorted(
            f"rdp.{name}" for name, value in values.items()
            if getattr(config.rdp, name) != value
        ))
        effective_rdp = replace(config.rdp, **values)
        return RdpPerformanceResolution(
            requested=requested,
            effective=requested,
            config=replace(config, rdp=effective_rdp),
            changed_fields=changed,
        )

from __future__ import annotations

from dataclasses import dataclass

from xaac_thinclient.config.models import MultimonMode, ThinClientConfig
from xaac_thinclient.rdp.hardware import RdpHardwareInventory


@dataclass(frozen=True, slots=True)
class RdpDisplayPlan:
    monitor_count: int
    multimon_enabled: bool
    multimon_forced: bool
    desktop_scale_percent: int
    device_scale_percent: int
    mixed_resolutions: bool
    maximum_width: int
    maximum_height: int
    warnings: tuple[str, ...] = ()

    @property
    def arguments(self) -> tuple[str, ...]:
        return (
            f"/scale-desktop:{self.desktop_scale_percent}",
            f"/scale-device:{self.device_scale_percent}",
        )


class RdpDisplayPlanner:
    """Resolve immutable multimonitor and DPI settings before command building."""

    def resolve(
        self,
        config: ThinClientConfig,
        hardware: RdpHardwareInventory,
        monitor_count_hint: int,
    ) -> RdpDisplayPlan:
        monitor_count = max(1, hardware.monitor_count, monitor_count_hint)
        multimon_enabled = (
            config.rdp.multimon is MultimonMode.ENABLED
            or (config.rdp.multimon is MultimonMode.AUTO and monitor_count > 1)
        )
        displays = hardware.displays
        geometries = {(item.width, item.height) for item in displays if item.width and item.height}
        mixed = len(geometries) > 1
        warnings: list[str] = []
        if mixed and multimon_enabled:
            warnings.append("mixed-monitor-resolutions")
        if config.rdp.dynamic_resolution and multimon_enabled:
            warnings.append("dynamic-resolution-with-multimon")
        maximum = hardware.maximum_display
        return RdpDisplayPlan(
            monitor_count=monitor_count,
            multimon_enabled=multimon_enabled,
            multimon_forced=config.rdp.multimon is MultimonMode.ENABLED,
            desktop_scale_percent=config.rdp.desktop_scale_percent,
            device_scale_percent=config.rdp.device_scale_percent,
            mixed_resolutions=mixed,
            maximum_width=maximum.width if maximum else 0,
            maximum_height=maximum.height if maximum else 0,
            warnings=tuple(sorted(set(warnings))),
        )

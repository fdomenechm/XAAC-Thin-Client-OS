from __future__ import annotations

from dataclasses import dataclass

from xaac_thinclient.config.models import CertificateMode, SecurityMode, ThinClientConfig
from xaac_thinclient.rdp.tls import RdpTlsPolicy


@dataclass(frozen=True, slots=True)
class RdpSecurityPolicy:
    mode: SecurityMode
    arguments: tuple[str, ...]
    nla_enabled: bool
    negotiation_enabled: bool
    tls_forced: bool
    credential_delegation: bool
    warnings: tuple[str, ...] = ()


class RdpSecurityPolicyError(ValueError):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


class RdpSecurityPolicyResolver:
    """Resolve the configured authentication/security mode canonically.

    FreeRDP performs automatic protocol negotiation when no ``/sec:`` option
    is supplied.  Therefore ``SecurityMode.NEGOTIATE`` deliberately emits no
    security selector instead of the invalid ``/sec:negotiate`` token.
    """

    def resolve(self, config: ThinClientConfig, tls: RdpTlsPolicy) -> RdpSecurityPolicy:
        mode = config.rdp.security_mode
        warnings: list[str] = []

        if mode is SecurityMode.NLA:
            security_arguments = ("/sec:nla",)
            nla_enabled = True
            negotiation_enabled = False
            tls_forced = False
            credential_delegation = True
        elif mode is SecurityMode.TLS:
            security_arguments = ("/sec:tls",)
            nla_enabled = False
            negotiation_enabled = False
            tls_forced = True
            credential_delegation = False
            warnings.append("nla-disabled")
        elif mode is SecurityMode.NEGOTIATE:
            security_arguments = ()
            nla_enabled = False
            negotiation_enabled = True
            tls_forced = False
            credential_delegation = False
            warnings.append("security-mode-negotiated")
        else:  # defensive guard for future enum extensions
            raise RdpSecurityPolicyError(
                "RDP-SEC-001", "The configured RDP security mode is unsupported."
            )

        if mode is not SecurityMode.NLA and config.rdp.certificate_mode is CertificateMode.IGNORE:
            warnings.append("authentication-without-certificate-validation")

        certificate_arguments = tuple(
            argument for argument in tls.arguments if not argument.startswith("/sec:")
        )
        return RdpSecurityPolicy(
            mode=mode,
            arguments=security_arguments + certificate_arguments,
            nla_enabled=nla_enabled,
            negotiation_enabled=negotiation_enabled,
            tls_forced=tls_forced,
            credential_delegation=credential_delegation,
            warnings=tuple(warnings),
        )

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class PreflightStatus(str, Enum):
    PASS = "pass"
    WARNING = "warning"
    FAIL = "fail"
    SKIPPED = "skipped"


@dataclass(frozen=True, slots=True)
class RdpPreflightCheck:
    name: str
    status: PreflightStatus
    code: str
    detail: str = ""
    required: bool = False

    @property
    def blocking(self) -> bool:
        return self.required and self.status is PreflightStatus.FAIL


@dataclass(frozen=True, slots=True)
class RdpPreflightReport:
    checks: tuple[RdpPreflightCheck, ...]

    @property
    def passed(self) -> bool:
        return not any(item.blocking for item in self.checks)

    @property
    def connection_allowed(self) -> bool:
        return self.passed

    @property
    def blocking_checks(self) -> tuple[RdpPreflightCheck, ...]:
        return tuple(item for item in self.checks if item.blocking)

    @property
    def warning_checks(self) -> tuple[RdpPreflightCheck, ...]:
        return tuple(item for item in self.checks if item.status is PreflightStatus.WARNING)

    def get(self, name: str) -> RdpPreflightCheck | None:
        return next((item for item in self.checks if item.name == name), None)

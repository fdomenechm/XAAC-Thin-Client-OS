from __future__ import annotations

from dataclasses import dataclass
from typing import TextIO


@dataclass(frozen=True, slots=True)
class RdpCredentialPolicy:
    """Sanitised, immutable description of the credential transport policy."""

    transport: str = "stdin"
    command_line_secret: bool = False
    persisted: bool = False
    logged: bool = False
    reusable_for_reconnect: bool = True


class RdpCredentialError(ValueError):
    """Invalid credential input with a stable execution error code."""


class RdpCredentialSecret:
    """Short-lived mutable password buffer with redacted representation.

    Python cannot guarantee complete process-memory erasure, but this wrapper
    avoids retaining the password in plans, commands, diagnostics or object
    representations and overwrites its owned byte buffer after execution.
    """

    __slots__ = ("_buffer", "_cleared")

    def __init__(self, password: str) -> None:
        if not isinstance(password, str):
            raise TypeError("password must be a string")
        if any(character in password for character in ("\x00", "\r", "\n")):
            raise RdpCredentialError("credential contains an invalid control character")
        self._buffer = bytearray(password.encode("utf-8"))
        self._cleared = False

    @property
    def cleared(self) -> bool:
        return self._cleared

    def write_to(self, stream: TextIO) -> None:
        if self._cleared:
            raise RuntimeError("credential secret has already been cleared")
        # FreeRDP's text stdin contract requires a transient str at this edge.
        stream.write(self._buffer.decode("utf-8"))
        stream.write("\n")
        stream.flush()

    def clear(self) -> None:
        for index in range(len(self._buffer)):
            self._buffer[index] = 0
        self._buffer.clear()
        self._cleared = True

    def __repr__(self) -> str:
        return "RdpCredentialSecret(<redacted>)"

    __str__ = __repr__

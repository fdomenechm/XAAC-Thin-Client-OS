from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

from xaac_thinclient.config.models import MultimonMode, ThinClientConfig
from xaac_thinclient.services.audio import AudioRedirectionService, AudioRedirectionStatus
from xaac_thinclient.services.clipboard import ClipboardRedirectionService
from xaac_thinclient.services.drives import DriveRedirectionService
from xaac_thinclient.services.keyboard import KeyboardService
from xaac_thinclient.services.printers import PrinterRedirectionService, PrinterRedirectionStatus
from xaac_thinclient.services.usb import UsbService
from xaac_thinclient.services.video import VideoRedirectionService, VideoRedirectionStatus


@dataclass(frozen=True, slots=True)
class RdpCommandRequest:
    """Immutable input required to build one effective FreeRDP command."""

    executable: str
    config: ThinClientConfig
    username: str
    monitor_count: int
    printer_status: PrinterRedirectionStatus | None = None
    audio_status: AudioRedirectionStatus | None = None
    video_status: VideoRedirectionStatus | None = None
    graphics_arguments: tuple[str, ...] = ()
    display_arguments: tuple[str, ...] = ()
    tls_arguments: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class RdpCommand:
    """Immutable, shell-safe representation of a FreeRDP invocation."""

    arguments: tuple[str, ...]

    def as_list(self) -> list[str]:
        return list(self.arguments)

class RdpCommandValidationError(ValueError):
    """Raised when an effective FreeRDP argument vector is incoherent."""


class FreeRdpArgumentNormalizer:
    """Normalize and validate an effective FreeRDP argument vector.

    Rules are deliberately deterministic:
    * singleton options use the last effective value;
    * opposite boolean toggles use the last effective value;
    * exact duplicates are removed;
    * fullscreen takes precedence over explicit width/height;
    * repeatable redirections are sorted within their canonical section.
    """

    _SINGLETON_PREFIXES = (
        "/v:", "/u:", "/d:", "/client-hostname:", "/from-stdin:",
        "/network:", "/log-level:", "/sec:", "/cert:", "/w:", "/h:",
        "/bpp:", "/kbd:", "/kbd-lang:", "/cache:bitmap:",
        "/scale-desktop:", "/scale-device:",
    )
    _TOGGLE_NAMES = frozenset(
        {"fonts", "aero", "wallpaper", "menu-anims", "window-drag", "themes", "clipboard"}
    )
    _REPEATABLE_PREFIXES = ("/drive:", "/printer:")
    _CANONICAL_PREFIX_ORDER = (
        "/v:", "/u:", "/d:", "/client-hostname:", "/from-stdin:",
        "/network:", "/log-level:", "/sec:", "/cert:", "/f", "/w:",
        "/h:", "+dynamic-resolution", "/smart-sizing", "/bpp:",
        "+fonts", "-fonts", "+aero", "-aero", "+wallpaper", "-wallpaper",
        "+menu-anims", "-menu-anims", "+window-drag", "-window-drag",
        "+themes", "-themes", "/cache:bitmap:", "/scale-desktop:",
        "/scale-device:", "/multimon", "/kbd:",
        "/kbd-lang:", "+clipboard", "-clipboard", "/sound", "/microphone",
        "/gfx", "/video", "/smartcard", "/usb:", "/drive:", "/printer:",
    )

    def normalize(self, arguments: Sequence[str]) -> tuple[str, ...]:
        if not arguments:
            raise RdpCommandValidationError("The FreeRDP command is empty.")
        executable = arguments[0].strip()
        if not executable or executable.startswith(("/", "+", "-")) and ":" in executable:
            raise RdpCommandValidationError("The FreeRDP executable is invalid.")

        singletons: dict[str, str] = {}
        toggles: dict[str, str] = {}
        repeatable: dict[str, str] = {}
        flags: dict[str, str] = {}
        passthrough: dict[str, str] = {}

        for raw in arguments[1:]:
            argument = raw.strip()
            if not argument:
                continue
            if argument.startswith(("/p:", "/password:")):
                raise RdpCommandValidationError(
                    "Credentials must never be serialised in the FreeRDP command."
                )
            singleton = self._singleton_key(argument)
            if singleton is not None:
                singletons[singleton] = argument
                continue
            toggle = self._toggle_key(argument)
            if toggle is not None:
                toggles[toggle] = argument
                continue
            repeatable_prefix = self._matching_prefix(argument, self._REPEATABLE_PREFIXES)
            if repeatable_prefix is not None:
                repeatable[argument] = argument
                continue
            if argument in {"/f", "+dynamic-resolution", "/smart-sizing", "/multimon", "/sound", "/microphone", "/video", "/smartcard"} or argument.startswith(("/usb:", "/gfx:")) or argument == "/gfx":
                flags[argument] = argument
                continue
            passthrough[argument] = argument

        if "/f" in flags:
            singletons.pop("/w:", None)
            singletons.pop("/h:", None)
        elif ("/w:" in singletons) != ("/h:" in singletons):
            raise RdpCommandValidationError(
                "Explicit RDP dimensions require both width and height."
            )

        effective = list(singletons.values()) + list(toggles.values())
        effective += list(flags.values()) + sorted(repeatable.values())
        effective += sorted(passthrough.values())
        effective.sort(key=self._sort_key)
        normalized = (executable, *effective)
        self.validate(normalized)
        return normalized

    def validate(self, arguments: Sequence[str]) -> None:
        required = ("/v:", "/u:", "/from-stdin:")
        for prefix in required:
            matches = [item for item in arguments[1:] if item.startswith(prefix)]
            if len(matches) != 1 or not matches[0][len(prefix):].strip():
                raise RdpCommandValidationError(
                    f"The normalized FreeRDP command requires one valid {prefix} option."
                )
        if "/f" in arguments and any(
            item.startswith(("/w:", "/h:")) for item in arguments
        ):
            raise RdpCommandValidationError(
                "Fullscreen cannot coexist with explicit width or height."
            )
        for item in arguments[1:]:
            if item.startswith(("/drive:", "/printer:", "/usb:")) and not item.split(":", 1)[1].strip():
                raise RdpCommandValidationError(
                    f"The redirection argument {item!r} has an empty value."
                )

    @classmethod
    def _singleton_key(cls, argument: str) -> str | None:
        return cls._matching_prefix(argument, cls._SINGLETON_PREFIXES)

    @classmethod
    def _toggle_key(cls, argument: str) -> str | None:
        if len(argument) < 2 or argument[0] not in "+-":
            return None
        name = argument[1:]
        return name if name in cls._TOGGLE_NAMES else None

    @staticmethod
    def _matching_prefix(argument: str, prefixes: Sequence[str]) -> str | None:
        return next((prefix for prefix in prefixes if argument.startswith(prefix)), None)

    @classmethod
    def _sort_key(cls, argument: str) -> tuple[int, str]:
        for index, prefix in enumerate(cls._CANONICAL_PREFIX_ORDER):
            if argument == prefix or argument.startswith(prefix):
                return index, argument
        return len(cls._CANONICAL_PREFIX_ORDER), argument


class FreeRdpCommandBuilder:
    """Single authoritative builder for the effective FreeRDP command.

    The builder only returns an argument vector; it never invokes a shell and it
    never receives or serialises a password.
    """

    def __init__(
        self,
        *,
        usb_service: UsbService | None = None,
        drive_service: DriveRedirectionService | None = None,
        printer_service: PrinterRedirectionService | None = None,
        audio_service: AudioRedirectionService | None = None,
        video_service: VideoRedirectionService | None = None,
        clipboard_service: ClipboardRedirectionService | None = None,
        keyboard_service: KeyboardService | None = None,
        argument_normalizer: FreeRdpArgumentNormalizer | None = None,
        command_hardener=None,
    ) -> None:
        self.usb_service = usb_service or UsbService()
        self.drive_service = drive_service or DriveRedirectionService()
        self.printer_service = printer_service or PrinterRedirectionService()
        self.audio_service = audio_service or AudioRedirectionService()
        self.video_service = video_service or VideoRedirectionService()
        self.clipboard_service = clipboard_service or ClipboardRedirectionService()
        self.keyboard_service = keyboard_service or KeyboardService()
        self.argument_normalizer = argument_normalizer or FreeRdpArgumentNormalizer()
        if command_hardener is None:
            from xaac_thinclient.rdp.hardening import RdpCommandHardener
            command_hardener = RdpCommandHardener()
        self.command_hardener = command_hardener

    def build(self, request: RdpCommandRequest) -> RdpCommand:
        config = request.config
        command: list[str] = [
            request.executable,
            f"/v:{config.device.server}:{config.rdp.port}",
            f"/u:{request.username}",
            f"/d:{config.rdp.domain}",
            f"/client-hostname:{config.device.device_name}",
            "/from-stdin:force",
            f"/network:{config.rdp.network_profile.value}",
            "/log-level:INFO",
        ]

        if request.tls_arguments:
            command.extend(request.tls_arguments)
        else:
            security_argument = self._security_argument(config.rdp.security_mode.value)
            if security_argument is not None:
                command.append(security_argument)
            command.append(self._certificate_argument(config.rdp.certificate_mode.value))

        if config.rdp.fullscreen:
            command.append("/f")
        else:
            command.extend((f"/w:{config.rdp.width}", f"/h:{config.rdp.height}"))

        if config.rdp.dynamic_resolution:
            command.append("+dynamic-resolution")
        if config.rdp.smart_sizing:
            command.append("/smart-sizing")

        command.extend(
            (
                f"/bpp:{config.rdp.color_depth}",
                "+fonts" if config.rdp.font_smoothing else "-fonts",
                "+aero" if config.rdp.desktop_composition else "-aero",
                "+wallpaper" if config.rdp.wallpaper else "-wallpaper",
                "+menu-anims" if config.rdp.menu_animations else "-menu-anims",
                "+window-drag" if config.rdp.window_drag else "-window-drag",
                "+themes" if config.rdp.themes else "-themes",
                "/cache:bitmap:on" if config.rdp.bitmap_cache else "/cache:bitmap:off",
            )
        )

        command.extend(request.graphics_arguments)
        command.extend(request.display_arguments)

        multimon_argument = self._multimon_argument(
            config.rdp.multimon, request.monitor_count
        )
        if multimon_argument is not None:
            command.append(multimon_argument)

        keyboard_resolution = self.keyboard_service.resolve(
            config.keyboard.layout, config.application.language
        )
        self.keyboard_service.audit_resolution(keyboard_resolution)
        command.extend(self.keyboard_service.build_arguments(keyboard_resolution))

        clipboard_resolution = self.clipboard_service.resolve_policy(
            enabled=config.clipboard.enabled,
            profile=config.clipboard.profile,
            direction=config.clipboard.direction,
            files=config.clipboard.files,
        )
        self.clipboard_service.audit_resolution(clipboard_resolution)
        clipboard_arguments = tuple(
            self.clipboard_service.build_arguments(clipboard_resolution.policy)
        )
        command.extend(clipboard_arguments)

        audio_policy = (
            request.audio_status.policy
            if request.audio_status is not None
            else self.audio_service.get_policy(
                playback_enabled=config.audio.playback_enabled,
                recording_enabled=config.audio.recording_enabled,
                playback_required=config.audio.playback_required,
                recording_required=config.audio.recording_required,
            )
        )
        command.extend(self.audio_service.build_arguments(audio_policy))

        if request.video_status is None:
            video_policy = self.video_service.get_policy(
                enabled=config.video.enabled,
                required=config.video.required,
            )
        else:
            video_policy = request.video_status.policy
        command.extend(self.video_service.build_arguments(video_policy))

        if config.smartcard.redirection_enabled:
            command.append("/smartcard")

        usb_status = self.usb_service.get_status(
            enabled=config.usb.enabled,
            allowed_devices=config.usb.allowed_devices,
            blocked_devices=config.usb.blocked_devices,
        )
        if usb_status.redirected_identifiers:
            command.append("/usb:id:" + "#".join(usb_status.redirected_identifiers))

        drive_status = self.drive_service.get_status(
            enabled=config.drives.enabled,
            include_existing=config.drives.include_existing,
            allowed_roots=config.drives.allowed_roots,
        )
        command.extend(f"/drive:{share.name},{share.path}" for share in drive_status.shares)
        if config.drives.enabled and config.drives.hotplug:
            command.append("/drive:hotplug,*")

        printer_status = request.printer_status or self.printer_service.get_status(
            enabled=config.printers.enabled,
            allowed_printers=config.printers.allowed_printers,
            default_only=config.printers.default_only,
        )
        command.extend(f"/printer:{printer.name}" for printer in printer_status.redirected)
        if config.rdp.printers and not config.printers.enabled:
            command.append("/printer")

        normalized = RdpCommand(self.argument_normalizer.normalize(command))
        hardened, _report = self.command_hardener.harden(
            normalized, trusted_arguments=clipboard_arguments
        )
        return hardened

    @staticmethod
    def _security_argument(mode: str) -> str | None:
        if mode == "auto":
            return None
        return f"/sec:{mode}"

    @staticmethod
    def _certificate_argument(mode: str) -> str:
        return "/cert:deny" if mode == "strict" else f"/cert:{mode}"

    @staticmethod
    def _multimon_argument(
        mode: MultimonMode, monitor_count: int
    ) -> str | None:
        # Explicit ENABLED is a strict administrator/user decision.  FreeRDP 3
        # exposes the optional ``:force`` modifier precisely for topologies
        # that its conservative validation would otherwise collapse to one
        # monitor.  AUTO remains non-forced and depends on local detection.
        if mode is MultimonMode.ENABLED:
            return "/multimon:force"
        if mode is MultimonMode.DISABLED:
            return None
        return "/multimon" if monitor_count > 1 else None

    @classmethod
    def _should_use_multimon(cls, mode: MultimonMode, monitor_count: int) -> bool:
        """Compatibility predicate retained for existing callers/tests."""
        return cls._multimon_argument(mode, monitor_count) is not None


def build_rdp_command(
    server: str,
    domain: str,
    username: str,
    *,
    multimon: bool = True,
    fullscreen: bool = True,
) -> list[str]:
    """Compatibility helper retained for old callers and external tests.

    New production code must use :class:`FreeRdpCommandBuilder`.
    """
    command = [
        "xfreerdp3",
        f"/v:{server}",
        f"/d:{domain}",
        f"/u:{username}",
        "/sec:nla",
        "/cert:tofu",
        "+clipboard",
    ]
    if multimon:
        command.append("/multimon")
    if fullscreen:
        command.append("/f")
    return command

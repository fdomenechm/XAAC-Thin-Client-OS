from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from xaac_thinclient.config.models import PerformanceProfile
from xaac_thinclient.rdp.hardware import RdpHardwareInventory
from xaac_thinclient.rdp.network_quality import RdpNetworkQuality, RdpNetworkQualitySnapshot
from xaac_thinclient.services.freerdp_capabilities import FreeRdpCapability, FreeRdpCapabilityStatus


class RdpGraphicsMode(str, Enum):
    LEGACY = "legacy"
    GFX = "gfx"
    THIN_CLIENT = "thin-client"
    AVC420 = "avc420"
    AVC444 = "avc444"


@dataclass(frozen=True, slots=True)
class RdpGraphicsSelection:
    requested_profile: PerformanceProfile
    mode: RdpGraphicsMode
    arguments: tuple[str, ...]
    reasons: tuple[str, ...] = ()
    degraded: bool = False


class RdpGraphicsSelector:
    """Select a conservative FreeRDP graphics pipeline from immutable facts."""

    def select(
        self,
        *,
        profile: PerformanceProfile,
        hardware: RdpHardwareInventory,
        network: RdpNetworkQualitySnapshot | None,
        capabilities: FreeRdpCapabilityStatus,
    ) -> RdpGraphicsSelection:
        supports_method = getattr(capabilities, "supports", None)
        supports = supports_method if callable(supports_method) else (lambda capability: False)
        quality = network.quality if network is not None else RdpNetworkQuality.UNKNOWN
        weak_hardware = hardware.logical_cpus <= 2 or (0 < hardware.memory_mib < 3072)
        large_surface = hardware.monitor_count > 1 or hardware.total_pixels > 4_000_000

        if not supports(FreeRdpCapability.GFX):
            return RdpGraphicsSelection(profile, RdpGraphicsMode.LEGACY, (), ("gfx-unavailable",), True)

        if weak_hardware:
            return RdpGraphicsSelection(
                profile, RdpGraphicsMode.THIN_CLIENT, ("/gfx:thin-client",),
                ("limited-local-hardware",),
            )

        if profile is PerformanceProfile.QUALITY:
            if supports(FreeRdpCapability.GFX_AVC444) and not large_surface:
                return RdpGraphicsSelection(profile, RdpGraphicsMode.AVC444, ("/gfx:AVC444",), ("quality-profile",))
            if supports(FreeRdpCapability.GFX_AVC420):
                return RdpGraphicsSelection(profile, RdpGraphicsMode.AVC420, ("/gfx:AVC420",), ("quality-safe-fallback",), True)

        if profile in {PerformanceProfile.WAN, PerformanceProfile.LOW_BANDWIDTH} or quality in {RdpNetworkQuality.FAIR, RdpNetworkQuality.POOR}:
            if supports(FreeRdpCapability.GFX_AVC420):
                return RdpGraphicsSelection(profile, RdpGraphicsMode.AVC420, ("/gfx:AVC420",), ("bandwidth-optimised",))

        if profile is PerformanceProfile.LAN and supports(FreeRdpCapability.GFX_AVC444) and not large_surface:
            return RdpGraphicsSelection(profile, RdpGraphicsMode.AVC444, ("/gfx:AVC444",), ("lan-quality",))

        return RdpGraphicsSelection(profile, RdpGraphicsMode.GFX, ("/gfx",), ("compatible-default",))

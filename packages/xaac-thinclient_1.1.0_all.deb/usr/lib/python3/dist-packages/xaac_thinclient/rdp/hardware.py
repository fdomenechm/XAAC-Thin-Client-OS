from __future__ import annotations

import os
import platform
import re
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable


@dataclass(frozen=True, slots=True)
class RdpDisplayGeometry:
    width: int
    height: int


@dataclass(frozen=True, slots=True)
class RdpHardwareInventory:
    """Sanitised, immutable local hardware facts used by RDP planning."""

    architecture: str
    cpu_model: str
    logical_cpus: int
    memory_mib: int
    gpu_devices: tuple[str, ...]
    monitor_count: int
    maximum_display: RdpDisplayGeometry | None = None
    warnings: tuple[str, ...] = ()
    displays: tuple[RdpDisplayGeometry, ...] = ()

    @property
    def total_pixels(self) -> int:
        if self.maximum_display is None:
            return 0
        return self.maximum_display.width * self.maximum_display.height


class RdpHardwareDetector:
    """Best-effort Linux hardware detector with injectable I/O for tests.

    Missing optional tools or virtual files never block an RDP session. The
    returned inventory is always immutable and contains only non-sensitive
    hardware facts.
    """

    _CONNECTED = re.compile(r"^\S+\s+connected(?:\s+primary)?(?:\s+(\d+)x(\d+)\+[-\d]+\+[-\d]+)?")

    def __init__(
        self,
        read_text: Callable[[str], str] | None = None,
        list_paths: Callable[[str], Iterable[str]] | None = None,
        run_command: Callable[[tuple[str, ...]], str] | None = None,
    ) -> None:
        self._read_text = read_text or self._default_read_text
        self._list_paths = list_paths or self._default_list_paths
        self._run_command = run_command or self._default_run_command

    @staticmethod
    def _default_read_text(path: str) -> str:
        return Path(path).read_text(encoding="utf-8", errors="replace")

    @staticmethod
    def _default_list_paths(pattern: str) -> Iterable[str]:
        return (str(path) for path in Path("/").glob(pattern.lstrip("/")))

    @staticmethod
    def _default_run_command(command: tuple[str, ...]) -> str:
        completed = subprocess.run(
            command, check=False, capture_output=True, text=True, timeout=2.0,
        )
        return completed.stdout if completed.returncode == 0 else ""

    def detect(self, monitor_count_hint: int = 0) -> RdpHardwareInventory:
        warnings: list[str] = []
        cpu_model, logical_cpus = self._cpu(warnings)
        memory_mib = self._memory(warnings)
        gpu_devices = self._gpus(warnings)
        detected_monitors, maximum_display, displays = self._displays(warnings)
        monitor_count = detected_monitors or max(0, int(monitor_count_hint))
        return RdpHardwareInventory(
            architecture=platform.machine() or "unknown",
            cpu_model=cpu_model,
            logical_cpus=logical_cpus,
            memory_mib=memory_mib,
            gpu_devices=gpu_devices,
            monitor_count=monitor_count,
            maximum_display=maximum_display,
            warnings=tuple(sorted(set(warnings))),
            displays=displays,
        )

    def _cpu(self, warnings: list[str]) -> tuple[str, int]:
        logical = os.cpu_count() or 1
        try:
            text = self._read_text("/proc/cpuinfo")
        except OSError:
            warnings.append("cpuinfo-unavailable")
            return "unknown", logical
        models = []
        processors = 0
        for line in text.splitlines():
            key, _, value = line.partition(":")
            if key.strip() == "processor":
                processors += 1
            if key.strip() in {"model name", "Hardware", "Processor"} and value.strip():
                models.append(value.strip())
        return (models[0] if models else "unknown", processors or logical)

    def _memory(self, warnings: list[str]) -> int:
        try:
            text = self._read_text("/proc/meminfo")
        except OSError:
            warnings.append("meminfo-unavailable")
            return 0
        match = re.search(r"^MemTotal:\s+(\d+)\s+kB", text, re.MULTILINE)
        if not match:
            warnings.append("memtotal-unavailable")
            return 0
        return int(match.group(1)) // 1024

    def _gpus(self, warnings: list[str]) -> tuple[str, ...]:
        devices: set[str] = set()
        try:
            paths = tuple(self._list_paths("/sys/class/drm/card*/device/uevent"))
        except OSError:
            paths = ()
        for path in paths:
            try:
                text = self._read_text(path)
            except OSError:
                continue
            values = dict(
                line.split("=", 1) for line in text.splitlines() if "=" in line
            )
            driver = values.get("DRIVER", "unknown")
            pci_id = values.get("PCI_ID", "unknown")
            devices.add(f"{driver}:{pci_id}")
        if not devices:
            warnings.append("gpu-unavailable")
        return tuple(sorted(devices))

    def _displays(self, warnings: list[str]) -> tuple[int, RdpDisplayGeometry | None, tuple[RdpDisplayGeometry, ...]]:
        try:
            text = self._run_command(("xrandr", "--query"))
        except (OSError, subprocess.SubprocessError):
            text = ""
        geometries: list[RdpDisplayGeometry] = []
        count = 0
        for line in text.splitlines():
            match = self._CONNECTED.match(line)
            if not match:
                continue
            count += 1
            if match.group(1) and match.group(2):
                geometries.append(RdpDisplayGeometry(int(match.group(1)), int(match.group(2))))
        if not text:
            warnings.append("display-detection-unavailable")
        maximum = max(geometries, key=lambda item: item.width * item.height, default=None)
        return count, maximum, tuple(geometries)

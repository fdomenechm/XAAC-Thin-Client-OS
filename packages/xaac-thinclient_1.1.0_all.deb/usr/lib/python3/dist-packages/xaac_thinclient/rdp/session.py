from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from xaac_thinclient.config.models import ThinClientConfig
from xaac_thinclient.rdp.command_builder import RdpCommand
from xaac_thinclient.rdp.preflight import RdpPreflightReport
from xaac_thinclient.rdp.hardware import RdpHardwareInventory
from xaac_thinclient.rdp.network_quality import RdpNetworkQualitySnapshot
from xaac_thinclient.rdp.graphics import RdpGraphicsSelection
from xaac_thinclient.rdp.display import RdpDisplayPlan
from xaac_thinclient.rdp.reconnect import RdpReconnectPolicy
from xaac_thinclient.rdp.tls import RdpTlsPolicy
from xaac_thinclient.rdp.security import RdpSecurityPolicy
from xaac_thinclient.rdp.credentials import RdpCredentialPolicy
from xaac_thinclient.rdp.hardening import RdpCommandHardeningReport
from xaac_thinclient.rdp.audit import RdpSecurityAuditReport


@dataclass(frozen=True, slots=True)
class RdpSessionWarning:
    """Stable, immutable warning produced while preparing an RDP session."""

    code: str
    message: str


@dataclass(frozen=True, slots=True)
class RdpSessionDiagnostic:
    """Sanitised diagnostic fact safe for logs, support and remote telemetry."""

    key: str
    value: str


@dataclass(frozen=True, slots=True)
class RdpSessionPlan:
    """Complete immutable representation of one prepared RDP session.

    Passwords are deliberately absent.  The plan can therefore be inspected,
    audited and tested before a later execution phase consumes it.
    """

    command: RdpCommand
    effective_config: ThinClientConfig
    degraded_features: tuple[str, ...] = ()
    warnings: tuple[RdpSessionWarning, ...] = ()
    diagnostics: tuple[RdpSessionDiagnostic, ...] = ()
    preflight: RdpPreflightReport | None = None
    hardware: RdpHardwareInventory | None = None
    network_quality: RdpNetworkQualitySnapshot | None = None
    graphics: RdpGraphicsSelection | None = None
    display: RdpDisplayPlan | None = None
    reconnect: RdpReconnectPolicy = RdpReconnectPolicy()
    tls: RdpTlsPolicy | None = None
    security: RdpSecurityPolicy | None = None
    credentials: RdpCredentialPolicy = RdpCredentialPolicy()
    command_hardening: RdpCommandHardeningReport = RdpCommandHardeningReport()
    security_audit: RdpSecurityAuditReport = RdpSecurityAuditReport()

    def command_as_list(self) -> list[str]:
        return self.command.as_list()

    def diagnostic_value(self, key: str) -> str | None:
        return next((item.value for item in self.diagnostics if item.key == key), None)


class RdpSessionPlanError(ValueError):
    """Preparation failure with a stable code suitable for presentation."""

    def __init__(self, code: str | None, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


def canonical_strings(values: Iterable[str]) -> tuple[str, ...]:
    """Return unique non-empty strings in deterministic order."""
    return tuple(sorted({value.strip() for value in values if value.strip()}))

from __future__ import annotations


# FreeRDP pot retornar 12 quan la sessió ja establida es tanca de manera
# ordenada des de l'escriptori remot. Per a l'usuari és un final normal,
# encara que el procés no haja retornat zero.
NORMAL_SESSION_EXIT_CODES = frozenset({0, 12})


def is_normal_session_exit(return_code: int | None) -> bool:
    """Indica si el codi representa un tancament normal de la sessió."""
    return return_code in NORMAL_SESSION_EXIT_CODES

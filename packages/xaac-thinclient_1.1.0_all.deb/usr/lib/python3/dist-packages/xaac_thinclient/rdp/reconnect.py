from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class RdpReconnectPolicy:
    enabled: bool = True
    max_attempts: int = 3
    initial_delay_seconds: float = 1.0
    maximum_delay_seconds: float = 8.0

    def delay_for_retry(self, retry_number: int) -> float:
        if retry_number < 1:
            raise ValueError("retry_number must be at least 1")
        return min(
            self.maximum_delay_seconds,
            self.initial_delay_seconds * (2 ** (retry_number - 1)),
        )

    def allows_retry(self, retry_number: int) -> bool:
        return self.enabled and retry_number <= self.max_attempts


@dataclass(frozen=True, slots=True)
class RdpReconnectReport:
    attempts: int = 1
    retries: int = 0
    reconnected: bool = False
    cancelled: bool = False

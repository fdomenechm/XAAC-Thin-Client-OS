from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

from xaac_thinclient.rdp.command_builder import RdpCommand, RdpCommandValidationError


@dataclass(frozen=True, slots=True)
class RdpCommandHardeningPolicy:
    """Immutable command-line security contract for one RDP session."""

    shell_used: bool = False
    secret_argument_allowed: bool = False
    unknown_arguments_allowed: bool = False
    control_characters_allowed: bool = False
    executable_name: str = "xfreerdp3"


@dataclass(frozen=True, slots=True)
class RdpCommandHardeningReport:
    """Sanitised result of validating the final FreeRDP argument vector."""

    policy: RdpCommandHardeningPolicy = RdpCommandHardeningPolicy()
    argument_count: int = 0
    validated: bool = True


class RdpCommandHardeningError(RdpCommandValidationError):
    """Raised when the final command violates the hardening policy."""

    code = "RDP-CMD-001"


class RdpCommandHardener:
    """Validate the final shell-free command against a strict allowlist."""

    _EXACT = frozenset({
        "/f", "+dynamic-resolution", "/smart-sizing", "/multimon",
        "/multimon:force", "+fonts", "-fonts", "+aero", "-aero",
        "+wallpaper", "-wallpaper", "+menu-anims", "-menu-anims",
        "+window-drag", "-window-drag", "+themes", "-themes",
        "+clipboard", "-clipboard", "/sound", "/microphone", "/video",
        "/smartcard", "/printer", "/gfx",
    })
    _PREFIXES = (
        "/v:", "/u:", "/d:", "/client-hostname:", "/from-stdin:",
        "/network:", "/log-level:", "/sec:", "/cert:", "/w:", "/h:",
        "/bpp:", "/kbd:", "/kbd-lang:", "/cache:bitmap:",
        "/scale-desktop:", "/scale-device:", "/gfx:", "/usb:",
        "/drive:", "/printer:", "/dvc:", "/clipboard:",
    )
    _FORBIDDEN_PREFIXES = (
        "/p:", "/password:", "/args-from:", "/gateway-password:",
        "/proxy-password:",
    )

    def __init__(self, policy: RdpCommandHardeningPolicy | None = None) -> None:
        self.policy = policy or RdpCommandHardeningPolicy()

    def harden(
        self,
        command: RdpCommand | Sequence[str],
        *,
        trusted_arguments: Sequence[str] = (),
    ) -> tuple[RdpCommand, RdpCommandHardeningReport]:
        arguments = command.arguments if isinstance(command, RdpCommand) else tuple(command)
        trusted = frozenset(trusted_arguments)
        if not arguments:
            raise RdpCommandHardeningError("The FreeRDP command is empty.")

        executable = arguments[0]
        if Path(executable).name != self.policy.executable_name:
            raise RdpCommandHardeningError("The final command does not target the approved FreeRDP executable.")
        self._reject_controls(executable)

        for argument in arguments[1:]:
            self._reject_controls(argument)
            lowered = argument.lower()
            if lowered.startswith(self._FORBIDDEN_PREFIXES):
                raise RdpCommandHardeningError("A credential-bearing FreeRDP argument was rejected.")
            if argument.startswith("--"):
                raise RdpCommandHardeningError("GNU-style or wrapper arguments are not allowed in the FreeRDP command.")
            if (
                argument not in trusted
                and argument not in self._EXACT
                and not argument.startswith(self._PREFIXES)
            ):
                raise RdpCommandHardeningError(f"Unapproved FreeRDP argument: {argument!r}.")

        if sum(item.startswith("/from-stdin:") for item in arguments[1:]) != 1 or "/from-stdin:force" not in arguments:
            raise RdpCommandHardeningError("The hardened command requires /from-stdin:force exactly once.")

        result = RdpCommand(tuple(arguments))
        return result, RdpCommandHardeningReport(
            policy=self.policy,
            argument_count=len(arguments),
            validated=True,
        )

    def _reject_controls(self, value: str) -> None:
        if any(ord(character) < 32 or ord(character) == 127 for character in value):
            raise RdpCommandHardeningError("Control characters are not allowed in the FreeRDP command.")

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Mapping

_SENSITIVE_TOKENS = (
    "password", "passwd", "secret", "credential", "username", "user",
    "server", "hostname", "address", "token", "pin",
)


@dataclass(frozen=True, slots=True)
class RdpSecurityAuditEvent:
    """One immutable, sanitised security event for an RDP session."""

    code: str
    phase: str
    outcome: str
    fields: tuple[tuple[str, str], ...] = ()

    def __post_init__(self) -> None:
        code = self.code.strip()
        phase = self.phase.strip()
        outcome = self.outcome.strip()
        if not code or not phase or not outcome:
            raise ValueError("Audit event code, phase and outcome are required.")
        for key, value in self.fields:
            lowered = key.lower()
            if any(token in lowered for token in _SENSITIVE_TOKENS):
                raise ValueError(f"Sensitive audit field is not allowed: {key}")
            if any(char in str(value) for char in ("\n", "\r", "\x00")):
                raise ValueError(f"Control characters are not allowed in audit field: {key}")

    @classmethod
    def create(
        cls,
        code: str,
        phase: str,
        outcome: str,
        fields: Mapping[str, object] | Iterable[tuple[str, object]] = (),
    ) -> "RdpSecurityAuditEvent":
        items = fields.items() if isinstance(fields, Mapping) else fields
        canonical = tuple(sorted((str(key), str(value)) for key, value in items))
        return cls(code=code, phase=phase, outcome=outcome, fields=canonical)

    def field_value(self, key: str) -> str | None:
        return next((value for item_key, value in self.fields if item_key == key), None)


@dataclass(frozen=True, slots=True)
class RdpSecurityAuditReport:
    """Immutable collection of security events safe for logs and telemetry."""

    events: tuple[RdpSecurityAuditEvent, ...] = ()

    def append(self, event: RdpSecurityAuditEvent) -> "RdpSecurityAuditReport":
        return RdpSecurityAuditReport(self.events + (event,))

    def event_codes(self) -> tuple[str, ...]:
        return tuple(event.code for event in self.events)

    def find(self, code: str) -> RdpSecurityAuditEvent | None:
        return next((event for event in self.events if event.code == code), None)

from __future__ import annotations

from dataclasses import dataclass

from xaac_thinclient.config.models import CertificateMode, SecurityMode, ThinClientConfig


@dataclass(frozen=True, slots=True)
class RdpTlsPolicy:
    certificate_mode: CertificateMode
    certificate_name: str
    security_mode: SecurityMode
    arguments: tuple[str, ...]
    warnings: tuple[str, ...] = ()

    @property
    def strict_validation(self) -> bool:
        return self.certificate_mode is CertificateMode.STRICT


class RdpTlsPolicyError(ValueError):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


class RdpTlsPolicyResolver:
    """Resolve certificate validation into one canonical FreeRDP policy."""

    def resolve(self, config: ThinClientConfig) -> RdpTlsPolicy:
        name = config.rdp.certificate_name.strip()
        if any(ch in name for ch in (",", "\n", "\r", "\x00")):
            raise RdpTlsPolicyError(
                "RDP-TLS-001",
                "The configured certificate name contains invalid characters.",
            )

        mode = config.rdp.certificate_mode
        # FreeRDP calls strict refusal of unknown/invalid certificates `deny`.
        token = {
            CertificateMode.STRICT: "deny",
            CertificateMode.TOFU: "tofu",
            CertificateMode.IGNORE: "ignore",
        }[mode]
        options = [token]
        if name:
            options.append(f"name:{name}")

        warnings: list[str] = []
        if mode is CertificateMode.IGNORE:
            warnings.append("certificate-validation-disabled")
        if config.rdp.security_mode is SecurityMode.TLS and mode is CertificateMode.IGNORE:
            warnings.append("tls-without-certificate-validation")

        security = f"/sec:{config.rdp.security_mode.value}"
        certificate = "/cert:" + ",".join(options)
        return RdpTlsPolicy(
            certificate_mode=mode,
            certificate_name=name,
            security_mode=config.rdp.security_mode,
            arguments=(security, certificate),
            warnings=tuple(warnings),
        )

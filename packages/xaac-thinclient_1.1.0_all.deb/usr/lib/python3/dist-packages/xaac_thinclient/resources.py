from __future__ import annotations

from pathlib import Path

from xaac_thinclient.paths import (
    ASSETS_DIR,
    DEFAULT_APPLICATION_LOGO_PATH,
    ORGANIZATION_LOGO_PATH,
    STYLE_PATH,
    XAAC_ABOUT_LOGO_PATH,
    get_config_dir,
)


DEFAULT_APPLICATION_LOGO = DEFAULT_APPLICATION_LOGO_PATH
ORGANIZATION_LOGO = ORGANIZATION_LOGO_PATH
XAAC_ABOUT_LOGO = XAAC_ABOUT_LOGO_PATH

# Àlies conservat per compatibilitat: representa el logo de l'organització.
LOGO = ORGANIZATION_LOGO
STYLE = STYLE_PATH


def resolve_application_logo(configured_logo: str) -> Path:
    """Resol el logotip principal configurat amb fallback segur al de XAAC.

    - Una ruta absoluta s'utilitza directament si existeix.
    - Una ruta relativa es busca primer al directori de configuració i després
      entre els recursos empaquetats.
    - Si el fitxer no existeix, s'utilitza ``xaac-thinclient-logo.png``.
    """

    value = configured_logo.strip()
    if not value:
        return DEFAULT_APPLICATION_LOGO

    candidate = Path(value).expanduser()
    if candidate.is_absolute():
        return candidate if candidate.is_file() else DEFAULT_APPLICATION_LOGO

    config_candidate = get_config_dir() / candidate
    if config_candidate.is_file():
        return config_candidate

    packaged_candidate = ASSETS_DIR / candidate
    if packaged_candidate.is_file():
        return packaged_candidate

    return DEFAULT_APPLICATION_LOGO

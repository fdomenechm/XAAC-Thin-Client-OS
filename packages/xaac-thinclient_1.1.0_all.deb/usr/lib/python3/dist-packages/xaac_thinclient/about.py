from __future__ import annotations

ABOUT_AUTHORS: tuple[str, ...] = ("Francesc Domènech",)
ABOUT_COPYRIGHT = "2026 Autor: Francesc Domènech"
ABOUT_DESCRIPTION = "Lightweight and secure thin client for remote desktop access."
ABOUT_LICENSE = """
XAAC Thin Client Remote és programari lliure distribuït sota la
**European Union Public Licence v1.2 (EUPL)**.

https://eupl.eu/1.2/en/

"""
ABOUT_WEBSITE = "https://source.canals.es/goal/xaactc"

"""Utilitats internes d'integració amb el paquet Debian."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Sequence

from xaac_thinclient.config.migrations import (
    MigrationResult,
    MigrationStatus,
    migrate_file,
)

DEFAULT_CONFIGURATION_FILES = ("config.ini", "device.ini", "user.ini")


def _result_payload(path: Path, result: MigrationResult) -> dict[str, object]:
    return {
        "path": str(path),
        "status": result.status.value,
        "source_version": result.source_version,
        "target_version": result.target_version,
        "changed": result.changed,
        "backup_path": str(result.backup_path) if result.backup_path else None,
        "diagnostic": result.diagnostic,
        "audit_event": result.audit.event,
    }


def migrate_directory(directory: Path) -> tuple[list[dict[str, object]], bool]:
    """Migra només els fitxers de configuració de sistema coneguts.

    Els fitxers absents no són un error: dpkg pot estar processant una
    instal·lació parcial o una configuració eliminada expressament.
    """
    results: list[dict[str, object]] = []
    failed = False
    for filename in DEFAULT_CONFIGURATION_FILES:
        path = directory / filename
        if not path.exists():
            results.append(
                {
                    "path": str(path),
                    "status": "absent",
                    "source_version": None,
                    "target_version": None,
                    "changed": False,
                    "backup_path": None,
                    "diagnostic": "configuration-absent",
                    "audit_event": "configuration-migration-absent",
                }
            )
            continue
        result = migrate_file(path)
        results.append(_result_payload(path, result))
        failed = failed or result.status in {
            MigrationStatus.INVALID,
            MigrationStatus.UNSUPPORTED,
        }
    return results, failed


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="xaac-thinclient-migrate",
        description="Migra de forma segura les configuracions de XAAC Thin Client Remote.",
    )
    parser.add_argument(
        "--system-config-dir",
        type=Path,
        default=Path("/etc/xaac-remote"),
        help="directori que conté config.ini, device.ini i user.ini",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="emet un registre JSON per línia",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    results, failed = migrate_directory(args.system_config_dir)
    for payload in results:
        if args.json:
            print(json.dumps(payload, ensure_ascii=False, sort_keys=True))
        else:
            print(
                "{path}: {status} ({diagnostic})".format_map(payload),
                file=sys.stderr if payload["status"] in {"invalid", "unsupported"} else sys.stdout,
            )
    return 2 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())

from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]

# Els recursos visuals formen part del paquet Python. Això evita dependre del
# directori de treball o de l'arbre font després d'instal·lar el paquet Debian.
PACKAGE_DIR = Path(__file__).resolve().parent
ASSETS_DIR = PACKAGE_DIR / "resources"
IMAGES_DIR = ASSETS_DIR
ICONS_DIR = ASSETS_DIR
CSS_DIR = ASSETS_DIR

DEFAULT_APPLICATION_LOGO_NAME = "xaac-thinclient-logo.png"
DEFAULT_APPLICATION_LOGO_PATH = ASSETS_DIR / DEFAULT_APPLICATION_LOGO_NAME
ORGANIZATION_LOGO_PATH = ASSETS_DIR / "organization-logo.png"
XAAC_ABOUT_LOGO_PATH = ASSETS_DIR / "xaac-thinclient-logo.png"
# Compatibilitat amb integracions anteriors: LOGO_PATH continua sent el logo corporatiu.
LOGO_PATH = ORGANIZATION_LOGO_PATH
STYLE_PATH = ASSETS_DIR / "style.css"

DEVELOPMENT_CONFIG_DIR = PROJECT_ROOT / "config"
SYSTEM_CONFIG_DIR = Path("/etc/xaac-remote")


def get_config_dir() -> Path:
    if SYSTEM_CONFIG_DIR.is_dir():
        return SYSTEM_CONFIG_DIR

    return DEVELOPMENT_CONFIG_DIR


CONFIG_FILE = get_config_dir() / "config.ini"
DEVICE_FILE = get_config_dir() / "device.ini"
SERVERS_FILE = get_config_dir() / "servers.ini"
USER_FILE = get_config_dir() / "user.ini"

# Preferències de l'usuari local
USER_CONFIG_DIR = Path.home() / ".config" / "xaac-thinclient"
USER_CONFIG_FILE = USER_CONFIG_DIR / "user.ini"

# Registres de l'aplicació
USER_STATE_DIR = (
    Path.home()
    / ".local"
    / "state"
    / "xaac-thinclient"
)

LOG_DIR = USER_STATE_DIR
LOG_FILE = LOG_DIR / "xaac-thinclient.log"

# Última configuració remota validada
REMOTE_CONFIG_CACHE_FILE = USER_STATE_DIR / "remote-config.json"

# Identitat persistent del dispositiu per a polítiques remotes
REMOTE_DEVICE_IDENTITY_FILE = USER_STATE_DIR / "device-identity.json"

# Cua local de telemetria pendent, sense credencials ni dades d'usuari
REMOTE_TELEMETRY_QUEUE_FILE = USER_STATE_DIR / "remote-telemetry-queue.json"

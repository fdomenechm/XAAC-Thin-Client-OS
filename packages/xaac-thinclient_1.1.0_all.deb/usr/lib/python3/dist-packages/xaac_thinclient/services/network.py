from __future__ import annotations

import json
import subprocess
from dataclasses import dataclass

from xaac_thinclient.services.logging import get_logger
from xaac_thinclient.i18n import _


logger = get_logger(__name__)


@dataclass(frozen=True, slots=True)
class NetworkStatus:
    connected: bool
    interface: str | None = None
    ip_address: str | None = None
    error: str | None = None


class NetworkService:
    """
    Detecta si hi ha una interfície de xarxa activa amb una
    adreça IPv4 utilitzable.

    No comprova Internet: una xarxa interna també es considera
    vàlida per al thin client.
    """

    def get_status(self) -> NetworkStatus:
        try:
            result = subprocess.run(
                [
                    "ip",
                    "-j",
                    "-4",
                    "address",
                    "show",
                    "up",
                ],
                check=True,
                capture_output=True,
                text=True,
                timeout=3,
            )
        except FileNotFoundError:
            error_message = _("The ip command was not found.")
            logger.error(error_message)

            return NetworkStatus(
                connected=False,
                error=error_message,
            )

        except subprocess.TimeoutExpired:
            error_message = (
                _("The network check timed out.")
            )
            logger.warning(error_message)

            return NetworkStatus(
                connected=False,
                error=error_message,
            )

        except subprocess.CalledProcessError as error:
            error_message = (
                    error.stderr.strip()
                    or _("An error occurred while checking the network.")
            )

            logger.warning(
                "L'ordre ip ha fallat: %s",
                error_message,
            )

            return NetworkStatus(
                connected=False,
                error=error_message,
            )

        try:
            interfaces = json.loads(result.stdout)
        except json.JSONDecodeError:
            error_message = (
                _("The response from the ip command is invalid.")
            )
            logger.error(error_message)

            return NetworkStatus(
                connected=False,
                error=error_message,
            )

        for interface_data in interfaces:
            interface_name = interface_data.get("ifname")

            if not interface_name:
                continue

            if interface_name == "lo":
                continue

            if interface_data.get("operstate") != "UP":
                continue

            for address in interface_data.get("addr_info", []):
                if address.get("family") != "inet":
                    continue

                ip_address = address.get("local")

                if not ip_address:
                    continue

                if ip_address.startswith("127."):
                    continue

                logger.debug(
                    "Interfície activa detectada: "
                    "interfície=%s, ip=%s",
                    interface_name,
                    ip_address,
                )

                return NetworkStatus(
                    connected=True,
                    interface=interface_name,
                    ip_address=ip_address,
                )

        error_message = (
            _("No active IPv4 interface is available.")
        )

        logger.warning(error_message)

        return NetworkStatus(
            connected=False,
            error=error_message,
        )
from __future__ import annotations

import json
import ssl
from dataclasses import dataclass, replace
from enum import Enum
from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import Any, Callable
from types import MappingProxyType
from urllib.parse import quote
from urllib.request import Request, urlopen

from xaac_thinclient.config.models import (
    CertificateMode,
    ClipboardDirection,
    ClipboardProfile,
    MultimonMode,
    NetworkProfile,
    PerformanceProfile,
    SecurityMode,
    ThinClientConfig,
)
from xaac_thinclient.config.validator import validate_config
from xaac_thinclient.config.policy import (
    ConfigurationMetadata,
    CONFIG_POLICY,
    is_allowed,
)
from xaac_thinclient.services.logging import get_logger
from xaac_thinclient.services.remote_policy_signature import (
    RemotePolicySignatureError,
    RemotePolicySignatureVerification,
    RemotePolicySignatureVerifier,
)
from xaac_thinclient.services.remote_policy_validity import (
    RemotePolicyValidity,
    RemotePolicyValidityError,
    RemotePolicyValidityValidator,
)
from xaac_thinclient.services.remote_policy_rollback import (
    RemotePolicyRollbackReport,
    RemotePolicyRollbackStore,
)
from xaac_thinclient.services.remote_device_identity import (
    RemoteDeviceIdentity,
    RemoteDeviceIdentityError,
    RemoteDeviceIdentityMatch,
    RemoteDeviceIdentityStore,
    RemoteDeviceIdentityValidator,
)
from xaac_thinclient.services.remote_policy_schema import (
    RemotePolicyDocument,
    RemotePolicySchemaError,
    RemotePolicySchemaValidator,
)

logger = get_logger(__name__)

from xaac_thinclient.config.scope import (
    ConfigurationScope,
    ConfigurationValueSource,
)


class RemoteConfigurationError(RuntimeError):
    """No s'ha pogut obtindre o validar la configuració remota."""


class RemoteConfigurationSource(Enum):
    LOCAL = "local"
    REMOTE = "remote"
    CACHE = "cache"
    ROLLBACK = "rollback"


@dataclass(frozen=True, slots=True)
class RemoteConfigurationSettings:
    enabled: bool = False
    url: str = ""
    timeout: float = 5.0
    cache_file: Path | None = None
    allow_http: bool = False
    require_signature: bool = False
    trusted_key_file: Path | None = None
    trusted_key_id: str = "default"
    require_expiration: bool = False
    clock_skew_seconds: int = 60
    rollback_enabled: bool = False
    rollback_directory: Path | None = None
    rollback_max_entries: int = 5
    prevent_policy_downgrade: bool = True
    device_identity_enabled: bool = False
    device_identity_file: Path | None = None
    require_device_target: bool = False


@dataclass(frozen=True, slots=True)
class RemoteConfigurationResult:
    config: ThinClientConfig
    source: RemoteConfigurationSource
    warning: str | None = None
    applied_keys: tuple[str, ...] = ()
    rejected_keys: tuple[str, ...] = ()
    schema_version: int | None = None
    legacy_schema: bool = False
    signature_present: bool = False
    signature_verified: bool = False
    signature_key_id: str | None = None
    validity_present: bool = False
    validity_verified: bool = False
    expires_at: str | None = None
    policy_revision: int | None = None
    rollback_used: bool = False
    rollback_candidates_checked: int = 0
    device_identity_enabled: bool = False
    policy_target_present: bool = False
    policy_target_matched: bool = False

    def metadata(self) -> ConfigurationMetadata:
        value_source = {
            RemoteConfigurationSource.LOCAL: ConfigurationValueSource.SYSTEM,
            RemoteConfigurationSource.REMOTE: ConfigurationValueSource.REMOTE,
            RemoteConfigurationSource.CACHE: ConfigurationValueSource.CACHE,
            RemoteConfigurationSource.ROLLBACK: ConfigurationValueSource.CACHE,
        }[self.source]
        origins = {
            path: ConfigurationValueSource.SYSTEM
            for path in CONFIG_POLICY
            if not path.startswith("user.")
        }
        for path in self.applied_keys:
            origins[path] = value_source
        return ConfigurationMetadata(
            remote_source=value_source,
            origins=MappingProxyType(origins),
            applied_remote_keys=self.applied_keys,
            rejected_remote_keys=self.rejected_keys,
            warning=self.warning,
        )


UrlOpen = Callable[..., Any]


class RemoteConfigurationService:
    """Obté una superposició JSON des d'un servidor central.

    La configuració local sempre és la base. El document remot només pot
    modificar camps explícitament admesos i mai preferències personals ni
    credencials. Si la consulta falla, es prova l'última còpia validada en
    memòria cau i, finalment, es conserva la configuració local.
    """

    def __init__(self, opener: UrlOpen = urlopen) -> None:
        self._opener = opener

    def resolve(
        self,
        base_config: ThinClientConfig,
        settings: RemoteConfigurationSettings,
    ) -> RemoteConfigurationResult:
        if not settings.enabled:
            return RemoteConfigurationResult(
                config=base_config,
                source=RemoteConfigurationSource.LOCAL,
            )

        identity = self._device_identity(base_config, settings)
        rollback_store = self._rollback_store(settings)
        rollback_validator = self._rollback_validator(settings, identity)
        highest_revision = (
            rollback_store.highest_revision(rollback_validator)
            if rollback_store is not None
            else None
        )

        try:
            payload = self._download(base_config, settings, identity)
            document, signature, validity, identity_match = self._validate_document(payload, settings, identity)
            self._ensure_not_downgrade(document, highest_revision, settings)
            logger.info(
                "remote_policy_schema_resolved source=remote version=%s legacy=%s revision=%s",
                document.schema_version, document.legacy, document.policy_revision,
            )
            config, applied, rejected = self.apply_overlay_with_metadata(
                base_config, document.policy_dict()
            )
            if settings.cache_file is not None:
                self._write_cache(settings.cache_file, payload)
            if rollback_store is not None:
                rollback_store.save(payload, revision=document.policy_revision)
            self._audit_clipboard_source(RemoteConfigurationSource.REMOTE, applied)
            self._audit_keyboard_source(RemoteConfigurationSource.REMOTE, applied)
            self._audit_smartcard_source(RemoteConfigurationSource.REMOTE, applied)
            return self._result(
                config, RemoteConfigurationSource.REMOTE, document, signature, validity, identity_match,
                applied=applied, rejected=rejected,
            )
        except Exception as remote_error:
            if settings.cache_file is not None:
                try:
                    payload = self._read_cache(settings.cache_file)
                    document, signature, validity, identity_match = self._validate_document(payload, settings, identity)
                    logger.info(
                        "remote_policy_schema_resolved source=cache version=%s legacy=%s revision=%s",
                        document.schema_version, document.legacy, document.policy_revision,
                    )
                    config, applied, rejected = self.apply_overlay_with_metadata(
                        base_config, document.policy_dict()
                    )
                    self._audit_clipboard_source(RemoteConfigurationSource.CACHE, applied)
                    self._audit_keyboard_source(RemoteConfigurationSource.CACHE, applied)
                    self._audit_smartcard_source(RemoteConfigurationSource.CACHE, applied)
                    return self._result(
                        config, RemoteConfigurationSource.CACHE, document, signature, validity, identity_match,
                        warning=str(remote_error), applied=applied, rejected=rejected,
                    )
                except Exception:
                    pass

            if rollback_store is not None:
                candidate, checked = rollback_store.select(rollback_validator)
                if candidate is not None:
                    try:
                        document, signature, validity, identity_match = self._validate_document(
                            candidate.payload, settings, identity
                        )
                        config, applied, rejected = self.apply_overlay_with_metadata(
                            base_config, document.policy_dict()
                        )
                        logger.warning(
                            "remote_policy_rollback_applied revision=%s candidates_checked=%s",
                            document.policy_revision, checked,
                        )
                        self._audit_clipboard_source(RemoteConfigurationSource.ROLLBACK, applied)
                        self._audit_keyboard_source(RemoteConfigurationSource.ROLLBACK, applied)
                        self._audit_smartcard_source(RemoteConfigurationSource.ROLLBACK, applied)
                        return self._result(
                            config, RemoteConfigurationSource.ROLLBACK, document, signature, validity, identity_match,
                            warning=str(remote_error), applied=applied, rejected=rejected,
                            rollback_used=True, rollback_candidates_checked=checked,
                        )
                    except Exception:
                        pass

            return RemoteConfigurationResult(
                config=base_config,
                source=RemoteConfigurationSource.LOCAL,
                warning=str(remote_error),
                rollback_candidates_checked=(
                    len(rollback_store.candidates()) if rollback_store is not None else 0
                ),
                device_identity_enabled=identity is not None,
            )

    @staticmethod
    def _result(
        config: ThinClientConfig,
        source: RemoteConfigurationSource,
        document: RemotePolicyDocument,
        signature: RemotePolicySignatureVerification,
        validity: RemotePolicyValidity,
        identity_match: RemoteDeviceIdentityMatch,
        *,
        warning: str | None = None,
        applied: tuple[str, ...] = (),
        rejected: tuple[str, ...] = (),
        rollback_used: bool = False,
        rollback_candidates_checked: int = 0,
    ) -> RemoteConfigurationResult:
        return RemoteConfigurationResult(
            config=config, source=source, warning=warning,
            applied_keys=applied, rejected_keys=rejected,
            schema_version=document.schema_version, legacy_schema=document.legacy,
            signature_present=signature.present, signature_verified=signature.verified,
            signature_key_id=signature.key_id, validity_present=validity.present,
            validity_verified=validity.valid, expires_at=document.expires_at,
            policy_revision=document.policy_revision, rollback_used=rollback_used,
            rollback_candidates_checked=rollback_candidates_checked,
            device_identity_enabled=identity_match.identity_available,
            policy_target_present=identity_match.target_present,
            policy_target_matched=identity_match.matched,
        )

    @staticmethod
    def _audit_clipboard_source(
        source: RemoteConfigurationSource,
        applied_keys: tuple[str, ...],
    ) -> None:
        clipboard_keys = tuple(
            key for key in applied_keys if key.startswith("clipboard.")
        )
        if clipboard_keys:
            logger.info(
                "clipboard_policy_managed source=%s keys=%s",
                source.value,
                ",".join(clipboard_keys),
            )

    @staticmethod
    def _audit_keyboard_source(
        source: RemoteConfigurationSource,
        applied_keys: tuple[str, ...],
    ) -> None:
        keyboard_keys = tuple(
            key for key in applied_keys if key.startswith("keyboard.")
        )
        if keyboard_keys:
            logger.info(
                "keyboard_policy_managed source=%s keys=%s",
                source.value,
                ",".join(keyboard_keys),
            )

    @staticmethod
    def _audit_smartcard_source(
        source: RemoteConfigurationSource,
        applied_keys: tuple[str, ...],
    ) -> None:
        smartcard_keys = tuple(
            key for key in applied_keys if key.startswith("smartcard.")
        )
        if smartcard_keys:
            logger.info(
                "smartcard_policy_managed source=%s keys=%s",
                source.value,
                ",".join(smartcard_keys),
            )

    def _download(
        self,
        base_config: ThinClientConfig,
        settings: RemoteConfigurationSettings,
        identity: RemoteDeviceIdentity | None,
    ) -> dict[str, Any]:
        url = settings.url.strip().format(
            device_name=quote(base_config.device.device_name, safe=""),
            device_id=quote(identity.device_id if identity is not None else "", safe=""),
        )

        if not url:
            raise RemoteConfigurationError(
                "La URL de configuració remota està buida."
            )

        if not settings.allow_http and not url.lower().startswith("https://"):
            raise RemoteConfigurationError(
                "La configuració remota exigeix HTTPS."
            )

        request = Request(
            url,
            headers={
                "Accept": "application/json",
                "User-Agent": "XAAC-ThinClient/0.1",
                **({"X-XAAC-Device-ID": identity.device_id} if identity is not None else {}),
            },
        )

        context = ssl.create_default_context()
        with self._opener(
            request,
            timeout=settings.timeout,
            context=context,
        ) as response:
            raw = response.read()

        try:
            payload = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise RemoteConfigurationError(
                "La resposta remota no és un JSON vàlid."
            ) from error

        if not isinstance(payload, dict):
            raise RemoteConfigurationError(
                "La configuració remota ha de ser un objecte JSON."
            )

        return payload


    @staticmethod
    def _verify_signature(
        document: RemotePolicyDocument,
        settings: RemoteConfigurationSettings,
    ) -> RemotePolicySignatureVerification:
        try:
            verifier = RemotePolicySignatureVerifier.from_pem_file(
                settings.trusted_key_file, key_id=settings.trusted_key_id
            )
            result = verifier.verify(
                schema_version=document.schema_version,
                policy=document.policy,
                signature=document.signature,
                required=settings.require_signature,
                issued_at=document.issued_at,
                expires_at=document.expires_at,
                policy_revision=document.policy_revision,
                target=(
                    {key: value for key, value in (("device_id", document.target.device_id), ("device_name", document.target.device_name)) if value is not None}
                    if document.target is not None else None
                ),
            )
        except RemotePolicySignatureError as error:
            raise RemoteConfigurationError(str(error)) from error
        logger.info(
            "remote_policy_signature_checked required=%s present=%s verified=%s key_id=%s",
            result.required, result.present, result.verified, result.key_id or "none",
        )
        return result

    @staticmethod
    def _validate_validity(
        document: RemotePolicyDocument,
        settings: RemoteConfigurationSettings,
    ) -> RemotePolicyValidity:
        try:
            result = RemotePolicyValidityValidator().validate(
                issued_at=document.issued_at,
                expires_at=document.expires_at,
                required=settings.require_expiration,
                clock_skew_seconds=settings.clock_skew_seconds,
            )
        except RemotePolicyValidityError as error:
            raise RemoteConfigurationError(str(error)) from error
        logger.info(
            "remote_policy_validity_checked required=%s present=%s valid=%s expires_at=%s",
            result.required, result.present, result.valid, document.expires_at or "none",
        )
        return result

    def _validate_document(
        self, payload: dict[str, Any], settings: RemoteConfigurationSettings,
        identity: RemoteDeviceIdentity | None,
    ) -> tuple[RemotePolicyDocument, RemotePolicySignatureVerification, RemotePolicyValidity, RemoteDeviceIdentityMatch]:
        document = self.parse_policy_document(payload)
        signature = self._verify_signature(document, settings)
        validity = self._validate_validity(document, settings)
        try:
            identity_match = RemoteDeviceIdentityValidator.validate(
                identity, document.target, required=settings.require_device_target
            )
        except RemoteDeviceIdentityError as error:
            raise RemoteConfigurationError(str(error)) from error
        return document, signature, validity, identity_match

    @staticmethod
    def _device_identity(
        base_config: ThinClientConfig, settings: RemoteConfigurationSettings
    ) -> RemoteDeviceIdentity | None:
        if not settings.device_identity_enabled:
            return None
        if settings.device_identity_file is None:
            raise RemoteConfigurationError("No s'ha configurat el fitxer d'identitat del dispositiu.")
        try:
            return RemoteDeviceIdentityStore(settings.device_identity_file).load_or_create(
                base_config.device.device_name
            )
        except RemoteDeviceIdentityError as error:
            raise RemoteConfigurationError(str(error)) from error

    @staticmethod
    def _rollback_store(settings: RemoteConfigurationSettings) -> RemotePolicyRollbackStore | None:
        if not settings.rollback_enabled:
            return None
        directory = settings.rollback_directory
        if directory is None and settings.cache_file is not None:
            directory = settings.cache_file.parent / "remote-policy-history"
        if directory is None:
            return None
        return RemotePolicyRollbackStore(directory, max_entries=settings.rollback_max_entries)

    def _rollback_validator(
        self, settings: RemoteConfigurationSettings, identity: RemoteDeviceIdentity | None
    ) -> Callable[[dict[str, Any]], int | None]:
        def validate(payload: dict[str, Any]) -> int | None:
            document, _, _, _ = self._validate_document(payload, settings, identity)
            return document.policy_revision
        return validate

    @staticmethod
    def _ensure_not_downgrade(
        document: RemotePolicyDocument, highest_revision: int | None, settings: RemoteConfigurationSettings
    ) -> None:
        if not settings.prevent_policy_downgrade:
            return
        if document.policy_revision is None or highest_revision is None:
            return
        if document.policy_revision < highest_revision:
            raise RemoteConfigurationError(
                "La revisió de política remota és anterior a l'última revisió validada."
            )

    @staticmethod
    def parse_policy_document(payload: dict[str, Any]) -> RemotePolicyDocument:
        try:
            return RemotePolicySchemaValidator.parse(payload)
        except RemotePolicySchemaError as error:
            raise RemoteConfigurationError(str(error)) from error

    @staticmethod
    def apply_policy_document(
        base: ThinClientConfig,
        payload: dict[str, Any],
    ) -> ThinClientConfig:
        document = RemoteConfigurationService.parse_policy_document(payload)
        return RemoteConfigurationService.apply_overlay(
            base, document.policy_dict()
        )

    @staticmethod
    def apply_overlay(
        base: ThinClientConfig,
        payload: dict[str, Any],
    ) -> ThinClientConfig:
        config, _, _ = RemoteConfigurationService.apply_overlay_with_metadata(
            base, payload
        )
        return config

    @staticmethod
    def apply_overlay_with_metadata(
        base: ThinClientConfig,
        payload: dict[str, Any],
    ) -> tuple[ThinClientConfig, tuple[str, ...], tuple[str, ...]]:
        sanitized, applied, rejected = RemoteConfigurationService._filter_payload(
            payload
        )
        application_data = RemoteConfigurationService._section(
            sanitized, "application"
        )
        rdp_data = RemoteConfigurationService._section(sanitized, "rdp")
        network_data = RemoteConfigurationService._section(sanitized, "network")
        smartcard_data = RemoteConfigurationService._section(sanitized, "smartcard")
        usb_data = RemoteConfigurationService._section(sanitized, "usb")
        drives_data = RemoteConfigurationService._section(sanitized, "drives")
        printers_data = RemoteConfigurationService._section(sanitized, "printers")
        audio_data = RemoteConfigurationService._section(sanitized, "audio")
        video_data = RemoteConfigurationService._section(sanitized, "video")
        clipboard_data = RemoteConfigurationService._section(sanitized, "clipboard")
        keyboard_data = RemoteConfigurationService._section(sanitized, "keyboard")
        device_data = RemoteConfigurationService._section(sanitized, "device")

        application = replace(
            base.application,
            title=RemoteConfigurationService._string(
                application_data, "title", base.application.title
            ),
            language=RemoteConfigurationService._string(
                application_data, "language", base.application.language
            ),
            remember_username=RemoteConfigurationService._boolean(
                application_data,
                "remember_username",
                base.application.remember_username,
            ),
        )

        rdp = replace(
            base.rdp,
            domain=RemoteConfigurationService._string(
                rdp_data, "domain", base.rdp.domain
            ),
            port=RemoteConfigurationService._integer(
                rdp_data, "port", base.rdp.port
            ),
            fullscreen=RemoteConfigurationService._boolean(
                rdp_data, "fullscreen", base.rdp.fullscreen
            ),
            multimon=RemoteConfigurationService._enum(
                rdp_data, "multimon", base.rdp.multimon, MultimonMode
            ),
            clipboard=RemoteConfigurationService._boolean(
                rdp_data, "clipboard", base.rdp.clipboard
            ),
            audio=RemoteConfigurationService._boolean(
                rdp_data, "audio", base.rdp.audio
            ),
            microphone=RemoteConfigurationService._boolean(
                rdp_data, "microphone", base.rdp.microphone
            ),
            smartcard=RemoteConfigurationService._boolean(
                rdp_data, "smartcard", base.rdp.smartcard
            ),
            printers=RemoteConfigurationService._boolean(
                rdp_data, "printers", base.rdp.printers
            ),
            certificate_mode=RemoteConfigurationService._enum(
                rdp_data,
                "certificate_mode",
                base.rdp.certificate_mode,
                CertificateMode,
            ),
            security_mode=RemoteConfigurationService._enum(
                rdp_data,
                "security_mode",
                base.rdp.security_mode,
                SecurityMode,
            ),
            certificate_name=RemoteConfigurationService._string(
                rdp_data, "certificate_name", base.rdp.certificate_name
            ),
            width=RemoteConfigurationService._integer(
                rdp_data, "width", base.rdp.width
            ),
            height=RemoteConfigurationService._integer(
                rdp_data, "height", base.rdp.height
            ),
            dynamic_resolution=RemoteConfigurationService._boolean(
                rdp_data,
                "dynamic_resolution",
                base.rdp.dynamic_resolution,
            ),
            smart_sizing=RemoteConfigurationService._boolean(
                rdp_data, "smart_sizing", base.rdp.smart_sizing
            ),
            color_depth=RemoteConfigurationService._integer(
                rdp_data, "color_depth", base.rdp.color_depth
            ),
            performance_profile=RemoteConfigurationService._enum(
                rdp_data,
                "performance_profile",
                base.rdp.performance_profile,
                PerformanceProfile,
            ),
            network_profile=RemoteConfigurationService._enum(
                rdp_data,
                "network_profile",
                base.rdp.network_profile,
                NetworkProfile,
            ),
            font_smoothing=RemoteConfigurationService._boolean(
                rdp_data, "font_smoothing", base.rdp.font_smoothing
            ),
            desktop_composition=RemoteConfigurationService._boolean(
                rdp_data,
                "desktop_composition",
                base.rdp.desktop_composition,
            ),
            wallpaper=RemoteConfigurationService._boolean(
                rdp_data, "wallpaper", base.rdp.wallpaper
            ),
            menu_animations=RemoteConfigurationService._boolean(
                rdp_data, "menu_animations", base.rdp.menu_animations
            ),
            window_drag=RemoteConfigurationService._boolean(
                rdp_data, "window_drag", base.rdp.window_drag
            ),
            themes=RemoteConfigurationService._boolean(
                rdp_data, "themes", base.rdp.themes
            ),
            bitmap_cache=RemoteConfigurationService._boolean(
                rdp_data, "bitmap_cache", base.rdp.bitmap_cache
            ),
            desktop_scale_percent=RemoteConfigurationService._integer(
                rdp_data, "desktop_scale_percent", base.rdp.desktop_scale_percent
            ),
            device_scale_percent=RemoteConfigurationService._integer(
                rdp_data, "device_scale_percent", base.rdp.device_scale_percent
            ),
        )

        smartcard = replace(
            base.smartcard,
            enabled=RemoteConfigurationService._boolean(
                smartcard_data, "enabled", base.smartcard.enabled
            ),
            required=RemoteConfigurationService._boolean(
                smartcard_data, "required", base.smartcard.required
            ),
            share=RemoteConfigurationService._boolean(
                smartcard_data, "share", base.smartcard.share
            ),
            preferred_reader=RemoteConfigurationService._string(
                smartcard_data,
                "preferred_reader",
                base.smartcard.preferred_reader,
            ),
            pkcs11_module=RemoteConfigurationService._string(
                smartcard_data,
                "pkcs11_module",
                base.smartcard.pkcs11_module,
            ),
        )

        usb = replace(
            base.usb,
            enabled=RemoteConfigurationService._boolean(
                usb_data, "enabled", base.usb.enabled
            ),
            allowed_devices=RemoteConfigurationService._string_tuple(
                usb_data, "allowed_devices", base.usb.allowed_devices
            ),
            blocked_devices=RemoteConfigurationService._string_tuple(
                usb_data, "blocked_devices", base.usb.blocked_devices
            ),
        )

        drives = replace(
            base.drives,
            enabled=RemoteConfigurationService._boolean(
                drives_data, "enabled", base.drives.enabled
            ),
            include_existing=RemoteConfigurationService._boolean(
                drives_data,
                "include_existing",
                base.drives.include_existing,
            ),
            hotplug=RemoteConfigurationService._boolean(
                drives_data, "hotplug", base.drives.hotplug
            ),
        )

        printers = replace(
            base.printers,
            enabled=RemoteConfigurationService._boolean(
                printers_data, "enabled", base.printers.enabled
            ),
            allowed_printers=RemoteConfigurationService._string_tuple_preserve(
                printers_data, "allowed_printers", base.printers.allowed_printers
            ),
            default_only=RemoteConfigurationService._boolean(
                printers_data, "default_only", base.printers.default_only
            ),
            required=RemoteConfigurationService._boolean(
                printers_data, "required", base.printers.required
            ),
        )

        audio = replace(
            base.audio,
            playback_enabled=RemoteConfigurationService._boolean(
                audio_data, "playback_enabled", base.audio.playback_enabled
            ),
            recording_enabled=RemoteConfigurationService._boolean(
                audio_data, "recording_enabled", base.audio.recording_enabled
            ),
            playback_required=RemoteConfigurationService._boolean(
                audio_data, "playback_required", base.audio.playback_required
            ),
            recording_required=RemoteConfigurationService._boolean(
                audio_data, "recording_required", base.audio.recording_required
            ),
        )

        video = replace(
            base.video,
            enabled=RemoteConfigurationService._boolean(
                video_data, "enabled", base.video.enabled
            ),
            required=RemoteConfigurationService._boolean(
                video_data, "required", base.video.required
            ),
        )

        clipboard = replace(
            base.clipboard,
            enabled=RemoteConfigurationService._boolean(
                clipboard_data, "enabled", base.clipboard.enabled
            ),
            profile=RemoteConfigurationService._enum(
                clipboard_data,
                "profile",
                base.clipboard.profile,
                ClipboardProfile,
            ),
            direction=RemoteConfigurationService._enum(
                clipboard_data,
                "direction",
                base.clipboard.direction,
                ClipboardDirection,
            ),
            files=RemoteConfigurationService._enum(
                clipboard_data,
                "files",
                base.clipboard.files,
                ClipboardDirection,
            ),
        )

        keyboard = replace(
            base.keyboard,
            layout=RemoteConfigurationService._string(
                keyboard_data, "layout", base.keyboard.layout
            ),
        )

        network = replace(
            base.network,
            connect_timeout=RemoteConfigurationService._number(
                network_data,
                "connect_timeout",
                base.network.connect_timeout,
            ),
            retry_interval=RemoteConfigurationService._number(
                network_data,
                "retry_interval",
                base.network.retry_interval,
            ),
        )

        # device_name identifica físicament el client i no es pot substituir
        # remotament. El servidor i la descripció sí que són administrables.
        device = replace(
            base.device,
            server=RemoteConfigurationService._string(
                device_data, "server", base.device.server
            ),
            description=RemoteConfigurationService._string(
                device_data, "description", base.device.description
            ),
        )

        result = replace(
            base,
            application=application,
            rdp=rdp,
            smartcard=smartcard,
            usb=usb,
            drives=drives,
            printers=printers,
            audio=audio,
            video=video,
            clipboard=clipboard,
            keyboard=keyboard,
            network=network,
            device=device,
        )
        validate_config(result)
        return result, applied, rejected

    @staticmethod
    def _filter_payload(
        payload: dict[str, Any],
    ) -> tuple[dict[str, Any], tuple[str, ...], tuple[str, ...]]:
        sanitized: dict[str, Any] = {}
        applied: list[str] = []
        rejected: list[str] = []

        for section, section_value in payload.items():
            if not isinstance(section_value, dict):
                rejected.append(str(section))
                continue

            accepted_section: dict[str, Any] = {}
            for key, value in section_value.items():
                path = f"{section}.{key}"
                if is_allowed(path, ConfigurationScope.REMOTE):
                    accepted_section[key] = value
                    applied.append(path)
                else:
                    rejected.append(path)

            if accepted_section:
                sanitized[section] = accepted_section

        return (
            sanitized,
            tuple(sorted(applied)),
            tuple(sorted(rejected)),
        )

    @staticmethod
    def _section(payload: dict[str, Any], name: str) -> dict[str, Any]:
        value = payload.get(name, {})
        if not isinstance(value, dict):
            raise RemoteConfigurationError(
                f"La secció remota '{name}' ha de ser un objecte."
            )
        return value

    @staticmethod
    def _string(data: dict[str, Any], key: str, default: str) -> str:
        if key not in data:
            return default
        value = data[key]
        if not isinstance(value, str):
            raise RemoteConfigurationError(
                f"El camp '{key}' ha de ser una cadena."
            )
        return value.strip()

    @staticmethod
    def _boolean(data: dict[str, Any], key: str, default: bool) -> bool:
        if key not in data:
            return default
        value = data[key]
        if not isinstance(value, bool):
            raise RemoteConfigurationError(
                f"El camp '{key}' ha de ser booleà."
            )
        return value


    @staticmethod
    def _string_tuple(
        data: dict[str, Any],
        key: str,
        default: tuple[str, ...],
    ) -> tuple[str, ...]:
        if key not in data:
            return default
        value = data[key]
        if not isinstance(value, list) or any(
            not isinstance(item, str) for item in value
        ):
            raise RemoteConfigurationError(
                f"El camp '{key}' ha de ser una llista de cadenes."
            )
        return tuple(
            item.strip().lower()
            for item in value
            if item.strip()
        )

    @staticmethod
    def _string_tuple_preserve(
        data: dict[str, Any], key: str, default: tuple[str, ...]
    ) -> tuple[str, ...]:
        if key not in data:
            return default
        value = data[key]
        if not isinstance(value, list) or any(not isinstance(item, str) for item in value):
            raise RemoteConfigurationError(f"El camp '{key}' ha de ser una llista de cadenes.")
        return tuple(item.strip() for item in value if item.strip())

    @staticmethod
    def _integer(data: dict[str, Any], key: str, default: int) -> int:
        if key not in data:
            return default
        value = data[key]
        if not isinstance(value, int) or isinstance(value, bool):
            raise RemoteConfigurationError(
                f"El camp '{key}' ha de ser enter."
            )
        return value

    @staticmethod
    def _number(data: dict[str, Any], key: str, default: float) -> float:
        if key not in data:
            return default
        value = data[key]
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            raise RemoteConfigurationError(
                f"El camp '{key}' ha de ser numèric."
            )
        return float(value)

    @staticmethod
    def _enum(data: dict[str, Any], key: str, default: Any, enum_type: Any) -> Any:
        if key not in data:
            return default
        value = data[key]
        if not isinstance(value, str):
            raise RemoteConfigurationError(
                f"El camp '{key}' ha de ser una cadena."
            )
        try:
            return enum_type(value.strip().lower())
        except ValueError as error:
            raise RemoteConfigurationError(
                f"Valor no admés per al camp '{key}': {value}"
            ) from error

    @staticmethod
    def _read_cache(path: Path) -> dict[str, Any]:
        with path.open("r", encoding="utf-8") as file:
            payload = json.load(file)
        if not isinstance(payload, dict):
            raise RemoteConfigurationError(
                "La memòria cau remota no conté un objecte JSON."
            )
        return payload

    @staticmethod
    def _write_cache(path: Path, payload: dict[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        with NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=path.parent,
            prefix=".remote-config-",
            suffix=".tmp",
            delete=False,
        ) as temporary_file:
            temporary_path = Path(temporary_file.name)
            json.dump(payload, temporary_file, ensure_ascii=False, indent=2)
            temporary_file.write("\n")
        temporary_path.replace(path)

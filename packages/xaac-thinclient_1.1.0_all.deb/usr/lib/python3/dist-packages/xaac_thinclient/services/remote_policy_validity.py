from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Callable


class RemotePolicyValidityError(ValueError):
    """La vigència temporal d'una política remota no és acceptable."""


@dataclass(frozen=True, slots=True)
class RemotePolicyValidity:
    required: bool
    present: bool
    valid: bool
    issued_at: datetime | None = None
    expires_at: datetime | None = None
    clock_skew_seconds: int = 0


Clock = Callable[[], datetime]


class RemotePolicyValidityValidator:
    """Valida dates ISO-8601 UTC amb una tolerància limitada de rellotge."""

    def __init__(self, clock: Clock | None = None) -> None:
        self._clock = clock or (lambda: datetime.now(timezone.utc))

    @staticmethod
    def parse_timestamp(value: str | None, field: str) -> datetime | None:
        if value is None:
            return None
        if not isinstance(value, str) or not value.strip():
            raise RemotePolicyValidityError(f"'{field}' ha de ser una data ISO-8601 no buida.")
        text = value.strip()
        if text.endswith("Z"):
            text = text[:-1] + "+00:00"
        try:
            parsed = datetime.fromisoformat(text)
        except ValueError as error:
            raise RemotePolicyValidityError(f"'{field}' no és una data ISO-8601 vàlida.") from error
        if parsed.tzinfo is None or parsed.utcoffset() is None:
            raise RemotePolicyValidityError(f"'{field}' ha d'incloure zona horària.")
        return parsed.astimezone(timezone.utc)

    def validate(
        self,
        *,
        issued_at: str | None,
        expires_at: str | None,
        required: bool,
        clock_skew_seconds: int = 60,
    ) -> RemotePolicyValidity:
        if clock_skew_seconds < 0 or clock_skew_seconds > 3600:
            raise RemotePolicyValidityError("La tolerància de rellotge ha d'estar entre 0 i 3600 segons.")
        issued = self.parse_timestamp(issued_at, "issued_at")
        expires = self.parse_timestamp(expires_at, "expires_at")
        present = issued is not None or expires is not None
        if required and expires is None:
            raise RemotePolicyValidityError("La política remota exigeix una data de caducitat.")
        if issued is None and expires is None:
            return RemotePolicyValidity(
                required=required,
                present=False,
                valid=not required,
                clock_skew_seconds=clock_skew_seconds,
            )
        if issued is None or expires is None:
            raise RemotePolicyValidityError("La vigència exigeix 'issued_at' i 'expires_at'.")
        if expires <= issued:
            raise RemotePolicyValidityError("'expires_at' ha de ser posterior a 'issued_at'.")
        now = self._clock().astimezone(timezone.utc)
        skew = timedelta(seconds=clock_skew_seconds)
        if issued > now + skew:
            raise RemotePolicyValidityError("La política remota encara no és vigent.")
        if expires < now - skew:
            raise RemotePolicyValidityError("La política remota ha caducat.")
        return RemotePolicyValidity(
            required=required,
            present=True,
            valid=True,
            issued_at=issued,
            expires_at=expires,
            clock_skew_seconds=clock_skew_seconds,
        )

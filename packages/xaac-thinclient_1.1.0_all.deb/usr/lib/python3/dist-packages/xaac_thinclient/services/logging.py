from __future__ import annotations

import logging as py_logging
import os
import sys
from dataclasses import dataclass
from logging.handlers import RotatingFileHandler
from pathlib import Path


LOGGER_NAMESPACE = "xaac_thinclient"

DEFAULT_LOG_LEVEL = py_logging.INFO
DEFAULT_MAX_BYTES = 2 * 1024 * 1024
DEFAULT_BACKUP_COUNT = 5
LOG_LEVEL_ENVIRONMENT_VARIABLE = "XAAC_LOG_LEVEL"

_ALLOWED_LEVELS = {
    "DEBUG": py_logging.DEBUG,
    "INFO": py_logging.INFO,
    "WARNING": py_logging.WARNING,
    "ERROR": py_logging.ERROR,
    "CRITICAL": py_logging.CRITICAL,
}


@dataclass(frozen=True, slots=True)
class LoggingSettings:
    level: str = "INFO"
    console: bool = True
    file: bool = True
    max_bytes: int = DEFAULT_MAX_BYTES
    backup_count: int = DEFAULT_BACKUP_COUNT


def parse_log_level(
    value: str | int | None,
    *,
    default: int = DEFAULT_LOG_LEVEL,
) -> int:
    """Converteix un nivell textual o numèric en un nivell de ``logging``.

    Els valors desconeguts no interrompen l'arrencada: es degraden al nivell
    per defecte indicat.
    """
    if isinstance(value, int):
        return value if value in _ALLOWED_LEVELS.values() else default

    if value is None:
        return default

    return _ALLOWED_LEVELS.get(str(value).strip().upper(), default)


def resolve_log_level(
    configured_level: str | int | None,
    *,
    environment: dict[str, str] | None = None,
    default: int = DEFAULT_LOG_LEVEL,
) -> int:
    """Resol el nivell efectiu.

    Prioritat: ``XAAC_LOG_LEVEL`` > configuració local > valor per defecte.
    """
    source = os.environ if environment is None else environment
    override = source.get(LOG_LEVEL_ENVIRONMENT_VARIABLE)
    return parse_log_level(
        override if override is not None else configured_level,
        default=default,
    )


def configure_logging(
    log_file: Path,
    level: int | str = DEFAULT_LOG_LEVEL,
    *,
    console: bool = True,
    file: bool = True,
    max_bytes: int = DEFAULT_MAX_BYTES,
    backup_count: int = DEFAULT_BACKUP_COUNT,
) -> py_logging.Logger:
    """Configura o reconfigura el registre de XAAC Thin Client Remote.

    La funció és idempotent i no duplica handlers. Una nova crida actualitza
    els handlers i nivells existents, fet que facilita els tests i futurs
    canvis de configuració en temps d'execució.
    """
    resolved_level = parse_log_level(level)
    root_logger = py_logging.getLogger(LOGGER_NAMESPACE)

    # Els handlers són propietat exclusiva d'aquest namespace. Es tanquen
    # abans de recrear-los per evitar descriptors oberts o línies duplicades.
    for handler in tuple(root_logger.handlers):
        root_logger.removeHandler(handler)
        try:
            handler.close()
        except Exception:
            pass

    root_logger.setLevel(resolved_level)
    root_logger.propagate = False

    formatter = py_logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    if file:
        log_file.parent.mkdir(parents=True, exist_ok=True)
        file_handler = RotatingFileHandler(
            filename=log_file,
            maxBytes=max(1, int(max_bytes)),
            backupCount=max(0, int(backup_count)),
            encoding="utf-8",
            delay=True,
        )
        file_handler.setLevel(resolved_level)
        file_handler.setFormatter(formatter)
        root_logger.addHandler(file_handler)

    if console:
        console_handler = py_logging.StreamHandler(stream=sys.stderr)
        console_handler.setLevel(resolved_level)
        console_handler.setFormatter(formatter)
        root_logger.addHandler(console_handler)

    root_logger.info(
        "Sistema de registre inicialitzat: nivell=%s fitxer=%s consola=%s",
        py_logging.getLevelName(resolved_level),
        log_file if file else "desactivat",
        console,
    )
    return root_logger


def get_logger(name: str) -> py_logging.Logger:
    """Retorna un logger fill del namespace principal."""
    if name.startswith(LOGGER_NAMESPACE):
        logger_name = name
    else:
        logger_name = f"{LOGGER_NAMESPACE}.{name}"

    return py_logging.getLogger(logger_name)

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


_HID_CLASS = 0x03
_HUB_CLASS = 0x09
_WIRELESS_CONTROLLER_CLASS = 0xE0
_ALWAYS_BLOCKED_CLASSES = {
    _HID_CLASS,
    _HUB_CLASS,
    _WIRELESS_CONTROLLER_CLASS,
}


@dataclass(frozen=True, slots=True)
class UsbDevice:
    """Dispositiu USB físic descobert en sysfs."""

    vendor_id: str
    product_id: str
    manufacturer: str = ""
    product: str = ""
    serial: str = ""
    device_class: int = 0
    interface_classes: tuple[int, ...] = ()
    bus_number: int | None = None
    device_number: int | None = None

    @property
    def identifier(self) -> str:
        return f"{self.vendor_id}:{self.product_id}"

    @property
    def display_name(self) -> str:
        parts = tuple(
            part.strip()
            for part in (self.manufacturer, self.product)
            if part.strip()
        )
        return " ".join(parts) or self.identifier

    @property
    def security_blocked(self) -> bool:
        classes = {self.device_class, *self.interface_classes}
        return bool(classes & _ALWAYS_BLOCKED_CLASSES)


@dataclass(frozen=True, slots=True)
class UsbStatus:
    enabled: bool
    detected: tuple[UsbDevice, ...] = ()
    allowed: tuple[UsbDevice, ...] = ()
    blocked: tuple[UsbDevice, ...] = ()
    error: str | None = None

    @property
    def redirected_identifiers(self) -> tuple[str, ...]:
        """Identificadors únics que es poden passar a FreeRDP."""
        return tuple(dict.fromkeys(device.identifier for device in self.allowed))


class UsbService:
    """Descobreix i filtra USB locals llegint directament sysfs."""

    def __init__(self, sysfs_root: Path = Path("/sys/bus/usb/devices")) -> None:
        self.sysfs_root = sysfs_root

    def get_status(
        self,
        *,
        enabled: bool,
        allowed_devices: tuple[str, ...] = (),
        blocked_devices: tuple[str, ...] = (),
    ) -> UsbStatus:
        if not enabled:
            return UsbStatus(enabled=False)

        try:
            detected = self.scan_devices()
        except OSError as error:
            return UsbStatus(enabled=True, error=str(error))

        allowed_ids = {value.casefold() for value in allowed_devices}
        blocked_ids = {value.casefold() for value in blocked_devices}
        allowed: list[UsbDevice] = []
        blocked: list[UsbDevice] = []

        for device in detected:
            identifier = device.identifier.casefold()

            if (
                device.security_blocked
                or identifier in blocked_ids
                or identifier not in allowed_ids
            ):
                blocked.append(device)
                continue

            allowed.append(device)

        return UsbStatus(
            enabled=True,
            detected=detected,
            allowed=tuple(allowed),
            blocked=tuple(blocked),
        )

    def scan_devices(self) -> tuple[UsbDevice, ...]:
        if not self.sysfs_root.exists():
            return ()

        devices: list[UsbDevice] = []
        for path in sorted(self.sysfs_root.iterdir(), key=lambda item: item.name):
            vendor = self._read_text(path / "idVendor")
            product = self._read_text(path / "idProduct")
            if not vendor or not product:
                continue

            devices.append(
                UsbDevice(
                    vendor_id=vendor.casefold().zfill(4),
                    product_id=product.casefold().zfill(4),
                    manufacturer=self._read_text(path / "manufacturer"),
                    product=self._read_text(path / "product"),
                    serial=self._read_text(path / "serial"),
                    device_class=self._read_hex(path / "bDeviceClass"),
                    interface_classes=self._read_interface_classes(path),
                    bus_number=self._read_int(path / "busnum"),
                    device_number=self._read_int(path / "devnum"),
                )
            )

        return tuple(devices)

    def _read_interface_classes(self, device_path: Path) -> tuple[int, ...]:
        prefix = f"{device_path.name}:"
        classes: list[int] = []
        try:
            entries = tuple(self.sysfs_root.iterdir())
        except OSError:
            return ()

        for interface_path in entries:
            if not interface_path.name.startswith(prefix):
                continue
            class_code = self._read_hex(interface_path / "bInterfaceClass")
            if class_code not in classes:
                classes.append(class_code)
        return tuple(classes)

    @staticmethod
    def _read_text(path: Path) -> str:
        try:
            return path.read_text(encoding="utf-8", errors="replace").strip()
        except (FileNotFoundError, OSError):
            return ""

    @classmethod
    def _read_hex(cls, path: Path) -> int:
        value = cls._read_text(path)
        try:
            return int(value, 16) if value else 0
        except ValueError:
            return 0

    @classmethod
    def _read_int(cls, path: Path) -> int | None:
        value = cls._read_text(path)
        try:
            return int(value) if value else None
        except ValueError:
            return None

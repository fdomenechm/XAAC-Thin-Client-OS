from __future__ import annotations

from dataclasses import dataclass
from types import MappingProxyType
from typing import Any, Mapping

from xaac_thinclient.services.remote_policy_signature import RemotePolicySignature
from xaac_thinclient.services.remote_device_identity import RemotePolicyTarget


CURRENT_REMOTE_POLICY_SCHEMA_VERSION = 1
LEGACY_REMOTE_POLICY_SCHEMA_VERSION = 0


class RemotePolicySchemaError(ValueError):
    """El document de política remota no compleix l'esquema admés."""


@dataclass(frozen=True, slots=True)
class RemotePolicyDocument:
    """Representació immutable i versionada d'una política remota.

    L'esquema 1 utilitza un embolcall explícit::

        {"schema_version": 1, "policy": { ... }}

    Els documents antics sense embolcall continuen admesos com a versió 0
    durant la migració. La signatura, caducitat i identitat s'afegiran en
    fases posteriors sense modificar el contingut de ``policy``.
    """

    schema_version: int
    policy: Mapping[str, Any]
    legacy: bool = False
    signature: RemotePolicySignature | None = None
    issued_at: str | None = None
    expires_at: str | None = None
    policy_revision: int | None = None
    target: RemotePolicyTarget | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "policy", MappingProxyType(dict(self.policy)))

    def policy_dict(self) -> dict[str, Any]:
        """Retorna una còpia mutable només per al pipeline d'aplicació."""
        return dict(self.policy)


class RemotePolicySchemaValidator:
    """Valida i normalitza documents remots sense aplicar-los."""

    _RESERVED_TOP_LEVEL_KEYS = frozenset({"schema_version", "policy", "signature", "issued_at", "expires_at", "policy_revision", "target"})

    @classmethod
    def parse(cls, payload: dict[str, Any]) -> RemotePolicyDocument:
        if not isinstance(payload, dict):
            raise RemotePolicySchemaError(
                "La política remota ha de ser un objecte JSON."
            )

        has_version = "schema_version" in payload
        has_policy = "policy" in payload

        # Compatibilitat amb el format històric: l'objecte complet era
        # directament la superposició de configuració.
        if not has_version and not has_policy:
            return RemotePolicyDocument(
                schema_version=LEGACY_REMOTE_POLICY_SCHEMA_VERSION,
                policy=cls._copy_policy(payload),
                legacy=True,
            )

        if not has_version or not has_policy:
            raise RemotePolicySchemaError(
                "L'esquema versionat exigeix 'schema_version' i 'policy'."
            )

        extra = sorted(set(payload) - cls._RESERVED_TOP_LEVEL_KEYS)
        if extra:
            raise RemotePolicySchemaError(
                "Camps superiors no admesos en l'esquema 1: " + ", ".join(extra)
            )

        version = payload["schema_version"]
        if not isinstance(version, int) or isinstance(version, bool):
            raise RemotePolicySchemaError(
                "'schema_version' ha de ser un enter."
            )
        if version != CURRENT_REMOTE_POLICY_SCHEMA_VERSION:
            raise RemotePolicySchemaError(
                "Versió d'esquema de política no admesa: " + str(version)
            )

        policy = payload["policy"]
        if not isinstance(policy, dict):
            raise RemotePolicySchemaError(
                "El camp 'policy' ha de ser un objecte JSON."
            )

        signature = cls._parse_signature(payload.get("signature"))
        return RemotePolicyDocument(
            schema_version=version,
            policy=cls._copy_policy(policy),
            legacy=False,
            signature=signature,
            issued_at=cls._parse_optional_text(payload.get("issued_at"), "issued_at"),
            expires_at=cls._parse_optional_text(payload.get("expires_at"), "expires_at"),
            policy_revision=cls._parse_revision(payload.get("policy_revision")),
            target=cls._parse_target(payload.get("target")),
        )

    @staticmethod
    def _copy_policy(policy: dict[str, Any]) -> dict[str, Any]:
        copied: dict[str, Any] = {}
        for key, value in policy.items():
            if not isinstance(key, str) or not key.strip():
                raise RemotePolicySchemaError(
                    "Les claus de la política han de ser cadenes no buides."
                )
            copied[key] = value
        return copied




    @staticmethod
    def _parse_target(value: Any) -> RemotePolicyTarget | None:
        if value is None:
            return None
        if not isinstance(value, dict):
            raise RemotePolicySchemaError("El camp 'target' ha de ser un objecte JSON.")
        extra = set(value) - {"device_id", "device_name"}
        if extra:
            raise RemotePolicySchemaError("Camps de destinatari no admesos: " + ", ".join(sorted(extra)))
        device_id = RemotePolicySchemaValidator._parse_optional_text(value.get("device_id"), "target.device_id")
        device_name = RemotePolicySchemaValidator._parse_optional_text(value.get("device_name"), "target.device_name")
        if device_id is None and device_name is None:
            raise RemotePolicySchemaError("El destinatari exigeix device_id o device_name.")
        return RemotePolicyTarget(device_id=device_id, device_name=device_name)

    @staticmethod
    def _parse_revision(value: Any) -> int | None:
        if value is None:
            return None
        if not isinstance(value, int) or isinstance(value, bool) or value < 0:
            raise RemotePolicySchemaError("'policy_revision' ha de ser un enter no negatiu.")
        return value

    @staticmethod
    def _parse_optional_text(value: Any, field: str) -> str | None:
        if value is None:
            return None
        if not isinstance(value, str) or not value.strip():
            raise RemotePolicySchemaError(f"El camp '{field}' ha de ser una cadena no buida.")
        if any(char in value for char in ("\n", "\r", "\x00")):
            raise RemotePolicySchemaError(f"El camp '{field}' conté caràcters no admesos.")
        return value.strip()

    @staticmethod
    def _parse_signature(value: Any) -> RemotePolicySignature | None:
        if value is None:
            return None
        if not isinstance(value, dict):
            raise RemotePolicySchemaError("El camp 'signature' ha de ser un objecte JSON.")
        extra = set(value) - {"key_id", "algorithm", "value"}
        if extra:
            raise RemotePolicySchemaError("Camps de signatura no admesos: " + ", ".join(sorted(extra)))
        key_id = value.get("key_id")
        algorithm = value.get("algorithm", "ed25519")
        signature = value.get("value")
        if not all(isinstance(item, str) and item.strip() for item in (key_id, algorithm, signature)):
            raise RemotePolicySchemaError("La signatura exigeix key_id, algorithm i value no buits.")
        return RemotePolicySignature(key_id=key_id.strip(), algorithm=algorithm.strip(), value=signature.strip())

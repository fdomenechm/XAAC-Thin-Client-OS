from __future__ import annotations

import re
import shutil
import subprocess
import time
from dataclasses import dataclass, replace
from threading import RLock
from enum import Enum
from pathlib import Path
from typing import Callable, Sequence

from xaac_thinclient.config.models import MultimonMode, ThinClientConfig
from xaac_thinclient.services.logging import get_logger


logger = get_logger(__name__)


class FreeRdpCapability(str, Enum):
    """Capacitats estables que XAAC pot consumir de FreeRDP 3."""

    SMARTCARD = "smartcard"
    CLIPBOARD = "clipboard"
    DRIVE = "drive"
    USB = "usb"
    AUDIO_OUTPUT = "audio-output"
    AUDIO_INPUT = "audio-input"
    MULTIMON = "multimon"
    RDPECAM = "rdpecam"
    GFX = "gfx"
    GFX_AVC420 = "gfx-avc420"
    GFX_AVC444 = "gfx-avc444"


class FreeRdpCapabilityStatusCode(str, Enum):
    AVAILABLE = "available"
    UNAVAILABLE = "unavailable"
    EXECUTABLE_NOT_FOUND = "executable_not_found"
    DETECTION_FAILED = "detection_failed"


class FreeRdpCapabilitySource(str, Enum):
    """Origen estable de la instantània retornada al consumidor."""

    LIVE = "live"
    CACHE = "cache"


@dataclass(frozen=True, slots=True)
class FreeRdpCapabilityStatus:
    executable: str | None
    capabilities: frozenset[FreeRdpCapability]
    status_code: FreeRdpCapabilityStatusCode
    error: str | None = None
    version: str | None = None
    evidence: tuple[str, ...] = ()
    source: FreeRdpCapabilitySource = FreeRdpCapabilitySource.LIVE
    cache_age_seconds: int = 0

    @property
    def executable_name(self) -> str:
        return Path(self.executable).name if self.executable else "not found"

    @property
    def health_summary(self) -> str:
        if self.status_code is FreeRdpCapabilityStatusCode.AVAILABLE:
            return "ready"
        if self.status_code is FreeRdpCapabilityStatusCode.EXECUTABLE_NOT_FOUND:
            return "missing executable"
        if self.status_code is FreeRdpCapabilityStatusCode.DETECTION_FAILED:
            return "detection failed"
        return "limited capabilities"

    def supports(self, capability: FreeRdpCapability) -> bool:
        return capability in self.capabilities

    @property
    def rdpecam_available(self) -> bool:
        return self.supports(FreeRdpCapability.RDPECAM)

    @property
    def detected_count(self) -> int:
        return len(self.capabilities)

    def audit_fields(self) -> tuple[tuple[str, str], ...]:
        """Retorna camps estables sense rutes, eixida bruta ni dades d'usuari."""
        return (
            ("status", self.status_code.value),
            ("executable_found", str(self.executable is not None).lower()),
            ("detected_count", str(self.detected_count)),
            ("version_known", str(self.version is not None).lower()),
            (
                "capabilities",
                ",".join(sorted(item.value for item in self.capabilities)) or "-",
            ),
        )


@dataclass(frozen=True, slots=True)
class FreeRdpConfigurationCompatibility:
    """Resultat immutable de comparar configuració i capacitats reals."""

    requested: frozenset[FreeRdpCapability]
    unsupported: frozenset[FreeRdpCapability]
    blocking: frozenset[FreeRdpCapability]

    @property
    def compatible(self) -> bool:
        return not self.unsupported

    @property
    def connection_allowed(self) -> bool:
        return not self.blocking

    def audit_fields(self) -> tuple[tuple[str, str], ...]:
        render = lambda values: ",".join(sorted(item.value for item in values)) or "-"
        return (
            ("compatible", str(self.compatible).lower()),
            ("connection_allowed", str(self.connection_allowed).lower()),
            ("requested", render(self.requested)),
            ("unsupported", render(self.unsupported)),
            ("blocking", render(self.blocking)),
        )


@dataclass(frozen=True, slots=True)
class FreeRdpDegradationPlan:
    """Configuració efectiva després d'aplicar degradació segura."""

    effective_config: ThinClientConfig
    compatibility: FreeRdpConfigurationCompatibility
    degraded: frozenset[FreeRdpCapability]

    @property
    def connection_allowed(self) -> bool:
        return self.compatibility.connection_allowed

    @property
    def degraded_count(self) -> int:
        return len(self.degraded)

    def audit_fields(self) -> tuple[tuple[str, str], ...]:
        rendered = ",".join(sorted(item.value for item in self.degraded)) or "-"
        return (
            ("connection_allowed", str(self.connection_allowed).lower()),
            ("degraded_count", str(self.degraded_count)),
            ("degraded", rendered),
        )


CommandRunner = Callable[[Sequence[str], float], subprocess.CompletedProcess[str]]


# Tokens publicats per /help o /buildconfig. Els patrons exigeixen delimitadors
# per evitar falsos positius en paraules o textos no relacionats.
_CAPABILITY_PATTERNS: dict[FreeRdpCapability, tuple[re.Pattern[str], ...]] = {
    FreeRdpCapability.SMARTCARD: (
        re.compile(r"(?:^|\s)/smartcard(?:[\s,:]|$)"),
        re.compile(r"with_channel_smartcard_client\s*=\s*on"),
    ),
    FreeRdpCapability.CLIPBOARD: (
        re.compile(r"(?:^|\s)[+/]clipboard(?:[\s,:]|$)"),
        re.compile(r"with_channel_cliprdr_client\s*=\s*on"),
    ),
    FreeRdpCapability.DRIVE: (
        re.compile(r"(?:^|\s)/drive(?:[\s,:]|$)"),
        re.compile(r"with_channel_rdpdr_client\s*=\s*on"),
    ),
    FreeRdpCapability.USB: (
        re.compile(r"(?:^|\s)/usb(?:[\s,:]|$)"),
        re.compile(r"with_channel_urbdrc_client\s*=\s*on"),
    ),
    FreeRdpCapability.AUDIO_OUTPUT: (
        re.compile(r"(?:^|\s)/sound(?:[\s,:]|$)"),
        re.compile(r"with_channel_rdpsnd_client\s*=\s*on"),
    ),
    FreeRdpCapability.AUDIO_INPUT: (
        re.compile(r"(?:^|\s)/microphone(?:[\s,:]|$)"),
        re.compile(r"with_channel_audin_client\s*=\s*on"),
    ),
    FreeRdpCapability.MULTIMON: (
        re.compile(r"(?:^|\s)[+/]multimon(?:\[|[\s,:]|$)"),
    ),
    FreeRdpCapability.GFX: (
        re.compile(r"(?:^|\s)/gfx(?:\[|[\s,:]|$)", re.IGNORECASE),
    ),
    FreeRdpCapability.GFX_AVC420: (
        re.compile(r"\bavc420\b", re.IGNORECASE),
    ),
    FreeRdpCapability.GFX_AVC444: (
        re.compile(r"\bavc444\b", re.IGNORECASE),
    ),
    FreeRdpCapability.RDPECAM: (
        re.compile(r"\brdpecam\b"),
        re.compile(r"with_channel_rdpecam_client\s*=\s*on"),
    ),
}


class FreeRdpCapabilityService:
    """Detecta funcionalitats anunciades o instal·lades en xfreerdp3."""

    def __init__(
        self,
        *,
        executable_finder: Callable[[], str | None] | None = None,
        command_runner: CommandRunner | None = None,
        timeout: float = 3.0,
        plugin_roots: tuple[Path, ...] | None = None,
        cache_ttl: float = 300.0,
        clock: Callable[[], float] | None = None,
    ) -> None:
        self.executable_finder = executable_finder or (
            lambda: shutil.which("xfreerdp3")
        )
        self.command_runner = command_runner or self._run_command
        self.timeout = timeout
        self.plugin_roots = plugin_roots
        self.cache_ttl = max(0.0, cache_ttl)
        self.clock = clock or time.monotonic
        self._cache_lock = RLock()
        self._cached_status: FreeRdpCapabilityStatus | None = None
        self._cached_at: float | None = None
        self._last_compatibility_audit: tuple[tuple[str, str], ...] | None = None

    def get_status(self, *, force_refresh: bool = False) -> FreeRdpCapabilityStatus:
        """Retorna capacitats detectades, reutilitzant una instantània recent.

        La memòria cau és només de procés, no persisteix eixida bruta de FreeRDP
        i pot invalidar-se explícitament després d'una actualització del sistema.
        """
        now = self.clock()
        with self._cache_lock:
            if not force_refresh and self._cache_is_valid(now):
                assert self._cached_status is not None
                assert self._cached_at is not None
                return replace(
                    self._cached_status,
                    source=FreeRdpCapabilitySource.CACHE,
                    cache_age_seconds=max(0, int(now - self._cached_at)),
                )

            status = self._detect_status()
            self._cached_status = replace(
                status,
                source=FreeRdpCapabilitySource.LIVE,
                cache_age_seconds=0,
            )
            self._cached_at = now
            return self._cached_status


    def validate_configuration(
        self,
        config: ThinClientConfig,
        *,
        status: FreeRdpCapabilityStatus | None = None,
    ) -> FreeRdpConfigurationCompatibility:
        """Compara opcions efectives amb les capacitats anunciades per FreeRDP.

        Les opcions opcionals incompatibles es publiquen com ``unsupported``.
        Només les polítiques explícitament obligatòries formen ``blocking``.
        """
        current = status or self.get_status()
        requested: set[FreeRdpCapability] = set()
        blocking_requested: set[FreeRdpCapability] = set()

        def require(capability: FreeRdpCapability, enabled: bool, required: bool = False) -> None:
            if enabled:
                requested.add(capability)
                if required:
                    blocking_requested.add(capability)

        require(
            FreeRdpCapability.SMARTCARD,
            config.smartcard.redirection_enabled,
            config.smartcard.card_required,
        )
        require(FreeRdpCapability.CLIPBOARD, config.clipboard.enabled)
        require(FreeRdpCapability.DRIVE, config.drives.enabled)
        require(FreeRdpCapability.USB, config.usb.enabled)
        require(
            FreeRdpCapability.AUDIO_OUTPUT,
            config.audio.playback_enabled,
            config.audio.playback_required,
        )
        require(
            FreeRdpCapability.AUDIO_INPUT,
            config.audio.recording_enabled,
            config.audio.recording_required,
        )
        require(
            FreeRdpCapability.MULTIMON,
            config.rdp.multimon is not MultimonMode.DISABLED,
        )
        require(
            FreeRdpCapability.RDPECAM,
            config.video.enabled,
            config.video.required,
        )

        unsupported = requested.difference(current.capabilities)
        return FreeRdpConfigurationCompatibility(
            requested=frozenset(requested),
            unsupported=frozenset(unsupported),
            blocking=frozenset(unsupported.intersection(blocking_requested)),
        )


    def apply_safe_degradation(
        self,
        config: ThinClientConfig,
        *,
        status: FreeRdpCapabilityStatus | None = None,
    ) -> FreeRdpDegradationPlan:
        """Desactiva només funcions opcionals que FreeRDP no suporta.

        Les discrepàncies obligatòries no es modifiquen silenciosament i
        mantenen ``connection_allowed=False`` perquè el consumidor bloquege
        l'inici de sessió amb un error estable.
        """
        compatibility = self.validate_configuration(config, status=status)
        degraded = compatibility.unsupported.difference(compatibility.blocking)
        effective = config

        if FreeRdpCapability.SMARTCARD in degraded:
            effective = replace(
                effective,
                smartcard=replace(effective.smartcard, share=False),
            )
        if FreeRdpCapability.CLIPBOARD in degraded:
            effective = replace(
                effective,
                clipboard=replace(effective.clipboard, enabled=False),
            )
        if FreeRdpCapability.DRIVE in degraded:
            effective = replace(
                effective,
                drives=replace(effective.drives, enabled=False),
            )
        if FreeRdpCapability.USB in degraded:
            effective = replace(
                effective,
                usb=replace(effective.usb, enabled=False),
            )
        if FreeRdpCapability.AUDIO_OUTPUT in degraded:
            effective = replace(
                effective,
                audio=replace(effective.audio, playback_enabled=False),
            )
        if FreeRdpCapability.AUDIO_INPUT in degraded:
            effective = replace(
                effective,
                audio=replace(effective.audio, recording_enabled=False),
            )
        if FreeRdpCapability.MULTIMON in degraded:
            effective = replace(
                effective,
                rdp=replace(effective.rdp, multimon=MultimonMode.DISABLED),
            )
        if FreeRdpCapability.RDPECAM in degraded:
            effective = replace(
                effective,
                video=replace(effective.video, enabled=False),
            )

        return FreeRdpDegradationPlan(
            effective_config=effective,
            compatibility=compatibility,
            degraded=frozenset(degraded),
        )

    def audit_configuration(
        self,
        config: ThinClientConfig,
        *,
        status: FreeRdpCapabilityStatus | None = None,
    ) -> FreeRdpConfigurationCompatibility:
        """Valida i audita canvis reals de compatibilitat de manera segura."""
        compatibility = self.validate_configuration(config, status=status)
        self.audit_compatibility(compatibility)
        return compatibility

    def audit_compatibility(
        self,
        compatibility: FreeRdpConfigurationCompatibility,
    ) -> bool:
        """Registra una transició només quan canvia el resultat sanejat.

        No inclou rutes, eixida de FreeRDP, servidor, usuari ni cap altra dada
        de sessió. Retorna ``True`` quan s'ha emés un esdeveniment.
        """
        fields = compatibility.audit_fields()
        with self._cache_lock:
            previous = self._last_compatibility_audit
            if previous == fields:
                return False
            self._last_compatibility_audit = fields

        previous_fields = dict(previous or ())
        current_fields = dict(fields)
        logger.info(
            "freerdp_compatibility_changed "
            "previous_compatible=%s previous_connection_allowed=%s "
            "compatible=%s connection_allowed=%s requested=%s "
            "unsupported=%s blocking=%s",
            previous_fields.get("compatible", "unknown"),
            previous_fields.get("connection_allowed", "unknown"),
            current_fields["compatible"],
            current_fields["connection_allowed"],
            current_fields["requested"],
            current_fields["unsupported"],
            current_fields["blocking"],
        )
        return True

    def reset_compatibility_audit(self) -> None:
        """Oblida l'última transició auditada, principalment per a reinicis/tests."""
        with self._cache_lock:
            self._last_compatibility_audit = None

    def invalidate_cache(self) -> None:
        """Elimina la instantània en memòria sense afectar el sistema."""
        with self._cache_lock:
            self._cached_status = None
            self._cached_at = None

    def _cache_is_valid(self, now: float) -> bool:
        return (
            self._cached_status is not None
            and self._cached_at is not None
            and self.cache_ttl > 0
            and now - self._cached_at < self.cache_ttl
        )

    def _detect_status(self) -> FreeRdpCapabilityStatus:
        executable = self.executable_finder()
        if executable is None:
            return FreeRdpCapabilityStatus(
                executable=None,
                capabilities=frozenset(),
                status_code=FreeRdpCapabilityStatusCode.EXECUTABLE_NOT_FOUND,
                error="The xfreerdp3 executable was not found.",
            )

        evidence: list[str] = []
        errors: list[str] = []
        output_parts: list[str] = []
        for argument in ("/buildconfig", "/help"):
            try:
                result = self.command_runner((executable, argument), self.timeout)
            except (OSError, TypeError, subprocess.SubprocessError) as error:
                errors.append(f"{argument}: {type(error).__name__}")
                continue
            output = "\n".join(
                part for part in (result.stdout, result.stderr) if part
            )
            output_parts.append(output)
            evidence.append(f"{argument} returned {result.returncode}")

        raw_combined = "\n".join(output_parts)
        combined = raw_combined.lower()
        version_match = re.search(r"(?:freerdp|xfreerdp)(?:\s+version)?\s*[:v]?\s*(\d+\.\d+(?:\.\d+)?)", raw_combined, re.IGNORECASE)
        version = version_match.group(1) if version_match else None
        capabilities = {
            capability
            for capability, patterns in _CAPABILITY_PATTERNS.items()
            if any(pattern.search(combined) for pattern in patterns)
        }

        # L'ajuda de FreeRDP pot anunciar codecs GFX que el parser real del
        # binari empaquetat rebutja (observat, entre altres, amb AVC420 en
        # algunes compilacions de FreeRDP 3.30). Verifiquem els codecs
        # anunciats amb una connexió local deliberadament invàlida. Si el
        # parser rebutja l'opció, eliminem només eixa capacitat i el selector
        # gràfic degradarà de manera segura a ``/gfx``.
        for capability, gfx_value in (
            (FreeRdpCapability.GFX_AVC420, "AVC420"),
            (FreeRdpCapability.GFX_AVC444, "AVC444"),
        ):
            if capability not in capabilities:
                continue
            accepted = self._gfx_codec_parser_accepts(executable, gfx_value)
            if accepted is False:
                capabilities.discard(capability)
                evidence.append(f"{gfx_value} rejected by command-line parser")
            elif accepted is True:
                evidence.append(f"{gfx_value} accepted by command-line parser")
            else:
                evidence.append(f"{gfx_value} parser probe inconclusive")

        # RDPECAM pot estar distribuït com a plugin separat i no aparéixer en
        # l'ajuda, segons l'empaquetat de la distribució.
        if (
            FreeRdpCapability.RDPECAM not in capabilities
            and self._rdpecam_plugin_exists(executable)
        ):
            capabilities.add(FreeRdpCapability.RDPECAM)
            evidence.append("rdpecam client plugin found on disk")

        if capabilities:
            code = FreeRdpCapabilityStatusCode.AVAILABLE
        elif output_parts:
            code = FreeRdpCapabilityStatusCode.UNAVAILABLE
        else:
            code = FreeRdpCapabilityStatusCode.DETECTION_FAILED

        if capabilities:
            evidence.append(f"detected {len(capabilities)} capabilities")

        return FreeRdpCapabilityStatus(
            executable=executable,
            capabilities=frozenset(capabilities),
            status_code=code,
            error="; ".join(errors) or None,
            version=version,
            evidence=tuple(evidence),
        )

    def _gfx_codec_parser_accepts(self, executable: str, value: str) -> bool | None:
        """Comprova si el parser real accepta un valor de ``/gfx``.

        La destinació local al port 1 evita contactar cap servidor remot. Un
        error de connexió o un timeout significa que el parser ha acceptat la
        sintaxi i ha avançat fins a la capa de transport. Només un error
        explícit de parseig invalida la capacitat anunciada per ``/help``.
        """
        command = (
            executable,
            "/v:127.0.0.1:1",
            "/u:xaac-capability-probe",
            "/cert:ignore",
            f"/gfx:{value}",
        )
        try:
            result = self.command_runner(command, min(self.timeout, 2.0))
        except subprocess.TimeoutExpired:
            return True
        except (OSError, TypeError, subprocess.SubprocessError):
            return None

        output = "\n".join(part for part in (result.stdout, result.stderr) if part)
        lowered = output.lower()
        parse_failed = (
            "command line parsing failed" in lowered
            or "parse_command_line" in lowered
            or "failed at 'gfx'" in lowered
            or 'failed at "gfx"' in lowered
        )
        return not parse_failed

    def _rdpecam_plugin_exists(self, executable: str) -> bool:
        if self.plugin_roots is None:
            roots = [
                Path("/usr/lib"),
                Path("/usr/lib64"),
                Path("/usr/local/lib"),
                Path(executable).parent.parent / "lib",
            ]
        else:
            roots = list(self.plugin_roots)
        patterns = ("**/*rdpecam*client*.so*", "**/*rdpecam*.so*")
        for root in roots:
            if not root.exists():
                continue
            try:
                for pattern in patterns:
                    if next(root.glob(pattern), None) is not None:
                        return True
            except OSError:
                continue
        return False

    @staticmethod
    def _run_command(
        command: Sequence[str], timeout: float
    ) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            tuple(command),
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass
from pathlib import Path
from tempfile import NamedTemporaryFile
from uuid import uuid4


class RemoteDeviceIdentityError(ValueError):
    """La identitat local o el destinatari de política no són vàlids."""


_ID_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$")


@dataclass(frozen=True, slots=True)
class RemoteDeviceIdentity:
    device_id: str
    device_name: str

    def __post_init__(self) -> None:
        if not _ID_PATTERN.fullmatch(self.device_id):
            raise RemoteDeviceIdentityError("L'identificador del dispositiu no és vàlid.")
        if not self.device_name.strip() or any(c in self.device_name for c in "\n\r\x00"):
            raise RemoteDeviceIdentityError("El nom del dispositiu no és vàlid.")


@dataclass(frozen=True, slots=True)
class RemotePolicyTarget:
    device_id: str | None = None
    device_name: str | None = None

    @property
    def present(self) -> bool:
        return self.device_id is not None or self.device_name is not None


@dataclass(frozen=True, slots=True)
class RemoteDeviceIdentityMatch:
    required: bool
    target_present: bool
    matched: bool
    identity_available: bool = False


class RemoteDeviceIdentityStore:
    """Crea una identitat aleatòria una sola vegada i la conserva amb 0600."""

    def __init__(self, path: Path) -> None:
        self._path = path

    def load_or_create(self, device_name: str) -> RemoteDeviceIdentity:
        if self._path.is_file():
            return self._read()
        identity = RemoteDeviceIdentity(device_id=str(uuid4()), device_name=device_name.strip())
        self._write(identity)
        return identity

    def _read(self) -> RemoteDeviceIdentity:
        try:
            payload = json.loads(self._path.read_text(encoding="utf-8"))
            if not isinstance(payload, dict) or payload.get("schema_version") != 1:
                raise ValueError
            return RemoteDeviceIdentity(
                device_id=str(payload["device_id"]),
                device_name=str(payload["device_name"]),
            )
        except (OSError, ValueError, KeyError, json.JSONDecodeError) as error:
            raise RemoteDeviceIdentityError("No s'ha pogut llegir la identitat del dispositiu.") from error

    def _write(self, identity: RemoteDeviceIdentity) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        payload = {"schema_version": 1, "device_id": identity.device_id, "device_name": identity.device_name}
        temp_name: str | None = None
        try:
            with NamedTemporaryFile("w", encoding="utf-8", dir=self._path.parent,
                                   prefix=".device-identity-", suffix=".tmp", delete=False) as handle:
                temp_name = handle.name
                json.dump(payload, handle, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
                handle.flush()
                os.fsync(handle.fileno())
            os.chmod(temp_name, 0o600)
            os.replace(temp_name, self._path)
            os.chmod(self._path, 0o600)
        finally:
            if temp_name and os.path.exists(temp_name):
                os.unlink(temp_name)


class RemoteDeviceIdentityValidator:
    @staticmethod
    def validate(
        identity: RemoteDeviceIdentity | None,
        target: RemotePolicyTarget | None,
        *,
        required: bool,
    ) -> RemoteDeviceIdentityMatch:
        present = bool(target and target.present)
        if required and not present:
            raise RemoteDeviceIdentityError("La política remota exigeix un destinatari de dispositiu.")
        if not present:
            return RemoteDeviceIdentityMatch(required=required, target_present=False, matched=False, identity_available=identity is not None)
        if identity is None:
            raise RemoteDeviceIdentityError("No hi ha identitat local per validar el destinatari.")
        assert target is not None
        if target.device_id is not None and target.device_id != identity.device_id:
            raise RemoteDeviceIdentityError("La política remota està destinada a un altre dispositiu.")
        if target.device_name is not None and target.device_name != identity.device_name:
            raise RemoteDeviceIdentityError("La política remota està destinada a un altre nom de dispositiu.")
        return RemoteDeviceIdentityMatch(required=required, target_present=True, matched=True, identity_available=True)

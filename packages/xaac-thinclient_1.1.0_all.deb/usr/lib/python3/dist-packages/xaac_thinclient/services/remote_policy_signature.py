from __future__ import annotations

import base64
import json
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType
from typing import Any, Mapping

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey


class RemotePolicySignatureError(ValueError):
    """La signatura d'una política remota no és vàlida o no és verificable."""


@dataclass(frozen=True, slots=True)
class RemotePolicySignature:
    key_id: str
    value: str
    algorithm: str = "ed25519"


@dataclass(frozen=True, slots=True)
class RemotePolicySignatureVerification:
    required: bool
    present: bool
    verified: bool
    key_id: str | None = None
    algorithm: str | None = None


class RemotePolicySignatureVerifier:
    """Verifica signatures Ed25519 sobre la representació JSON canònica."""

    def __init__(self, trusted_keys: Mapping[str, Ed25519PublicKey] | None = None) -> None:
        self._trusted_keys = MappingProxyType(dict(trusted_keys or {}))

    @classmethod
    def from_pem_file(
        cls, path: Path | None, *, key_id: str = "default"
    ) -> "RemotePolicySignatureVerifier":
        if path is None:
            return cls()
        try:
            raw = path.read_bytes()
            key = serialization.load_pem_public_key(raw)
        except (OSError, ValueError, TypeError) as error:
            raise RemotePolicySignatureError(
                "No s'ha pogut carregar la clau pública de confiança."
            ) from error
        if not isinstance(key, Ed25519PublicKey):
            raise RemotePolicySignatureError(
                "La clau de confiança ha de ser Ed25519."
            )
        return cls({key_id: key})

    @staticmethod
    def canonical_payload(
        schema_version: int,
        policy: Mapping[str, Any],
        *,
        issued_at: str | None = None,
        expires_at: str | None = None,
        policy_revision: int | None = None,
        target: Mapping[str, Any] | None = None,
    ) -> bytes:
        payload: dict[str, Any] = {"policy": dict(policy), "schema_version": schema_version}
        if issued_at is not None:
            payload["issued_at"] = issued_at
        if expires_at is not None:
            payload["expires_at"] = expires_at
        if policy_revision is not None:
            payload["policy_revision"] = policy_revision
        if target is not None:
            payload["target"] = dict(target)
        return json.dumps(
            payload,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")

    def verify(
        self,
        *,
        schema_version: int,
        policy: Mapping[str, Any],
        signature: RemotePolicySignature | None,
        required: bool,
        issued_at: str | None = None,
        expires_at: str | None = None,
        policy_revision: int | None = None,
        target: Mapping[str, Any] | None = None,
    ) -> RemotePolicySignatureVerification:
        if signature is None:
            if required:
                raise RemotePolicySignatureError(
                    "La política remota exigeix una signatura vàlida."
                )
            return RemotePolicySignatureVerification(
                required=required, present=False, verified=False
            )
        if signature.algorithm.lower() != "ed25519":
            raise RemotePolicySignatureError(
                "Algorisme de signatura de política no admés."
            )
        key = self._trusted_keys.get(signature.key_id)
        if key is None:
            raise RemotePolicySignatureError(
                "La política està signada amb una clau no confiable."
            )
        try:
            value = base64.b64decode(signature.value, validate=True)
        except (ValueError, TypeError) as error:
            raise RemotePolicySignatureError(
                "La signatura de política no és Base64 vàlid."
            ) from error
        try:
            key.verify(value, self.canonical_payload(schema_version, policy, issued_at=issued_at, expires_at=expires_at, policy_revision=policy_revision, target=target))
        except InvalidSignature as error:
            raise RemotePolicySignatureError(
                "La signatura de la política no és vàlida."
            ) from error
        return RemotePolicySignatureVerification(
            required=required,
            present=True,
            verified=True,
            key_id=signature.key_id,
            algorithm="ed25519",
        )

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from pathlib import Path
import re
from typing import Callable, Iterable


class VideoPolicyMode(str, Enum):
    """Mode efectiu de la política de vídeo."""

    DISABLED = "disabled"
    ENABLED = "enabled"


class VideoStatusCode(str, Enum):
    """Codi estable de l'estat local de vídeo."""

    DISABLED = "disabled"
    READY = "ready"
    NO_CAMERA = "no-camera"
    DETECTION_FAILED = "detection-failed"


@dataclass(frozen=True, slots=True)
class VideoRedirectionPolicy:
    """Política immutable de redirecció de càmera per RDP."""

    enabled: bool = False
    required: bool = False

    @property
    def mode(self) -> VideoPolicyMode:
        return VideoPolicyMode.ENABLED if self.enabled else VideoPolicyMode.DISABLED

    @property
    def effective_required_resources(self) -> tuple[str, ...]:
        if self.enabled and self.required:
            return ("camera",)
        return ()

    @property
    def ignored_requirements(self) -> tuple[str, ...]:
        if self.required and not self.enabled:
            return ("required",)
        return ()


@dataclass(frozen=True, slots=True)
class VideoDevice:
    """Dispositiu V4L2 local que pot oferir vídeo a la sessió remota."""

    path: str
    name: str


@dataclass(frozen=True, slots=True)
class VideoRedirectionStatus:
    """Instantània de la disponibilitat local de vídeo."""

    policy: VideoRedirectionPolicy
    detected: tuple[VideoDevice, ...] = ()
    ignored_nodes: tuple[str, ...] = ()
    error: str | None = None

    @property
    def available(self) -> bool:
        return bool(self.detected)

    @property
    def ready(self) -> bool:
        return not self.policy.enabled or (self.error is None and self.available)

    @property
    def status_code(self) -> VideoStatusCode:
        if not self.policy.enabled:
            return VideoStatusCode.DISABLED
        if self.error is not None:
            return VideoStatusCode.DETECTION_FAILED
        if self.available:
            return VideoStatusCode.READY
        return VideoStatusCode.NO_CAMERA

    @property
    def status_detail(self) -> str:
        details = {
            VideoStatusCode.DISABLED: "Video redirection is disabled.",
            VideoStatusCode.READY: "At least one local camera is ready.",
            VideoStatusCode.NO_CAMERA: "No local camera was detected.",
            VideoStatusCode.DETECTION_FAILED: (
                "Local camera detection could not be completed."
            ),
        }
        return details[self.status_code]

    def required_error(self) -> str | None:
        """Retorna el motiu que impedeix complir una política obligatòria."""
        if not self.policy.enabled or not self.policy.required:
            return None
        if self.error is not None:
            return (
                "The required local camera could not be checked: "
                f"{self.error}"
            )
        if not self.available:
            return "No local camera is available."
        return None


NodeFinder = Callable[[], Iterable[Path]]
NameReader = Callable[[Path], str]


_VIDEO_NODE_RE = re.compile(r"video(?P<index>\d+)\Z")


def _video_node_sort_key(node: Path) -> tuple[int, str]:
    match = _VIDEO_NODE_RE.fullmatch(node.name)
    if match is None:
        return (2**31 - 1, node.name.casefold())
    return (int(match.group("index")), node.name.casefold())


def _normalise_device_name(raw_name: str, *, fallback: str) -> str:
    # Sysfs should expose a single line, but collapsing whitespace also prevents
    # control characters from breaking diagnostic reports.
    normalised = " ".join(raw_name.split())
    return normalised or fallback


def _is_safe_video_node(node: Path) -> bool:
    return node.parent == Path("/dev") and _VIDEO_NODE_RE.fullmatch(node.name) is not None


def _default_node_finder() -> Iterable[Path]:
    return sorted(Path("/dev").glob("video*"), key=_video_node_sort_key)


def _default_name_reader(node: Path) -> str:
    sysfs_name = Path("/sys/class/video4linux") / node.name / "name"
    return sysfs_name.read_text(encoding="utf-8", errors="replace").strip()


class VideoRedirectionService:
    """Construeix RDPECAM i detecta dispositius locals V4L2.

    La detecció usa els nodes ``/dev/video*`` i els noms publicats per sysfs,
    sense requerir paquets opcionals. El proveïdor és injectable per facilitar
    proves i mantindre separada la detecció de la construcció de FreeRDP.
    """

    def __init__(
        self,
        *,
        node_finder: NodeFinder = _default_node_finder,
        name_reader: NameReader = _default_name_reader,
    ) -> None:
        self._node_finder = node_finder
        self._name_reader = name_reader

    def get_policy(self, *, enabled: bool, required: bool = False) -> VideoRedirectionPolicy:
        return VideoRedirectionPolicy(enabled=bool(enabled), required=bool(required))

    def build_arguments(self, policy: VideoRedirectionPolicy) -> tuple[str, ...]:
        if not policy.enabled:
            return ()
        return ("/dvc:rdpecam",)

    def get_status(self, policy: VideoRedirectionPolicy) -> VideoRedirectionStatus:
        if not policy.enabled:
            return VideoRedirectionStatus(policy=policy)

        try:
            raw_nodes = tuple(self._node_finder())
            nodes: list[Path] = []
            ignored_nodes: list[str] = []
            for raw_node in raw_nodes:
                try:
                    node = Path(raw_node)
                except (TypeError, ValueError):
                    ignored_nodes.append(repr(raw_node))
                    continue
                if not _is_safe_video_node(node):
                    ignored_nodes.append(str(node))
                    continue
                nodes.append(node)

            devices: list[VideoDevice] = []
            seen_paths: set[str] = set()
            for node in sorted(nodes, key=_video_node_sort_key):
                path = str(node)
                if path in seen_paths:
                    ignored_nodes.append(path)
                    continue
                seen_paths.add(path)
                try:
                    raw_name = self._name_reader(node)
                except (OSError, UnicodeError, ValueError):
                    raw_name = ""
                devices.append(
                    VideoDevice(
                        path=path,
                        name=_normalise_device_name(raw_name, fallback=node.name),
                    )
                )
            return VideoRedirectionStatus(
                policy=policy,
                detected=tuple(devices),
                ignored_nodes=tuple(ignored_nodes),
            )
        except (OSError, RuntimeError) as error:
            detail = str(error).strip() or type(error).__name__
            return VideoRedirectionStatus(policy=policy, error=detail)

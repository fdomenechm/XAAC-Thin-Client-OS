from __future__ import annotations

import socket
from dataclasses import dataclass

from xaac_thinclient.services.logging import get_logger
from xaac_thinclient.i18n import _


logger = get_logger(__name__)


@dataclass(frozen=True, slots=True)
class DnsStatus:
    resolved: bool
    hostname: str
    addresses: tuple[str, ...] = ()
    canonical_name: str | None = None
    error: str | None = None


class DnsService:
    """
    Resol noms DNS mitjançant el resolutor configurat
    en el sistema operatiu.

    No comprova encara si el port RDP està accessible.
    """

    def resolve(self, hostname: str) -> DnsStatus:
        logger.debug(
            "Resolent el servidor %s",
            hostname,
        )
        hostname = hostname.strip()

        if not hostname:
            return DnsStatus(
                resolved=False,
                hostname=hostname,
                error=_("The server name is empty."),
            )

        try:
            results = socket.getaddrinfo(
                hostname,
                None,
                family=socket.AF_INET,
                type=socket.SOCK_STREAM,
            )

        except socket.gaierror as error:
            logger.warning(
                "Error de resolució DNS per a %s: %s",
                hostname,
                error,
            )
            return DnsStatus(
                resolved=False,
                hostname=hostname,
                error=self._format_gai_error(error),
            )
        except OSError as error:
            return DnsStatus(
                resolved=False,
                hostname=hostname,
                error=str(error),
            )

        addresses: list[str] = []
        canonical_name: str | None = None

        for result in results:
            _family, _socket_type, _protocol, canonname, sockaddr = result

            if canonname and canonical_name is None:
                canonical_name = canonname

            ip_address = sockaddr[0]

            if ip_address not in addresses:
                addresses.append(ip_address)

        if not addresses:
            return DnsStatus(
                resolved=False,
                hostname=hostname,
                error=_("The DNS query returned no IPv4 address."),
            )

        logger.debug(
            "Resolució DNS correcta: servidor=%s, adreces=%s",
            hostname,
            addresses,
        )
        return DnsStatus(
            resolved=True,
            hostname=hostname,
            addresses=tuple(addresses),
            canonical_name=canonical_name,
        )

    @staticmethod
    def _format_gai_error(error: socket.gaierror) -> str:
        if error.errno == socket.EAI_NONAME:
            return _("The server does not exist in DNS.")

        if error.errno == socket.EAI_AGAIN:
            return _("The DNS server is temporarily unavailable.")

        return str(error)
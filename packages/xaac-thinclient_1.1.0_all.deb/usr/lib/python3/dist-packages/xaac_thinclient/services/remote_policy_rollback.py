from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import Any, Callable, Iterable


class RemotePolicyRollbackError(ValueError):
    """L'historial local de polítiques no és utilitzable de manera segura."""


@dataclass(frozen=True, slots=True)
class RemotePolicyRollbackCandidate:
    path: Path
    payload: dict[str, Any]
    revision: int | None


@dataclass(frozen=True, slots=True)
class RemotePolicyRollbackReport:
    enabled: bool
    used: bool = False
    revision: int | None = None
    candidates_checked: int = 0


Validator = Callable[[dict[str, Any]], int | None]


class RemotePolicyRollbackStore:
    """Historial atòmic i limitat de documents remots validats.

    El magatzem no decideix si una política és vàlida: cada lectura de rollback
    torna a passar per esquema, signatura i vigència mitjançant ``validator``.
    """

    def __init__(self, directory: Path, *, max_entries: int = 5) -> None:
        if max_entries < 1 or max_entries > 50:
            raise RemotePolicyRollbackError(
                "El nombre de polítiques de rollback ha d'estar entre 1 i 50."
            )
        self.directory = directory
        self.max_entries = max_entries

    def save(self, payload: dict[str, Any], *, revision: int | None) -> None:
        self.directory.mkdir(parents=True, exist_ok=True)
        revision_part = f"{revision:020d}" if revision is not None else "legacy"
        # El comptador monotònic del nom evita col·lisions sense conservar dades sensibles.
        existing = len(tuple(self.directory.glob("policy-*.json")))
        target = self.directory / f"policy-{revision_part}-{existing:06d}.json"
        with NamedTemporaryFile(
            mode="w", encoding="utf-8", dir=self.directory,
            prefix=".policy-rollback-", suffix=".tmp", delete=False,
        ) as temporary:
            temporary_path = Path(temporary.name)
            json.dump(payload, temporary, ensure_ascii=False, sort_keys=True, indent=2)
            temporary.write("\n")
        temporary_path.chmod(0o600)
        temporary_path.replace(target)
        self._prune()

    def candidates(self) -> tuple[Path, ...]:
        if not self.directory.is_dir():
            return ()
        return tuple(sorted(self.directory.glob("policy-*.json"), reverse=True))

    def select(self, validator: Validator) -> tuple[RemotePolicyRollbackCandidate | None, int]:
        checked = 0
        valid: list[RemotePolicyRollbackCandidate] = []
        for path in self.candidates():
            checked += 1
            try:
                payload = json.loads(path.read_text(encoding="utf-8"))
                if not isinstance(payload, dict):
                    continue
                revision = validator(payload)
                valid.append(RemotePolicyRollbackCandidate(path, payload, revision))
            except Exception:
                continue
        if not valid:
            return None, checked
        # Preferim la revisió més alta; per documents sense revisió, l'ordre del fitxer.
        valid.sort(key=lambda item: (-1 if item.revision is None else item.revision, item.path.name), reverse=True)
        return valid[0], checked

    def highest_revision(self, validator: Validator) -> int | None:
        revisions: list[int] = []
        for path in self.candidates():
            try:
                payload = json.loads(path.read_text(encoding="utf-8"))
                if not isinstance(payload, dict):
                    continue
                revision = validator(payload)
                if revision is not None:
                    revisions.append(revision)
            except Exception:
                continue
        return max(revisions) if revisions else None

    def _prune(self) -> None:
        entries = sorted(self.directory.glob("policy-*.json"), reverse=True)
        for path in entries[self.max_entries:]:
            try:
                path.unlink()
            except OSError:
                pass

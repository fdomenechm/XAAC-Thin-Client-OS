from __future__ import annotations

import platform
import shutil
import socket
import subprocess
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from xaac_thinclient import __version__
from xaac_thinclient.config.models import ThinClientConfig
from xaac_thinclient.config.policy import ConfigurationMetadata
from xaac_thinclient.core.errors import ApplicationError
from xaac_thinclient.core.state import ApplicationState
from xaac_thinclient.paths import LOG_FILE, USER_STATE_DIR
from xaac_thinclient.services.usb import UsbService
from xaac_thinclient.services.drives import DriveRedirectionService
from xaac_thinclient.services.printers import PrinterRedirectionService
from xaac_thinclient.services.audio import AudioRedirectionService
from xaac_thinclient.services.video import VideoRedirectionService
from xaac_thinclient.services.clipboard import ClipboardRedirectionService
from xaac_thinclient.services.keyboard import KeyboardService
from xaac_thinclient.services.pkcs11 import Pkcs11ModuleService
from xaac_thinclient.services.freerdp_capabilities import (
    FreeRdpCapability,
    FreeRdpCapabilityService,
)


@dataclass(frozen=True, slots=True)
class DiagnosticSection:
    """Secció immutable d'un informe de diagnòstic."""

    title: str
    values: tuple[tuple[str, str], ...]


@dataclass(frozen=True, slots=True)
class DiagnosticReport:
    """Informe de diagnòstic textual, segur per compartir amb suport."""

    generated_at: datetime
    sections: tuple[DiagnosticSection, ...]

    def render_text(self) -> str:
        lines = [
            "XAAC Thin Client Remote Diagnostic Report",
            "==================================",
            f"Generated at: {self.generated_at.isoformat()}",
            "",
        ]

        for section in self.sections:
            lines.append(section.title)
            lines.append("-" * len(section.title))
            lines.extend(
                f"{name}: {value}"
                for name, value in section.values
            )
            lines.append("")

        return "\n".join(lines).rstrip() + "\n"

    def suggested_filename(self) -> str:
        """Retorna un nom de fitxer estable basat en la data de generació."""
        timestamp = self.generated_at.strftime("%Y%m%d-%H%M%S")
        return f"xaac-diagnostic-{timestamp}.txt"

    def save(self, destination: Path) -> Path:
        destination = destination.expanduser()
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(self.render_text(), encoding="utf-8")
        return destination


class DiagnosticService:
    """Genera informes sense incloure credencials ni dades sensibles."""

    def __init__(
        self,
        *,
        log_file: Path = LOG_FILE,
        output_dir: Path = USER_STATE_DIR,
        command_timeout: float = 3.0,
        max_log_lines: int = 100,
        usb_service: UsbService | None = None,
        drive_service: DriveRedirectionService | None = None,
        printer_service: PrinterRedirectionService | None = None,
        audio_service: AudioRedirectionService | None = None,
        video_service: VideoRedirectionService | None = None,
        capability_service: FreeRdpCapabilityService | None = None,
        clipboard_service: ClipboardRedirectionService | None = None,
        keyboard_service: KeyboardService | None = None,
    ) -> None:
        self.log_file = log_file
        self.output_dir = output_dir
        self.command_timeout = command_timeout
        self.max_log_lines = max(0, max_log_lines)
        self.usb_service = usb_service or UsbService()
        self.drive_service = drive_service or DriveRedirectionService()
        self.printer_service = printer_service or PrinterRedirectionService()
        self.audio_service = audio_service or AudioRedirectionService()
        self.video_service = video_service or VideoRedirectionService()
        self.clipboard_service = clipboard_service or ClipboardRedirectionService()
        self.keyboard_service = keyboard_service or KeyboardService()
        self.capability_service = (
            capability_service or FreeRdpCapabilityService()
        )

    def generate(
        self,
        *,
        config: ThinClientConfig,
        state: ApplicationState,
        configuration_metadata: ConfigurationMetadata | None = None,
    ) -> DiagnosticReport:
        generated_at = datetime.now(timezone.utc).astimezone()

        if configuration_metadata is None:
            configuration_metadata = ConfigurationMetadata.system_defaults()

        return DiagnosticReport(
            generated_at=generated_at,
            sections=(
                self._application_section(config),
                self._system_section(),
                self._network_section(state),
                self._rdp_section(config, state, configuration_metadata),
                self._freerdp_capabilities_section(config),
                self._smartcard_section(config, state),
                self._usb_section(config),
                self._drives_section(config),
                self._printers_section(config),
                self._audio_section(config),
                self._video_section(config),
                self._clipboard_section(config, configuration_metadata),
                self._configuration_section(configuration_metadata),
                self._error_section(state.current_error),
                self._log_section(),
            ),
        )

    def generate_and_save(
        self,
        *,
        config: ThinClientConfig,
        state: ApplicationState,
        configuration_metadata: ConfigurationMetadata | None = None,
        destination: Path | None = None,
    ) -> Path:
        report = self.generate(
            config=config,
            state=state,
            configuration_metadata=configuration_metadata,
        )

        if destination is None:
            destination = self.output_dir / report.suggested_filename()

        return report.save(destination)

    @staticmethod
    def _application_section(
        config: ThinClientConfig,
    ) -> DiagnosticSection:
        return DiagnosticSection(
            title="Application",
            values=(
                ("Version", __version__),
                ("Language", config.application.language),
                ("Device name", config.device.device_name),
                ("Description", config.device.description or "-"),
                ("Author", config.application.author),
                ("Application logo", config.application.logo),
            ),
        )

    def _system_section(self) -> DiagnosticSection:
        executable = shutil.which("xfreerdp3")
        return DiagnosticSection(
            title="System",
            values=(
                ("Hostname", socket.gethostname()),
                ("Operating system", platform.platform()),
                ("Python", platform.python_version()),
                ("Architecture", platform.machine() or "unknown"),
                ("xfreerdp3 path", executable or "not found"),
                ("xfreerdp3 version", self._xfreerdp_version(executable)),
            ),
        )


    def _freerdp_capabilities_section(self, config: ThinClientConfig) -> DiagnosticSection:
        status = self.capability_service.get_status()
        degradation = self.capability_service.apply_safe_degradation(
            config, status=status
        )
        compatibility = degradation.compatibility
        render = lambda values: ", ".join(
            sorted(item.value for item in values)
        ) or "-"
        supported = ", ".join(
            capability.value for capability in sorted(
                status.capabilities, key=lambda item: item.value
            )
        ) or "-"
        return DiagnosticSection(
            title="FreeRDP capabilities",
            values=(
                ("Executable", status.executable or "not found"),
                ("Executable name", status.executable_name),
                ("Detected version", status.version or "unknown"),
                ("Health summary", status.health_summary),
                ("Detection status", status.status_code.value),
                ("Snapshot source", status.source.value),
                ("Cache age (seconds)", str(status.cache_age_seconds)),
                ("Detected capability count", str(status.detected_count)),
                ("Capability coverage", f"{status.detected_count}/{len(FreeRdpCapability)}"),
                ("Supported capabilities", supported),
                ("Smartcard available", _yes_no(status.supports(FreeRdpCapability.SMARTCARD))),
                ("Clipboard available", _yes_no(status.supports(FreeRdpCapability.CLIPBOARD))),
                ("Drive available", _yes_no(status.supports(FreeRdpCapability.DRIVE))),
                ("USB available", _yes_no(status.supports(FreeRdpCapability.USB))),
                ("Audio output available", _yes_no(status.supports(FreeRdpCapability.AUDIO_OUTPUT))),
                ("Audio input available", _yes_no(status.supports(FreeRdpCapability.AUDIO_INPUT))),
                ("Multimon available", _yes_no(status.supports(FreeRdpCapability.MULTIMON))),
                ("RDPECAM available", _yes_no(status.supports(FreeRdpCapability.RDPECAM))),
                ("Configuration compatible", _yes_no(compatibility.compatible)),
                ("Connection allowed", _yes_no(compatibility.connection_allowed)),
                ("Requested capabilities", render(compatibility.requested)),
                ("Unsupported requested capabilities", render(compatibility.unsupported)),
                ("Blocking capability mismatches", render(compatibility.blocking)),
                ("Safe degradation applied", _yes_no(bool(degradation.degraded))),
                ("Degraded optional capabilities", render(degradation.degraded)),
                ("Degraded capability count", str(degradation.degraded_count)),
                ("Evidence", "; ".join(status.evidence) or "-"),
                ("Detection error", status.error or "-"),
            ),
        )

    @staticmethod
    def _network_section(
        state: ApplicationState,
    ) -> DiagnosticSection:
        return DiagnosticSection(
            title="Network and DNS",
            values=(
                ("Connected", _yes_no(state.network_connected)),
                ("Interface", state.network_interface or "-"),
                ("Local IP", state.local_ip or "-"),
                ("Network error", state.network_error or "-"),
                ("DNS resolved", _yes_no(state.dns_resolved)),
                (
                    "Resolved addresses",
                    ", ".join(state.resolved_addresses) or "-",
                ),
                ("DNS error", state.dns_error or "-"),
            ),
        )

    def _rdp_section(
        self,
        config: ThinClientConfig,
        state: ApplicationState,
        metadata: ConfigurationMetadata,
    ) -> DiagnosticSection:
        keyboard = self.keyboard_service.resolve(
            config.keyboard.layout, config.application.language
        )
        return DiagnosticSection(
            title="Remote desktop",
            values=(
                ("Server", config.device.server),
                ("Port", str(config.rdp.port)),
                ("Domain", config.rdp.domain),
                ("Keyboard configured", config.keyboard.layout),
                ("Keyboard configuration source", metadata.source_for("keyboard.layout").value),
                (
                    "Keyboard remotely managed",
                    _yes_no(
                        metadata.source_for("keyboard.layout").value
                        in {"remote", "cache", "rollback"}
                    ),
                ),
                ("Keyboard effective", keyboard.effective_layout),
                ("Keyboard layout ID", keyboard.layout_id),
                ("Keyboard source", keyboard.source),
                ("Keyboard status code", keyboard.status_code.value),
                ("Keyboard status detail", keyboard.status_detail),
                ("Keyboard detected layout", keyboard.detected_layout or "-"),
                ("Keyboard detected variant", keyboard.detected_variant or "-"),
                ("Fullscreen", _yes_no(config.rdp.fullscreen)),
                ("Window width", str(config.rdp.width)),
                ("Window height", str(config.rdp.height)),
                (
                    "Dynamic resolution",
                    _yes_no(config.rdp.dynamic_resolution),
                ),
                ("Smart sizing", _yes_no(config.rdp.smart_sizing)),
                ("Color depth", str(config.rdp.color_depth)),
                ("Network profile", config.rdp.network_profile.value),
                ("Font smoothing", _yes_no(config.rdp.font_smoothing)),
                (
                    "Desktop composition",
                    _yes_no(config.rdp.desktop_composition),
                ),
                ("Wallpaper", _yes_no(config.rdp.wallpaper)),
                ("Menu animations", _yes_no(config.rdp.menu_animations)),
                ("Window drag", _yes_no(config.rdp.window_drag)),
                ("Themes", _yes_no(config.rdp.themes)),
                ("Bitmap cache", _yes_no(config.rdp.bitmap_cache)),
                ("Available", _yes_no(state.rdp_available)),
                ("Availability error", state.rdp_error or "-"),
                ("Session running", _yes_no(state.rdp_session_running)),
                (
                    "Last return code",
                    _optional_value(state.session_return_code),
                ),
                ("Session error", state.session_error or "-"),
            ),
        )



    @staticmethod
    def _smartcard_section(
        config: ThinClientConfig,
        state: ApplicationState,
    ) -> DiagnosticSection:
        pkcs11 = Pkcs11ModuleService().inspect(config.smartcard.pkcs11_module)
        return DiagnosticSection(
            title="Smart Card",
            values=(
                ("Enabled", _yes_no(config.smartcard.enabled)),
                ("Required", _yes_no(config.smartcard.required)),
                ("Redirect policy", _yes_no(config.smartcard.share)),
                ("Redirect effective", _yes_no(config.smartcard.redirection_enabled)),
                ("Preferred reader", config.smartcard.preferred_reader or "-"),
                ("PKCS#11 configured", _yes_no(pkcs11.configured)),
                ("PKCS#11 module", pkcs11.module_name or "-"),
                ("PKCS#11 available", _yes_no(pkcs11.available)),
                ("PKCS#11 status code", pkcs11.status_code.value),
                ("PKCS#11 status detail", pkcs11.status_detail),
                ("PKCS#11 compatibility", pkcs11.compatibility_code.value),
                ("PKCS#11 compatibility detail", pkcs11.compatibility_detail),
                (
                    "PKCS#11 module bitness",
                    str(pkcs11.module_bitness) if pkcs11.module_bitness else "-",
                ),
                ("Local process bitness", str(pkcs11.process_bitness)),
                ("Policy mode", state.smartcard_policy_mode),
                (
                    "Effective requirements",
                    "; ".join(state.smartcard_effective_requirements) or "-",
                ),
                ("PC/SC library available", _yes_no(state.smartcard_pcsc_available)),
                ("pcscd running", _yes_no(state.smartcard_pcscd_running)),
                ("Status code", state.smartcard_status_code),
                ("Status detail", state.smartcard_status_detail),
                ("Ready", _yes_no(state.smartcard_ready)),
                ("Reader selection mode", state.smartcard_reader_mode),
                ("Preferred reader matched", _yes_no(state.smartcard_preferred_reader_matched)),
                ("Detected reader count", str(state.smartcard_detected_reader_count)),
                ("Eligible reader count", str(state.smartcard_eligible_reader_count)),
                ("Reader count", str(state.smartcard_reader_count)),
                ("Detected readers", "; ".join(state.smartcard_readers) or "-"),
                ("Card present", _yes_no(state.smartcard_card_present)),
                (
                    "Readers with card",
                    "; ".join(state.smartcard_readers_with_card) or "-",
                ),
                ("Last error", state.smartcard_error or "-"),
            ),
        )


    def _usb_section(
        self,
        config: ThinClientConfig,
    ) -> DiagnosticSection:
        status = self.usb_service.get_status(
            enabled=config.usb.enabled,
            allowed_devices=config.usb.allowed_devices,
            blocked_devices=config.usb.blocked_devices,
        )

        def describe(devices: tuple[object, ...]) -> str:
            return "; ".join(
                f"{device.display_name} [{device.identifier}]"
                for device in devices
            ) or "-"

        return DiagnosticSection(
            title="USB",
            values=(
                ("Enabled", _yes_no(config.usb.enabled)),
                (
                    "Allowed devices",
                    ", ".join(config.usb.allowed_devices) or "-",
                ),
                (
                    "Blocked devices",
                    ", ".join(config.usb.blocked_devices) or "-",
                ),
                ("Detected devices", describe(status.detected)),
                ("Redirected devices", describe(status.allowed)),
                ("Rejected devices", describe(status.blocked)),
                ("Detection error", status.error or "-"),
            ),
        )

    def _drives_section(
        self,
        config: ThinClientConfig,
    ) -> DiagnosticSection:
        status = self.drive_service.get_status(
            enabled=config.drives.enabled,
            include_existing=config.drives.include_existing,
            allowed_roots=config.drives.allowed_roots,
        )
        shares = "; ".join(
            f"{share.name} [{share.path}]"
            for share in status.shares
        ) or "-"
        return DiagnosticSection(
            title="Drive redirection",
            values=(
                ("Enabled", _yes_no(config.drives.enabled)),
                (
                    "Include existing media",
                    _yes_no(config.drives.include_existing),
                ),
                ("Hotplug", _yes_no(config.drives.hotplug)),
                (
                    "Allowed mount roots",
                    ", ".join(config.drives.allowed_roots) or "-",
                ),
                ("Detected shares", shares),
                ("Detection error", status.error or "-"),
            ),
        )

    def _printers_section(
        self,
        config: ThinClientConfig,
    ) -> DiagnosticSection:
        status = self.printer_service.get_status(
            enabled=config.printers.enabled,
            allowed_printers=config.printers.allowed_printers,
            default_only=config.printers.default_only,
        )

        def describe(printers: tuple[object, ...]) -> str:
            return "; ".join(
                f"{printer.name}{' [default]' if printer.is_default else ''}"
                for printer in printers
            ) or "-"

        return DiagnosticSection(
            title="Printer redirection",
            values=(
                ("Enabled", _yes_no(config.printers.enabled)),
                (
                    "Allowed printers",
                    ", ".join(config.printers.allowed_printers) or "all",
                ),
                ("Default only", _yes_no(config.printers.default_only)),
                ("Required", _yes_no(config.printers.required)),
                ("Policy mode", status.policy_mode.value),
                (
                    "Effective allowlist",
                    ", ".join(status.effective_allowlist) or "-",
                ),
                (
                    "Ignored allowlist entries",
                    ", ".join(status.ignored_allowlist) or "-",
                ),
                ("Ready", _yes_no(status.ready)),
                ("Status code", status.status_code.value),
                ("Status detail", status.status_detail),
                ("Detected printers", describe(status.detected)),
                ("Redirected printers", describe(status.redirected)),
                ("Rejected printers", describe(status.rejected)),
                ("Detection error", status.error or "-"),
            ),
        )

    def _audio_section(
        self,
        config: ThinClientConfig,
    ) -> DiagnosticSection:
        policy = self.audio_service.get_policy(
            playback_enabled=config.audio.playback_enabled,
            recording_enabled=config.audio.recording_enabled,
            playback_required=config.audio.playback_required,
            recording_required=config.audio.recording_required,
        )
        status = self.audio_service.get_status(policy)

        def describe(devices: tuple[object, ...]) -> str:
            return "; ".join(
                f"{device.name}{' (default)' if device.is_default else ''}"
                for device in devices
            ) or "-"

        return DiagnosticSection(
            title="Audio redirection",
            values=(
                ("Playback enabled", _yes_no(policy.playback_enabled)),
                ("Playback required", _yes_no(policy.playback_required)),
                ("Recording enabled", _yes_no(policy.recording_enabled)),
                ("Recording required", _yes_no(policy.recording_required)),
                ("Policy mode", policy.mode.value),
                (
                    "Effective required resources",
                    ", ".join(policy.effective_required_resources) or "-",
                ),
                (
                    "Ignored requirements",
                    ", ".join(policy.ignored_requirements) or "-",
                ),
                ("Audio backend", status.backend or "-"),
                ("Status code", status.status_code.value),
                ("Status detail", status.status_detail),
                ("Playback status code", status.playback_status_code.value),
                (
                    "Playback status detail",
                    status.resource_status_detail(
                        status.playback_status_code,
                        resource="Playback",
                    ),
                ),
                ("Playback available", _yes_no(status.playback_available)),
                ("Playback ready", _yes_no(status.playback_ready)),
                ("Playback devices", describe(status.playback_devices)),
                ("Recording status code", status.recording_status_code.value),
                (
                    "Recording status detail",
                    status.resource_status_detail(
                        status.recording_status_code,
                        resource="Recording",
                    ),
                ),
                ("Recording available", _yes_no(status.recording_available)),
                ("Recording ready", _yes_no(status.recording_ready)),
                ("Recording devices", describe(status.recording_devices)),
                ("Detection error", status.error or "-"),
            ),
        )

    def _video_section(
        self,
        config: ThinClientConfig,
    ) -> DiagnosticSection:
        policy = self.video_service.get_policy(
            enabled=config.video.enabled,
            required=config.video.required,
        )
        status = self.video_service.get_status(policy)
        devices = "; ".join(
            f"{device.name} [{device.path}]"
            for device in status.detected
        ) or "-"
        return DiagnosticSection(
            title="Video redirection",
            values=(
                ("Enabled", _yes_no(policy.enabled)),
                ("Required", _yes_no(policy.required)),
                ("Policy mode", policy.mode.value),
                (
                    "Effective required resources",
                    ", ".join(policy.effective_required_resources) or "-",
                ),
                (
                    "Ignored requirements",
                    ", ".join(policy.ignored_requirements) or "-",
                ),
                ("Status code", status.status_code.value),
                ("Status detail", status.status_detail),
                ("Available", _yes_no(status.available)),
                ("Ready", _yes_no(status.ready)),
                ("Detected cameras", devices),
                ("Ignored video nodes", ", ".join(status.ignored_nodes) or "-"),
                ("Detection error", status.error or "-"),
            ),
        )

    def _clipboard_section(
        self,
        config: ThinClientConfig,
        metadata: ConfigurationMetadata,
    ) -> DiagnosticSection:
        resolution = self.clipboard_service.resolve_policy(
            enabled=config.clipboard.enabled,
            profile=config.clipboard.profile,
            direction=config.clipboard.direction,
            files=config.clipboard.files,
        )
        policy = resolution.policy
        status = self.clipboard_service.get_status(policy)
        return DiagnosticSection(
            title="Clipboard redirection",
            values=(
                ("Configured profile", config.clipboard.profile.value),
                ("Profile source", metadata.source_for("clipboard.profile").value),
                ("Enabled", _yes_no(policy.enabled)),
                ("Enabled source", metadata.source_for("clipboard.enabled").value),
                ("Policy mode", policy.mode.value),
                ("Content direction", policy.direction.value),
                ("Content direction source", metadata.source_for("clipboard.direction").value),
                ("File direction", policy.files.value),
                ("File direction source", metadata.source_for("clipboard.files").value),
                ("Profile overrides settings", _yes_no(resolution.has_overrides)),
                (
                    "Overridden settings",
                    ", ".join(resolution.overridden_fields) or "-",
                ),
                ("Policy normalized", _yes_no(resolution.has_normalizations)),
                (
                    "Normalized settings",
                    ", ".join(resolution.normalized_fields) or "-",
                ),
                (
                    "Remotely managed",
                    _yes_no(any(
                        metadata.source_for(path).value in {"remote", "cache", "rollback"}
                        for path in (
                            "clipboard.enabled",
                            "clipboard.profile",
                            "clipboard.direction",
                            "clipboard.files",
                        )
                    )),
                ),
                ("Status code", status.status_code.value),
                ("Status detail", status.status_detail),
                ("Ready", _yes_no(status.ready)),
                (
                    "FreeRDP argument",
                    self.clipboard_service.build_arguments(policy)[0],
                ),
            ),
        )

    @staticmethod
    def _configuration_section(
        metadata: ConfigurationMetadata,
    ) -> DiagnosticSection:
        source = metadata.remote_source.value
        applied = ", ".join(metadata.applied_remote_keys) or "-"
        rejected = ", ".join(metadata.rejected_remote_keys) or "-"
        values = [
            ("Effective remote source", source),
            ("Applied remote keys", applied),
            ("Rejected remote keys", rejected),
            ("Remote warning", metadata.warning or "-"),
            ("Server source", metadata.source_for("device.server").value),
            ("Domain source", metadata.source_for("rdp.domain").value),
            ("Port source", metadata.source_for("rdp.port").value),
            (
                "Fullscreen source",
                metadata.source_for("rdp.fullscreen").value,
            ),
            (
                "Resolution source",
                metadata.source_for("rdp.width").value,
            ),
            (
                "Network profile source",
                metadata.source_for("rdp.network_profile").value,
            ),
            ("Language source", metadata.source_for("application.language").value),
            ("Smart Card enabled source", metadata.source_for("smartcard.enabled").value),
            ("Smart Card required source", metadata.source_for("smartcard.required").value),
            ("Smart Card redirect source", metadata.source_for("smartcard.share").value),
            ("Smart Card reader source", metadata.source_for("smartcard.preferred_reader").value),
            ("Smart Card PKCS#11 source", metadata.source_for("smartcard.pkcs11_module").value),
            ("USB source", metadata.source_for("usb.enabled").value),
            (
                "Drive redirection source",
                metadata.source_for("drives.enabled").value,
            ),
            (
                "Printer redirection source",
                metadata.source_for("printers.enabled").value,
            ),
        ]
        return DiagnosticSection(
            title="Configuration policy",
            values=tuple(values),
        )

    @staticmethod
    def _error_section(
        error: ApplicationError | None,
    ) -> DiagnosticSection:
        if error is None:
            values = (("Current error", "none"),)
        else:
            values = (
                ("Code", error.code),
                ("Category", error.category.name),
                ("Severity", error.severity.name),
                ("Recoverable", _yes_no(error.recoverable)),
                ("User message", error.user_message),
                ("Technical detail", error.technical_detail or "-"),
            )

        return DiagnosticSection(
            title="Current error",
            values=values,
        )

    def _log_section(self) -> DiagnosticSection:
        return DiagnosticSection(
            title="Recent log",
            values=(("Lines", self._read_log_tail()),),
        )

    def _read_log_tail(self) -> str:
        if self.max_log_lines == 0:
            return "disabled"

        try:
            lines = self.log_file.read_text(
                encoding="utf-8",
                errors="replace",
            ).splitlines()
        except FileNotFoundError:
            return "log file not found"
        except OSError as error:
            return f"could not read log: {error}"

        tail = lines[-self.max_log_lines :]
        return "\n".join(tail) if tail else "log file is empty"

    def _xfreerdp_version(self, executable: str | None) -> str:
        if executable is None:
            return "not available"

        try:
            result = subprocess.run(
                [executable, "/version"],
                capture_output=True,
                text=True,
                timeout=self.command_timeout,
                check=False,
            )
        except (OSError, subprocess.SubprocessError) as error:
            return f"could not determine: {error}"

        output = (result.stdout or result.stderr).strip()
        return output.splitlines()[0] if output else "unknown"


def _yes_no(value: bool) -> str:
    return "yes" if value else "no"


def _optional_value(value: object | None) -> str:
    return "-" if value is None else str(value)

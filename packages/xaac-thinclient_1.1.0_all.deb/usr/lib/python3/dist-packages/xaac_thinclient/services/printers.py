from __future__ import annotations

import os
import re
import shutil
import subprocess
from dataclasses import dataclass
from enum import Enum
from typing import Protocol


_SAFE_PRINTER_NAME = re.compile(r"^[A-Za-z0-9_.-]+$")


class PrinterPolicyMode(str, Enum):
    """Mode efectiu i estable de selecció de cues."""

    ALL = "all"
    ALLOWLIST = "allowlist"
    DEFAULT_ONLY = "default-only"
    ALLOWLIST_DEFAULT_ONLY = "allowlist+default-only"


class PrinterStatusCode(str, Enum):
    """Codi estable per diagnosticar la política d'impressores."""

    DISABLED = "disabled"
    READY = "ready"
    CUPS_UNAVAILABLE = "cups-unavailable"
    NO_PRINTERS = "no-printers"
    NO_AUTHORISED_PRINTER = "no-authorised-printer"
    NO_DEFAULT_PRINTER = "no-default-printer"


@dataclass(frozen=True, slots=True)
class Printer:
    name: str
    is_default: bool = False


@dataclass(frozen=True, slots=True)
class PrinterRedirectionStatus:
    enabled: bool
    detected: tuple[Printer, ...] = ()
    redirected: tuple[Printer, ...] = ()
    rejected: tuple[Printer, ...] = ()
    error: str | None = None
    status_code: PrinterStatusCode = PrinterStatusCode.DISABLED
    policy_mode: PrinterPolicyMode = PrinterPolicyMode.ALL
    effective_allowlist: tuple[str, ...] = ()
    ignored_allowlist: tuple[str, ...] = ()

    @property
    def ready(self) -> bool:
        """Indica si la redirecció pot usar almenys una cua."""
        return not self.enabled or (self.error is None and bool(self.redirected))

    @property
    def status_detail(self) -> str:
        """Explicació breu i estable per a diagnòstic i suport."""
        descriptions = {
            PrinterStatusCode.DISABLED: "Printer redirection is disabled.",
            PrinterStatusCode.READY: "At least one authorised printer is ready.",
            PrinterStatusCode.CUPS_UNAVAILABLE: (
                "The local CUPS service could not be queried."
            ),
            PrinterStatusCode.NO_PRINTERS: "No local printer was detected.",
            PrinterStatusCode.NO_AUTHORISED_PRINTER: (
                "No detected printer matches the configured allowlist."
            ),
            PrinterStatusCode.NO_DEFAULT_PRINTER: (
                "No authorised default printer is available."
            ),
        }
        return descriptions[self.status_code]

    @property
    def redirected_names(self) -> tuple[str, ...]:
        return tuple(printer.name for printer in self.redirected)

    def required_error(self, required: bool) -> str | None:
        """Retorna l'error que ha de bloquejar la sessió, si escau."""
        if not required or self.ready:
            return None
        if self.error:
            return (
                "Printer redirection is required but CUPS is unavailable: "
                f"{self.error}"
            )
        return (
            "Printer redirection is required, but no authorised local "
            "printer is available."
        )


class PrinterProvider(Protocol):
    def list_printers(self) -> tuple[Printer, ...]: ...


class CupsPrinterProvider:
    """Descobreix cues locals de CUPS sense usar bindings opcionals."""

    def __init__(self, timeout: float = 3.0) -> None:
        self.timeout = timeout

    def list_printers(self) -> tuple[Printer, ...]:
        if shutil.which("lpstat") is None:
            raise RuntimeError("No s'ha trobat l'ordre lpstat de CUPS.")

        result = subprocess.run(
            ["lpstat", "-p", "-d"],
            capture_output=True,
            text=True,
            timeout=self.timeout,
            check=False,
            # El parser necessita una eixida estable, independentment de
            # l'idioma configurat en el thin client.
            env={**os.environ, "LC_ALL": "C", "LANG": "C"},
        )
        if result.returncode not in {0, 1}:
            raise RuntimeError(result.stderr.strip() or "CUPS no ha respost.")

        names: list[str] = []
        seen_names: set[str] = set()
        default: str | None = None
        for raw_line in result.stdout.splitlines():
            line = raw_line.strip()
            if line.startswith("printer "):
                fields = line.split(maxsplit=2)
                if len(fields) < 2:
                    continue
                name = fields[1].strip()
                folded = name.casefold()
                if (
                    _SAFE_PRINTER_NAME.fullmatch(name)
                    and folded not in seen_names
                ):
                    names.append(name)
                    seen_names.add(folded)
            elif line.startswith("system default destination:"):
                candidate = line.partition(":")[2].strip()
                if _SAFE_PRINTER_NAME.fullmatch(candidate):
                    default = candidate

        default_folded = default.casefold() if default else None
        return tuple(
            Printer(name, name.casefold() == default_folded)
            for name in names
        )


class PrinterRedirectionService:
    def __init__(self, provider: PrinterProvider | None = None) -> None:
        self.provider = provider or CupsPrinterProvider()

    def get_status(
        self,
        *,
        enabled: bool,
        allowed_printers: tuple[str, ...] = (),
        default_only: bool = False,
    ) -> PrinterRedirectionStatus:
        configured_allowlist = any(name.strip() for name in allowed_printers)
        effective_allowlist_list: list[str] = []
        ignored_allowlist_list: list[str] = []
        seen_allowlist: set[str] = set()
        for raw_name in allowed_printers:
            name = raw_name.strip()
            if not name:
                continue
            folded = name.casefold()
            if not _SAFE_PRINTER_NAME.fullmatch(name) or folded in seen_allowlist:
                ignored_allowlist_list.append(name)
                continue
            effective_allowlist_list.append(name)
            seen_allowlist.add(folded)

        effective_allowlist = tuple(effective_allowlist_list)
        ignored_allowlist = tuple(ignored_allowlist_list)
        if configured_allowlist and default_only:
            policy_mode = PrinterPolicyMode.ALLOWLIST_DEFAULT_ONLY
        elif configured_allowlist:
            policy_mode = PrinterPolicyMode.ALLOWLIST
        elif default_only:
            policy_mode = PrinterPolicyMode.DEFAULT_ONLY
        else:
            policy_mode = PrinterPolicyMode.ALL

        if not enabled:
            return PrinterRedirectionStatus(
                enabled=False,
                status_code=PrinterStatusCode.DISABLED,
                policy_mode=policy_mode,
                effective_allowlist=effective_allowlist,
                ignored_allowlist=ignored_allowlist,
            )
        try:
            detected = self.provider.list_printers()
        except (OSError, RuntimeError, subprocess.SubprocessError) as error:
            return PrinterRedirectionStatus(
                enabled=True,
                error=str(error),
                status_code=PrinterStatusCode.CUPS_UNAVAILABLE,
                policy_mode=policy_mode,
                effective_allowlist=effective_allowlist,
                ignored_allowlist=ignored_allowlist,
            )

        allowed_names = {name.casefold() for name in effective_allowlist}
        redirected_list: list[Printer] = []
        redirected_names: set[str] = set()
        for printer in detected:
            folded = printer.name.casefold()
            if folded in redirected_names:
                continue
            if default_only and not printer.is_default:
                continue
            if configured_allowlist and folded not in allowed_names:
                continue
            redirected_list.append(printer)
            redirected_names.add(folded)

        redirected = tuple(redirected_list)
        rejected = tuple(
            printer for printer in detected
            if printer.name.casefold() not in redirected_names
        )
        if redirected:
            status_code = PrinterStatusCode.READY
        elif not detected:
            status_code = PrinterStatusCode.NO_PRINTERS
        elif default_only:
            status_code = PrinterStatusCode.NO_DEFAULT_PRINTER
        else:
            status_code = PrinterStatusCode.NO_AUTHORISED_PRINTER

        return PrinterRedirectionStatus(
            enabled=True,
            detected=detected,
            redirected=redirected,
            rejected=rejected,
            status_code=status_code,
            policy_mode=policy_mode,
            effective_allowlist=effective_allowlist,
            ignored_allowlist=ignored_allowlist,
        )

    def build_arguments(self, **kwargs: object) -> tuple[str, ...]:
        status = self.get_status(**kwargs)  # type: ignore[arg-type]
        return tuple(f"/printer:{printer.name}" for printer in status.redirected)

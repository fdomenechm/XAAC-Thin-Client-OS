from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from xaac_thinclient.config.models import ClipboardDirection, ClipboardProfile
from xaac_thinclient.services.logging import get_logger


logger = get_logger(__name__)


class ClipboardPolicyMode(str, Enum):
    """Mode efectiu de la política de porta-retalls."""

    DISABLED = "disabled"
    ENABLED = "enabled"
    RESTRICTED = "restricted"


class ClipboardStatusCode(str, Enum):
    """Codi estable de l'estat de redirecció del porta-retalls."""

    DISABLED = "disabled"
    ENABLED = "enabled"
    RESTRICTED = "restricted"


@dataclass(frozen=True, slots=True)
class ClipboardRedirectionPolicy:
    """Política immutable i ja resolta de redirecció del porta-retalls."""

    enabled: bool = True
    profile: ClipboardProfile = ClipboardProfile.CUSTOM
    direction: ClipboardDirection = ClipboardDirection.ALL
    files: ClipboardDirection = ClipboardDirection.ALL

    @property
    def mode(self) -> ClipboardPolicyMode:
        if not self.enabled:
            return ClipboardPolicyMode.DISABLED
        if self.direction is ClipboardDirection.ALL and self.files is ClipboardDirection.ALL:
            return ClipboardPolicyMode.ENABLED
        return ClipboardPolicyMode.RESTRICTED


@dataclass(frozen=True, slots=True)
class ClipboardPolicyResolution:
    """Resultat de resoldre i normalitzar la configuració declarada."""

    policy: ClipboardRedirectionPolicy
    overridden_fields: tuple[str, ...] = ()
    normalized_fields: tuple[str, ...] = ()

    @property
    def has_overrides(self) -> bool:
        return bool(self.overridden_fields)

    @property
    def has_normalizations(self) -> bool:
        return bool(self.normalized_fields)


@dataclass(frozen=True, slots=True)
class ClipboardRedirectionStatus:
    """Instantània de la política efectiva del porta-retalls."""

    policy: ClipboardRedirectionPolicy

    @property
    def status_code(self) -> ClipboardStatusCode:
        return ClipboardStatusCode(self.policy.mode.value)

    @property
    def status_detail(self) -> str:
        if not self.policy.enabled:
            return "Clipboard redirection is disabled."
        if self.policy.mode is ClipboardPolicyMode.ENABLED:
            return "Clipboard redirection is enabled."
        return (
            "Clipboard redirection is restricted: "
            f"content={self.policy.direction.value}, files={self.policy.files.value}."
        )

    @property
    def ready(self) -> bool:
        return True


class ClipboardRedirectionService:
    """Resol perfils i construeix els arguments de FreeRDP."""

    _PROFILE_POLICIES = {
        ClipboardProfile.FULL: (True, ClipboardDirection.ALL, ClipboardDirection.ALL),
        ClipboardProfile.TEXT_ONLY: (True, ClipboardDirection.ALL, ClipboardDirection.OFF),
        ClipboardProfile.LOCAL_TO_REMOTE: (
            True, ClipboardDirection.REMOTE, ClipboardDirection.OFF
        ),
        ClipboardProfile.REMOTE_TO_LOCAL: (
            True, ClipboardDirection.LOCAL, ClipboardDirection.OFF
        ),
        ClipboardProfile.DISABLED: (
            False, ClipboardDirection.OFF, ClipboardDirection.OFF
        ),
    }

    @classmethod
    def resolve_policy(
        cls,
        *,
        enabled: bool,
        profile: ClipboardProfile = ClipboardProfile.CUSTOM,
        direction: ClipboardDirection = ClipboardDirection.ALL,
        files: ClipboardDirection = ClipboardDirection.ALL,
    ) -> ClipboardPolicyResolution:
        if profile is ClipboardProfile.CUSTOM:
            # Quan el canal està desactivat, FreeRDP ignora qualsevol direcció.
            # Normalitzar-les a ``off`` evita que diagnòstic i política efectiva
            # mostren permisos que realment no s'aplicaran.
            if not enabled:
                normalized = tuple(
                    name
                    for name, value in (("direction", direction), ("files", files))
                    if value is not ClipboardDirection.OFF
                )
                return ClipboardPolicyResolution(
                    policy=ClipboardRedirectionPolicy(
                        enabled=False,
                        profile=profile,
                        direction=ClipboardDirection.OFF,
                        files=ClipboardDirection.OFF,
                    ),
                    normalized_fields=normalized,
                )
            return ClipboardPolicyResolution(
                policy=ClipboardRedirectionPolicy(
                    enabled=True,
                    profile=profile,
                    direction=direction,
                    files=files,
                )
            )

        effective_enabled, effective_direction, effective_files = cls._PROFILE_POLICIES[profile]
        overridden = tuple(
            name
            for name, configured, effective in (
                ("enabled", bool(enabled), effective_enabled),
                ("direction", direction, effective_direction),
                ("files", files, effective_files),
            )
            if configured != effective
        )
        return ClipboardPolicyResolution(
            policy=ClipboardRedirectionPolicy(
                enabled=effective_enabled,
                profile=profile,
                direction=effective_direction,
                files=effective_files,
            ),
            overridden_fields=overridden,
        )

    @classmethod
    def get_policy(
        cls,
        *,
        enabled: bool,
        profile: ClipboardProfile = ClipboardProfile.CUSTOM,
        direction: ClipboardDirection = ClipboardDirection.ALL,
        files: ClipboardDirection = ClipboardDirection.ALL,
    ) -> ClipboardRedirectionPolicy:
        return cls.resolve_policy(
            enabled=enabled,
            profile=profile,
            direction=direction,
            files=files,
        ).policy


    @staticmethod
    def audit_resolution(
        resolution: ClipboardPolicyResolution,
        *,
        managed_source: str = "system",
    ) -> None:
        """Registra de forma estructurada la política efectiva del porta-retalls."""
        policy = resolution.policy
        logger.debug(
            "clipboard_policy_resolved profile=%s mode=%s enabled=%s "
            "direction=%s files=%s source=%s",
            policy.profile.value,
            policy.mode.value,
            str(policy.enabled).lower(),
            policy.direction.value,
            policy.files.value,
            managed_source,
        )
        if resolution.has_overrides:
            logger.debug(
                "clipboard_profile_overrides fields=%s",
                ",".join(resolution.overridden_fields),
            )
        if resolution.has_normalizations:
            logger.debug(
                "clipboard_policy_normalized fields=%s",
                ",".join(resolution.normalized_fields),
            )
        if policy.mode is ClipboardPolicyMode.DISABLED:
            logger.debug("clipboard_redirection_disabled source=%s", managed_source)
        elif policy.mode is ClipboardPolicyMode.RESTRICTED:
            logger.debug(
                "clipboard_redirection_restricted direction=%s files=%s",
                policy.direction.value,
                policy.files.value,
            )

    @staticmethod
    def get_status(policy: ClipboardRedirectionPolicy) -> ClipboardRedirectionStatus:
        return ClipboardRedirectionStatus(policy=policy)

    @staticmethod
    def build_arguments(policy: ClipboardRedirectionPolicy) -> tuple[str, ...]:
        if not policy.enabled:
            return ("-clipboard",)
        if policy.direction is ClipboardDirection.ALL and policy.files is ClipboardDirection.ALL:
            return ("+clipboard",)
        return (
            "/clipboard:"
            f"direction-to:{policy.direction.value},"
            f"files-to:{policy.files.value}",
        )

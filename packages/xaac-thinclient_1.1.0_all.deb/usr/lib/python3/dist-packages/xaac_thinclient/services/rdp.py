from __future__ import annotations

import shutil
import socket
from subprocess import Popen

from dataclasses import dataclass
from typing import Callable

from xaac_thinclient.config.models import (
    CertificateMode,
    MultimonMode,
    NetworkProfile,
    SecurityMode,
    ThinClientConfig,
)

from xaac_thinclient.services.logging import get_logger
from xaac_thinclient.services.clipboard import ClipboardRedirectionService
from xaac_thinclient.services.keyboard import KeyboardService
from xaac_thinclient.services.dns import DnsService
from xaac_thinclient.services.smartcard import SmartCardService
from xaac_thinclient.services.pkcs11 import Pkcs11ModuleService
from xaac_thinclient.services.freerdp_capabilities import (
    FreeRdpCapability,
    FreeRdpCapabilityService,
)
from xaac_thinclient.services.usb import UsbService
from xaac_thinclient.services.drives import DriveRedirectionService
from xaac_thinclient.services.video import (
    VideoRedirectionService,
    VideoRedirectionStatus,
)
from xaac_thinclient.services.audio import (
    AudioRedirectionService,
    AudioRedirectionStatus,
)
from xaac_thinclient.services.printers import (
    PrinterRedirectionService,
    PrinterRedirectionStatus,
)
from xaac_thinclient.i18n import _
from xaac_thinclient.rdp.command_builder import (
    FreeRdpCommandBuilder,
    RdpCommandRequest,
)
from xaac_thinclient.rdp.performance import RdpPerformanceProfileResolver
from xaac_thinclient.rdp.hardware import RdpHardwareDetector
from xaac_thinclient.rdp.network_quality import RdpNetworkQualityDetector
from xaac_thinclient.rdp.graphics import RdpGraphicsSelector
from xaac_thinclient.rdp.display import RdpDisplayPlanner
from xaac_thinclient.rdp.preflight import (
    PreflightStatus, RdpPreflightCheck, RdpPreflightReport,
)
from xaac_thinclient.rdp.reconnect import RdpReconnectPolicy
from xaac_thinclient.rdp.tls import RdpTlsPolicyError, RdpTlsPolicyResolver
from xaac_thinclient.rdp.security import (
    RdpSecurityPolicyError, RdpSecurityPolicyResolver,
)
from xaac_thinclient.rdp.hardening import RdpCommandHardeningError
from xaac_thinclient.rdp.audit import RdpSecurityAuditEvent, RdpSecurityAuditReport
from xaac_thinclient.rdp.session import (
    RdpSessionDiagnostic,
    RdpSessionPlan,
    RdpSessionPlanError,
    RdpSessionWarning,
    canonical_strings,
)


logger = get_logger(__name__)


@dataclass(frozen=True, slots=True)
class RdpAvailability:
    available: bool
    server: str
    port: int
    error: str | None = None


from xaac_thinclient.services.rdp_execution import (
    RdpSessionExecutor,
    RdpSessionResult,
)


class FreeRdpBackend:
    """
    Comprova la disponibilitat del servei RDP i executa
    xfreerdp3.

    La contrasenya no s'inclou mai en la línia d'ordres.
    """

    def __init__(
        self,
        usb_service: UsbService | None = None,
        drive_service: DriveRedirectionService | None = None,
        printer_service: PrinterRedirectionService | None = None,
        audio_service: AudioRedirectionService | None = None,
        video_service: VideoRedirectionService | None = None,
        capability_service: FreeRdpCapabilityService | None = None,
        clipboard_service: ClipboardRedirectionService | None = None,
        keyboard_service: KeyboardService | None = None,
        dns_service: DnsService | None = None,
        smartcard_service: SmartCardService | None = None,
        pkcs11_service: Pkcs11ModuleService | None = None,
        preflight_enabled: bool = False,
        performance_resolver: RdpPerformanceProfileResolver | None = None,
        hardware_detector: RdpHardwareDetector | None = None,
        network_quality_detector: RdpNetworkQualityDetector | None = None,
        network_quality_enabled: bool = False,
        graphics_selector: RdpGraphicsSelector | None = None,
        display_planner: RdpDisplayPlanner | None = None,
        tls_resolver: RdpTlsPolicyResolver | None = None,
        security_resolver: RdpSecurityPolicyResolver | None = None,
    ) -> None:
        self.usb_service = usb_service or UsbService()
        self.drive_service = drive_service or DriveRedirectionService()
        self.printer_service = printer_service or PrinterRedirectionService()
        self.audio_service = audio_service or AudioRedirectionService()
        self.video_service = video_service or VideoRedirectionService()
        self.clipboard_service = clipboard_service or ClipboardRedirectionService()
        self.keyboard_service = keyboard_service or KeyboardService()
        self.dns_service = dns_service or DnsService()
        self.smartcard_service = smartcard_service or SmartCardService()
        self.pkcs11_service = pkcs11_service or Pkcs11ModuleService()
        self.preflight_enabled = bool(preflight_enabled)
        self.performance_resolver = performance_resolver or RdpPerformanceProfileResolver()
        self.hardware_detector = hardware_detector or RdpHardwareDetector()
        self.network_quality_detector = network_quality_detector or RdpNetworkQualityDetector()
        self.network_quality_enabled = bool(network_quality_enabled)
        self.graphics_selector = graphics_selector or RdpGraphicsSelector()
        self.display_planner = display_planner or RdpDisplayPlanner()
        self.tls_resolver = tls_resolver or RdpTlsPolicyResolver()
        self.security_resolver = security_resolver or RdpSecurityPolicyResolver()
        self.capability_service = (
            capability_service or FreeRdpCapabilityService(
                executable_finder=self.find_executable
            )
        )
        self.command_builder = FreeRdpCommandBuilder(
            usb_service=self.usb_service,
            drive_service=self.drive_service,
            printer_service=self.printer_service,
            audio_service=self.audio_service,
            video_service=self.video_service,
            clipboard_service=self.clipboard_service,
            keyboard_service=self.keyboard_service,
        )
        self.session_executor = RdpSessionExecutor(
            process_factory=lambda *args, **kwargs: Popen(*args, **kwargs)
        )

    @staticmethod
    def find_executable() -> str | None:
        """
        Retorna la ruta de xfreerdp3 si està instal·lat.
        """
        return shutil.which("xfreerdp3")

    def check_availability(
        self,
        server: str,
        port: int,
        timeout: float,
    ) -> RdpAvailability:
        logger.debug(
            "Comprovant RDP: servidor=%s, port=%s",
            server,
            port,
        )
        """
        Comprova si el servidor accepta connexions TCP
        al port configurat.
        """
        server = server.strip()

        if not server:
            return RdpAvailability(
                available=False,
                server=server,
                port=port,
                error=_("The server name is empty."),
            )

        try:
            with socket.create_connection(
                (server, port),
                timeout=timeout,
            ):
                pass
        except socket.timeout:
            return RdpAvailability(
                available=False,
                server=server,
                port=port,
                error=_("The RDP server did not respond before the timeout."),
            )
        except socket.gaierror as error:
            return RdpAvailability(
                available=False,
                server=server,
                port=port,
                error=_("The server could not be resolved: {error}").format(error=error),
            )
        except ConnectionRefusedError:
            return RdpAvailability(
                available=False,
                server=server,
                port=port,
                error=_("The server refused connections on port {port}.").format(port=port),
            )
        except OSError as error:
            return RdpAvailability(
                available=False,
                server=server,
                port=port,
                error=str(error),
            )

        return RdpAvailability(
            available=True,
            server=server,
            port=port,
        )

    def build_command(
        self,
        config: ThinClientConfig,
        username: str,
        monitor_count: int,
        printer_status: PrinterRedirectionStatus | None = None,
        audio_status: AudioRedirectionStatus | None = None,
        video_status: VideoRedirectionStatus | None = None,
    ) -> list[str]:
        """Build the effective shell-free FreeRDP argument vector.

        The definitive builder is isolated in ``rdp.command_builder`` and the
        password is deliberately absent from its immutable request model.
        """
        try:
            tls = self.tls_resolver.resolve(config)
        except RdpTlsPolicyError as error:
            raise ValueError(error.message) from error
        try:
            security = self.security_resolver.resolve(config, tls)
        except RdpSecurityPolicyError as error:
            raise ValueError(error.message) from error

        executable = self.find_executable()
        if executable is None:
            raise FileNotFoundError(
                _("The xfreerdp3 executable was not found.")
            )

        if video_status is None:
            video_status, video_error = self._resolve_video_status(config)
            if video_error is not None:
                raise ValueError(
                    video_error.error or "Video redirection is unavailable."
                )

        request = RdpCommandRequest(
            executable=executable,
            config=config,
            username=username,
            monitor_count=monitor_count,
            printer_status=printer_status,
            audio_status=audio_status,
            video_status=video_status,
            tls_arguments=security.arguments,
        )
        return self.command_builder.build(request).as_list()

    def run_preflight(self, config: ThinClientConfig) -> RdpPreflightReport:
        """Run all local and network prerequisites and return one report."""
        checks: list[RdpPreflightCheck] = []
        dns = self.dns_service.resolve(config.device.server)
        checks.append(RdpPreflightCheck(
            "dns", PreflightStatus.PASS if dns.resolved else PreflightStatus.FAIL,
            "PREFLIGHT-DNS-OK" if dns.resolved else "PREFLIGHT-DNS-001",
            dns.error or ",".join(dns.addresses), True,
        ))

        tcp = self.check_availability(
            config.device.server, config.rdp.port, config.network.connect_timeout
        ) if dns.resolved else None
        checks.append(RdpPreflightCheck(
            "tcp",
            PreflightStatus.PASS if tcp and tcp.available else (PreflightStatus.FAIL if dns.resolved else PreflightStatus.SKIPPED),
            "PREFLIGHT-TCP-OK" if tcp and tcp.available else "PREFLIGHT-TCP-001",
            (tcp.error if tcp else "DNS resolution failed." ) or "", True,
        ))

        executable = self.find_executable()
        checks.append(RdpPreflightCheck(
            "freerdp", PreflightStatus.PASS if executable else PreflightStatus.FAIL,
            "PREFLIGHT-FREERDP-OK" if executable else "PREFLIGHT-FREERDP-001",
            executable or "The xfreerdp3 executable was not found.", True,
        ))

        sc = self.smartcard_service.get_status(
            enabled=config.smartcard.enabled, required=config.smartcard.required,
            preferred_reader=config.smartcard.preferred_reader,
        )
        sc_required = config.smartcard.card_required
        sc_ok = (not config.smartcard.enabled) or sc.ready
        checks.append(RdpPreflightCheck(
            "smartcard",
            PreflightStatus.PASS if sc_ok else (PreflightStatus.FAIL if sc_required else PreflightStatus.WARNING),
            "PREFLIGHT-SMARTCARD-OK" if sc_ok else "PREFLIGHT-SMARTCARD-001",
            sc.required_error() or sc.status_detail, sc_required,
        ))

        pkcs = self.pkcs11_service.inspect(config.smartcard.pkcs11_module)
        pkcs_required = config.smartcard.card_required and config.smartcard.pkcs11_enabled
        pkcs_ok = (not pkcs.configured) or (pkcs.available and pkcs.compatible)
        checks.append(RdpPreflightCheck(
            "pkcs11",
            PreflightStatus.PASS if pkcs_ok else (PreflightStatus.FAIL if pkcs_required else PreflightStatus.WARNING),
            "PREFLIGHT-PKCS11-OK" if pkcs_ok else "PREFLIGHT-PKCS11-001",
            pkcs.status_detail if not pkcs.available else pkcs.compatibility_detail, pkcs_required,
        ))

        usb = self.usb_service.get_status(
            enabled=config.usb.enabled, allowed_devices=config.usb.allowed_devices,
            blocked_devices=config.usb.blocked_devices,
        )
        usb_ok = not config.usb.enabled or usb.error is None
        checks.append(RdpPreflightCheck(
            "usb", PreflightStatus.PASS if usb_ok else PreflightStatus.WARNING,
            "PREFLIGHT-USB-OK" if usb_ok else "PREFLIGHT-USB-001",
            usb.error or f"redirectable={len(usb.allowed)}", False,
        ))

        video_policy = self.video_service.get_policy(
            enabled=config.video.enabled, required=config.video.required
        )
        video = self.video_service.get_status(video_policy)
        video_ok = not config.video.enabled or video.ready
        checks.append(RdpPreflightCheck(
            "camera",
            PreflightStatus.PASS if video_ok else (PreflightStatus.FAIL if config.video.required else PreflightStatus.WARNING),
            "PREFLIGHT-CAMERA-OK" if video_ok else "PREFLIGHT-CAMERA-001",
            video.required_error() or video.status_detail, config.video.required,
        ))
        return RdpPreflightReport(tuple(checks))

    def prepare_session(
        self,
        config: ThinClientConfig,
        username: str,
        monitor_count: int,
    ) -> RdpSessionPlan:
        """Prepare and validate a complete immutable RDP session plan."""
        warnings: list[RdpSessionWarning] = []
        diagnostics: list[RdpSessionDiagnostic] = []
        degraded_features: set[str] = set()
        preflight = self.run_preflight(config) if self.preflight_enabled else None
        if preflight is not None:
            blocking = preflight.blocking_checks
            if blocking:
                first = blocking[0]
                raise RdpSessionPlanError(first.code, first.detail)
            for item in preflight.warning_checks:
                warnings.append(RdpSessionWarning(item.code, item.detail))
            diagnostics.extend(
                RdpSessionDiagnostic(f"preflight.{item.name}", item.status.value)
                for item in preflight.checks
            )

        audio_policy = self.audio_service.get_policy(
            playback_enabled=config.audio.playback_enabled,
            recording_enabled=config.audio.recording_enabled,
            playback_required=config.audio.playback_required,
            recording_required=config.audio.recording_required,
        )
        audio_status: AudioRedirectionStatus | None = None
        if audio_policy.playback_required or audio_policy.recording_required:
            audio_status = self.audio_service.get_status(audio_policy)
            diagnostics.append(RdpSessionDiagnostic(
                "audio.status", audio_status.status_code.value
            ))
            audio_error = audio_status.required_error()
            if audio_error is not None:
                error_code, error_detail = audio_error
                raise RdpSessionPlanError(error_code, _(error_detail))

        video_status, video_error = self._resolve_video_status(config)
        if video_error is not None:
            raise RdpSessionPlanError(video_error.error_code, video_error.error or "Video redirection is unavailable.")
        diagnostics.append(RdpSessionDiagnostic(
            "video.status", video_status.status_code.value
        ))

        printer_status = self.printer_service.get_status(
            enabled=config.printers.enabled,
            allowed_printers=config.printers.allowed_printers,
            default_only=config.printers.default_only,
        )
        diagnostics.extend((
            RdpSessionDiagnostic("printers.status", printer_status.status_code.value),
            RdpSessionDiagnostic("printers.redirected", str(len(printer_status.redirected))),
        ))
        printer_error = printer_status.required_error(config.printers.required)
        if printer_error is not None:
            raise RdpSessionPlanError("PRINTER-001", _(printer_error))

        hardware = self.hardware_detector.detect(monitor_count_hint=monitor_count)
        diagnostics.extend((
            RdpSessionDiagnostic("hardware.architecture", hardware.architecture),
            RdpSessionDiagnostic("hardware.cpu_model", hardware.cpu_model),
            RdpSessionDiagnostic("hardware.logical_cpus", str(hardware.logical_cpus)),
            RdpSessionDiagnostic("hardware.memory_mib", str(hardware.memory_mib)),
            RdpSessionDiagnostic("hardware.gpu_count", str(len(hardware.gpu_devices))),
            RdpSessionDiagnostic("hardware.monitor_count", str(hardware.monitor_count)),
            RdpSessionDiagnostic("hardware.maximum_display",
                f"{hardware.maximum_display.width}x{hardware.maximum_display.height}"
                if hardware.maximum_display else "unknown"),
            RdpSessionDiagnostic("hardware.warnings", ",".join(hardware.warnings)),
        ))
        logger.info(
            "rdp_hardware_detected arch=%s cpus=%s memory_mib=%s gpus=%s monitors=%s display=%s warnings=%s",
            hardware.architecture, hardware.logical_cpus, hardware.memory_mib,
            len(hardware.gpu_devices), hardware.monitor_count,
            diagnostics[-2].value, diagnostics[-1].value or "none",
        )

        network_quality = None
        if self.network_quality_enabled:
            network_quality = self.network_quality_detector.detect(config.device.server)
            diagnostics.extend((
                RdpSessionDiagnostic("network.quality", network_quality.quality.value),
                RdpSessionDiagnostic("network.latency_ms",
                    f"{network_quality.latency_ms:.2f}" if network_quality.latency_ms is not None else "unknown"),
                RdpSessionDiagnostic("network.packet_loss_percent",
                    f"{network_quality.packet_loss_percent:.2f}" if network_quality.packet_loss_percent is not None else "unknown"),
                RdpSessionDiagnostic("network.samples",
                    f"{network_quality.samples_received}/{network_quality.samples_sent}"),
                RdpSessionDiagnostic("network.warnings", ",".join(network_quality.warnings)),
            ))
            for warning in network_quality.warnings:
                warnings.append(RdpSessionWarning(
                    "RDP-NETWORK-QUALITY",
                    f"Network quality measurement warning: {warning}.",
                ))
            logger.debug(
                "rdp_network_quality quality=%s latency_ms=%s loss_percent=%s samples=%s/%s warnings=%s",
                network_quality.quality.value,
                network_quality.latency_ms if network_quality.latency_ms is not None else "unknown",
                network_quality.packet_loss_percent if network_quality.packet_loss_percent is not None else "unknown",
                network_quality.samples_received, network_quality.samples_sent,
                ",".join(network_quality.warnings) or "none",
            )
        performance = self.performance_resolver.resolve(config)
        effective_config = performance.config
        diagnostics.extend((
            RdpSessionDiagnostic("performance.requested_profile", performance.requested.value),
            RdpSessionDiagnostic("performance.effective_profile", performance.effective.value),
            RdpSessionDiagnostic("performance.changed_fields", ",".join(performance.changed_fields)),
        ))
        logger.debug(
            "rdp_performance_profile requested=%s effective=%s changed=%s",
            performance.requested.value, performance.effective.value,
            ",".join(performance.changed_fields) or "none",
        )
        display = self.display_planner.resolve(effective_config, hardware, monitor_count)
        diagnostics.extend((
            RdpSessionDiagnostic("display.monitor_count", str(display.monitor_count)),
            RdpSessionDiagnostic("display.multimon_enabled", str(display.multimon_enabled).lower()),
            RdpSessionDiagnostic("display.multimon_forced", str(display.multimon_forced).lower()),
            RdpSessionDiagnostic("display.desktop_scale_percent", str(display.desktop_scale_percent)),
            RdpSessionDiagnostic("display.device_scale_percent", str(display.device_scale_percent)),
            RdpSessionDiagnostic("display.mixed_resolutions", str(display.mixed_resolutions).lower()),
            RdpSessionDiagnostic("display.warnings", ",".join(display.warnings)),
        ))
        for warning in display.warnings:
            warnings.append(RdpSessionWarning("RDP-DISPLAY-001", f"Display planning warning: {warning}."))

        capability_status = self.capability_service.get_status()
        graphics = self.graphics_selector.select(
            profile=performance.effective,
            hardware=hardware,
            network=network_quality,
            capabilities=capability_status,
        )
        diagnostics.extend((
            RdpSessionDiagnostic("graphics.mode", graphics.mode.value),
            RdpSessionDiagnostic("graphics.arguments", ",".join(graphics.arguments)),
            RdpSessionDiagnostic("graphics.reasons", ",".join(graphics.reasons)),
            RdpSessionDiagnostic("graphics.degraded", str(graphics.degraded).lower()),
        ))
        if graphics.degraded:
            warnings.append(RdpSessionWarning(
                "RDP-GRAPHICS-DEGRADED",
                "The preferred graphics pipeline was degraded safely.",
            ))
        logger.debug(
            "rdp_graphics_selected mode=%s reasons=%s degraded=%s",
            graphics.mode.value, ",".join(graphics.reasons) or "none", graphics.degraded,
        )
        if hasattr(self.capability_service, "apply_safe_degradation"):
            degradation = self.capability_service.apply_safe_degradation(
                effective_config, status=capability_status
            )
            self.capability_service.audit_compatibility(degradation.compatibility)
            diagnostics.extend(
                RdpSessionDiagnostic(f"freerdp.{key}", value)
                for key, value in capability_status.audit_fields()
            )
            if not degradation.connection_allowed:
                blocking = ", ".join(
                    sorted(item.value for item in degradation.compatibility.blocking)
                )
                raise RdpSessionPlanError(
                    "FREERDP-CAP-001",
                    _(
                        "The installed FreeRDP client does not support required "
                        "features: {features}."
                    ).format(features=blocking or "unknown"),
                )
            effective_config = degradation.effective_config
            degraded_features.update(item.value for item in degradation.degraded)
            for feature in sorted(degraded_features):
                warnings.append(RdpSessionWarning(
                    "RDP-DEGRADED",
                    f"Optional FreeRDP feature disabled safely: {feature}.",
                ))

        try:
            tls = self.tls_resolver.resolve(effective_config)
        except RdpTlsPolicyError as error:
            raise RdpSessionPlanError(error.code, error.message) from error
        try:
            security = self.security_resolver.resolve(effective_config, tls)
        except RdpSecurityPolicyError as error:
            raise RdpSessionPlanError(error.code, error.message) from error

        diagnostics.extend((
            RdpSessionDiagnostic("security.mode", security.mode.value),
            RdpSessionDiagnostic("security.nla_enabled", str(security.nla_enabled).lower()),
            RdpSessionDiagnostic("security.negotiation_enabled", str(security.negotiation_enabled).lower()),
            RdpSessionDiagnostic("security.tls_forced", str(security.tls_forced).lower()),
            RdpSessionDiagnostic("security.credential_delegation", str(security.credential_delegation).lower()),
            RdpSessionDiagnostic("security.warnings", ",".join(security.warnings)),
        ))
        for warning in security.warnings:
            warnings.append(RdpSessionWarning("RDP-SEC-WARNING", f"RDP security policy warning: {warning}."))

        diagnostics.extend((
            RdpSessionDiagnostic("tls.security_mode", tls.security_mode.value),
            RdpSessionDiagnostic("tls.certificate_mode", tls.certificate_mode.value),
            RdpSessionDiagnostic("tls.certificate_name_configured", str(bool(tls.certificate_name)).lower()),
            RdpSessionDiagnostic("tls.strict_validation", str(tls.strict_validation).lower()),
            RdpSessionDiagnostic("tls.warnings", ",".join(tls.warnings)),
        ))
        for warning in tls.warnings:
            warnings.append(RdpSessionWarning("RDP-TLS-WARNING", f"TLS policy warning: {warning}."))

        executable = self.find_executable()
        if executable is None:
            raise RdpSessionPlanError(None, _("The xfreerdp3 executable was not found."))
        request = RdpCommandRequest(
            executable=executable,
            config=effective_config,
            username=username,
            monitor_count=display.monitor_count,
            printer_status=printer_status,
            audio_status=audio_status,
            video_status=video_status,
            graphics_arguments=graphics.arguments,
            display_arguments=display.arguments,
            tls_arguments=security.arguments,
        )
        try:
            command = self.command_builder.build(request)
        except RdpCommandHardeningError as error:
            raise RdpSessionPlanError(error.code, str(error)) from error
        except ValueError as error:
            raise RdpSessionPlanError(None, str(error)) from error

        _hardened, hardening_report = self.command_builder.command_hardener.harden(command)

        security_audit = RdpSecurityAuditReport(events=(
            RdpSecurityAuditEvent.create(
                "RDP-AUDIT-TLS", "prepare", "accepted",
                {"certificate_mode": tls.certificate_mode.value, "strict": str(tls.strict_validation).lower()},
            ),
            RdpSecurityAuditEvent.create(
                "RDP-AUDIT-SECURITY", "prepare", "accepted",
                {"mode": security.mode.value, "nla": str(security.nla_enabled).lower()},
            ),
            RdpSecurityAuditEvent.create(
                "RDP-AUDIT-CREDENTIALS", "prepare", "protected",
                {"transport": "stdin", "persisted": "false", "logged": "false"},
            ),
            RdpSecurityAuditEvent.create(
                "RDP-AUDIT-COMMAND", "prepare", "hardened",
                {"validated": str(hardening_report.validated).lower(), "shell": "false"},
            ),
            RdpSecurityAuditEvent.create(
                "RDP-AUDIT-PREFLIGHT", "prepare",
                "completed" if preflight is not None else "skipped",
                {"blocking": str(bool(preflight and not preflight.connection_allowed)).lower()},
            ),
        ))
        diagnostics.append(RdpSessionDiagnostic("audit.event_count", str(len(security_audit.events))))

        diagnostics.extend((
            RdpSessionDiagnostic("session.server_configured", str(bool(effective_config.device.server.strip())).lower()),
            RdpSessionDiagnostic("session.username_configured", str(bool(username.strip())).lower()),
            RdpSessionDiagnostic("session.monitor_count", str(max(0, monitor_count))),
            RdpSessionDiagnostic("session.argument_count", str(len(command.arguments))),
            RdpSessionDiagnostic("session.credentials_serialised", "false"),
            RdpSessionDiagnostic("command.hardened", str(hardening_report.validated).lower()),
            RdpSessionDiagnostic("command.shell_used", str(hardening_report.policy.shell_used).lower()),
            RdpSessionDiagnostic("command.unknown_arguments_allowed", str(hardening_report.policy.unknown_arguments_allowed).lower()),
            RdpSessionDiagnostic("command.secret_argument_allowed", str(hardening_report.policy.secret_argument_allowed).lower()),
            RdpSessionDiagnostic("credentials.transport", "stdin"),
            RdpSessionDiagnostic("credentials.command_line_secret", "false"),
            RdpSessionDiagnostic("credentials.persisted", "false"),
            RdpSessionDiagnostic("credentials.logged", "false"),
            RdpSessionDiagnostic("credentials.reusable_for_reconnect", "true"),
            RdpSessionDiagnostic("reconnect.enabled", str(effective_config.rdp.reconnect_enabled).lower()),
            RdpSessionDiagnostic("reconnect.max_attempts", str(effective_config.rdp.reconnect_max_attempts)),
            RdpSessionDiagnostic("reconnect.initial_delay", str(effective_config.rdp.reconnect_initial_delay)),
            RdpSessionDiagnostic("reconnect.max_delay", str(effective_config.rdp.reconnect_max_delay)),
        ))
        return RdpSessionPlan(
            command=command,
            effective_config=effective_config,
            degraded_features=canonical_strings(degraded_features),
            warnings=tuple(warnings),
            diagnostics=tuple(sorted(diagnostics, key=lambda item: (item.key, item.value))),
            preflight=preflight,
            hardware=hardware,
            network_quality=network_quality,
            graphics=graphics,
            display=display,
            tls=tls,
            security=security,
            command_hardening=hardening_report,
            security_audit=security_audit,
            reconnect=RdpReconnectPolicy(
                enabled=effective_config.rdp.reconnect_enabled,
                max_attempts=effective_config.rdp.reconnect_max_attempts,
                initial_delay_seconds=effective_config.rdp.reconnect_initial_delay,
                maximum_delay_seconds=effective_config.rdp.reconnect_max_delay,
            ),
        )

    def execute_session_plan(
        self,
        plan: RdpSessionPlan,
        password: str,
        on_started: Callable[[], None] | None = None,
    ) -> RdpSessionResult:
        """Execute a previously prepared immutable session plan."""
        return self.session_executor.execute(plan, password, on_started)

    def connect(
        self,
        config: ThinClientConfig,
        username: str,
        password: str,
        monitor_count: int,
        on_started: Callable[[], None] | None = None,
    ) -> RdpSessionResult:
        """Prepare the immutable plan and delegate its execution."""
        try:
            plan = self.prepare_session(config, username, monitor_count)
        except RdpSessionPlanError as error:
            logger.warning(
                "Preparació de sessió RDP bloquejada [%s]: %s",
                error.code or "RDP-PLAN",
                error.message,
            )
            return RdpSessionResult(
                started=False, error=error.message, error_code=error.code
            )
        return self.execute_session_plan(plan, password, on_started)

    def _resolve_video_status(
        self, config: ThinClientConfig
    ) -> tuple[VideoRedirectionStatus, RdpSessionResult | None]:
        """Calcula una sola política efectiva de vídeo per a tota la sessió."""
        policy = self.video_service.get_policy(
            enabled=config.video.enabled,
            required=config.video.required,
        )
        if not policy.enabled:
            return VideoRedirectionStatus(policy=policy), None

        capability_status = self.capability_service.get_status()
        if not capability_status.supports(FreeRdpCapability.RDPECAM):
            detail = (
                "The installed FreeRDP client does not provide the "
                "RDPECAM dynamic virtual channel required for video "
                "redirection."
            )
            if capability_status.error:
                detail = f"{detail} {capability_status.error}"

            if policy.required:
                logger.warning(
                    "Sessió RDP bloquejada: RDPECAM no disponible [%s]",
                    capability_status.status_code.value,
                )
                return VideoRedirectionStatus(policy=policy), RdpSessionResult(
                    started=False,
                    error=_(detail),
                    error_code="VIDEO-002",
                )

            logger.warning(
                "RDPECAM no disponible [%s]; la sessió continuarà "
                "sense redirecció de vídeo",
                capability_status.status_code.value,
            )
            disabled = self.video_service.get_policy(
                enabled=False, required=False
            )
            return VideoRedirectionStatus(policy=disabled), None

        if not policy.required:
            return VideoRedirectionStatus(policy=policy), None

        status = self.video_service.get_status(policy)
        video_error = status.required_error()
        if video_error is not None:
            logger.warning(
                "Sessió RDP bloquejada per la política de vídeo: %s",
                video_error,
            )
            return status, RdpSessionResult(
                started=False,
                error=_(video_error),
                error_code="VIDEO-001",
            )
        return status, None

    @property
    def _process(self):
        """Compatibility view of the executor active process."""
        return self.session_executor.active_process

    @_process.setter
    def _process(self, process) -> None:
        self.session_executor.active_process = process

    def disconnect(self) -> None:
        """Finalitza la sessió RDP activa, si n'hi ha una."""
        self.session_executor.disconnect()

    @staticmethod
    def _should_use_multimon(
        mode: MultimonMode,
        monitor_count: int,
    ) -> bool:
        if mode == MultimonMode.ENABLED:
            return True

        if mode == MultimonMode.DISABLED:
            return False

        return monitor_count > 1

    @staticmethod
    def _certificate_argument(
        mode: CertificateMode,
    ) -> str:
        if mode == CertificateMode.TOFU:
            return "/cert:tofu"

        if mode == CertificateMode.IGNORE:
            return "/cert:ignore"

        return "/cert:deny"

    @staticmethod
    def _security_argument(
        mode: SecurityMode,
    ) -> str:
        if mode == SecurityMode.NLA:
            return "/sec:nla"

        if mode == SecurityMode.TLS:
            return "/sec:tls"
        return None


# Àlies de compatibilitat temporal per al codi i els tests existents.
# El nom canònic de la implementació és FreeRdpBackend.
RdpService = FreeRdpBackend

from __future__ import annotations

import os
import struct
from dataclasses import dataclass
from enum import Enum
from pathlib import Path


class Pkcs11ModuleStatusCode(str, Enum):
    """Codi estable de disponibilitat del mòdul PKCS#11 configurat."""

    NOT_CONFIGURED = "not-configured"
    AVAILABLE = "available"
    NOT_FOUND = "not-found"
    NOT_A_FILE = "not-a-file"
    NOT_READABLE = "not-readable"
    CHECK_FAILED = "check-failed"


class Pkcs11ModuleCompatibilityCode(str, Enum):
    """Resultat estable de la inspecció binària passiva del mòdul."""

    NOT_CHECKED = "not-checked"
    COMPATIBLE = "compatible"
    INVALID_FORMAT = "invalid-format"
    BITNESS_MISMATCH = "bitness-mismatch"
    INSPECTION_FAILED = "inspection-failed"


_STATUS_DETAILS = {
    Pkcs11ModuleStatusCode.NOT_CONFIGURED: "No PKCS#11 module is configured.",
    Pkcs11ModuleStatusCode.AVAILABLE: "The configured PKCS#11 module is locally available.",
    Pkcs11ModuleStatusCode.NOT_FOUND: "The configured PKCS#11 module was not found.",
    Pkcs11ModuleStatusCode.NOT_A_FILE: "The configured PKCS#11 path is not a regular file.",
    Pkcs11ModuleStatusCode.NOT_READABLE: "The configured PKCS#11 module is not readable.",
    Pkcs11ModuleStatusCode.CHECK_FAILED: "The PKCS#11 module availability could not be verified.",
}

_COMPATIBILITY_DETAILS = {
    Pkcs11ModuleCompatibilityCode.NOT_CHECKED: "Binary compatibility was not checked.",
    Pkcs11ModuleCompatibilityCode.COMPATIBLE: "The ELF class matches the local process.",
    Pkcs11ModuleCompatibilityCode.INVALID_FORMAT: "The configured file is not a supported ELF shared object.",
    Pkcs11ModuleCompatibilityCode.BITNESS_MISMATCH: "The ELF class does not match the local process.",
    Pkcs11ModuleCompatibilityCode.INSPECTION_FAILED: "Binary compatibility could not be inspected.",
}


@dataclass(frozen=True, slots=True)
class Pkcs11ModuleStatus:
    configured: bool
    module_name: str = ""
    status_code: Pkcs11ModuleStatusCode = Pkcs11ModuleStatusCode.NOT_CONFIGURED
    compatibility_code: Pkcs11ModuleCompatibilityCode = (
        Pkcs11ModuleCompatibilityCode.NOT_CHECKED
    )
    module_bitness: int | None = None
    process_bitness: int = struct.calcsize("P") * 8

    @property
    def available(self) -> bool:
        return self.status_code is Pkcs11ModuleStatusCode.AVAILABLE

    @property
    def compatible(self) -> bool:
        return self.compatibility_code is Pkcs11ModuleCompatibilityCode.COMPATIBLE

    @property
    def status_detail(self) -> str:
        return _STATUS_DETAILS[self.status_code]

    @property
    def compatibility_detail(self) -> str:
        return _COMPATIBILITY_DETAILS[self.compatibility_code]


class Pkcs11ModuleService:
    """Comprova disponibilitat i compatibilitat sense carregar PKCS#11."""

    _ELF_MAGIC = b"\x7fELF"
    _ELF_CLASS_32 = 1
    _ELF_CLASS_64 = 2

    def inspect(self, module_path: str) -> Pkcs11ModuleStatus:
        if not module_path:
            return Pkcs11ModuleStatus(configured=False)

        path = Path(module_path)
        module_name = path.name
        try:
            if not path.exists():
                code = Pkcs11ModuleStatusCode.NOT_FOUND
            elif not path.is_file():
                code = Pkcs11ModuleStatusCode.NOT_A_FILE
            elif not os.access(path, os.R_OK):
                code = Pkcs11ModuleStatusCode.NOT_READABLE
            else:
                code = Pkcs11ModuleStatusCode.AVAILABLE
        except OSError:
            code = Pkcs11ModuleStatusCode.CHECK_FAILED

        compatibility_code = Pkcs11ModuleCompatibilityCode.NOT_CHECKED
        module_bitness: int | None = None
        if code is Pkcs11ModuleStatusCode.AVAILABLE:
            compatibility_code, module_bitness = self._inspect_binary(path)

        return Pkcs11ModuleStatus(
            configured=True,
            module_name=module_name,
            status_code=code,
            compatibility_code=compatibility_code,
            module_bitness=module_bitness,
        )

    def _inspect_binary(
        self,
        path: Path,
    ) -> tuple[Pkcs11ModuleCompatibilityCode, int | None]:
        try:
            with path.open("rb") as stream:
                header = stream.read(5)
        except OSError:
            return Pkcs11ModuleCompatibilityCode.INSPECTION_FAILED, None

        if len(header) < 5 or header[:4] != self._ELF_MAGIC:
            return Pkcs11ModuleCompatibilityCode.INVALID_FORMAT, None

        elf_class = header[4]
        if elf_class == self._ELF_CLASS_32:
            module_bitness = 32
        elif elf_class == self._ELF_CLASS_64:
            module_bitness = 64
        else:
            return Pkcs11ModuleCompatibilityCode.INVALID_FORMAT, None

        process_bitness = struct.calcsize("P") * 8
        if module_bitness != process_bitness:
            return Pkcs11ModuleCompatibilityCode.BITNESS_MISMATCH, module_bitness
        return Pkcs11ModuleCompatibilityCode.COMPATIBLE, module_bitness

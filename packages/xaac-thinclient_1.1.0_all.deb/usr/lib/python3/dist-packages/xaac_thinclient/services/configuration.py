from __future__ import annotations

import configparser
import os
from pathlib import Path
from tempfile import NamedTemporaryFile

from xaac_thinclient.config.loader import load_config
from xaac_thinclient.config.models import (
    ThinClientConfig,
    UserPreferences,
)
from xaac_thinclient.paths import (
    CONFIG_FILE,
    DEVICE_FILE,
    USER_CONFIG_FILE,
    REMOTE_CONFIG_CACHE_FILE,
    REMOTE_DEVICE_IDENTITY_FILE,
    REMOTE_TELEMETRY_QUEUE_FILE,
)


class ConfigService:
    """
    Gestiona:

    - La lectura de la configuració administrativa.
    - La lectura i escriptura de les preferències personals.

    No guarda mai contrasenyes.
    No modifica config.ini ni device.ini.
    """

    def __init__(
        self,
        config_file: Path = CONFIG_FILE,
        device_file: Path = DEVICE_FILE,
        user_file: Path = USER_CONFIG_FILE,
    ) -> None:
        self._config_file = config_file
        self._device_file = device_file
        self._user_file = user_file

    def load_system_config(self) -> ThinClientConfig:
        """
        Llig config.ini i device.ini.

        Aquest mètode és només de lectura.
        """
        return load_config(
            config_path=self._config_file,
            device_path=self._device_file,
        )




    def load_logging_settings(self):
        """Llig la configuració local del sistema de registre.

        La lectura és tolerant: qualsevol valor absent o invàlid conserva
        un valor segur per defecte i no impedeix l'arrencada.
        """
        from xaac_thinclient.services.logging import LoggingSettings

        parser = configparser.ConfigParser(interpolation=None)
        try:
            loaded_files = parser.read(self._config_file, encoding="utf-8")
        except configparser.Error:
            loaded_files = []

        if not loaded_files or not parser.has_section("logging"):
            return LoggingSettings()

        level = parser.get("logging", "level", fallback="INFO").strip() or "INFO"
        try:
            console = parser.getboolean("logging", "console", fallback=True)
        except ValueError:
            console = True
        try:
            file_enabled = parser.getboolean("logging", "file", fallback=True)
        except ValueError:
            file_enabled = True
        try:
            max_bytes = parser.getint(
                "logging", "max_bytes", fallback=2 * 1024 * 1024
            )
        except ValueError:
            max_bytes = 2 * 1024 * 1024
        try:
            backup_count = parser.getint(
                "logging", "backup_count", fallback=5
            )
        except ValueError:
            backup_count = 5

        return LoggingSettings(
            level=level,
            console=console,
            file=file_enabled,
            max_bytes=max(1, max_bytes),
            backup_count=max(0, backup_count),
        )

    def load_remote_configuration_settings(self):
        """Llig els paràmetres locals del servei de configuració remota."""
        from xaac_thinclient.services.remote_configuration import (
            RemoteConfigurationSettings,
        )

        parser = configparser.ConfigParser(interpolation=None)
        try:
            loaded_files = parser.read(self._config_file, encoding="utf-8")
        except configparser.Error:
            loaded_files = []

        if not loaded_files or not parser.has_section("remote_config"):
            return RemoteConfigurationSettings()

        try:
            enabled = parser.getboolean(
                "remote_config", "enabled", fallback=False
            )
            allow_http = parser.getboolean(
                "remote_config", "allow_http", fallback=False
            )
            timeout = parser.getfloat(
                "remote_config", "timeout", fallback=5.0
            )
            require_signature = parser.getboolean(
                "remote_config", "require_signature", fallback=False
            )
            require_expiration = parser.getboolean(
                "remote_config", "require_expiration", fallback=False
            )
            clock_skew_seconds = parser.getint(
                "remote_config", "clock_skew_seconds", fallback=60
            )
            rollback_enabled = parser.getboolean(
                "remote_config", "rollback_enabled", fallback=False
            )
            rollback_max_entries = parser.getint(
                "remote_config", "rollback_max_entries", fallback=5
            )
            prevent_policy_downgrade = parser.getboolean(
                "remote_config", "prevent_policy_downgrade", fallback=True
            )
            device_identity_enabled = parser.getboolean(
                "remote_config", "device_identity_enabled", fallback=False
            )
            require_device_target = parser.getboolean(
                "remote_config", "require_device_target", fallback=False
            )
        except ValueError:
            return RemoteConfigurationSettings()

        url = parser.get(
            "remote_config", "url", fallback=""
        ).strip()
        trusted_key = parser.get(
            "remote_config", "trusted_key_file", fallback=""
        ).strip()
        rollback_directory = parser.get(
            "remote_config", "rollback_directory", fallback=""
        ).strip()
        device_identity_file = parser.get(
            "remote_config", "device_identity_file", fallback=""
        ).strip()
        trusted_key_id = parser.get(
            "remote_config", "trusted_key_id", fallback="default"
        ).strip() or "default"

        return RemoteConfigurationSettings(
            enabled=enabled,
            url=url,
            timeout=max(0.1, timeout),
            cache_file=REMOTE_CONFIG_CACHE_FILE,
            allow_http=allow_http,
            require_signature=require_signature,
            trusted_key_file=Path(trusted_key) if trusted_key else None,
            trusted_key_id=trusted_key_id,
            require_expiration=require_expiration,
            clock_skew_seconds=max(0, min(3600, clock_skew_seconds)),
            rollback_enabled=rollback_enabled,
            rollback_directory=Path(rollback_directory) if rollback_directory else None,
            rollback_max_entries=max(1, min(50, rollback_max_entries)),
            prevent_policy_downgrade=prevent_policy_downgrade,
            device_identity_enabled=device_identity_enabled,
            device_identity_file=Path(device_identity_file) if device_identity_file else REMOTE_DEVICE_IDENTITY_FILE,
            require_device_target=require_device_target,
        )


    def load_remote_telemetry_settings(self):
        """Llig la configuració local, sempre opcional, de telemetria."""
        from xaac_thinclient.services.remote_telemetry import RemoteTelemetrySettings

        parser = configparser.ConfigParser(interpolation=None)
        try:
            loaded_files = parser.read(self._config_file, encoding="utf-8")
        except configparser.Error:
            loaded_files = []
        if not loaded_files or not parser.has_section("telemetry"):
            return RemoteTelemetrySettings()
        try:
            enabled = parser.getboolean("telemetry", "enabled", fallback=False)
            allow_http = parser.getboolean("telemetry", "allow_http", fallback=False)
            timeout = parser.getfloat("telemetry", "timeout", fallback=3.0)
            max_entries = parser.getint("telemetry", "max_queue_entries", fallback=100)
        except ValueError:
            return RemoteTelemetrySettings()
        url = parser.get("telemetry", "url", fallback="").strip()
        queue_file = parser.get("telemetry", "queue_file", fallback="").strip()
        return RemoteTelemetrySettings(
            enabled=enabled, url=url, timeout=max(0.1, min(60.0, timeout)),
            queue_file=Path(queue_file) if queue_file else REMOTE_TELEMETRY_QUEUE_FILE,
            max_queue_entries=max(1, min(1000, max_entries)), allow_http=allow_http,
        )

    def load_user_preferences(self) -> UserPreferences:
        """
        Llig user.ini.

        Si no existeix o està mal formatat, retorna
        unes preferències buides.
        """
        if not self._user_file.is_file():
            return UserPreferences()

        parser = configparser.ConfigParser(
            interpolation=None,
        )

        try:
            loaded_files = parser.read(
                self._user_file,
                encoding="utf-8",
            )
        except configparser.Error:
            return UserPreferences()

        if not loaded_files or not parser.has_section("user"):
            return UserPreferences()

        try:
            remember_username = parser.getboolean(
                "user",
                "remember_username",
                fallback=False,
            )
        except ValueError:
            remember_username = False

        username = parser.get(
            "user",
            "username",
            fallback="",
        ).strip()

        if not remember_username:
            username = ""

        return UserPreferences(
            username=username,
            remember_username=remember_username,
        )

    def save_user_preferences(
        self,
        preferences: UserPreferences,
    ) -> None:
        """
        Guarda només el nom d'usuari i la casella
        recordar usuari.

        Mai guarda la contrasenya.
        """
        self._user_file.parent.mkdir(
            parents=True,
            exist_ok=True,
        )

        username = (
            preferences.username.strip()
            if preferences.remember_username
            else ""
        )

        parser = configparser.ConfigParser(
            interpolation=None,
        )

        parser["user"] = {
            "username": username,
            "remember_username": (
                "true"
                if preferences.remember_username
                else "false"
            ),
        }

        self._write_atomic(parser)

        os.chmod(self._user_file, 0o600)

    def clear_user_preferences(self) -> None:
        """
        Elimina user.ini si existeix.
        """
        try:
            self._user_file.unlink()
        except FileNotFoundError:
            pass

    def _write_atomic(
        self,
        parser: configparser.ConfigParser,
    ) -> None:
        directory = self._user_file.parent

        with NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=directory,
            prefix=".user-",
            suffix=".tmp",
            delete=False,
        ) as temporary_file:
            temporary_path = Path(temporary_file.name)
            parser.write(temporary_file)

        try:
            temporary_path.replace(self._user_file)
        except OSError:
            try:
                temporary_path.unlink()
            except FileNotFoundError:
                pass
            raise
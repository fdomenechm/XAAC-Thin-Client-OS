from pathlib import Path

def mounted_usb_paths(base_path: Path=Path("/media/thinclient")) -> list[Path]:
    return [p for p in base_path.iterdir() if p.is_dir()] if base_path.exists() else []

from __future__ import annotations

import json
import os
import ssl
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import Any, Callable, Mapping
from urllib.request import Request, urlopen
from uuid import uuid4


class RemoteTelemetryError(RuntimeError):
    """La telemetria no s'ha pogut validar, serialitzar o enviar."""


_SENSITIVE_FRAGMENTS = (
    "password", "passwd", "secret", "credential", "username", "user",
    "server", "address", "hostname", "token", "pin", "certificate_name",
)
_ALLOWED_EVENT_TYPES = {"configuration", "startup", "health", "session"}


@dataclass(frozen=True, slots=True)
class RemoteTelemetrySettings:
    enabled: bool = False
    url: str = ""
    timeout: float = 3.0
    queue_file: Path | None = None
    max_queue_entries: int = 100
    allow_http: bool = False


@dataclass(frozen=True, slots=True)
class RemoteTelemetryEvent:
    event_id: str
    occurred_at: str
    event_type: str
    device_id: str | None
    fields: tuple[tuple[str, bool | int | float | str | None], ...]

    def __post_init__(self) -> None:
        if self.event_type not in _ALLOWED_EVENT_TYPES:
            raise RemoteTelemetryError("El tipus d'esdeveniment de telemetria no és vàlid.")
        if any(character in self.event_id for character in "\n\r\x00"):
            raise RemoteTelemetryError("L'identificador de telemetria no és vàlid.")
        try:
            parsed = datetime.fromisoformat(self.occurred_at.replace("Z", "+00:00"))
        except ValueError as error:
            raise RemoteTelemetryError("La data de telemetria no és vàlida.") from error
        if parsed.tzinfo is None:
            raise RemoteTelemetryError("La data de telemetria ha d'incloure zona horària.")
        seen: set[str] = set()
        for key, value in self.fields:
            normalized = key.strip().lower()
            if not normalized or normalized in seen:
                raise RemoteTelemetryError("Els camps de telemetria han de ser únics i no buits.")
            seen.add(normalized)
            if any(fragment in normalized for fragment in _SENSITIVE_FRAGMENTS):
                raise RemoteTelemetryError("La telemetria conté un camp potencialment sensible.")
            if not isinstance(value, (bool, int, float, str, type(None))):
                raise RemoteTelemetryError("La telemetria només admet valors escalars.")
            if isinstance(value, str) and any(character in value for character in "\n\r\x00"):
                raise RemoteTelemetryError("La telemetria conté caràcters de control.")

    @classmethod
    def create(
        cls,
        event_type: str,
        fields: Mapping[str, bool | int | float | str | None],
        *,
        device_id: str | None = None,
        now: datetime | None = None,
        event_id: str | None = None,
    ) -> "RemoteTelemetryEvent":
        timestamp = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
        return cls(
            event_id=event_id or str(uuid4()),
            occurred_at=timestamp.isoformat().replace("+00:00", "Z"),
            event_type=event_type,
            device_id=device_id,
            fields=tuple(sorted(fields.items())),
        )

    def to_payload(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "schema_version": 1,
            "event_id": self.event_id,
            "occurred_at": self.occurred_at,
            "event_type": self.event_type,
            "fields": dict(self.fields),
        }
        if self.device_id is not None:
            payload["device_id"] = self.device_id
        return payload

    @classmethod
    def from_payload(cls, payload: Mapping[str, Any]) -> "RemoteTelemetryEvent":
        if payload.get("schema_version") != 1 or not isinstance(payload.get("fields"), dict):
            raise RemoteTelemetryError("L'esdeveniment de telemetria en cua no és vàlid.")
        return cls(
            event_id=str(payload["event_id"]),
            occurred_at=str(payload["occurred_at"]),
            event_type=str(payload["event_type"]),
            device_id=(str(payload["device_id"]) if payload.get("device_id") is not None else None),
            fields=tuple(sorted(payload["fields"].items())),
        )


@dataclass(frozen=True, slots=True)
class RemoteTelemetryReport:
    enabled: bool
    sent: bool = False
    queued: bool = False
    flushed_events: int = 0
    pending_events: int = 0
    warning: str | None = None


UrlOpen = Callable[..., Any]


class RemoteTelemetryService:
    """Envia telemetria mínima i conserva una cua local si falla la xarxa."""

    def __init__(self, opener: UrlOpen = urlopen) -> None:
        self._opener = opener

    def publish(
        self,
        event: RemoteTelemetryEvent,
        settings: RemoteTelemetrySettings,
    ) -> RemoteTelemetryReport:
        if not settings.enabled:
            return RemoteTelemetryReport(enabled=False)
        self._validate_settings(settings)
        queued_events = self._read_queue(settings.queue_file)
        events = [*queued_events, event]
        flushed = 0
        try:
            for candidate in events:
                self._send(candidate, settings)
                flushed += 1
        except Exception as error:
            remaining = events[flushed:]
            limited = remaining[-settings.max_queue_entries:]
            self._write_queue(settings.queue_file, limited)
            return RemoteTelemetryReport(
                enabled=True,
                sent=False,
                queued=True,
                flushed_events=flushed,
                pending_events=len(limited),
                warning=str(error),
            )
        self._write_queue(settings.queue_file, [])
        return RemoteTelemetryReport(
            enabled=True,
            sent=True,
            queued=False,
            flushed_events=max(0, flushed - 1),
            pending_events=0,
        )

    @staticmethod
    def configuration_event(
        result: Any,
        *,
        device_id: str | None = None,
        now: datetime | None = None,
    ) -> RemoteTelemetryEvent:
        return RemoteTelemetryEvent.create(
            "configuration",
            {
                "source": result.source.value,
                "schema_version": result.schema_version,
                "legacy_schema": result.legacy_schema,
                "signature_verified": result.signature_verified,
                "validity_verified": result.validity_verified,
                "rollback_used": result.rollback_used,
                "policy_target_matched": result.policy_target_matched,
                "applied_key_count": len(result.applied_keys),
                "rejected_key_count": len(result.rejected_keys),
                "warning_present": result.warning is not None,
            },
            device_id=device_id,
            now=now,
        )

    @staticmethod
    def _validate_settings(settings: RemoteTelemetrySettings) -> None:
        if not settings.url:
            raise RemoteTelemetryError("La URL de telemetria està buida.")
        if not settings.url.startswith("https://"):
            if not settings.allow_http or not settings.url.startswith("http://"):
                raise RemoteTelemetryError("La telemetria requereix HTTPS.")
        if not 0.1 <= settings.timeout <= 60:
            raise RemoteTelemetryError("El timeout de telemetria no és vàlid.")
        if not 1 <= settings.max_queue_entries <= 1000:
            raise RemoteTelemetryError("El límit de la cua de telemetria no és vàlid.")

    def _send(self, event: RemoteTelemetryEvent, settings: RemoteTelemetrySettings) -> None:
        body = json.dumps(
            event.to_payload(), ensure_ascii=False, sort_keys=True, separators=(",", ":")
        ).encode("utf-8")
        request = Request(
            settings.url,
            data=body,
            headers={"Content-Type": "application/json", "User-Agent": "XAAC-ThinClient/telemetry-v1"},
            method="POST",
        )
        context = ssl.create_default_context() if settings.url.startswith("https://") else None
        with self._opener(request, timeout=settings.timeout, context=context) as response:
            status = getattr(response, "status", 200)
            if not 200 <= status < 300:
                raise RemoteTelemetryError(f"El servidor de telemetria ha retornat HTTP {status}.")

    @staticmethod
    def _read_queue(path: Path | None) -> list[RemoteTelemetryEvent]:
        if path is None or not path.is_file():
            return []
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(payload, dict) or payload.get("schema_version") != 1:
                raise ValueError
            events = payload.get("events")
            if not isinstance(events, list):
                raise ValueError
            return [RemoteTelemetryEvent.from_payload(item) for item in events]
        except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError, RemoteTelemetryError):
            return []

    @staticmethod
    def _write_queue(path: Path | None, events: list[RemoteTelemetryEvent]) -> None:
        if path is None:
            return
        path.parent.mkdir(parents=True, exist_ok=True)
        if not events:
            try:
                path.unlink()
            except FileNotFoundError:
                pass
            return
        payload = {"schema_version": 1, "events": [event.to_payload() for event in events]}
        temporary_name: str | None = None
        try:
            with NamedTemporaryFile(
                "w", encoding="utf-8", dir=path.parent,
                prefix=".telemetry-", suffix=".tmp", delete=False,
            ) as handle:
                temporary_name = handle.name
                json.dump(payload, handle, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
                handle.flush()
                os.fsync(handle.fileno())
            os.chmod(temporary_name, 0o600)
            os.replace(temporary_name, path)
            os.chmod(path, 0o600)
        finally:
            if temporary_name and os.path.exists(temporary_name):
                os.unlink(temporary_name)

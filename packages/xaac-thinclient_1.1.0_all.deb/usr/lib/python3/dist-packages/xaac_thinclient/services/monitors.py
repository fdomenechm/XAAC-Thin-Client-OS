import subprocess

def connected_monitor_count() -> int:
    r=subprocess.run(["xrandr","--query"],capture_output=True,text=True,check=True)
    return sum(" connected" in line for line in r.stdout.splitlines())

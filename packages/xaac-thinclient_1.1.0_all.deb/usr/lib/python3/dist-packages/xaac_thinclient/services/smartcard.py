from __future__ import annotations

import ctypes
import ctypes.util
from dataclasses import dataclass
from enum import Enum
from typing import Protocol, runtime_checkable


SCARD_SCOPE_SYSTEM = 2
SCARD_STATE_UNAWARE = 0x0000
SCARD_STATE_PRESENT = 0x0020
SCARD_S_SUCCESS = 0x00000000
SCARD_E_NO_READERS_AVAILABLE = 0x8010002E
SCARD_E_NO_SERVICE = 0x8010001D
SCARD_E_SERVICE_STOPPED = 0x8010001E
SCARD_E_INVALID_HANDLE = 0x80100003

# En pcsc-lite sobre Linux, LONG i DWORD són long/unsigned long.
# En x86_64 ocupen 8 bytes; usar c_int32/c_uint32 desquadra l'ABI i
# fa que dwEventState es llija des d'una posició incorrecta.
_PCSC_LONG = ctypes.c_long
_PCSC_DWORD = ctypes.c_ulong
_PCSC_CONTEXT = _PCSC_LONG


class SmartCardPolicyMode(str, Enum):
    """Mode efectiu de la política local de Smartcard."""

    DISABLED = "disabled"
    OPTIONAL = "optional"
    REQUIRED = "required"


class SmartCardReaderMode(str, Enum):
    """Mode estable de selecció de lector PC/SC."""

    ANY = "any"
    PREFERRED = "preferred"


class SmartCardStatusCode(str, Enum):
    """Codi estable de l'estat local PC/SC i de la targeta."""

    DISABLED = "disabled"
    READY = "ready"
    LIBRARY_UNAVAILABLE = "library-unavailable"
    SERVICE_UNAVAILABLE = "service-unavailable"
    NO_READER = "no-reader"
    PREFERRED_READER_UNAVAILABLE = "preferred-reader-unavailable"
    NO_CARD = "no-card"
    DETECTION_FAILED = "detection-failed"


_SMARTCARD_STATUS_DETAILS = {
    SmartCardStatusCode.DISABLED: "Smart card support is disabled.",
    SmartCardStatusCode.READY: "A smart card is present in an available reader.",
    SmartCardStatusCode.LIBRARY_UNAVAILABLE: (
        "The local PC/SC library is not available."
    ),
    SmartCardStatusCode.SERVICE_UNAVAILABLE: (
        "The local PC/SC service is not running or cannot be reached."
    ),
    SmartCardStatusCode.NO_READER: "No smart card reader was detected.",
    SmartCardStatusCode.PREFERRED_READER_UNAVAILABLE: (
        "No reader matches the configured preferred-reader filter."
    ),
    SmartCardStatusCode.NO_CARD: (
        "A reader is available, but no smart card is present."
    ),
    SmartCardStatusCode.DETECTION_FAILED: (
        "The local smart card state could not be determined completely."
    ),
}


@dataclass(frozen=True, slots=True)
class SmartCardReader:
    name: str
    card_present: bool = False


@dataclass(frozen=True, slots=True)
class SmartCardStatus:
    enabled: bool
    pcsc_available: bool
    pcscd_running: bool
    required: bool = False
    readers: tuple[SmartCardReader, ...] = ()
    detected_readers: tuple[SmartCardReader, ...] = ()
    preferred_reader: str = ""
    error: str | None = None


    @property
    def policy_mode(self) -> SmartCardPolicyMode:
        if not self.enabled:
            return SmartCardPolicyMode.DISABLED
        if self.required:
            return SmartCardPolicyMode.REQUIRED
        return SmartCardPolicyMode.OPTIONAL

    @property
    def effective_requirements(self) -> tuple[str, ...]:
        """Recursos locals que bloquegen la connexió per política."""
        if self.policy_mode is SmartCardPolicyMode.REQUIRED:
            return ("pcsc", "reader", "card")
        return ()

    def required_error(self) -> str | None:
        """Missatge estable i segur quan la política obligatòria no es compleix."""
        if not self.required or self.ready:
            return None
        messages = {
            SmartCardStatusCode.LIBRARY_UNAVAILABLE: (
                "The required local PC/SC library is not available."
            ),
            SmartCardStatusCode.SERVICE_UNAVAILABLE: (
                "The required local PC/SC service is not available."
            ),
            SmartCardStatusCode.NO_READER: (
                "No required smart card reader was detected."
            ),
            SmartCardStatusCode.PREFERRED_READER_UNAVAILABLE: (
                "The required preferred smart card reader is not available."
            ),
            SmartCardStatusCode.NO_CARD: (
                "Insert the required smart card before connecting."
            ),
            SmartCardStatusCode.DETECTION_FAILED: (
                "The required smart card state could not be verified."
            ),
        }
        return messages.get(
            self.status_code,
            "The required smart card is not available.",
        )

    @property
    def reader_mode(self) -> SmartCardReaderMode:
        return (
            SmartCardReaderMode.PREFERRED
            if self.preferred_reader
            else SmartCardReaderMode.ANY
        )

    @property
    def detected_reader_count(self) -> int:
        return len(self.detected_readers or self.readers)

    @property
    def eligible_reader_count(self) -> int:
        return len(self.readers)

    @property
    def preferred_reader_matched(self) -> bool:
        return not self.preferred_reader or bool(self.readers)

    @property
    def reader_count(self) -> int:
        """Compatibilitat: nombre de lectors elegibles per la política."""
        return self.eligible_reader_count

    @property
    def reader_names(self) -> tuple[str, ...]:
        """Noms dels lectors de la instantània, en ordre estable."""
        return tuple(reader.name for reader in self.readers)

    @property
    def readers_with_card(self) -> tuple[str, ...]:
        """Lectors que informen d'una targeta present, sense llegir-ne dades."""
        return tuple(reader.name for reader in self.readers if reader.card_present)

    @property
    def card_present(self) -> bool:
        return bool(self.readers_with_card)

    @property
    def ready(self) -> bool:
        return (
            self.enabled
            and self.pcsc_available
            and self.pcscd_running
            and bool(self.readers)
            and self.card_present
        )

    @property
    def status_code(self) -> SmartCardStatusCode:
        if not self.enabled:
            return SmartCardStatusCode.DISABLED
        if not self.pcsc_available:
            return SmartCardStatusCode.LIBRARY_UNAVAILABLE
        if not self.pcscd_running:
            return SmartCardStatusCode.SERVICE_UNAVAILABLE
        if self.error is not None:
            if self.preferred_reader and not self.readers:
                return SmartCardStatusCode.PREFERRED_READER_UNAVAILABLE
            return SmartCardStatusCode.DETECTION_FAILED
        if not self.readers:
            return SmartCardStatusCode.NO_READER
        if not self.card_present:
            return SmartCardStatusCode.NO_CARD
        return SmartCardStatusCode.READY

    @property
    def status_detail(self) -> str:
        return _SMARTCARD_STATUS_DETAILS[self.status_code]

    @property
    def audit_fields(self) -> tuple[tuple[str, str], ...]:
        """Camps estables i no sensibles per a auditoria estructurada."""
        return (
            ("status", self.status_code.value),
            ("policy", self.policy_mode.value),
            ("pcsc", str(self.pcsc_available).lower()),
            ("service", str(self.pcscd_running).lower()),
            ("reader_mode", self.reader_mode.value),
            ("detected_readers", str(self.detected_reader_count)),
            ("eligible_readers", str(self.eligible_reader_count)),
            ("preferred_matched", str(self.preferred_reader_matched).lower()),
            ("card_present", str(self.card_present).lower()),
            ("required_satisfied", str(not self.required or self.ready).lower()),
        )


class PcscError(RuntimeError):
    """Error base de la capa PC/SC."""


class PcscUnavailableError(PcscError):
    """La biblioteca PC/SC no està disponible al sistema."""


class PcscServiceError(PcscError):
    """El servei PC/SC no està disponible o no respon."""


@runtime_checkable
class SmartCardProvider(Protocol):
    """Contracte mínim per consultar lectors i targetes PC/SC."""

    def available(self) -> bool:
        """Indica si el suport PC/SC està instal·lat."""

    def list_readers(self) -> tuple[SmartCardReader, ...]:
        """Retorna una instantània dels lectors i de les targetes presents."""


class _ScardReaderState(ctypes.Structure):
    _fields_ = [
        ("szReader", ctypes.c_char_p),
        ("pvUserData", ctypes.c_void_p),
        ("dwCurrentState", _PCSC_DWORD),
        ("dwEventState", _PCSC_DWORD),
        ("cbAtr", _PCSC_DWORD),
        ("rgbAtr", ctypes.c_ubyte * 33),
    ]


class LibPcscProvider:
    """Implementació PC/SC basada directament en ``libpcsclite``.

    No executa ``pcsc_scan`` ni analitza eixida textual. La consulta és
    síncrona, curta i segura per executar-la en l'executor de serveis.
    """

    def __init__(self, library_name: str | None = None) -> None:
        self._library_name = (
            ctypes.util.find_library("pcsclite")
            if library_name is None
            else (library_name or None)
        )
        self._library: ctypes.CDLL | None = None

    def available(self) -> bool:
        return self._library_name is not None

    def list_readers(self) -> tuple[SmartCardReader, ...]:
        library = self._load_library()
        context = _PCSC_CONTEXT()

        result = library.SCardEstablishContext(
            SCARD_SCOPE_SYSTEM,
            None,
            None,
            ctypes.byref(context),
        )
        self._raise_for_result(result, "No s'ha pogut iniciar el context PC/SC.")

        try:
            names = self._reader_names(library, context)
            return tuple(
                SmartCardReader(
                    name=name,
                    card_present=self._card_present(library, context, name),
                )
                for name in names
            )
        finally:
            library.SCardReleaseContext(context)

    def _load_library(self) -> ctypes.CDLL:
        if self._library is not None:
            return self._library
        if self._library_name is None:
            raise PcscUnavailableError(
                "No s'ha trobat la biblioteca PC/SC (libpcsclite)."
            )

        try:
            library = ctypes.CDLL(self._library_name)
        except OSError as error:
            raise PcscUnavailableError(str(error)) from error

        library.SCardEstablishContext.argtypes = [
            ctypes.c_uint32,
            ctypes.c_void_p,
            ctypes.c_void_p,
            ctypes.POINTER(_PCSC_CONTEXT),
        ]
        library.SCardEstablishContext.restype = _PCSC_LONG
        library.SCardReleaseContext.argtypes = [_PCSC_CONTEXT]
        library.SCardReleaseContext.restype = _PCSC_LONG
        library.SCardListReaders.argtypes = [
            _PCSC_CONTEXT,
            ctypes.c_char_p,
            ctypes.c_void_p,
            ctypes.POINTER(_PCSC_DWORD),
        ]
        library.SCardListReaders.restype = _PCSC_LONG
        library.SCardGetStatusChange.argtypes = [
            _PCSC_CONTEXT,
            _PCSC_DWORD,
            ctypes.POINTER(_ScardReaderState),
            _PCSC_DWORD,
        ]
        library.SCardGetStatusChange.restype = _PCSC_LONG

        self._library = library
        return library

    def _reader_names(
        self,
        library: ctypes.CDLL,
        context: _PCSC_CONTEXT,
    ) -> tuple[str, ...]:
        length = _PCSC_DWORD(0)
        result = library.SCardListReaders(
            context,
            None,
            None,
            ctypes.byref(length),
        )

        if self._unsigned_result(result) == SCARD_E_NO_READERS_AVAILABLE:
            return ()
        self._raise_for_result(result, "No s'han pogut enumerar els lectors.")
        if length.value == 0:
            return ()

        buffer = ctypes.create_string_buffer(length.value)
        result = library.SCardListReaders(
            context,
            None,
            ctypes.cast(buffer, ctypes.c_void_p),
            ctypes.byref(length),
        )
        self._raise_for_result(result, "No s'han pogut llegir els lectors.")

        raw_names = bytes(buffer.raw[: length.value])
        return tuple(
            item.decode("utf-8", errors="replace")
            for item in raw_names.split(b"\x00")
            if item
        )

    def _card_present(
        self,
        library: ctypes.CDLL,
        context: _PCSC_CONTEXT,
        reader_name: str,
    ) -> bool:
        encoded_name = reader_name.encode("utf-8")
        state = _ScardReaderState()
        state.szReader = encoded_name
        state.dwCurrentState = SCARD_STATE_UNAWARE

        result = library.SCardGetStatusChange(
            context,
            0,
            ctypes.byref(state),
            1,
        )
        self._raise_for_result(
            result,
            f"No s'ha pogut consultar el lector {reader_name}.",
        )
        return bool(state.dwEventState & SCARD_STATE_PRESENT)

    @staticmethod
    def _unsigned_result(result: int) -> int:
        return ctypes.c_uint32(result).value

    @classmethod
    def _raise_for_result(cls, result: int, message: str) -> None:
        code = cls._unsigned_result(result)
        if code == SCARD_S_SUCCESS:
            return
        if code in {
            SCARD_E_NO_SERVICE,
            SCARD_E_SERVICE_STOPPED,
            SCARD_E_INVALID_HANDLE,
        }:
            raise PcscServiceError(message)
        raise PcscError(f"{message} Codi PC/SC: 0x{code:08X}")


class SmartCardService:
    """Consulta PC/SC sense processos externs ni bloquejos persistents."""

    def __init__(self, provider: SmartCardProvider | None = None) -> None:
        self.provider = provider or LibPcscProvider()

    def pcsc_available(self) -> bool:
        return self.provider.available()

    def get_status(
        self,
        *,
        enabled: bool,
        required: bool = False,
        preferred_reader: str = "",
    ) -> SmartCardStatus:
        available = self.pcsc_available()
        if not enabled:
            return SmartCardStatus(
                enabled=False,
                pcsc_available=available,
                pcscd_running=False,
                required=required,
                preferred_reader=preferred_reader,
            )

        if not available:
            return SmartCardStatus(
                enabled=True,
                pcsc_available=False,
                pcscd_running=False,
                required=required,
                preferred_reader=preferred_reader,
                error="No s'ha trobat la biblioteca PC/SC.",
            )

        try:
            readers = self.provider.list_readers()
        except PcscUnavailableError as error:
            return SmartCardStatus(
                enabled=True,
                pcsc_available=False,
                pcscd_running=False,
                required=required,
                preferred_reader=preferred_reader,
                error=str(error),
            )
        except PcscServiceError as error:
            return SmartCardStatus(
                enabled=True,
                pcsc_available=True,
                pcscd_running=False,
                required=required,
                preferred_reader=preferred_reader,
                error=str(error),
            )
        except PcscError as error:
            return SmartCardStatus(
                enabled=True,
                pcsc_available=True,
                pcscd_running=True,
                required=required,
                preferred_reader=preferred_reader,
                error=str(error),
            )

        detected_readers = readers

        if preferred_reader:
            readers = tuple(
                reader
                for reader in readers
                if preferred_reader.casefold() in reader.name.casefold()
            )
            if not readers:
                return SmartCardStatus(
                    enabled=True,
                    pcsc_available=True,
                    pcscd_running=True,
                    readers=(),
                    detected_readers=detected_readers,
                    required=required,
                    preferred_reader=preferred_reader,
                    error="No s'ha trobat el lector preferit.",
                )

        return SmartCardStatus(
            enabled=True,
            pcsc_available=True,
            pcscd_running=True,
            readers=readers,
            detected_readers=detected_readers,
            required=required,
            preferred_reader=preferred_reader,
        )

from __future__ import annotations

import os
import shutil
import subprocess
from dataclasses import dataclass
from enum import Enum
from typing import Callable, Sequence


class AudioResourceStatusCode(str, Enum):
    """Codi estable per a un recurs local d'àudio."""

    DISABLED = "disabled"
    READY = "ready"
    SERVICE_UNAVAILABLE = "audio-service-unavailable"
    NO_DEVICE = "no-device"


class AudioPolicyMode(str, Enum):
    """Mode efectiu de redirecció configurat."""

    DISABLED = "disabled"
    PLAYBACK = "playback"
    RECORDING = "recording"
    PLAYBACK_AND_RECORDING = "playback+recording"


class AudioStatusCode(str, Enum):
    """Codi global estable de la política d'àudio."""

    DISABLED = "disabled"
    READY = "ready"
    PARTIAL = "partial"
    SERVICE_UNAVAILABLE = "audio-service-unavailable"
    NO_DEVICES = "no-enabled-devices"


@dataclass(frozen=True, slots=True)
class AudioRedirectionPolicy:
    playback_enabled: bool = False
    recording_enabled: bool = False
    playback_required: bool = False
    recording_required: bool = False

    @property
    def mode(self) -> AudioPolicyMode:
        if self.playback_enabled and self.recording_enabled:
            return AudioPolicyMode.PLAYBACK_AND_RECORDING
        if self.playback_enabled:
            return AudioPolicyMode.PLAYBACK
        if self.recording_enabled:
            return AudioPolicyMode.RECORDING
        return AudioPolicyMode.DISABLED

    @property
    def effective_required_resources(self) -> tuple[str, ...]:
        resources: list[str] = []
        if self.playback_enabled and self.playback_required:
            resources.append("playback")
        if self.recording_enabled and self.recording_required:
            resources.append("recording")
        return tuple(resources)

    @property
    def ignored_requirements(self) -> tuple[str, ...]:
        ignored: list[str] = []
        if self.playback_required and not self.playback_enabled:
            ignored.append("playback_required")
        if self.recording_required and not self.recording_enabled:
            ignored.append("recording_required")
        return tuple(ignored)


@dataclass(frozen=True, slots=True)
class AudioEndpoint:
    """Dispositiu local d'àudio visible per al servidor d'àudio."""

    name: str
    description: str
    kind: str
    is_default: bool = False


@dataclass(frozen=True, slots=True)
class AudioRedirectionStatus:
    """Instantània de disponibilitat local per a la política d'àudio."""

    policy: AudioRedirectionPolicy
    backend: str | None = None
    playback_devices: tuple[AudioEndpoint, ...] = ()
    recording_devices: tuple[AudioEndpoint, ...] = ()
    error: str | None = None

    @property
    def playback_available(self) -> bool:
        return bool(self.playback_devices)

    @property
    def recording_available(self) -> bool:
        return bool(self.recording_devices)

    @property
    def playback_ready(self) -> bool:
        """Indica si la política de reproducció es pot complir."""
        return (
            not self.policy.playback_enabled
            or (self.error is None and self.playback_available)
        )

    @property
    def recording_ready(self) -> bool:
        """Indica si la política d'enregistrament es pot complir."""
        return (
            not self.policy.recording_enabled
            or (self.error is None and self.recording_available)
        )

    @property
    def playback_status_code(self) -> AudioResourceStatusCode:
        if not self.policy.playback_enabled:
            return AudioResourceStatusCode.DISABLED
        if self.error is not None:
            return AudioResourceStatusCode.SERVICE_UNAVAILABLE
        if self.playback_available:
            return AudioResourceStatusCode.READY
        return AudioResourceStatusCode.NO_DEVICE

    @property
    def recording_status_code(self) -> AudioResourceStatusCode:
        if not self.policy.recording_enabled:
            return AudioResourceStatusCode.DISABLED
        if self.error is not None:
            return AudioResourceStatusCode.SERVICE_UNAVAILABLE
        if self.recording_available:
            return AudioResourceStatusCode.READY
        return AudioResourceStatusCode.NO_DEVICE

    @property
    def status_code(self) -> AudioStatusCode:
        enabled = (
            self.policy.playback_enabled,
            self.policy.recording_enabled,
        )
        if not any(enabled):
            return AudioStatusCode.DISABLED
        if self.error is not None:
            return AudioStatusCode.SERVICE_UNAVAILABLE

        resource_ready = tuple(
            ready
            for is_enabled, ready in (
                (self.policy.playback_enabled, self.playback_ready),
                (self.policy.recording_enabled, self.recording_ready),
            )
            if is_enabled
        )
        if all(resource_ready):
            return AudioStatusCode.READY
        if any(resource_ready):
            return AudioStatusCode.PARTIAL
        return AudioStatusCode.NO_DEVICES

    @property
    def status_detail(self) -> str:
        descriptions = {
            AudioStatusCode.DISABLED: "Audio redirection is disabled.",
            AudioStatusCode.READY: "All enabled audio resources are ready.",
            AudioStatusCode.PARTIAL: (
                "Only some enabled audio resources are available."
            ),
            AudioStatusCode.SERVICE_UNAVAILABLE: (
                "The local audio service could not be queried."
            ),
            AudioStatusCode.NO_DEVICES: (
                "No device is available for the enabled audio resources."
            ),
        }
        return descriptions[self.status_code]

    @staticmethod
    def resource_status_detail(
        code: AudioResourceStatusCode,
        *,
        resource: str,
    ) -> str:
        if code is AudioResourceStatusCode.DISABLED:
            return f"{resource} redirection is disabled."
        if code is AudioResourceStatusCode.READY:
            return f"A local {resource.lower()} device is ready."
        if code is AudioResourceStatusCode.SERVICE_UNAVAILABLE:
            return "The local audio service could not be queried."
        return f"No local {resource.lower()} device was detected."

    def required_error(self) -> tuple[str, str] | None:
        """Retorna codi i detall del primer requisit que bloqueja la sessió."""
        if self.policy.playback_required and not self.playback_ready:
            if self.error:
                return (
                    "AUDIO-001",
                    "Audio playback is required but the local audio service "
                    f"is unavailable: {self.error}",
                )
            return (
                "AUDIO-001",
                "Audio playback is required, but no local playback device "
                "is available.",
            )

        if self.policy.recording_required and not self.recording_ready:
            if self.error:
                return (
                    "MICROPHONE-001",
                    "Microphone redirection is required but the local audio "
                    f"service is unavailable: {self.error}",
                )
            return (
                "MICROPHONE-001",
                "Microphone redirection is required, but no local recording "
                "device is available.",
            )

        return None


CommandRunner = Callable[..., subprocess.CompletedProcess[str]]


class AudioRedirectionService:
    """Gestiona la política FreeRDP i detecta l'àudio local.

    La detecció prefereix ``pactl``, que funciona tant amb PulseAudio com amb
    PipeWire mitjançant ``pipewire-pulse``. La construcció de la comanda RDP
    continua separada de la detecció i les polítiques obligatòries es validen
    abans d'executar FreeRDP.
    """

    def __init__(
        self,
        *,
        runner: CommandRunner = subprocess.run,
        which: Callable[[str], str | None] = shutil.which,
        timeout: float = 3.0,
    ) -> None:
        self._runner = runner
        self._which = which
        self.timeout = timeout

    def get_policy(
        self,
        *,
        playback_enabled: bool,
        recording_enabled: bool,
        playback_required: bool = False,
        recording_required: bool = False,
    ) -> AudioRedirectionPolicy:
        return AudioRedirectionPolicy(
            playback_enabled=bool(playback_enabled),
            recording_enabled=bool(recording_enabled),
            playback_required=bool(playback_required),
            recording_required=bool(recording_required),
        )

    def build_arguments(self, policy: AudioRedirectionPolicy) -> tuple[str, ...]:
        arguments: list[str] = []
        if policy.playback_enabled:
            arguments.append("/sound")
        if policy.recording_enabled:
            arguments.append("/microphone")
        return tuple(arguments)

    def get_status(self, policy: AudioRedirectionPolicy) -> AudioRedirectionStatus:
        """Detecta dispositius de reproducció i enregistrament locals."""
        if not policy.playback_enabled and not policy.recording_enabled:
            return AudioRedirectionStatus(policy=policy)

        pactl = self._which("pactl")
        if pactl is None:
            return AudioRedirectionStatus(
                policy=policy,
                error="The pactl executable was not found.",
            )

        try:
            info = self._run((pactl, "info"))
            sinks = (
                self._run((pactl, "list", "short", "sinks"))
                if policy.playback_enabled
                else None
            )
            sources = (
                self._run((pactl, "list", "short", "sources"))
                if policy.recording_enabled
                else None
            )
        except (OSError, subprocess.SubprocessError) as error:
            return AudioRedirectionStatus(
                policy=policy,
                backend="pactl",
                error=str(error) or error.__class__.__name__,
            )

        if info.returncode != 0:
            return AudioRedirectionStatus(
                policy=policy,
                backend="pactl",
                error=self._command_error(info, "The audio server is unavailable."),
            )
        if sinks is not None and sinks.returncode != 0:
            return AudioRedirectionStatus(
                policy=policy,
                backend="pactl",
                error=self._command_error(sinks, "Playback devices could not be detected."),
            )
        if sources is not None and sources.returncode != 0:
            return AudioRedirectionStatus(
                policy=policy,
                backend="pactl",
                error=self._command_error(sources, "Recording devices could not be detected."),
            )

        default_sink = self._info_value(info.stdout, "Default Sink")
        default_source = self._info_value(info.stdout, "Default Source")
        playback = (
            self._parse_short_devices(
                sinks.stdout,
                kind="playback",
                default_name=default_sink,
            )
            if sinks is not None
            else ()
        )
        recording = (
            tuple(
                endpoint
                for endpoint in self._parse_short_devices(
                    sources.stdout,
                    kind="recording",
                    default_name=default_source,
                )
                if not endpoint.name.casefold().endswith(".monitor")
            )
            if sources is not None
            else ()
        )
        server_name = self._info_value(info.stdout, "Server Name")
        backend = self._backend_name(server_name)

        return AudioRedirectionStatus(
            policy=policy,
            backend=backend,
            playback_devices=playback,
            recording_devices=recording,
        )

    def _run(self, command: Sequence[str]) -> subprocess.CompletedProcess[str]:
        environment = os.environ.copy()
        environment.update({"LC_ALL": "C", "LANG": "C"})
        return self._runner(
            list(command),
            capture_output=True,
            text=True,
            timeout=self.timeout,
            check=False,
            env=environment,
        )

    @staticmethod
    def _command_error(
        result: subprocess.CompletedProcess[str],
        fallback: str,
    ) -> str:
        detail = (result.stderr or result.stdout or "").strip()
        return detail or fallback

    @staticmethod
    def _info_value(output: str, key: str) -> str | None:
        prefix = f"{key}:"
        for raw_line in output.splitlines():
            line = raw_line.strip()
            if line.startswith(prefix):
                value = line[len(prefix):].strip()
                return value or None
        return None

    @staticmethod
    def _backend_name(server_name: str | None) -> str:
        if not server_name:
            return "pactl"
        folded = server_name.casefold()
        if "pipewire" in folded:
            return "PipeWire (PulseAudio compatibility)"
        if "pulseaudio" in folded or "pulse audio" in folded:
            return "PulseAudio"
        return server_name

    @staticmethod
    def _parse_short_devices(
        output: str,
        *,
        kind: str,
        default_name: str | None,
    ) -> tuple[AudioEndpoint, ...]:
        devices: list[AudioEndpoint] = []
        seen: set[str] = set()
        default_key = (default_name or "").casefold()

        for raw_line in output.splitlines():
            columns = raw_line.split("\t")
            if len(columns) < 2:
                columns = raw_line.split(maxsplit=2)
            if len(columns) < 2:
                continue
            name = columns[1].strip()
            if not name:
                continue
            key = name.casefold()
            if key in seen:
                continue
            seen.add(key)
            description = columns[1].strip()
            devices.append(
                AudioEndpoint(
                    name=name,
                    description=description,
                    kind=kind,
                    is_default=key == default_key,
                )
            )
        return tuple(devices)

from __future__ import annotations

from dataclasses import dataclass, field

from xaac_thinclient.services.diagnostics import DiagnosticService
from xaac_thinclient.services.dns import DnsService
from xaac_thinclient.services.network import NetworkService
from xaac_thinclient.services.rdp import FreeRdpBackend
from xaac_thinclient.services.remote_desktop import RemoteDesktopBackend
from xaac_thinclient.services.smartcard import SmartCardService
from xaac_thinclient.services.usb import UsbService
from xaac_thinclient.services.drives import DriveRedirectionService
from xaac_thinclient.services.printers import PrinterRedirectionService
from xaac_thinclient.services.audio import AudioRedirectionService
from xaac_thinclient.services.video import VideoRedirectionService
from xaac_thinclient.services.freerdp_capabilities import FreeRdpCapabilityService
from xaac_thinclient.services.remote_configuration import (
    RemoteConfigurationService,
)
from xaac_thinclient.services.remote_telemetry import RemoteTelemetryService
from xaac_thinclient.system.power import PowerActionService


@dataclass(frozen=True, slots=True)
class ApplicationServices:
    """Agrupa els serveis utilitzats per l'aplicació.

    El contenidor permet injectar implementacions reals o dobles de prova
    sense que el controlador haja de conéixer com es construeixen.
    """

    network: NetworkService
    dns: DnsService
    rdp: RemoteDesktopBackend
    smartcard: SmartCardService = field(default_factory=SmartCardService)
    usb: UsbService = field(default_factory=UsbService)
    drives: DriveRedirectionService = field(
        default_factory=DriveRedirectionService
    )
    printers: PrinterRedirectionService = field(
        default_factory=PrinterRedirectionService
    )
    audio: AudioRedirectionService = field(
        default_factory=AudioRedirectionService
    )
    video: VideoRedirectionService = field(
        default_factory=VideoRedirectionService
    )
    freerdp_capabilities: FreeRdpCapabilityService = field(
        default_factory=FreeRdpCapabilityService
    )
    diagnostics: DiagnosticService = field(
        default_factory=DiagnosticService
    )
    remote_configuration: RemoteConfigurationService = field(
        default_factory=RemoteConfigurationService
    )
    remote_telemetry: RemoteTelemetryService = field(
        default_factory=RemoteTelemetryService
    )
    power: PowerActionService = field(default_factory=PowerActionService)

    @property
    def remote_desktop(self) -> RemoteDesktopBackend:
        """Retorna el backend d'escriptori remot configurat.

        La propietat ``rdp`` es conserva per compatibilitat amb el codi
        existent, mentre que ``remote_desktop`` és el nom independent del
        protocol que haurà d'utilitzar el nou codi.
        """
        return self.rdp

    @classmethod
    def create_default(cls) -> ApplicationServices:
        """Crea el conjunt de serveis utilitzat en producció."""
        usb = UsbService()
        drives = DriveRedirectionService()
        printers = PrinterRedirectionService()
        audio = AudioRedirectionService()
        video = VideoRedirectionService()
        freerdp_capabilities = FreeRdpCapabilityService()
        dns = DnsService()
        smartcard = SmartCardService()
        return cls(
            network=NetworkService(),
            dns=dns,
            rdp=FreeRdpBackend(
                usb_service=usb,
                drive_service=drives,
                printer_service=printers,
                audio_service=audio,
                video_service=video,
                capability_service=freerdp_capabilities,
                dns_service=dns,
                smartcard_service=smartcard,
                preflight_enabled=True,
                network_quality_enabled=True,
            ),
            smartcard=smartcard,
            usb=usb,
            drives=drives,
            printers=printers,
            audio=audio,
            video=video,
            freerdp_capabilities=freerdp_capabilities,
            diagnostics=DiagnosticService(
                usb_service=usb,
                drive_service=drives,
                printer_service=printers,
                audio_service=audio,
                video_service=video,
                capability_service=freerdp_capabilities,
            ),
            remote_configuration=RemoteConfigurationService(),
            remote_telemetry=RemoteTelemetryService(),
        )

from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass
from enum import Enum
from types import MappingProxyType
import os
import re
import subprocess

from xaac_thinclient.services.logging import get_logger

_SUBPROCESS_POPEN = subprocess.Popen

logger = get_logger(__name__)


_LAYOUT_IDS = MappingProxyType({
    # Català i castellà
    "ca": "0x00000403",
    "ca-es": "0x00000403",
    "catalan": "0x00000403",
    "es": "0x0000040a",
    "es-es": "0x0000040a",
    "spanish": "0x0000040a",
    "es-419": "0x0000080a",
    "es-latam": "0x0000080a",
    "latin-american": "0x0000080a",
    "latam": "0x0000080a",

    # Anglés
    "en": "0x00000409",
    "en-us": "0x00000409",
    "us": "0x00000409",
    "english-us": "0x00000409",
    "en-gb": "0x00000809",
    "gb": "0x00000809",
    "english-uk": "0x00000809",

    # Francés, alemany, italià i neerlandés
    "fr": "0x0000040c",
    "fr-fr": "0x0000040c",
    "fr-be": "0x0000080c",
    "fr-ca": "0x00000c0c",
    "fr-ch": "0x0000100c",
    "de": "0x00000407",
    "de-de": "0x00000407",
    "de-ch": "0x00000807",
    "de-at": "0x00000c07",
    "it": "0x00000410",
    "it-it": "0x00000410",
    "nl": "0x00000413",
    "nl-nl": "0x00000413",
    "nl-be": "0x00000813",

    # Portugués
    "pt": "0x00000816",
    "pt-pt": "0x00000816",
    "portuguese": "0x00000816",
    "pt-br": "0x00000416",
    "br": "0x00000416",
    "brazilian": "0x00000416",

    # Països nòrdics
    "da": "0x00000406",
    "da-dk": "0x00000406",
    "dk": "0x00000406",
    "fi": "0x0000040b",
    "fi-fi": "0x0000040b",
    "sv": "0x0000041d",
    "sv-se": "0x0000041d",
    "se": "0x0000041d",
    "no": "0x00000414",
    "nb": "0x00000414",
    "nb-no": "0x00000414",
    "nn": "0x00000414",
    "nn-no": "0x00000414",

    # Europa central i oriental
    "pl": "0x00000415",
    "pl-pl": "0x00000415",
    "cs": "0x00000405",
    "cs-cz": "0x00000405",
    "cz": "0x00000405",
    "hu": "0x0000040e",
    "hu-hu": "0x0000040e",
    "ro": "0x00000418",
    "ro-ro": "0x00000418",
    "tr": "0x0000041f",
    "tr-tr": "0x0000041f",
    "el": "0x00000408",
    "el-gr": "0x00000408",
    "gr": "0x00000408",
    "ru": "0x00000419",
    "ru-ru": "0x00000419",
    "uk": "0x00000422",
    "uk-ua": "0x00000422",
    "ua": "0x00000422",
    "ukrainian": "0x00000422",

    # Àsia oriental (layouts base de Windows)
    "ja": "0x00000411",
    "ja-jp": "0x00000411",
    "jp": "0x00000411",
    "ko": "0x00000412",
    "ko-kr": "0x00000412",
    "kr": "0x00000412",
})

_LAYOUT_PATTERN = re.compile(r"^0x[0-9a-f]{8}$", re.IGNORECASE)
_CUSTOM_LAYOUT_PREFIX = "custom:"
_CATALAN_VARIANTS = frozenset({"cat", "catalan"})


class KeyboardStatusCode(str, Enum):
    CONFIGURED = "configured"
    LOCAL_DETECTED = "local-detected"
    LANGUAGE_FALLBACK = "language-fallback"


_STATUS_DETAILS = {
    KeyboardStatusCode.CONFIGURED: "An explicit keyboard layout is configured.",
    KeyboardStatusCode.LOCAL_DETECTED: "The effective keyboard layout was detected from the local XKB configuration.",
    KeyboardStatusCode.LANGUAGE_FALLBACK: "Local keyboard detection was unavailable; the application language was used as fallback.",
}


@dataclass(frozen=True, slots=True)
class KeyboardDetection:
    layout: str | None
    variant: str | None
    source: str


@dataclass(frozen=True, slots=True)
class KeyboardResolution:
    configured_layout: str
    effective_layout: str
    layout_id: str
    automatic: bool
    source: str = "configured"
    detected_layout: str | None = None
    detected_variant: str | None = None
    status_code: KeyboardStatusCode = KeyboardStatusCode.CONFIGURED
    status_detail: str = _STATUS_DETAILS[KeyboardStatusCode.CONFIGURED]


class KeyboardService:
    """Resol la distribució RDP i detecta de forma segura el teclat XKB local."""

    def __init__(
        self,
        *,
        environment: Mapping[str, str] | None = None,
        command_runner: Callable[[tuple[str, ...]], str | None] | None = None,
    ) -> None:
        self.environment = environment if environment is not None else os.environ
        self.command_runner = command_runner or self._run_command

    def resolve(self, configured_layout: str, application_language: str) -> KeyboardResolution:
        configured = self.normalise_layout_name(configured_layout) or "auto"
        automatic = configured == "auto"
        detection = KeyboardDetection(None, None, "not-requested")

        if automatic:
            detection = self.detect_local_layout()
            effective = self._normalise_detected(detection)
            if effective is None:
                effective = self.normalise_layout_name(application_language) or "en-us"
                source = "application-language"
                status_code = KeyboardStatusCode.LANGUAGE_FALLBACK
            else:
                source = detection.source
                status_code = KeyboardStatusCode.LOCAL_DETECTED
        else:
            effective = configured
            source = "configured"
            status_code = KeyboardStatusCode.CONFIGURED

        layout_id = self._layout_id(effective)
        if layout_id is None:
            raise ValueError(f"Unsupported keyboard layout: {configured_layout}")

        return KeyboardResolution(
            configured_layout=configured,
            effective_layout=effective,
            layout_id=layout_id,
            automatic=automatic,
            source=source,
            detected_layout=detection.layout,
            detected_variant=detection.variant,
            status_code=status_code,
            status_detail=_STATUS_DETAILS[status_code],
        )

    def detect_local_layout(self) -> KeyboardDetection:
        layout = self._first_value(self.environment.get("XKB_DEFAULT_LAYOUT"))
        variant = self._first_value(self.environment.get("XKB_DEFAULT_VARIANT"))
        if layout:
            return KeyboardDetection(layout, variant, "environment")

        output = self.command_runner(("localectl", "status"))
        if output:
            layout = self._extract_field(output, "X11 Layout")
            variant = self._extract_field(output, "X11 Variant")
            if layout:
                return KeyboardDetection(layout, variant, "localectl")

        output = self.command_runner(("localectl", "show", "--property=X11Layout", "--property=X11Variant"))
        if output:
            layout = self._extract_assignment(output, "X11Layout")
            variant = self._extract_assignment(output, "X11Variant")
            if layout:
                return KeyboardDetection(layout, variant, "localectl")

        output = self.command_runner(("setxkbmap", "-query"))
        if output:
            layout = self._extract_field(output, "layout")
            variant = self._extract_field(output, "variant")
            if layout:
                return KeyboardDetection(layout, variant, "setxkbmap")

        return KeyboardDetection(None, None, "unavailable")

    @staticmethod
    def audit_resolution(
        resolution: KeyboardResolution,
        *,
        managed_source: str = "system",
    ) -> None:
        """Registra de forma estructurada la resolució efectiva del teclat."""
        logger.debug(
            "keyboard_layout_resolved configured=%s effective=%s layout_id=%s "
            "automatic=%s detection_source=%s status=%s managed_source=%s",
            resolution.configured_layout,
            resolution.effective_layout,
            resolution.layout_id,
            str(resolution.automatic).lower(),
            resolution.source,
            resolution.status_code.value,
            managed_source,
        )
        if resolution.status_code is KeyboardStatusCode.LANGUAGE_FALLBACK:
            logger.info(
                "keyboard_layout_fallback effective=%s layout_id=%s",
                resolution.effective_layout,
                resolution.layout_id,
            )

    @staticmethod
    def build_arguments(resolution: KeyboardResolution) -> tuple[str, ...]:
        return (f"/kbd:layout:{resolution.layout_id}",)


    @staticmethod
    def normalise_layout_name(value: str | None) -> str:
        """Normalitza noms de layout sense modificar identificadors KLID."""
        return (value or "").strip().lower().replace("_", "-")

    @classmethod
    def supported_layouts(cls) -> tuple[str, ...]:
        """Retorna el catàleg públic d'àlies en ordre estable i immutable."""
        return tuple(sorted(_LAYOUT_IDS))

    @classmethod
    def is_supported(cls, layout: str) -> bool:
        """Indica si un àlies, KLID directe o KLID personalitzat és vàlid."""
        normalised = cls.normalise_layout_name(layout)
        return bool(normalised) and cls._layout_id(normalised) is not None

    @staticmethod
    def _normalise_detected(detection: KeyboardDetection) -> str | None:
        layout = KeyboardService.normalise_layout_name(detection.layout)
        variant = KeyboardService.normalise_layout_name(detection.variant)
        if not layout:
            return None
        if layout == "es" and variant in _CATALAN_VARIANTS:
            return "ca"
        return layout

    @staticmethod
    def _layout_id(effective: str) -> str | None:
        custom_value = KeyboardService._custom_layout_value(effective)
        if custom_value is not None:
            return custom_value

        layout_id = _LAYOUT_IDS.get(effective)
        if layout_id is None and "-" in effective:
            layout_id = _LAYOUT_IDS.get(effective.split("-", 1)[0])
        if layout_id is None and _LAYOUT_PATTERN.fullmatch(effective):
            layout_id = effective.lower()
        return layout_id

    @staticmethod
    def _custom_layout_value(effective: str) -> str | None:
        if not effective.startswith(_CUSTOM_LAYOUT_PREFIX):
            return None
        value = effective.removeprefix(_CUSTOM_LAYOUT_PREFIX).strip()
        if not _LAYOUT_PATTERN.fullmatch(value):
            return None
        return value.lower()

    @staticmethod
    def _first_value(value: str | None) -> str | None:
        if not value:
            return None
        first = value.split(",", 1)[0].strip()
        return first or None

    @classmethod
    def _extract_field(cls, output: str, field: str) -> str | None:
        pattern = re.compile(rf"^\s*{re.escape(field)}\s*:\s*(.*?)\s*$", re.IGNORECASE | re.MULTILINE)
        match = pattern.search(output)
        return cls._first_value(match.group(1)) if match else None

    @classmethod
    def _extract_assignment(cls, output: str, field: str) -> str | None:
        pattern = re.compile(rf"^\s*{re.escape(field)}\s*=\s*(.*?)\s*$", re.IGNORECASE | re.MULTILINE)
        match = pattern.search(output)
        return cls._first_value(match.group(1)) if match else None

    @staticmethod
    def _run_command(command: tuple[str, ...]) -> str | None:
        try:
            process = _SUBPROCESS_POPEN(
                command,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                text=True,
            )
            stdout, _ = process.communicate(timeout=1.0)
        except subprocess.TimeoutExpired:
            process.kill()
            process.communicate()
            return None
        except (FileNotFoundError, OSError, subprocess.SubprocessError):
            return None
        if process.returncode != 0:
            return None
        return stdout or None

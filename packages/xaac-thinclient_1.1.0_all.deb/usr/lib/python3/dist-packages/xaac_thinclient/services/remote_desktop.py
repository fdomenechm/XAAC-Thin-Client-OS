from __future__ import annotations

from collections.abc import Callable
from typing import Protocol, runtime_checkable

from xaac_thinclient.config.models import ThinClientConfig
from xaac_thinclient.rdp.session import RdpSessionPlan
from xaac_thinclient.services.rdp import (
    RdpAvailability,
    RdpSessionResult,
)


@runtime_checkable
class RemoteDesktopBackend(Protocol):
    """Contracte comú per als backends d'escriptori remot.

    El controlador depén d'aquest contracte i no d'una implementació
    concreta. Això permet substituir FreeRDP per altres tecnologies sense
    modificar la lògica d'orquestració ni la interfície gràfica.
    """

    def check_availability(
        self,
        server: str,
        port: int,
        timeout: float,
    ) -> RdpAvailability:
        """Comprova si el servei remot configurat està disponible."""
        ...

    def prepare_session(
        self,
        config: ThinClientConfig,
        username: str,
        monitor_count: int,
    ) -> RdpSessionPlan:
        """Prepara i valida un pla immutable sense executar-lo."""
        ...

    def execute_session_plan(
        self,
        plan: RdpSessionPlan,
        password: str,
        on_started: Callable[[], None] | None = None,
    ) -> RdpSessionResult:
        """Executa un pla prèviament preparat.

        ``on_started`` s'emet quan el client ha superat la postconnexió
        gràfica, no simplement quan s'ha creat el procés FreeRDP.
        """
        ...

    def connect(
        self,
        config: ThinClientConfig,
        username: str,
        password: str,
        monitor_count: int,
        on_started: Callable[[], None] | None = None,
    ) -> RdpSessionResult:
        """Inicia una sessió remota i retorna-ne el resultat final.

        ``on_started`` indica que la sessió ha arribat a la fase gràfica de
        postconnexió.
        """
        ...

    def disconnect(self) -> None:
        """Finalitza la sessió remota activa, si existeix."""
        ...

from __future__ import annotations

import shlex
import threading
from dataclasses import dataclass
from subprocess import PIPE
from typing import Callable, Protocol, TextIO

from xaac_thinclient.i18n import _
from xaac_thinclient.rdp.session import RdpSessionPlan
from xaac_thinclient.rdp.credentials import RdpCredentialError, RdpCredentialSecret
from xaac_thinclient.rdp.audit import RdpSecurityAuditEvent, RdpSecurityAuditReport
from xaac_thinclient.services.logging import get_logger

logger = get_logger(__name__)

_GRACEFUL_REMOTE_TERMINATION_MARKERS = (
    "ERRINFO_LOGOFF_BY_USER",
    "ERRINFO_RPC_INITIATED_LOGOFF",
    "ERRINFO_RPC_INITIATED_DISCONNECT",
)

# FreeRDP can emit these messages when stdin is a pipe rather than a terminal, or
# when the local XKB map contains keys without an RDP scancode. They do not
# affect an otherwise successful session and must not pollute normal INFO logs.
_BENIGN_FREERDP_STDERR_MARKERS = (
    "[info]",
    "[debug]",
    "[trace]",
    "[set_terminal_nonblock]",
    "tcgetattr() failed",
    "tcsetattr(tcsanow) failed",
    "[load_map_from_xkbfile]",
    "no rdp scancode found",
)

# These diagnostics are relevant when a session cannot be established, but are
# expected fallback noise after a session has connected and ended normally.
_SUCCESSFUL_SESSION_NOISE_MARKERS = (
    "certificate does not have a subject",
    "unable to get local issuer certificate",
    "[verify_cb]",
    "cannot find kdc for realm",
    "krb5_init_creds_get",
    "kerberos_acquirecredentialshandle",
    "krb5glue",
    "errinfo_logoff_by_user",
    "errinfo_rpc_initiated_logoff",
    "errinfo_rpc_initiated_disconnect",
)

# xfreerdp does not expose a dedicated CLI callback for "the graphical
# session is now usable".  With INFO logging enabled, framebuffer
# initialisation happens after the RDP protocol post-connect stage and is a
# reliable signal that the X11 client has progressed beyond mere process
# creation / TCP connection.
_RDP_CONNECTED_LOG_MARKERS = (
    "local framebuffer format",
    "remote framebuffer format",
)

# FreeRDP X11 reserves 129..160 for client/protocol/connection failures (authentication,
# TLS, DNS, access denied, target booting, etc.).  These are not transient
# disconnects of an already established desktop and therefore must not trigger
# the automatic reconnection loop.
_FREERDP_INITIAL_CONNECTION_EXIT_CODES = frozenset(range(129, 161))


def _partition_freerdp_stderr(
    stderr_text: str,
    *,
    successful_session: bool = False,
) -> tuple[list[str], list[str]]:
    """Split FreeRDP stderr into actionable and known-benign lines.

    Certificate-chain and Kerberos fallback diagnostics are hidden only after
    an otherwise successful session. They remain actionable when startup or
    authentication fails.
    """

    actionable: list[str] = []
    benign: list[str] = []
    for raw_line in stderr_text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        lowered = line.casefold()
        always_benign = any(
            marker in lowered for marker in _BENIGN_FREERDP_STDERR_MARKERS
        )
        successful_noise = successful_session and any(
            marker in lowered for marker in _SUCCESSFUL_SESSION_NOISE_MARKERS
        )
        if always_benign or successful_noise:
            benign.append(line)
        else:
            actionable.append(line)
    return actionable, benign


def _log_freerdp_stderr(
    stderr_text: str,
    *,
    successful_session: bool = False,
) -> None:
    """Log only actionable FreeRDP diagnostics at normal log levels."""

    actionable, benign = _partition_freerdp_stderr(
        stderr_text, successful_session=successful_session
    )
    if actionable:
        logger.warning("FreeRDP stderr: %s", "\n".join(actionable))
    if benign:
        logger.debug(
            "FreeRDP: %s missatges tècnics coneguts ocultats: %s",
            len(benign),
            " | ".join(benign),
        )


def _is_graceful_remote_termination(stdout_text: str, stderr_text: str) -> bool:
    """Return True when FreeRDP reports an intentional remote session closure."""

    combined = f"{stdout_text}\n{stderr_text}".upper()
    return any(marker in combined for marker in _GRACEFUL_REMOTE_TERMINATION_MARKERS)



class RdpProcess(Protocol):
    stdin: TextIO | None
    stdout: TextIO | None
    stderr: TextIO | None

    def wait(self) -> int: ...
    def poll(self) -> int | None: ...
    def terminate(self) -> None: ...


ProcessFactory = Callable[..., RdpProcess]


def _line_indicates_connected(line: str) -> bool:
    lowered = line.casefold()
    return any(marker in lowered for marker in _RDP_CONNECTED_LOG_MARKERS)


def _is_initial_connection_failure(return_code: int | None) -> bool:
    return return_code in _FREERDP_INITIAL_CONNECTION_EXIT_CODES


@dataclass(frozen=True, slots=True)
class RdpSessionResult:
    started: bool
    return_code: int | None = None
    error: str | None = None
    cancelled: bool = False
    error_code: str | None = None
    attempts: int = 1
    retries: int = 0
    reconnected: bool = False
    security_audit: RdpSecurityAuditReport = RdpSecurityAuditReport()
    connection_established: bool = False


class RdpSessionExecutor:
    """Execute an immutable RDP plan and recover transient disconnects."""

    def __init__(self, process_factory: ProcessFactory) -> None:
        self._process_factory = process_factory
        self._process: RdpProcess | None = None
        self._process_lock = threading.Lock()
        self._cancel_event = threading.Event()

    @property
    def active_process(self) -> RdpProcess | None:
        with self._process_lock:
            return self._process

    @active_process.setter
    def active_process(self, process: RdpProcess | None) -> None:
        with self._process_lock:
            self._process = process

    def execute(
        self,
        plan: RdpSessionPlan,
        password: str,
        on_started: Callable[[], None] | None = None,
    ) -> RdpSessionResult:
        audit = plan.security_audit.append(RdpSecurityAuditEvent.create(
            "RDP-AUDIT-EXECUTION", "execute", "requested",
            {"reconnect": str(plan.reconnect.enabled).lower()},
        ))

        def finalise(result: RdpSessionResult, outcome: str) -> RdpSessionResult:
            report = audit.append(RdpSecurityAuditEvent.create(
                "RDP-AUDIT-RESULT", "execute", outcome,
                {
                    "attempts": result.attempts,
                    "retries": result.retries,
                    "return_code": result.return_code if result.return_code is not None else "none",
                    "error_code": result.error_code or "none",
                },
            ))
            return RdpSessionResult(
                started=result.started, return_code=result.return_code,
                connection_established=result.connection_established, error=result.error,
                cancelled=result.cancelled, error_code=result.error_code,
                attempts=result.attempts, retries=result.retries,
                reconnected=result.reconnected, security_audit=report,
            )

        with self._process_lock:
            if self._process is not None:
                return finalise(RdpSessionResult(
                    started=False, error=_("An RDP session is already running."),
                ), "blocked")
        self._cancel_event.clear()
        retry_number = 0
        callback_pending = on_started
        try:
            secret = RdpCredentialSecret(password)
        except RdpCredentialError:
            return finalise(RdpSessionResult(
                started=False,
                error=_("The password contains invalid control characters."),
                error_code="RDP-CRED-001",
            ), "blocked")

        try:
            while True:
                result = self._execute_once(plan, secret, callback_pending)
                if result.connection_established:
                    callback_pending = None
                attempts = retry_number + 1
                if result.started or result.cancelled or self._cancel_event.is_set():
                    completed = RdpSessionResult(
                        started=result.started, return_code=result.return_code,
                        connection_established=result.connection_established, error=result.error,
                        cancelled=result.cancelled or self._cancel_event.is_set(),
                        error_code=result.error_code, attempts=attempts, retries=retry_number,
                        reconnected=result.started and retry_number > 0,
                    )
                    return finalise(completed, "cancelled" if completed.cancelled else "completed")

                if result.error_code not in {"RDP-EXEC-001", "RDP-EXEC-003", "RDP-EXEC-004"}:
                    return finalise(RdpSessionResult(
                        started=False, return_code=result.return_code,
                        connection_established=result.connection_established, error=result.error,
                        error_code=result.error_code, attempts=attempts, retries=retry_number,
                    ), "failed")

                retry_number += 1
                if not plan.reconnect.allows_retry(retry_number):
                    return finalise(RdpSessionResult(
                        started=False, return_code=result.return_code,
                        connection_established=result.connection_established, error=result.error,
                        error_code=result.error_code, attempts=attempts, retries=retry_number - 1,
                    ), "failed")

                delay = plan.reconnect.delay_for_retry(retry_number)
                audit = audit.append(RdpSecurityAuditEvent.create(
                    "RDP-AUDIT-RETRY", "execute", "scheduled",
                    {"retry": retry_number, "delay_seconds": f"{delay:.2f}"},
                ))
                logger.warning(
                    "Sessió RDP interrompuda; reintent %s/%s en %.2f segons",
                    retry_number, plan.reconnect.max_attempts, delay,
                )
                if self._cancel_event.wait(delay):
                    return finalise(RdpSessionResult(
                        started=False, return_code=result.return_code,
                        connection_established=result.connection_established, error=result.error,
                        cancelled=True, attempts=attempts, retries=retry_number - 1,
                    ), "cancelled")
        finally:
            secret.clear()

    def _execute_once(
        self,
        plan: RdpSessionPlan,
        secret: RdpCredentialSecret,
        on_started: Callable[[], None] | None,
    ) -> RdpSessionResult:
        command = plan.command_as_list()
        config = plan.effective_config

        if plan.degraded_features:
            logger.warning(
                "Sessió RDP degradada de manera segura: disabled=%s",
                ",".join(plan.degraded_features),
            )

        try:
            logger.info("Iniciant sessió RDP preparada: servidor=%s", config.device.server)
            logger.debug("Comanda FreeRDP efectiva: %s", shlex.join(command))
            process = self._process_factory(
                command,
                stdin=PIPE,
                stdout=PIPE,
                stderr=PIPE,
                text=True,
                bufsize=1,
                start_new_session=True,
            )
        except OSError as error:
            return RdpSessionResult(
                started=False,
                error=_("FreeRDP could not be started: {error}").format(error=error),
                error_code="RDP-EXEC-001",
            )

        with self._process_lock:
            if self._cancel_event.is_set():
                process.terminate()
                return RdpSessionResult(started=False, cancelled=True)
            self._process = process

        stdout_lines: list[str] = []
        stderr_lines: list[str] = []
        connection_signalled = threading.Event()
        callback_lock = threading.Lock()

        def consume_output(stream: TextIO | None, sink: list[str]) -> None:
            if stream is None:
                return
            try:
                for line in stream:
                    sink.append(line)
                    if not _line_indicates_connected(line):
                        continue
                    with callback_lock:
                        if connection_signalled.is_set():
                            continue
                        connection_signalled.set()
                    if on_started is not None:
                        try:
                            on_started()
                        except Exception:
                            logger.exception(
                                "Error notificant l'establiment de la sessió RDP"
                            )
            except (OSError, TypeError, ValueError):
                # El procés pot tancar els pipes mentre finalitza. La lectura de
                # diagnòstic no ha d'alterar el resultat de la sessió.
                logger.debug("Canal de log de FreeRDP tancat durant la lectura")

        readers = [
            threading.Thread(
                target=consume_output,
                args=(getattr(process, "stdout", None), stdout_lines),
                name="xaac-rdp-stdout",
                daemon=True,
            ),
            threading.Thread(
                target=consume_output,
                args=(getattr(process, "stderr", None), stderr_lines),
                name="xaac-rdp-stderr",
                daemon=True,
            ),
        ]
        for reader in readers:
            reader.start()

        try:
            if process.stdin is None:
                process.terminate()
                return RdpSessionResult(
                    started=False,
                    error=_("The password could not be sent to FreeRDP."),
                    error_code="RDP-EXEC-002",
                )

            secret.write_to(process.stdin)
            process.stdin.close()

            return_code = process.wait()
            for reader in readers:
                reader.join(timeout=1.0)

            stdout_text = "".join(stdout_lines).strip()
            stderr_text = "".join(stderr_lines).strip()

            logger.info("Sessió RDP finalitzada amb codi %s", return_code)
            if stdout_text:
                logger.debug("FreeRDP stdout: %s", stdout_text)

            graceful_remote_termination = _is_graceful_remote_termination(
                stdout_text,
                stderr_text,
            )
            successful_session = (
                return_code == 0
                or return_code == -15
                or graceful_remote_termination
            )
            if stderr_text:
                _log_freerdp_stderr(
                    stderr_text, successful_session=successful_session
                )
            if graceful_remote_termination:
                logger.info(
                    "Sessió RDP tancada voluntàriament al servidor; no es reconnectarà"
                )

            if (
                return_code != 0
                and return_code != -15
                and not graceful_remote_termination
            ):
                actionable_stderr, benign_stderr = _partition_freerdp_stderr(
                    stderr_text, successful_session=False
                )
                detail = "\n".join(actionable_stderr) or stdout_text or _(
                    "FreeRDP ended with return code {code}."
                ).format(code=return_code)
                return RdpSessionResult(
                    started=False,
                    return_code=return_code,
                    connection_established=connection_signalled.is_set(),
                    error=detail,
                    error_code=(
                        "RDP-EXEC-005"
                        if (
                            not connection_signalled.is_set()
                            and _is_initial_connection_failure(return_code)
                        )
                        else "RDP-EXEC-003"
                    ),
                )

            return RdpSessionResult(
                started=True,
                return_code=return_code,
                connection_established=connection_signalled.is_set(),
                cancelled=return_code == -15 or self._cancel_event.is_set(),
            )
        except (BrokenPipeError, OSError) as error:
            logger.exception("No s'ha pogut iniciar o gestionar la sessió RDP")
            return RdpSessionResult(
                started=False,
                error=_("FreeRDP ended unexpectedly: {error}").format(error=error),
                error_code="RDP-EXEC-004",
            )
        finally:
            for stream_name in ("stdout", "stderr"):
                stream = getattr(process, stream_name, None)
                if stream is not None:
                    try:
                        stream.close()
                    except OSError:
                        pass
            with self._process_lock:
                if self._process is process:
                    self._process = None

    def disconnect(self) -> None:
        self._cancel_event.set()
        with self._process_lock:
            process = self._process
        if process is None or process.poll() is not None:
            return
        process.terminate()

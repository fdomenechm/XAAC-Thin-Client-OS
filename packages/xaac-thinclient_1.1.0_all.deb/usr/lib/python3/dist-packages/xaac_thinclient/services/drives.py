from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path


_MOUNT_ESCAPE = re.compile(r"\\([0-7]{3})")
_SAFE_NAME = re.compile(r"[^A-Za-z0-9_-]+")


@dataclass(frozen=True, slots=True)
class DriveShare:
    name: str
    path: Path


@dataclass(frozen=True, slots=True)
class DriveRedirectionStatus:
    enabled: bool
    shares: tuple[DriveShare, ...] = ()
    error: str | None = None


class DriveRedirectionService:
    """Descobreix punts de muntatge extraïbles per a RDPDR.

    Només s'accepten muntatges situats davall de les arrels
    administratives configurades. Això evita compartir accidentalment
    el directori personal o el sistema de fitxers complet.
    """

    def __init__(
        self,
        mountinfo_path: Path = Path("/proc/self/mountinfo"),
    ) -> None:
        self.mountinfo_path = mountinfo_path

    def get_status(
        self,
        *,
        enabled: bool,
        include_existing: bool,
        allowed_roots: tuple[str, ...],
    ) -> DriveRedirectionStatus:
        if not enabled or not include_existing:
            return DriveRedirectionStatus(enabled=enabled)

        try:
            shares = self.discover(allowed_roots)
        except OSError as error:
            return DriveRedirectionStatus(enabled=True, error=str(error))

        return DriveRedirectionStatus(enabled=True, shares=shares)

    def discover(
        self,
        allowed_roots: tuple[str, ...],
    ) -> tuple[DriveShare, ...]:
        roots = tuple(
            Path(root).expanduser().resolve(strict=False)
            for root in allowed_roots
            if root.strip()
        )
        if not roots:
            return ()

        text = self.mountinfo_path.read_text(
            encoding="utf-8", errors="replace"
        )
        mount_points: list[Path] = []
        for line in text.splitlines():
            fields = line.split()
            if len(fields) < 6:
                continue
            mount_point = Path(self._unescape(fields[4])).resolve(strict=False)
            if not self._is_below_allowed_root(mount_point, roots):
                continue
            if mount_point in mount_points:
                continue
            # La sintaxi /drive:<name>,<path> usa la coma com a
            # separador i FreeRDP no ofereix escapament estable ací.
            if "," in str(mount_point):
                continue
            mount_points.append(mount_point)

        shares: list[DriveShare] = []
        used_names: set[str] = set()
        for index, mount_point in enumerate(sorted(mount_points), start=1):
            base = self._share_name(mount_point, index)
            name = base
            suffix = 2
            while name.casefold() in used_names:
                name = f"{base}_{suffix}"
                suffix += 1
            used_names.add(name.casefold())
            shares.append(DriveShare(name=name, path=mount_point))

        return tuple(shares)

    @staticmethod
    def _is_below_allowed_root(path: Path, roots: tuple[Path, ...]) -> bool:
        for root in roots:
            if path == root:
                continue
            try:
                path.relative_to(root)
            except ValueError:
                continue
            return True
        return False

    @staticmethod
    def _unescape(value: str) -> str:
        return _MOUNT_ESCAPE.sub(
            lambda match: chr(int(match.group(1), 8)),
            value,
        )

    @staticmethod
    def _share_name(path: Path, index: int) -> str:
        cleaned = _SAFE_NAME.sub("_", path.name).strip("_")
        if not cleaned:
            cleaned = f"MEDIA_{index}"
        return f"XAAC_{cleaned}"[:64]

from __future__ import annotations

import gettext
from pathlib import Path

DOMAIN = "xaac-thinclient"
LOCALE_DIR = Path(__file__).resolve().parent / "locale"

_translation: gettext.NullTranslations = gettext.translation(
    DOMAIN,
    localedir=LOCALE_DIR,
    languages=["ca"],
    fallback=True,
)


def configure_language(language: str | None) -> None:
    """Configura l'idioma actiu de l'aplicació."""
    global _translation

    normalized = (language or "ca").strip().replace("_", "-")
    language_code = normalized.split("-", 1)[0].lower() or "ca"

    _translation = gettext.translation(
        DOMAIN,
        localedir=LOCALE_DIR,
        languages=[language_code],
        fallback=True,
    )


def gettext_message(message: str) -> str:
    """Retorna la traducció activa d'una cadena."""
    return _translation.gettext(message)


_ = gettext_message

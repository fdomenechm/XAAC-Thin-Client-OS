from __future__ import annotations

from pathlib import Path

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")

from gi.repository import Gdk, Gio, GLib, Gtk

from xaac_thinclient.i18n import _
from xaac_thinclient.services.diagnostics import DiagnosticReport
from xaac_thinclient.services.logging import get_logger


logger = get_logger(__name__)


class DiagnosticDialog(Gtk.Window):
    """Mostra un informe de diagnòstic i permet copiar-lo o desar-lo."""

    def __init__(
        self,
        *,
        parent: Gtk.Window,
        report: DiagnosticReport,
        initial_path: Path,
    ) -> None:
        super().__init__(
            title=_("Diagnostic report"),
            transient_for=parent,
            modal=True,
        )

        self.report = report
        self.initial_path = initial_path
        self.report_text = report.render_text()
        self._save_chooser: Gtk.FileChooserNative | None = None
        self._action_busy = False
        self._busy_button: Gtk.Button | None = None

        self.set_default_size(760, 560)
        self.set_resizable(True)

        header = Gtk.HeaderBar()
        header.set_show_title_buttons(False)
        close_button = Gtk.Button()
        close_button.set_icon_name("window-close-symbolic")
        close_button.set_tooltip_text(_("Close"))
        close_button.connect("clicked", self._on_close_requested)
        header.pack_end(close_button)
        self.set_titlebar(header)

        self._build_interface()

    def _build_interface(self) -> None:
        root = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=12,
        )
        root.set_margin_top(16)
        root.set_margin_bottom(16)
        root.set_margin_start(16)
        root.set_margin_end(16)
        self.set_child(root)

        heading = Gtk.Label(
            label=_("XAAC Thin Client Remote diagnostic report")
        )
        heading.set_halign(Gtk.Align.START)
        heading.add_css_class("diagnostic-title")
        root.append(heading)

        description = Gtk.Label(
            label=_(
                "This report contains technical information for support. "
                "It does not include usernames or passwords."
            )
        )
        description.set_wrap(True)
        description.set_halign(Gtk.Align.START)
        description.set_xalign(0.0)
        description.add_css_class("diagnostic-description")
        root.append(description)

        path_label = Gtk.Label(
            label=_("Saved automatically in: {path}").format(
                path=str(self.initial_path),
            )
        )
        path_label.set_selectable(True)
        path_label.set_wrap(True)
        path_label.set_halign(Gtk.Align.START)
        path_label.set_xalign(0.0)
        path_label.add_css_class("diagnostic-path")
        root.append(path_label)

        scrolled = Gtk.ScrolledWindow()
        scrolled.set_hexpand(True)
        scrolled.set_vexpand(True)
        scrolled.set_policy(
            Gtk.PolicyType.AUTOMATIC,
            Gtk.PolicyType.AUTOMATIC,
        )
        root.append(scrolled)

        text_view = Gtk.TextView()
        text_view.set_editable(False)
        text_view.set_cursor_visible(False)
        text_view.set_monospace(True)
        text_view.set_wrap_mode(Gtk.WrapMode.NONE)
        text_view.get_buffer().set_text(self.report_text)
        text_view.add_css_class("diagnostic-report")
        scrolled.set_child(text_view)

        self.feedback_label = Gtk.Label()
        self.feedback_label.set_halign(Gtk.Align.START)
        self.feedback_label.set_xalign(0.0)
        self.feedback_label.add_css_class("diagnostic-feedback")
        root.append(self.feedback_label)

        actions = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=8,
        )
        actions.set_halign(Gtk.Align.END)
        root.append(actions)

        copy_button = Gtk.Button(label=_("Copy"))
        copy_button.connect("clicked", self._on_copy)
        actions.append(copy_button)

        save_button = Gtk.Button(label=_("Save a copy…"))
        save_button.connect("clicked", self._on_save)
        actions.append(save_button)

        close_button = Gtk.Button(label=_("Close"))
        close_button.add_css_class("suggested-action")
        close_button.connect("clicked", self._on_close_requested)
        actions.append(close_button)

        self.set_default_widget(close_button)

    def _set_action_busy(self, button: Gtk.Button, busy: bool) -> None:
        self._action_busy = busy
        if busy:
            self._busy_button = button
            button.set_sensitive(False)
        elif self._busy_button is button:
            button.set_sensitive(True)
            self._busy_button = None
        self.set_cursor_from_name("wait" if busy else None)

    def _on_close_requested(self, button: Gtk.Button) -> None:
        if self._action_busy:
            return
        self._set_action_busy(button, True)
        GLib.idle_add(self._finish_close)

    def _finish_close(self) -> bool:
        self.close()
        return False

    def _on_copy(self, button: Gtk.Button) -> None:
        if self._action_busy:
            return
        self._set_action_busy(button, True)
        GLib.idle_add(self._execute_copy, button)

    def _execute_copy(self, button: Gtk.Button) -> bool:
        try:
            display = Gdk.Display.get_default()
            if display is None:
                self._show_error(_("The clipboard is not available."))
                return False

            display.get_clipboard().set(self.report_text)
            self._show_success(_("Report copied to the clipboard."))
            return False
        finally:
            self._set_action_busy(button, False)

    def _on_save(self, button: Gtk.Button) -> None:
        # Mantindre una referència al selector mentre està obert.
        # Si queda només com a variable local, alguns backends/portals
        # poden cancel·lar l'operació en destruir-se l'objecte Python.
        if self._action_busy or self._save_chooser is not None:
            return

        self._set_action_busy(button, True)
        GLib.idle_add(self._present_save_chooser, button)

    def _present_save_chooser(self, button: Gtk.Button) -> bool:
        try:
            chooser = Gtk.FileChooserNative(
                title=_("Save diagnostic report"),
                transient_for=self,
                action=Gtk.FileChooserAction.SAVE,
                accept_label=_("Save"),
                cancel_label=_("Cancel"),
            )
            chooser.set_modal(True)
            chooser.set_current_name(self.report.suggested_filename())

            initial_folder = self.initial_path.parent
            initial_folder.mkdir(parents=True, exist_ok=True)
            chooser.set_current_folder(
                Gio.File.new_for_path(str(initial_folder))
            )

            chooser.connect("response", self._on_save_response)
            self._save_chooser = chooser
            chooser.show()
        except OSError as error:
            logger.exception("No s'ha pogut obrir el selector de desament")
            self._show_error(
                _("The report could not be saved: {error}").format(error=error)
            )
        finally:
            self._set_action_busy(button, False)
        return False

    def _on_save_response(
        self,
        chooser: Gtk.FileChooserNative,
        response: int,
    ) -> None:
        try:
            if response != Gtk.ResponseType.ACCEPT:
                return

            selected_file = chooser.get_file()
            if selected_file is None:
                self._show_error(_("No destination file was selected."))
                return

            path = selected_file.get_path()
            if path is None:
                self._show_error(
                    _("The selected destination is not a local file.")
                )
                return

            destination = self.report.save(Path(path))
            self._show_success(
                _("Report saved in: {path}").format(path=destination)
            )
            logger.info(
                "Còpia de l'informe de diagnòstic desada: %s",
                destination,
            )
        except OSError as error:
            logger.exception(
                "No s'ha pogut desar la còpia de l'informe de diagnòstic"
            )
            self._show_error(
                _("The report could not be saved: {error}").format(
                    error=error,
                )
            )
        finally:
            chooser.destroy()
            if chooser is self._save_chooser:
                self._save_chooser = None

    def _show_success(self, message: str) -> None:
        self.feedback_label.remove_css_class("status-error")
        self.feedback_label.add_css_class("status-success")
        self.feedback_label.set_text(message)

    def _show_error(self, message: str) -> None:
        self.feedback_label.remove_css_class("status-success")
        self.feedback_label.add_css_class("status-error")
        self.feedback_label.set_text(message)

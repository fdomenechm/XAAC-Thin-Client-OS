from __future__ import annotations

import gi

gi.require_version("Gtk", "4.0")

from gi.repository import GLib, Gtk

from xaac_thinclient import __version__
from xaac_thinclient.about import ABOUT_AUTHORS, ABOUT_WEBSITE
from xaac_thinclient.i18n import _
from xaac_thinclient.resources import XAAC_ABOUT_LOGO
from xaac_thinclient.paths import PACKAGE_DIR


class LicenseDialog(Gtk.Window):
    """Visor local de la llicència, segur per al mode quiosc."""

    def __init__(self, parent: Gtk.Window) -> None:
        super().__init__(
            title=_("Llicència EUPL 1.2"),
            transient_for=parent,
            modal=True,
        )
        self.set_default_size(720, 620)
        self.set_resizable(True)
        self.add_css_class("xaac-license-dialog")

        header = Gtk.HeaderBar()
        header.set_show_title_buttons(False)
        close_button = Gtk.Button(label=_("Tanca"))
        close_button.connect("clicked", self._on_close_requested)
        header.pack_end(close_button)
        self.set_titlebar(header)

        content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        content.set_margin_top(12)
        content.set_margin_bottom(12)
        content.set_margin_start(16)
        content.set_margin_end(16)

        title = Gtk.Label(label=_("European Union Public Licence v1.2"))
        title.add_css_class("xaac-about-section-title")
        title.set_halign(Gtk.Align.CENTER)
        content.append(title)

        scrolled = Gtk.ScrolledWindow()
        scrolled.set_hexpand(True)
        scrolled.set_vexpand(True)
        scrolled.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)

        viewer = Gtk.TextView()
        viewer.set_editable(False)
        viewer.set_cursor_visible(False)
        viewer.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        viewer.set_left_margin(12)
        viewer.set_right_margin(12)
        viewer.set_top_margin(12)
        viewer.set_bottom_margin(12)
        viewer.add_css_class("xaac-license-text")
        viewer.get_buffer().set_text(self._license_text())
        scrolled.set_child(viewer)
        content.append(scrolled)

        footer_close = Gtk.Button(label=_("Tanca"))
        footer_close.set_halign(Gtk.Align.END)
        footer_close.connect("clicked", self._on_close_requested)
        content.append(footer_close)
        self.set_child(content)

    def _on_close_requested(self, button: Gtk.Button) -> None:
        button.set_sensitive(False)
        self.set_cursor_from_name("wait")
        GLib.idle_add(self._finish_close)

    def _finish_close(self) -> bool:
        self.close()
        return False

    @staticmethod
    def _license_text() -> str:
        path = PACKAGE_DIR / "resources" / "EUPL-1.2.txt"
        return path.read_text(encoding="utf-8")


class AboutDialog(Gtk.Window):
    """Diàleg «Quant a» propi, compacte i compatible amb GTK 4."""

    LOGO_WIDTH = 180
    LOGO_HEIGHT = 90

    def __init__(self, parent: Gtk.Window) -> None:
        super().__init__(
            title=_("Quant a XAAC Thin Client Remote"),
            transient_for=parent,
            modal=True,
        )

        self.set_default_size(500, 470)
        self.set_resizable(False)
        self.add_css_class("xaac-about-dialog")

        header = Gtk.HeaderBar()
        # XAAC Thin Client OS intentionally hides standard GTK title buttons in
        # kiosk mode.  Auxiliary modal windows therefore need their own close
        # control, independent of gtk-decoration-layout.
        header.set_show_title_buttons(False)
        close_button = Gtk.Button()
        close_button.set_icon_name("window-close-symbolic")
        close_button.set_tooltip_text(_("Close"))
        close_button.connect("clicked", self._on_close_requested)
        header.pack_end(close_button)
        self.set_titlebar(header)

        notebook = Gtk.Notebook()
        notebook.set_hexpand(True)
        notebook.set_vexpand(True)
        notebook.set_margin_top(12)
        notebook.set_margin_bottom(16)
        notebook.set_margin_start(20)
        notebook.set_margin_end(20)

        notebook.append_page(self._build_about_page(), Gtk.Label(label=_("Quant a")))
        notebook.append_page(self._build_credits_page(), Gtk.Label(label=_("Crèdits")))
        notebook.append_page(self._build_license_page(), Gtk.Label(label=_("Llicència")))

        self.set_child(notebook)

    def _on_close_requested(self, button: Gtk.Button) -> None:
        button.set_sensitive(False)
        self.set_cursor_from_name("wait")
        GLib.idle_add(self._finish_close)

    def _finish_close(self) -> bool:
        self.close()
        return False

    def _build_about_page(self) -> Gtk.Widget:
        page = self._new_centered_page()

        logo = Gtk.Picture.new_for_filename(str(XAAC_ABOUT_LOGO))
        logo.set_size_request(self.LOGO_WIDTH, self.LOGO_HEIGHT)
        logo.set_content_fit(Gtk.ContentFit.CONTAIN)
        logo.set_can_shrink(True)
        logo.set_halign(Gtk.Align.CENTER)
        logo.set_valign(Gtk.Align.CENTER)
        logo.add_css_class("xaac-about-logo")
        page.append(logo)

        title = Gtk.Label(label="XAAC Thin Client Remote")
        title.add_css_class("xaac-about-title")
        title.set_halign(Gtk.Align.CENTER)
        page.append(title)

        version = Gtk.Label(label=_("Versió {version}").format(version=__version__))
        version.add_css_class("xaac-about-version")
        version.set_halign(Gtk.Align.CENTER)
        page.append(version)

        description = Gtk.Label(
            label=_(
                "Lightweight and secure thin client for remote desktop access."
            )
        )
        description.set_wrap(True)
        description.set_justify(Gtk.Justification.CENTER)
        description.set_halign(Gtk.Align.CENTER)
        description.set_max_width_chars(48)
        description.add_css_class("xaac-about-description")
        page.append(description)

        website = Gtk.Label()
        website.set_markup(
            f'<a href="{ABOUT_WEBSITE}">{_("Projecte XAAC Thin Client Remote")}</a>'
        )
        website.set_use_markup(True)
        website.set_selectable(True)
        website.set_halign(Gtk.Align.CENTER)
        website.set_justify(Gtk.Justification.CENTER)
        website.add_css_class("xaac-about-link")
        page.append(website)

        copyright_label = Gtk.Label(label=_("2026 Autor: Francesc Domènech"))
        copyright_label.set_halign(Gtk.Align.CENTER)
        copyright_label.set_justify(Gtk.Justification.CENTER)
        copyright_label.add_css_class("xaac-about-copyright")
        page.append(copyright_label)

        return page

    def _build_credits_page(self) -> Gtk.Widget:
        page = self._new_centered_page()

        heading = Gtk.Label(label=_("Autor"))
        heading.add_css_class("xaac-about-section-title")
        heading.set_halign(Gtk.Align.CENTER)
        page.append(heading)

        authors = Gtk.Label(label="\n".join(ABOUT_AUTHORS))
        authors.set_halign(Gtk.Align.CENTER)
        authors.set_justify(Gtk.Justification.CENTER)
        authors.set_selectable(True)
        page.append(authors)

        return page

    def _build_license_page(self) -> Gtk.Widget:
        page = self._new_centered_page()

        heading = Gtk.Label(label=_("European Union Public Licence v1.2"))
        heading.add_css_class("xaac-about-section-title")
        heading.set_halign(Gtk.Align.CENTER)
        heading.set_justify(Gtk.Justification.CENTER)
        page.append(heading)

        license_text = Gtk.Label(
            label=_(
                "XAAC Thin Client Remote és programari lliure distribuït sota la "
                "European Union Public Licence v1.2 (EUPL)."
            )
        )
        license_text.set_wrap(True)
        license_text.set_max_width_chars(48)
        license_text.set_halign(Gtk.Align.CENTER)
        license_text.set_justify(Gtk.Justification.CENTER)
        license_text.set_selectable(True)
        page.append(license_text)

        license_link = Gtk.Label()
        license_link.set_markup(
            '<a href="xaac://license/eupl-1.2">'
            + _("Llegiu el text complet de la llicència")
            + "</a>"
        )
        license_link.set_use_markup(True)
        license_link.connect("activate-link", self._open_local_license)
        license_link.set_selectable(True)
        license_link.set_halign(Gtk.Align.CENTER)
        license_link.set_justify(Gtk.Justification.CENTER)
        license_link.add_css_class("xaac-about-link")
        page.append(license_link)

        page.set_tooltip_text(
            _(
                "XAAC Thin Client Remote és programari lliure distribuït sota la "
                "European Union Public Licence v1.2 (EUPL)."
            )
        )
        return page

    def _open_local_license(self, _label: Gtk.Label, _uri: str) -> bool:
        dialog = LicenseDialog(self)
        dialog.present()
        return True

    @staticmethod
    def _new_centered_page() -> Gtk.Box:
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        page.set_halign(Gtk.Align.FILL)
        page.set_valign(Gtk.Align.CENTER)
        page.set_hexpand(True)
        page.set_vexpand(True)
        page.set_margin_top(16)
        page.set_margin_bottom(16)
        page.set_margin_start(16)
        page.set_margin_end(16)
        return page

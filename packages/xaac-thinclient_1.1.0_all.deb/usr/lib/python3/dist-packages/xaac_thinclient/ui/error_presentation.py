from __future__ import annotations

from dataclasses import dataclass

from xaac_thinclient.core.errors import ApplicationError, ErrorCategory
from xaac_thinclient.i18n import _


@dataclass(frozen=True, slots=True)
class ErrorPresentation:
    """Text segur i accionable que la interfície mostra a l'usuari."""

    title: str
    message: str
    action: str | None = None
    show_diagnostics: bool = False

    @property
    def status_text(self) -> str:
        if self.action:
            return f"{self.message} {self.action}"
        return self.message


def present_application_error(
    error: ApplicationError | None,
    fallback: str | None = None,
) -> ErrorPresentation:
    """Converteix un error tècnic en informació apta per a la GUI."""
    if error is None:
        return ErrorPresentation(
            title=_("Connection error"),
            message=fallback or _("The connection could not be completed."),
        )

    if error.category is ErrorCategory.PRINTERS:
        return ErrorPresentation(
            title=_("Required printer unavailable"),
            message=_("The remote session requires an authorised local printer."),
            action=_(
                "Check that the printer is installed and available, then try again."
            ),
            show_diagnostics=True,
        )

    if error.code == "AUDIO-001":
        return ErrorPresentation(
            title=_("Required audio output unavailable"),
            message=_("The remote session requires a local audio output device."),
            action=_(
                "Check the speakers or headset and the local audio service, then try again."
            ),
            show_diagnostics=True,
        )

    if error.code == "MICROPHONE-001":
        return ErrorPresentation(
            title=_("Required microphone unavailable"),
            message=_("The remote session requires a local microphone."),
            action=_(
                "Check the microphone and the local audio service, then try again."
            ),
            show_diagnostics=True,
        )

    if error.code == "VIDEO-001":
        return ErrorPresentation(
            title=_("Required camera unavailable"),
            message=_("The remote session requires a local camera."),
            action=_(
                "Check that the camera is connected and available, then try again."
            ),
            show_diagnostics=True,
        )

    if error.code == "VIDEO-002":
        return ErrorPresentation(
            title=_("Video redirection unavailable"),
            message=_(
                "The installed FreeRDP client does not include the RDPECAM module."
            ),
            action=_(
                "Install a FreeRDP build with RDPECAM support or disable video redirection."
            ),
            show_diagnostics=True,
        )

    return ErrorPresentation(
        title=_("Connection error"),
        message=error.user_message,
        show_diagnostics=error.technical_detail is not None,
    )

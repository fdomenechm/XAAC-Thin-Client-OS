from __future__ import annotations

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")

from gi.repository import Gdk, GLib, Gtk

from xaac_thinclient import __version__
from xaac_thinclient.config.models import ApplicationMode
from xaac_thinclient.core.controller import ApplicationController
from xaac_thinclient.core.errors import ErrorCategory
from xaac_thinclient.resources import resolve_application_logo
from xaac_thinclient.core.events import ApplicationEvent
from xaac_thinclient.core.state import (
    ApplicationPhase,
    ApplicationState,
)
from xaac_thinclient.services.logging import get_logger
from xaac_thinclient.i18n import _
from xaac_thinclient.ui.error_presentation import present_application_error
from xaac_thinclient.ui.diagnostic_dialog import DiagnosticDialog
from xaac_thinclient.ui.about_dialog import AboutDialog
from xaac_thinclient.system.kiosk import KioskPolicyService
from xaac_thinclient.system.kiosk_runtime import KioskExitReason, KioskRuntimeService

logger = get_logger(__name__)

class LoginWindow(Gtk.ApplicationWindow):
    def __init__(
            self,
            application: Gtk.Application,
            controller: ApplicationController,
    ) -> None:
        super().__init__(application=application)

        self.controller = controller
        self.controller.subscribe(
            self._on_controller_event
        )

        configured_title = self.controller.config.application.title
        self.set_title(
            _("XAAC Thin Client Sessió Remota")
            if configured_title == "XAAC Thin Client Sessió Remota"
            else configured_title
        )
        self.set_default_size(520, 520)
        self.set_resizable(False)

        self._kiosk_policy = KioskPolicyService().resolve(
            self.controller.config.system
        )
        self._kiosk_runtime = KioskRuntimeService()
        self._administrative_exit_requested = False
        self._power_dialog: Gtk.MessageDialog | None = None
        self._power_confirm_button: Gtk.Widget | None = None
        self._power_action_busy = False
        self._connection_action_busy = False
        self._connection_request_pending = False
        self._auxiliary_action_busy = False
        self._auxiliary_busy_button: Gtk.Button | None = None

        self._build_interface()
        self._connect_signals()
        self._apply_kiosk_runtime()
        self._load_user_preferences()

    def _build_interface(self) -> None:
        root = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=0,
        )
        root.add_css_class("application-background")
        self.set_child(root)

        root.set_halign(Gtk.Align.FILL)
        root.set_valign(Gtk.Align.FILL)
        root.set_hexpand(True)
        root.set_vexpand(True)

        card = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=18,
        )
        card.add_css_class("login-card")
        card.set_halign(Gtk.Align.CENTER)
        card.set_valign(Gtk.Align.CENTER)
        card.set_size_request(470, -1)

        root.append(card)

        # Capçalera
        # Logo principal configurable des de [application] logo.
        application_logo = resolve_application_logo(
            self.controller.config.application.logo
        )
        logo = Gtk.Picture.new_for_filename(str(application_logo))
        logo.set_can_shrink(True)
        logo.set_content_fit(Gtk.ContentFit.CONTAIN)
        logo.set_size_request(-1, 90)
        logo.add_css_class("company-logo")
        logo.set_halign(Gtk.Align.CENTER)

        card.append(logo)


        # Servidor assignat
        server_box = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=10,
        )
        server_box.add_css_class("server-panel")

        server_icon = Gtk.Image.new_from_icon_name(
            "computer-symbolic"
        )
        server_icon.set_pixel_size(22)
        server_box.append(server_icon)



        server_caption = Gtk.Label(label=_("Connect to: "))
        server_caption.add_css_class("field-caption")
        server_box.append(server_caption)

        self._server_items = tuple(self.controller.available_servers)
        self._server_model = Gtk.StringList.new([item.name for item in self._server_items])
        self.server_dropdown = Gtk.DropDown(model=self._server_model)
        self.server_dropdown.add_css_class("server-dropdown")
        self.server_dropdown.set_hexpand(True)
        selected_index = next(
            (index for index, item in enumerate(self._server_items)
             if item.server_id == self.controller.selected_server_id),
            0,
        )
        if self._server_items:
            self.server_dropdown.set_selected(selected_index)
            selected = self._server_items[selected_index]
            self.server_dropdown.set_tooltip_text(f"{selected.host}:{selected.port}")
        self.server_dropdown.set_sensitive(len(self._server_items) > 1)
        server_box.append(self.server_dropdown)



        card.append(server_box)

        # Formulari compacte: etiqueta a l'esquerra, camp a la dreta
        form = Gtk.Grid()
        form.set_row_spacing(10)
        form.set_column_spacing(14)
        form.set_hexpand(True)
        card.append(form)


        username_label = self._create_form_label(_("Username"))
        password_label = self._create_form_label(_("Password"))
        domain_label = self._create_form_label(_("Domain"))


        self.username_entry = Gtk.Entry()
        self.username_entry.set_hexpand(True)
        self.username_entry.add_css_class("login-entry")

        self.password_entry = Gtk.PasswordEntry()
        self.password_entry.set_hexpand(True)
        self.password_entry.set_show_peek_icon(True)
        self.password_entry.add_css_class("login-entry")

        self.domain_entry = Gtk.Entry()
        self.domain_entry.set_text(
            self.controller.config.rdp.domain
        )

        self.domain_entry.set_hexpand(True)
        self.domain_entry.set_editable(False)
        self.domain_entry.set_can_focus(False)
        self.domain_entry.add_css_class("login-entry")
        self.domain_entry.add_css_class("readonly-entry")
        self.domain_entry.set_tooltip_text(
            _("The domain is configured by the administrator.")
        )

        form.attach(username_label, 0, 0, 1, 1)
        form.attach(self.username_entry, 1, 0, 1, 1)

        form.attach(password_label, 0, 1, 1, 1)
        form.attach(self.password_entry, 1, 1, 1, 1)

        form.attach(domain_label, 0, 2, 1, 1)
        form.attach(self.domain_entry, 1, 2, 1, 1)

        # Opció recordar usuari
        options_row = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=12,
        )
        options_row.set_hexpand(True)
        card.append(options_row)

        self.remember_username_check = Gtk.CheckButton(
            label=_("Remember username")
        )
        self.remember_username_check.set_active(True)
        self.remember_username_check.set_hexpand(True)
        options_row.append(self.remember_username_check)

        # Botó
        self.connect_button = Gtk.Button(label=_("CONNECT"))
        self.connect_button.set_size_request(-1, 46)
        self.connect_button.set_hexpand(True)
        self.connect_button.add_css_class("connect-button")
        self.connect_button.add_css_class("suggested-action")
        card.append(self.connect_button)

        # Estat general
        status_box = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=6,
        )
        status_box.set_halign(Gtk.Align.END)
        options_row.append(status_box)

        self.status_spinner = Gtk.Spinner()
        self.status_spinner.set_visible(False)
        status_box.append(self.status_spinner)

        self.status_label = Gtk.Label(label=_("Starting…"))
        self.status_label.add_css_class("compact-status")
        status_box.append(self.status_label)

        # Separador
        separator = Gtk.Separator(
            orientation=Gtk.Orientation.HORIZONTAL
        )
        card.append(separator)

        # Indicadors inferiors
        # Resum compacte d'estat
        self.connection_summary = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=24,
        )
        self.connection_summary.set_halign(Gtk.Align.CENTER)
        card.append(self.connection_summary)

        #
        # Estat de la xarxa
        #

        network_box = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=6,
        )

        self.network_icon = Gtk.Image.new_from_icon_name(
            "network-wired-symbolic"
        )
        self.network_icon.set_pixel_size(18)
        network_box.append(self.network_icon)

        self.network_label = Gtk.Label(
            label=_("Network connected")
        )
        network_box.append(self.network_label)

        self.connection_summary.append(network_box)

        #
        # Estat del servidor
        #

        server_box = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=6,
        )

        self.server_icon = Gtk.Image.new_from_icon_name(
            "network-server-symbolic"
        )
        self.server_icon.set_pixel_size(18)

        self.server_status_label = Gtk.Label(
            label=_("Server pending")
        )

        server_box.append(self.server_icon)
        server_box.append(self.server_status_label)

        self.connection_summary.append(server_box)

        # Estat de la targeta intel·ligent (només si està habilitada)
        self.smartcard_box = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=6,
        )
        self.smartcard_box.set_visible(
            self.controller.config.smartcard.enabled
        )

        self.smartcard_icon = Gtk.Image.new_from_icon_name(
            "auth-sim-symbolic"
        )
        self.smartcard_icon.set_pixel_size(18)
        self.smartcard_box.append(self.smartcard_icon)

        self.smartcard_status_label = Gtk.Label(
            label=_("Smart Card pending")
        )
        self.smartcard_box.append(self.smartcard_status_label)
        self.connection_summary.append(self.smartcard_box)

        # Peu secundari: versió i accés discret al diagnòstic
        footer_separator = Gtk.Separator(
            orientation=Gtk.Orientation.HORIZONTAL,
        )
        footer_separator.add_css_class("footer-separator")
        card.append(footer_separator)

        footer = Gtk.CenterBox()
        footer.set_hexpand(True)
        footer.add_css_class("application-footer")
        card.append(footer)

        self.about_button = Gtk.Button()
        self.about_button.add_css_class("flat")
        self.about_button.add_css_class("about-button")
        self.about_button.set_halign(Gtk.Align.START)
        self.about_button.set_valign(Gtk.Align.CENTER)
        self.about_button.set_tooltip_text(
            _("View application information, authorship and licence.")
        )

        about_content = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=6,
        )
        about_icon = Gtk.Image.new_from_icon_name(
            "help-about-symbolic"
        )
        about_icon.set_pixel_size(15)
        about_label = Gtk.Label(
            label=f"{_('Quant a')} v.{__version__}",
        )
        about_content.append(about_icon)
        about_content.append(about_label)
        self.about_button.set_child(about_content)
        footer.set_start_widget(self.about_button)

        self.diagnostic_button = Gtk.Button()
        self.diagnostic_button.add_css_class("flat")
        self.diagnostic_button.add_css_class("diagnostic-button")
        self.diagnostic_button.set_halign(Gtk.Align.CENTER)
        self.diagnostic_button.set_valign(Gtk.Align.CENTER)
        self.diagnostic_button.set_tooltip_text(
            _("View and export a technical diagnostic report.")
        )

        diagnostic_content = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=6,
        )

        diagnostic_icon = Gtk.Image.new_from_icon_name(
            "utilities-system-monitor-symbolic"
        )
        diagnostic_icon.set_pixel_size(16)

        diagnostic_label = Gtk.Label(
            label=_("Diagnostics")
        )

        diagnostic_content.append(diagnostic_icon)
        diagnostic_content.append(diagnostic_label)
        self.diagnostic_button.set_child(diagnostic_content)
        footer.set_center_widget(self.diagnostic_button)

        self.power_button = Gtk.Button()
        self.power_button.add_css_class("flat")
        self.power_button.add_css_class("power-button")
        self.power_button.set_halign(Gtk.Align.END)
        self.power_button.set_valign(Gtk.Align.CENTER)

        production = (
            self.controller.config.application.mode is ApplicationMode.PRODUCTION
        )
        power_label = _("Shut down") if production else _("Close")
        power_tooltip = (
            _("Shut down this terminal.")
            if production
            else _("Close XAAC Thin Client Remote.")
        )
        self.power_button.set_tooltip_text(power_tooltip)

        power_content = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=6,
        )
        power_icon = Gtk.Image.new_from_icon_name("system-shutdown-symbolic")
        power_icon.set_pixel_size(16)
        power_content.append(power_icon)
        power_content.append(Gtk.Label(label=power_label))
        self.power_button.set_child(power_content)
        footer.set_end_widget(self.power_button)

        self.set_default_widget(self.connect_button)

    def _on_controller_event(
            self,
            event: ApplicationEvent,
            state: ApplicationState,
    ) -> None:
        """
        Aplica directament l'esdeveniment rebut.

        ApplicationController garanteix que les notificacions
        destinades a la vista s'emeten des del fil principal GTK.
        """
        self._apply_controller_event(
            event,
            state,
        )

    def _apply_form_state(
            self,
            state: ApplicationState,
    ) -> None:
        session_busy = (
                state.rdp_session_running
                or state.phase in (
                    ApplicationPhase.CONNECTING,
                    ApplicationPhase.CONNECTED,
                )
        )

        self.username_entry.set_sensitive(
            not session_busy
        )
        self.password_entry.set_sensitive(
            not session_busy
        )
        self.remember_username_check.set_sensitive(
            not session_busy
        )

        self.connect_button.set_sensitive(
            state.can_connect
        )
        self._set_connection_busy(
            self._connection_request_pending
            or state.phase == ApplicationPhase.CONNECTING
        )

    def _refresh_wait_cursor(self) -> None:
        """Manté un únic cursor d'espera coherent entre totes les accions."""
        busy = (
            self._connection_action_busy
            or self._power_action_busy
            or self._auxiliary_action_busy
        )
        self.set_cursor_from_name("wait" if busy else None)

    def _set_connection_busy(
            self,
            busy: bool,
    ) -> None:
        """
        Dona feedback immediat mentre s'està iniciant la sessió remota.

        El botó es bloqueja abans de qualsevol validació o crida al
        controlador, de manera que el cursor d'espera apareix tan prompte com
        l'usuari prem Connectar. L'estat es restaura en validació fallida,
        rebuig, error o quan el controlador abandona CONNECTING.
        """
        self._connection_action_busy = busy
        if busy:
            self.connect_button.set_sensitive(False)
        self._refresh_wait_cursor()

    def _set_auxiliary_busy(
        self,
        button: Gtk.Button,
        busy: bool,
    ) -> None:
        """Feedback immediat per a Quant a i Diagnòstics."""
        self._auxiliary_action_busy = busy
        if busy:
            self._auxiliary_busy_button = button
            button.set_sensitive(False)
        elif self._auxiliary_busy_button is button:
            button.set_sensitive(True)
            self._auxiliary_busy_button = None
        self._refresh_wait_cursor()

    def _apply_controller_event(
            self,
            event: ApplicationEvent,
            state: ApplicationState,
    ) -> bool:
        """
        Aplica a la vista l'estat comunicat pel controlador.
        """
        self._apply_form_state(state)

        if state.phase == ApplicationPhase.CONNECTING:
            self.status_spinner.set_visible(True)
            self.status_spinner.start()

        else:
            self.status_spinner.stop()
            self.status_spinner.set_visible(False)

        if state.status_message:
            self.status_label.set_text(
                state.status_message
            )

        if state.error_message:
            self.status_label.remove_css_class(
                "status-success"
            )
            self.status_label.add_css_class(
                "status-error"
            )
        else:
            self.status_label.remove_css_class(
                "status-error"
            )

        if event == ApplicationEvent.NETWORK_CHECKING:
            self._show_network_checking()

        elif event == ApplicationEvent.NETWORK_CHANGED:
            self._show_network_state(state)
        elif event == ApplicationEvent.DNS_CHECKING:
            self._show_dns_checking()
        elif event == ApplicationEvent.DNS_CHANGED:
            self._show_dns_state(state)
        elif event == ApplicationEvent.RDP_CHECKING:
            self._show_rdp_checking()
        elif event == ApplicationEvent.RDP_AVAILABILITY_CHANGED:
            self._show_rdp_state(state)
        elif event == ApplicationEvent.SMARTCARD_CHANGED:
            self._show_smartcard_state(state)

        elif event == ApplicationEvent.SESSION_CONNECTING:
            self._show_session_connecting(state)

        elif event == ApplicationEvent.SESSION_STARTED:
            self._show_session_started()

        elif event == ApplicationEvent.SESSION_FINISHED:
            self._show_session_finished(state)

        elif event == ApplicationEvent.ERROR:
            self._show_session_error(state)

        return False



    def _show_smartcard_state(
        self,
        state: ApplicationState,
    ) -> None:
        if not state.smartcard_enabled:
            self.smartcard_box.set_visible(False)
            return

        self.smartcard_box.set_visible(True)
        self.smartcard_icon.remove_css_class("server-ok")
        self.smartcard_icon.remove_css_class("server-error")
        self.smartcard_status_label.remove_css_class("server-ok")
        self.smartcard_status_label.remove_css_class("server-error")

        if state.smartcard_ready:
            self.smartcard_icon.set_from_icon_name("auth-sim-symbolic")
            self.smartcard_icon.add_css_class("server-ok")
            self.smartcard_status_label.add_css_class("server-ok")
            self.smartcard_status_label.set_text(_("Smart Card ready"))
            tooltip = _("A smart card is inserted and ready.")
        elif state.smartcard_reader_count > 0:
            self.smartcard_icon.set_from_icon_name("auth-sim-symbolic")
            self.smartcard_icon.add_css_class("server-error")
            self.smartcard_status_label.add_css_class("server-error")
            self.smartcard_status_label.set_text(_("Insert Smart Card"))
            tooltip = state.smartcard_error or _("Insert the smart card.")
        else:
            self.smartcard_icon.set_from_icon_name("dialog-warning-symbolic")
            self.smartcard_icon.add_css_class("server-error")
            self.smartcard_status_label.add_css_class("server-error")
            self.smartcard_status_label.set_text(_("Reader unavailable"))
            tooltip = state.smartcard_error or _("No smart card reader was detected.")

        self.smartcard_icon.set_tooltip_text(tooltip)
        self.smartcard_status_label.set_tooltip_text(tooltip)

    def _set_server_without_network(self) -> None:
        self.server_icon.remove_css_class("server-ok")
        self.server_status_label.remove_css_class("server-ok")

        self.server_icon.add_css_class("server-error")
        self.server_status_label.add_css_class("server-error")

        self.server_icon.set_from_icon_name(
            "network-offline-symbolic"
        )

        self.server_status_label.set_text(
            _("Server offline")
        )

        tooltip = (
            _("The server cannot be resolved because the terminal has no network connection.")
        )

        self.server_icon.set_tooltip_text(tooltip)
        self.server_status_label.set_tooltip_text(tooltip)

    def _load_user_preferences(self) -> None:
        preferences = self.controller.preferences

        self.remember_username_check.set_active(
            preferences.remember_username
        )

        if preferences.remember_username:
            self.username_entry.set_text(
                preferences.username
            )

        if self.username_entry.get_text().strip():
            self.password_entry.grab_focus()
        else:
            self.username_entry.grab_focus()

    def _connect_signals(self) -> None:
        self.connect_button.connect(
            "clicked",
            self._on_connect_requested,
        )

        self.server_dropdown.connect(
            "notify::selected",
            self._on_server_selected,
        )

        self.username_entry.connect(
            "activate",
            self._focus_password,
        )

        self.password_entry.connect(
            "activate",
            self._on_password_activate,
        )

        self.about_button.connect(
            "clicked",
            self._on_about_requested,
        )

        self.diagnostic_button.connect(
            "clicked",
            self._on_diagnostic_requested,
        )

        self.power_button.connect(
            "clicked",
            self._on_power_requested,
        )

        self.connect(
            "close-request",
            self._on_close_requested,
        )

        key_controller = Gtk.EventControllerKey()
        key_controller.connect(
            "key-pressed",
            self._on_key_pressed,
        )
        self.add_controller(key_controller)

    def _on_server_selected(self, dropdown: Gtk.DropDown, _pspec: object) -> None:
        index = dropdown.get_selected()
        if index == Gtk.INVALID_LIST_POSITION or index >= len(self._server_items):
            return
        server = self._server_items[index]
        if not self.controller.select_server(server.server_id):
            return
        self.domain_entry.set_text(self.controller.config.rdp.domain)
        dropdown.set_tooltip_text(f"{server.host}:{server.port}")
        self.connect_button.set_sensitive(False)
        self.server_status_label.set_text(_("Resolving server…"))

    def _apply_kiosk_runtime(self) -> None:
        self._kiosk_runtime.apply(self, self._kiosk_policy)

    def _on_close_requested(self, _window: Gtk.Window) -> bool:
        reason = (
            KioskExitReason.ADMINISTRATIVE
            if self._administrative_exit_requested
            else KioskExitReason.USER
        )
        return self._kiosk_runtime.should_inhibit_close(
            self._kiosk_policy, reason
        )

    def _on_key_pressed(
        self,
        _controller: Gtk.EventControllerKey,
        keyval: int,
        _keycode: int,
        state: Gdk.ModifierType,
    ) -> bool:
        required = (
            Gdk.ModifierType.CONTROL_MASK
            | Gdk.ModifierType.ALT_MASK
            | Gdk.ModifierType.SHIFT_MASK
        )
        if keyval not in (Gdk.KEY_q, Gdk.KEY_Q) or (state & required) != required:
            return False

        if self._kiosk_runtime.should_inhibit_close(
            self._kiosk_policy,
            KioskExitReason.ADMINISTRATIVE,
        ):
            logger.warning("Eixida administrativa quiosc bloquejada per política local")
            return True

        logger.info("Eixida administrativa quiosc sol·licitada")
        self._administrative_exit_requested = True
        application = self.get_application()
        if application is not None:
            application.quit()
        return True

    def _on_about_requested(self, button: Gtk.Button) -> None:
        if self._auxiliary_action_busy:
            return

        self._set_auxiliary_busy(button, True)
        GLib.idle_add(self._present_about_dialog, button)

    def _present_about_dialog(self, button: Gtk.Button) -> bool:
        try:
            dialog = AboutDialog(self)
            dialog.present()
        except Exception:
            logger.exception("No s'ha pogut mostrar el diàleg Quant a")
        finally:
            self._set_auxiliary_busy(button, False)
        return False

    def _close_development_application(self) -> None:
        """Tanca de manera ordenada la finestra i l'aplicació en desenvolupament."""
        self._administrative_exit_requested = True

        application = self.get_application()
        self.close()

        if application is not None:
            application.quit()

    def _set_power_busy(self, busy: bool) -> None:
        """
        Aplica el feedback d'ocupat de les accions d'apagat/tancament.

        El botó principal queda bloquejat mentre hi ha un diàleg de confirmació
        o una operació d'energia en curs. Quan l'usuari confirma, també es
        deshabilita el botó de confirmació i s'activa immediatament el cursor
        d'espera. En cancel·lació o error, tots els controls es restauren.
        """
        self._power_action_busy = busy

        dialog_active = self._power_dialog is not None
        self.power_button.set_sensitive(not busy and not dialog_active)

        if self._power_confirm_button is not None:
            self._power_confirm_button.set_sensitive(not busy)

        self._refresh_wait_cursor()

    def _release_power_dialog(self, dialog: Gtk.MessageDialog) -> None:
        """Desvincula i destrueix el diàleg de confirmació actiu."""
        if self._power_dialog is dialog:
            self._power_dialog = None
            self._power_confirm_button = None
        dialog.destroy()

    def _on_power_requested(self, _button: Gtk.Button) -> None:
        # Protecció addicional contra dobles clics o una segona invocació
        # programàtica mentre el diàleg o l'operació anterior continuen actius.
        if self._power_action_busy or self._power_dialog is not None:
            return

        # Feedback immediat, igual que en Connectar: el clic queda bloquejat i
        # el cursor canvia abans de construir/presentar el diàleg modal.
        self._set_power_busy(True)

        dialog: Gtk.MessageDialog | None = None
        try:
            production = (
                self.controller.config.application.mode is ApplicationMode.PRODUCTION
            )
            title = _("Shut down terminal?") if production else _("Close application?")
            message = (
                _("The terminal will be shut down and any active remote session will be closed.")
                if production
                else _("XAAC Thin Client Remote will close and any active remote session will be disconnected.")
            )
            confirm_label = _("Shut down") if production else _("Close")

            dialog = Gtk.MessageDialog(
                transient_for=self,
                modal=True,
                message_type=Gtk.MessageType.QUESTION,
                buttons=Gtk.ButtonsType.NONE,
                text=title,
                secondary_text=message,
            )
            dialog.add_button(_("Cancel"), Gtk.ResponseType.CANCEL)
            confirm_button = dialog.add_button(confirm_label, Gtk.ResponseType.ACCEPT)

            self._power_dialog = dialog
            self._power_confirm_button = confirm_button

            dialog.connect("response", self._on_power_confirmation_response)
            dialog.present()
        except Exception:
            logger.exception("No s'ha pogut mostrar el diàleg d'apagat")
            if dialog is not None:
                dialog.destroy()
            self._power_dialog = None
            self._power_confirm_button = None
            self._set_power_busy(False)
            self.status_label.set_text(
                _("The terminal could not be shut down. Contact the administrator.")
            )
            self.status_label.remove_css_class("status-success")
            self.status_label.add_css_class("status-error")
            return

        # El diàleg ja és modal i el botó principal continua bloquejat, però
        # l'usuari ha de poder decidir amb cursor normal.
        self._set_power_busy(False)

    def _on_power_confirmation_response(
        self,
        dialog: Gtk.MessageDialog,
        response: int,
    ) -> None:
        if dialog is not self._power_dialog:
            dialog.destroy()
            return

        # No s'accepten respostes duplicades mentre la petició està en curs.
        if self._power_action_busy:
            return

        # Qualsevol botó del diàleg dona feedback immediat abans de processar
        # la resposta. Això evita que Cancel·lar o Confirmar pareguen inactius.
        self._set_power_busy(True)

        if response != Gtk.ResponseType.ACCEPT:
            GLib.idle_add(self._cancel_power_action, dialog)
            return

        # Executem en el següent cicle GTK perquè el canvi de cursor/sensibilitat
        # puga arribar a la interfície abans d'una crida d'apagat potencialment
        # bloquejant.
        GLib.idle_add(self._execute_power_action, dialog)

    def _cancel_power_action(self, dialog: Gtk.MessageDialog) -> bool:
        if dialog is self._power_dialog:
            self._release_power_dialog(dialog)
        else:
            dialog.destroy()
        self._set_power_busy(False)
        return False

    def _execute_power_action(self, dialog: Gtk.MessageDialog) -> bool:
        if dialog is not self._power_dialog:
            self._set_power_busy(False)
            return False

        if self.controller.config.application.mode is ApplicationMode.DEVELOPMENT:
            logger.info("Tancament de desenvolupament sol·licitat des de la interfície")
            self._release_power_dialog(dialog)
            # Conservem l'estat ocupat fins que la finestra desaparega.
            self._set_power_busy(True)
            self._close_development_application()
            return False

        try:
            result = self.controller.request_poweroff()
        except Exception:
            logger.exception("Error inesperat en sol·licitar l'apagat del terminal")
            self._release_power_dialog(dialog)
            self._set_power_busy(False)
            self.status_label.set_text(
                _("The terminal could not be shut down. Contact the administrator.")
            )
            self.status_label.remove_css_class("status-success")
            self.status_label.add_css_class("status-error")
            return False

        if result.succeeded:
            self._release_power_dialog(dialog)
            # L'ordre ja ha estat acceptada: mantindre el feedback i el bloqueig
            # fins que el sistema complete l'apagat evita noves accions.
            self._set_power_busy(True)
            self.status_label.set_text(_("Shutting down terminal…"))
            self.status_label.remove_css_class("status-error")
            return False

        self._release_power_dialog(dialog)
        self._set_power_busy(False)
        self.status_label.set_text(
            _("The terminal could not be shut down. Contact the administrator.")
        )
        self.status_label.remove_css_class("status-success")
        self.status_label.add_css_class("status-error")
        return False

    def _on_diagnostic_requested(
        self,
        button: Gtk.Button,
    ) -> None:
        if self._auxiliary_action_busy:
            return

        self._set_auxiliary_busy(button, True)
        GLib.idle_add(self._execute_diagnostic_requested, button)

    def _execute_diagnostic_requested(self, button: Gtk.Button) -> bool:
        try:
            report = self.controller.create_diagnostic_report()
            report_path = report.save(
                self.controller.diagnostic_service.output_dir
                / report.suggested_filename()
            )
            dialog = DiagnosticDialog(
                parent=self,
                report=report,
                initial_path=report_path,
            )
            dialog.present()
        except OSError as error:
            logger.exception(
                "No s'ha pogut generar l'informe de diagnòstic"
            )
            self.status_label.set_text(
                _("The diagnostic report could not be generated: {error}").format(
                    error=error,
                )
            )
            self.status_label.remove_css_class("status-success")
            self.status_label.add_css_class("status-error")
        except Exception as error:
            logger.exception("No s'ha pogut mostrar el diàleg de diagnòstic")
            self.status_label.set_text(
                _("The diagnostic report could not be generated: {error}").format(
                    error=error,
                )
            )
            self.status_label.remove_css_class("status-success")
            self.status_label.add_css_class("status-error")
        finally:
            self._set_auxiliary_busy(button, False)
        return False

    @staticmethod
    def _create_form_label(text: str) -> Gtk.Label:
        label = Gtk.Label(label=text)
        label.set_halign(Gtk.Align.START)
        label.add_css_class("field-label")
        return label

    def _focus_password(self, _entry: Gtk.Entry) -> None:
        self.password_entry.grab_focus()

    def _on_password_activate(
        self,
        _entry: Gtk.PasswordEntry,
    ) -> None:
        self._on_connect_requested(self.connect_button)

    def _on_connect_requested(
            self,
            _button: Gtk.Button,
    ) -> None:
        if self._connection_action_busy:
            return

        # El feedback s'activa en el mateix instant del clic. La validació i
        # l'inici de la connexió es difereixen un cicle de GTK perquè el cursor
        # d'espera i el bloqueig del botó es puguen pintar abans de treballar.
        self._connection_request_pending = True
        self._set_connection_busy(True)
        GLib.idle_add(self._execute_connect_request)

    def _execute_connect_request(self) -> bool:
        username = self.username_entry.get_text().strip()
        password = self.password_entry.get_text()

        self._clear_validation_styles()

        if not username:
            self._show_validation_error(
                self.username_entry,
                _("Enter the username."),
            )
            self._connection_request_pending = False
            self._set_connection_busy(False)
            self.connect_button.set_sensitive(self.controller.state.can_connect)
            return False

        if not password:
            self._show_validation_error(
                self.password_entry,
                _("Enter the password."),
            )
            self._connection_request_pending = False
            self._set_connection_busy(False)
            self.connect_button.set_sensitive(self.controller.state.can_connect)
            return False

        self.connect_button.grab_focus()

        try:
            self.controller.save_user_preferences(
                username=username,
                remember_username=(
                    self.remember_username_check.get_active()
                ),
            )
        except OSError as error:
            logger.warning(
                "No s'han pogut guardar les preferències: %s",
                error,
            )

        try:
            started = self.controller.connect_rdp(
                username=username,
                password=password,
            )
        except Exception:
            logger.exception("Error inesperat en iniciar la connexió RDP")
            self._connection_request_pending = False
            self.password_entry.set_text("")
            self._set_connection_busy(False)
            self.connect_button.set_sensitive(self.controller.state.can_connect)
            self.status_label.set_text(_("Connection error"))
            self.status_label.remove_css_class("status-success")
            self.status_label.add_css_class("status-error")
            self.password_entry.grab_focus()
            return False

        self._connection_request_pending = False

        # La vista no ha de conservar mai la contrasenya.
        self.password_entry.set_text("")

        if not started:
            # Normalment l'esdeveniment ERROR ja haurà restaurat la vista,
            # però aquest fallback cobreix també una negativa sense event.
            self._set_connection_busy(False)
            self.connect_button.set_sensitive(
                self.controller.state.can_connect
            )
            self.password_entry.grab_focus()

        return False


    def _show_validation_error(
        self,
        widget: Gtk.Widget,
        message: str,
    ) -> None:
        widget.add_css_class("validation-error")
        widget.grab_focus()

        self.status_spinner.stop()
        self.status_spinner.set_visible(False)

        self.status_label.set_text(message)
        self.status_label.remove_css_class("status-success")
        self.status_label.add_css_class("status-error")

    def _clear_validation_styles(self) -> None:
        for widget in (
            self.username_entry,
            self.password_entry,
        ):
            widget.remove_css_class("validation-error")

        self.status_label.remove_css_class("status-error")
        self.status_label.remove_css_class("status-success")

    def _show_network_checking(self) -> None:
        self.network_icon.remove_css_class("network-ok")
        self.network_icon.remove_css_class("network-error")
        self.network_label.remove_css_class("network-ok")
        self.network_label.remove_css_class("network-error")

        self.network_icon.set_from_icon_name(
            "network-transmit-receive-symbolic"
        )

        self.network_label.set_text(
            _("Checking network…")
        )

    def _show_network_state(
            self,
            state: ApplicationState,
    ) -> None:
        self.network_icon.remove_css_class("network-ok")
        self.network_icon.remove_css_class("network-error")
        self.network_label.remove_css_class("network-ok")
        self.network_label.remove_css_class("network-error")

        if state.network_connected:
            self.network_icon.set_from_icon_name(
                "network-wired-symbolic"
            )
            self.network_icon.add_css_class("network-ok")

            self.network_label.set_text(
                _("Network connected")
            )
            self.network_label.add_css_class("network-ok")

            tooltip = (
                _("Interface: {interface}\nIP: {ip}").format(
                    interface=state.network_interface,
                    ip=state.local_ip,
                )
            )

            self.network_icon.set_tooltip_text(tooltip)
            self.network_label.set_tooltip_text(tooltip)

        else:
            error_message = (
                    state.network_error
                    or _("Network unavailable")
            )

            self.network_icon.set_from_icon_name(
                "network-offline-symbolic"
            )
            self.network_icon.add_css_class("network-error")

            self.network_label.set_text(
                _("No network")
            )
            self.network_label.add_css_class("network-error")

            self.network_icon.set_tooltip_text(error_message)
            self.network_label.set_tooltip_text(error_message)

            self._set_server_without_network()

    def _show_dns_checking(self) -> None:
        self.server_icon.remove_css_class("server-ok")
        self.server_icon.remove_css_class("server-error")
        self.server_status_label.remove_css_class("server-ok")
        self.server_status_label.remove_css_class("server-error")

        self.server_icon.set_from_icon_name(
            "system-search-symbolic"
        )

        self.server_status_label.set_text(
            _("Resolving server…")
        )

    def _show_dns_state(
            self,
            state: ApplicationState,
    ) -> None:
        self.server_icon.remove_css_class("server-ok")
        self.server_icon.remove_css_class("server-error")
        self.server_status_label.remove_css_class("server-ok")
        self.server_status_label.remove_css_class("server-error")

        if state.dns_resolved:
            self.server_icon.set_from_icon_name(
                "network-server-symbolic"
            )
            self.server_icon.add_css_class("server-ok")

            self.server_status_label.set_text(
                _("Server resolved")
            )
            self.server_status_label.add_css_class(
                "server-ok"
            )

            addresses = ", ".join(
                state.resolved_addresses
            )

            tooltip = (
                _("Server: {server}\nIP: {addresses}").format(
                    server=self.controller.config.device.server,
                    addresses=addresses,
                )
            )

            self.server_icon.set_tooltip_text(tooltip)
            self.server_status_label.set_tooltip_text(tooltip)
        else:
            error_message = (
                    state.dns_error
                    or _("The server could not be resolved.")
            )

            self.server_icon.set_from_icon_name(
                "dialog-error-symbolic"
            )
            self.server_icon.add_css_class("server-error")

            self.server_status_label.set_text(
                _("Server not resolved")
            )
            self.server_status_label.add_css_class(
                "server-error"
            )

            tooltip = (
                _("Server: {server}\nError: {error}").format(
                    server=self.controller.config.device.server,
                    error=error_message,
                )
            )

            self.server_icon.set_tooltip_text(tooltip)
            self.server_status_label.set_tooltip_text(tooltip)

    def _show_rdp_checking(self) -> None:
        self.server_icon.remove_css_class("server-ok")
        self.server_icon.remove_css_class("server-error")
        self.server_status_label.remove_css_class("server-ok")
        self.server_status_label.remove_css_class("server-error")

        self.server_icon.set_from_icon_name(
            "network-server-symbolic"
        )

        self.server_status_label.set_text(
            _("Checking RDP…")
        )

    def _show_rdp_state(
            self,
            state: ApplicationState,
    ) -> None:
        self.server_icon.remove_css_class("server-ok")
        self.server_icon.remove_css_class("server-error")
        self.server_status_label.remove_css_class("server-ok")
        self.server_status_label.remove_css_class("server-error")

        if state.rdp_available:
            self.server_icon.set_from_icon_name(
                "network-server-symbolic"
            )
            self.server_icon.add_css_class("server-ok")

            self.server_status_label.set_text(
                _("Server available")
            )
            self.server_status_label.add_css_class(
                "server-ok"
            )

            tooltip = (
                _("Server: {server}\nRDP port: {port}\nStatus: available").format(
                    server=self.controller.config.device.server,
                    port=self.controller.config.rdp.port,
                )
            )

        else:
            # Un sondeig TCP negatiu no és una prova autoritativa que la
            # sessió RDP siga impossible. Visualment tornem a l'últim estat
            # fiable (DNS resolt) i deixem l'error del sondeig només al
            # diagnòstic/log. L'intent real de FreeRDP decidirà el resultat.
            self.server_icon.set_from_icon_name(
                "network-server-symbolic"
            )

            if state.dns_resolved:
                self.server_icon.add_css_class("server-ok")
                self.server_status_label.set_text(
                    _("Server resolved")
                )
                self.server_status_label.add_css_class(
                    "server-ok"
                )

                addresses = ", ".join(state.resolved_addresses)
                tooltip = _(
                    "Server: {server}\nIP: {addresses}"
                ).format(
                    server=self.controller.config.device.server,
                    addresses=addresses,
                )
            else:
                self.server_status_label.set_text(
                    _("Resolving server…")
                )
                tooltip = _(
                    "Server: {server}"
                ).format(
                    server=self.controller.config.device.server,
                )

        self.server_icon.set_tooltip_text(tooltip)
        self.server_status_label.set_tooltip_text(tooltip)

    def _show_session_connecting(
            self,
            _state: ApplicationState,
    ) -> None:
        self.status_label.remove_css_class(
            "status-error"
        )
        self.status_label.remove_css_class(
            "status-success"
        )

    def _show_session_started(self) -> None:
        """
        FreeRDP ha arrancat, però això no garanteix que
        l'autenticació haja finalitzat correctament.

        La finestra es manté visible darrere de la sessió remota
        per garantir que sempre es puga recuperar en cas d'error.
        """

    def _show_session_finished(
            self,
            state: ApplicationState,
    ) -> None:
        self.set_visible(True)
        self.present()

        self.status_label.remove_css_class(
            "status-success"
        )
        self.status_label.remove_css_class(
            "status-error"
        )

        if state.session_error:
            self.status_label.add_css_class(
                "status-error"
            )
        else:
            self.status_label.add_css_class(
                "status-success"
            )

        self.password_entry.set_text("")
        self.password_entry.grab_focus()

    def _show_session_error(
            self,
            state: ApplicationState,
    ) -> None:
        self.set_visible(True)
        self.present()

        self.status_label.remove_css_class(
            "status-success"
        )
        self.status_label.add_css_class(
            "status-error"
        )

        presentation = present_application_error(
            state.current_error,
            state.session_error or state.error_message,
        )
        self.status_label.set_text(presentation.status_text)
        self.status_label.set_tooltip_text(
            state.current_error.technical_detail
            if state.current_error is not None
            else None
        )

        if presentation.show_diagnostics:
            self.diagnostic_button.add_css_class("suggested-action")
        else:
            self.diagnostic_button.remove_css_class("suggested-action")

        self.password_entry.set_text("")
        if (
            state.current_error is None
            or state.current_error.category
            not in {
                ErrorCategory.PRINTERS,
                ErrorCategory.AUDIO,
                ErrorCategory.VIDEO,
            }
        ):
            self.password_entry.grab_focus()




from __future__ import annotations

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")


from gi.repository import Gdk, Gtk

from xaac_thinclient.resources import STYLE
from xaac_thinclient.ui.login_window import LoginWindow
from xaac_thinclient.services.configuration import ConfigService
from xaac_thinclient.services.container import ApplicationServices
from xaac_thinclient.core.context import ApplicationContext
from xaac_thinclient.core.controller import ApplicationController
from xaac_thinclient.core.runtime import ApplicationRuntime
from xaac_thinclient.ipc import RemoteStateDbusService

import platform

from xaac_thinclient.paths import LOG_FILE
from xaac_thinclient.i18n import configure_language
from xaac_thinclient.services.logging import (
    configure_logging,
    get_logger,
    resolve_log_level,
)

logger = get_logger(__name__)

APPLICATION_ID = "org.xaac.thinclient"


class XaacThinClientApplication(Gtk.Application):
    def __init__(self) -> None:
        super().__init__(application_id=APPLICATION_ID)

        self._controller: ApplicationController | None = None
        self._window: LoginWindow | None = None
        self._state_service: RemoteStateDbusService | None = None

    def do_startup(self) -> None:
        logging_settings = ConfigService().load_logging_settings()
        effective_level = resolve_log_level(logging_settings.level)

        configure_logging(
            log_file=LOG_FILE,
            level=effective_level,
            console=logging_settings.console,
            file=logging_settings.file,
            max_bytes=logging_settings.max_bytes,
            backup_count=logging_settings.backup_count,
        )

        logger.info("Iniciant XAAC Thin Client Remote")
        logger.info(
            "Python %s sobre %s",
            platform.python_version(),
            platform.platform(),
        )

        Gtk.Application.do_startup(self)
        self._load_css()

    def do_activate(self) -> None:
        window = self.props.active_window

        if window is None:
            try:
                config_service = ConfigService()

                services = ApplicationServices.create_default()
                local_config = config_service.load_system_config()
                remote_settings = (
                    config_service.load_remote_configuration_settings()
                )
                remote_result = services.remote_configuration.resolve(
                    local_config,
                    remote_settings,
                )
                system_config = remote_result.config

                telemetry_settings = config_service.load_remote_telemetry_settings()
                if telemetry_settings.enabled:
                    device_id = None
                    if remote_settings.device_identity_enabled and remote_settings.device_identity_file is not None:
                        try:
                            from xaac_thinclient.services.remote_device_identity import RemoteDeviceIdentityStore
                            device_id = RemoteDeviceIdentityStore(
                                remote_settings.device_identity_file
                            ).load_or_create(system_config.device.device_name).device_id
                        except Exception as identity_error:
                            logger.warning(
                                "No s'ha pogut carregar la identitat per a telemetria: %s",
                                identity_error,
                            )
                    telemetry_event = services.remote_telemetry.configuration_event(
                        remote_result, device_id=device_id
                    )
                    telemetry_report = services.remote_telemetry.publish(
                        telemetry_event, telemetry_settings
                    )
                    if telemetry_report.warning:
                        logger.warning(
                            "Telemetria pendent: %s", telemetry_report.warning
                        )
                user_preferences = config_service.load_user_preferences()

                if remote_result.rejected_keys:
                    logger.warning(
                        "Claus de configuració remota rebutjades: %s",
                        ", ".join(remote_result.rejected_keys),
                    )

                if remote_result.warning:
                    logger.warning(
                        "Configuració remota no disponible; "
                        "origen=%s, detall=%s",
                        remote_result.source.value,
                        remote_result.warning,
                    )
                else:
                    logger.info(
                        "Origen de configuració: %s",
                        remote_result.source.value,
                    )

                configure_language(system_config.application.language)

                logger.info(
                    "Configuració carregada: dispositiu=%s, servidor=%s, port=%s",
                    system_config.device.device_name,
                    system_config.device.server,
                    system_config.rdp.port,
                )

                logger.info(
                    "Preferències carregades: recordar_usuari=%s",
                    user_preferences.remember_username,
                )

                runtime = ApplicationRuntime.create_default()
                context = ApplicationContext(
                    config=system_config,
                    preferences=user_preferences,
                    config_service=config_service,
                    services=services,
                    runtime=runtime,
                    configuration_metadata=remote_result.metadata(),
                )

                self._controller = ApplicationController(
                    context=context,
                )
                # The read-only Dock state contract is observational.  A
                # session-bus or registration failure must never prevent the
                # primary Remote UI from appearing.
                state_service = RemoteStateDbusService(self._controller)
                try:
                    state_service.start()
                except Exception:
                    logger.warning(
                        "No s'ha pogut publicar l'estat D-Bus per al Dock",
                        exc_info=True,
                    )
                else:
                    self._state_service = state_service

                self._window = LoginWindow(
                    application=self,
                    controller=self._controller,
                )
                window = self._window
                self._controller.start()

            except Exception:
                logger.exception(
                    "Error durant l'activació de l'aplicació"
                )
                raise

        window.present()

    def do_shutdown(self) -> None:
        logger.info("Tancant aplicació")

        if self._state_service is not None:
            self._state_service.close()
            self._state_service = None

        if self._controller is not None:
            self._controller.shutdown()
            self._controller = None

        self._window = None

        Gtk.Application.do_shutdown(self)

    @staticmethod
    def _load_css() -> None:
        display = Gdk.Display.get_default()

        if display is None:
            raise RuntimeError(
                "No s'ha pogut obtindre la pantalla gràfica."
            )

        if not STYLE.exists():
            raise FileNotFoundError(
                f"No s'ha trobat el CSS: {STYLE}"
            )

        provider = Gtk.CssProvider()
        provider.load_from_path(str(STYLE))

        Gtk.StyleContext.add_provider_for_display(
            display,
            provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION,
        )


def run() -> int:
    app = XaacThinClientApplication()
    return app.run(None)

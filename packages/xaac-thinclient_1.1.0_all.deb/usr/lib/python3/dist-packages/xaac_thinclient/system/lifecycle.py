from __future__ import annotations

import logging
from dataclasses import dataclass
from enum import Enum

from xaac_thinclient.config.models import SystemConfig
from xaac_thinclient.system.kiosk import KioskPolicy, KioskPolicyService
from xaac_thinclient.system.recovery import RecoveryRecord, RecoveryState
from xaac_thinclient.system.supervisor import SupervisorSnapshot, SupervisorState

_LOGGER = logging.getLogger(__name__)


class SystemLifecycleState(Enum):
    DISABLED = "disabled"
    READY = "ready"
    DEGRADED = "degraded"
    SAFE_MODE = "safe-mode"


@dataclass(frozen=True, slots=True)
class SystemLifecycleReport:
    state: SystemLifecycleState
    kiosk_policy: KioskPolicy
    supervisor: SupervisorSnapshot
    recovery: RecoveryRecord
    ready: bool
    safe_mode: bool
    status_code: str
    issues: tuple[str, ...] = ()


class SystemLifecycleService:
    """Tanca el Bloc 5 amb una vista immutable de salut del sistema/quiosc.

    El servei només agrega decisions ja tipades. No crea processos, no toca el
    sistema de fitxers i no executa ordres.
    """

    def __init__(self, *, kiosk_service: KioskPolicyService | None = None) -> None:
        self.kiosk_service = kiosk_service or KioskPolicyService()

    def evaluate(
        self,
        config: SystemConfig,
        supervisor: SupervisorSnapshot,
        recovery: RecoveryRecord,
    ) -> SystemLifecycleReport:
        policy = self.kiosk_service.resolve(config)
        issues: list[str] = []

        persistent_safe = recovery.safe_mode or recovery.state in (
            RecoveryState.SAFE_MODE,
            RecoveryState.DEGRADED,
        )
        safe_mode = supervisor.safe_mode or persistent_safe

        if not config.kiosk_enabled:
            state = SystemLifecycleState.DISABLED
            ready = True
            code = "SYSTEM-KIOSK-OFF"
        elif safe_mode:
            state = SystemLifecycleState.SAFE_MODE
            ready = False
            code = "SYSTEM-SAFE-001"
            issues.append(recovery.status_code if persistent_safe else supervisor.status_code)
        elif supervisor.state is SupervisorState.RUNNING:
            state = SystemLifecycleState.READY
            ready = True
            code = "SYSTEM-READY"
        else:
            state = SystemLifecycleState.DEGRADED
            ready = False
            code = "SYSTEM-DEGRADED-001"
            issues.append(supervisor.status_code)

        report = SystemLifecycleReport(
            state=state,
            kiosk_policy=policy,
            supervisor=supervisor,
            recovery=recovery,
            ready=ready,
            safe_mode=safe_mode,
            status_code=code,
            issues=tuple(dict.fromkeys(issues)),
        )
        _LOGGER.info(
            "system.lifecycle.evaluated",
            extra={
                "state": report.state.value,
                "ready": report.ready,
                "safe_mode": report.safe_mode,
                "status_code": report.status_code,
                "issue_count": len(report.issues),
            },
        )
        return report

    @staticmethod
    def status_values(report: SystemLifecycleReport) -> tuple[tuple[str, str], ...]:
        return (
            ("System lifecycle state", report.state.value),
            ("System lifecycle ready", str(report.ready).lower()),
            ("System lifecycle safe mode", str(report.safe_mode).lower()),
            ("System lifecycle status code", report.status_code),
            ("System lifecycle issues", ",".join(report.issues) or "-"),
        )

from __future__ import annotations

import logging
import os
import tempfile
from dataclasses import dataclass
from enum import Enum
from pathlib import Path

from xaac_thinclient.config.models import SystemConfig

_LOGGER = logging.getLogger(__name__)


class AutostartAction(Enum):
    NO_CHANGE = "no-change"
    INSTALL = "install"
    REMOVE = "remove"


@dataclass(frozen=True, slots=True)
class AutostartPlan:
    action: AutostartAction
    destination: Path
    content: str | None
    reason: str


@dataclass(frozen=True, slots=True)
class AutostartResult:
    action: AutostartAction
    changed: bool
    destination: Path
    success: bool
    error_code: str | None = None


class AutostartService:
    """Reconcilia l'arrencada XDG de forma idempotent i sense shell."""

    FILE_NAME = "xaac-thinclient.desktop"

    def __init__(self, *, config_home: Path | None = None, executable: str = "xaac-thinclient") -> None:
        base = config_home or Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
        self.destination = base.expanduser() / "autostart" / self.FILE_NAME
        self.executable = executable

    def plan(self, config: SystemConfig) -> AutostartPlan:
        expected = self.render(config) if config.autostart_enabled else None
        current = self._read_current()
        if expected is None:
            managed = current is not None and "X-XAAC-Managed=true" in current
            action = AutostartAction.REMOVE if managed else AutostartAction.NO_CHANGE
            if managed:
                reason = "disabled-managed-present"
            elif current is None:
                reason = "disabled-absent"
            else:
                reason = "disabled-foreign-present"
        elif current == expected:
            action, reason = AutostartAction.NO_CHANGE, "already-current"
        else:
            action, reason = AutostartAction.INSTALL, "missing-or-outdated"
        return AutostartPlan(action, self.destination, expected, reason)

    def apply(self, config: SystemConfig) -> AutostartResult:
        plan = self.plan(config)
        try:
            if plan.action is AutostartAction.INSTALL:
                self._atomic_write(plan.content or "")
            elif plan.action is AutostartAction.REMOVE:
                self.destination.unlink(missing_ok=True)
            changed = plan.action is not AutostartAction.NO_CHANGE
            _LOGGER.info("system.autostart.reconciled", extra={"action": plan.action.value, "changed": changed, "success": True})
            return AutostartResult(plan.action, changed, self.destination, True)
        except OSError:
            _LOGGER.warning("system.autostart.failed", extra={"action": plan.action.value, "changed": False, "success": False, "error_code": "AUTOSTART-IO-001"})
            return AutostartResult(plan.action, False, self.destination, False, "AUTOSTART-IO-001")

    def render(self, config: SystemConfig) -> str:
        return ("[Desktop Entry]\nType=Application\nName=XAAC Thin Client Remote\n"
                f"Exec={self.executable}\nTerminal=false\nX-GNOME-Autostart-enabled=true\n"
                f"X-GNOME-Autostart-Delay={config.autostart_delay_seconds}\n"
                "X-XAAC-Managed=true\n")

    def status_values(self, config: SystemConfig) -> tuple[tuple[str, str], ...]:
        plan = self.plan(config)
        return (("Autostart configured", str(config.autostart_enabled).lower()),
                ("Autostart delay", str(config.autostart_delay_seconds)),
                ("Autostart state", plan.reason),
                ("Autostart action", plan.action.value))

    def _read_current(self) -> str | None:
        try:
            return self.destination.read_text(encoding="utf-8")
        except (FileNotFoundError, OSError):
            return None

    def _atomic_write(self, content: str) -> None:
        self.destination.parent.mkdir(parents=True, exist_ok=True)
        fd, temporary = tempfile.mkstemp(prefix=".xaac-autostart-", dir=self.destination.parent, text=True)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                handle.write(content)
                handle.flush()
                os.fsync(handle.fileno())
            os.chmod(temporary, 0o600)
            os.replace(temporary, self.destination)
        finally:
            Path(temporary).unlink(missing_ok=True)

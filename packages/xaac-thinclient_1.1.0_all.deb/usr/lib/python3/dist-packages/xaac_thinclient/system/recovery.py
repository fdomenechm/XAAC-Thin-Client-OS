from __future__ import annotations

import json
import logging
import os
import tempfile
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any

from xaac_thinclient.system.supervisor import SupervisorSnapshot

_LOGGER = logging.getLogger(__name__)


class RecoveryState(Enum):
    CLEAR = "clear"
    SAFE_MODE = "safe-mode"
    DEGRADED = "degraded"


class RecoveryAction(Enum):
    NO_CHANGE = "no-change"
    PERSIST = "persist"
    CLEAR = "clear"
    BLOCKED = "blocked"


@dataclass(frozen=True, slots=True)
class RecoveryRecord:
    state: RecoveryState
    safe_mode: bool
    failure_count: int
    entered_at: float | None
    status_code: str
    schema_version: int = 1


@dataclass(frozen=True, slots=True)
class RecoveryResult:
    action: RecoveryAction
    record: RecoveryRecord
    changed: bool
    success: bool
    error_code: str | None = None


class KioskRecoveryService:
    """Persisteix el mode segur sense shell ni dades sensibles.

    L'estat es guarda sota XDG_STATE_HOME amb escriptura atòmica i permisos
    0600. Una recuperació només pot netejar-se mitjançant autorització local
    explícita; no existeix cap camp de política remota que ho permeta.
    """

    FILE_NAME = "kiosk-recovery.json"
    SCHEMA_VERSION = 1

    def __init__(self, *, state_home: Path | None = None) -> None:
        base = state_home or Path(
            os.environ.get("XDG_STATE_HOME", Path.home() / ".local" / "state")
        )
        self.destination = base.expanduser() / "xaac-thinclient" / self.FILE_NAME

    @staticmethod
    def clear_record() -> RecoveryRecord:
        return RecoveryRecord(
            state=RecoveryState.CLEAR,
            safe_mode=False,
            failure_count=0,
            entered_at=None,
            status_code="RECOVERY-CLEAR",
        )

    def from_supervisor(
        self, snapshot: SupervisorSnapshot, *, now: float
    ) -> RecoveryRecord:
        if now < 0:
            raise ValueError("now must be non-negative")
        if not snapshot.safe_mode:
            return self.clear_record()
        return RecoveryRecord(
            state=RecoveryState.SAFE_MODE,
            safe_mode=True,
            failure_count=max(0, snapshot.consecutive_failures),
            entered_at=now,
            status_code="RECOVERY-SAFE-001",
        )

    def load(self) -> RecoveryRecord:
        try:
            raw = self.destination.read_text(encoding="utf-8")
        except FileNotFoundError:
            return self.clear_record()
        except OSError:
            return self._degraded("RECOVERY-IO-001")

        try:
            payload = json.loads(raw)
            return self._decode(payload)
        except (json.JSONDecodeError, TypeError, ValueError, KeyError):
            return self._degraded("RECOVERY-STATE-001")

    def persist(self, record: RecoveryRecord) -> RecoveryResult:
        current = self.load()
        if current == record and self.destination.is_file():
            return self._result(RecoveryAction.NO_CHANGE, record, False, True)
        try:
            self._atomic_write(self._encode(record))
        except OSError:
            degraded = self._degraded("RECOVERY-IO-001")
            return self._result(
                RecoveryAction.PERSIST,
                degraded,
                False,
                False,
                "RECOVERY-IO-001",
            )
        return self._result(RecoveryAction.PERSIST, record, True, True)

    def clear(self, *, local_authorized: bool) -> RecoveryResult:
        current = self.load()
        if not local_authorized:
            blocked = RecoveryRecord(
                state=current.state,
                safe_mode=current.safe_mode,
                failure_count=current.failure_count,
                entered_at=current.entered_at,
                status_code="RECOVERY-AUTH-001",
            )
            return self._result(
                RecoveryAction.BLOCKED,
                blocked,
                False,
                False,
                "RECOVERY-AUTH-001",
            )
        try:
            existed = self.destination.exists()
            self.destination.unlink(missing_ok=True)
        except OSError:
            degraded = self._degraded("RECOVERY-IO-001")
            return self._result(
                RecoveryAction.CLEAR,
                degraded,
                False,
                False,
                "RECOVERY-IO-001",
            )
        return self._result(
            RecoveryAction.CLEAR,
            self.clear_record(),
            existed,
            True,
        )

    def status_values(self, record: RecoveryRecord) -> tuple[tuple[str, str], ...]:
        return (
            ("Kiosk recovery state", record.state.value),
            ("Kiosk recovery safe mode", str(record.safe_mode).lower()),
            ("Kiosk recovery failures", str(record.failure_count)),
            ("Kiosk recovery status code", record.status_code),
        )

    def _decode(self, payload: Any) -> RecoveryRecord:
        if not isinstance(payload, dict):
            raise ValueError("record must be an object")
        allowed = {
            "schema_version",
            "safe_mode",
            "failure_count",
            "entered_at",
            "status_code",
        }
        if set(payload) != allowed:
            raise ValueError("unexpected recovery fields")
        if payload["schema_version"] != self.SCHEMA_VERSION:
            raise ValueError("unsupported recovery schema")
        safe_mode = payload["safe_mode"]
        failure_count = payload["failure_count"]
        entered_at = payload["entered_at"]
        status_code = payload["status_code"]
        if not isinstance(safe_mode, bool):
            raise ValueError("safe_mode must be boolean")
        if not isinstance(failure_count, int) or isinstance(failure_count, bool) or failure_count < 0:
            raise ValueError("failure_count must be a non-negative integer")
        if entered_at is not None and (
            not isinstance(entered_at, (int, float))
            or isinstance(entered_at, bool)
            or entered_at < 0
        ):
            raise ValueError("entered_at must be non-negative")
        if not isinstance(status_code, str) or not status_code.startswith("RECOVERY-"):
            raise ValueError("invalid status code")
        state = RecoveryState.SAFE_MODE if safe_mode else RecoveryState.CLEAR
        return RecoveryRecord(
            state=state,
            safe_mode=safe_mode,
            failure_count=failure_count,
            entered_at=float(entered_at) if entered_at is not None else None,
            status_code=status_code,
        )

    def _encode(self, record: RecoveryRecord) -> str:
        payload = {
            "schema_version": self.SCHEMA_VERSION,
            "safe_mode": record.safe_mode,
            "failure_count": record.failure_count,
            "entered_at": record.entered_at,
            "status_code": record.status_code,
        }
        return json.dumps(payload, sort_keys=True, separators=(",", ":")) + "\n"

    def _atomic_write(self, content: str) -> None:
        self.destination.parent.mkdir(parents=True, exist_ok=True)
        fd, temporary = tempfile.mkstemp(
            prefix=".xaac-recovery-", dir=self.destination.parent, text=True
        )
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                handle.write(content)
                handle.flush()
                os.fsync(handle.fileno())
            os.chmod(temporary, 0o600)
            os.replace(temporary, self.destination)
        finally:
            Path(temporary).unlink(missing_ok=True)

    @staticmethod
    def _degraded(code: str) -> RecoveryRecord:
        return RecoveryRecord(
            state=RecoveryState.DEGRADED,
            safe_mode=True,
            failure_count=0,
            entered_at=None,
            status_code=code,
        )

    @staticmethod
    def _result(
        action: RecoveryAction,
        record: RecoveryRecord,
        changed: bool,
        success: bool,
        error_code: str | None = None,
    ) -> RecoveryResult:
        log = _LOGGER.info if success else _LOGGER.warning
        log(
            "system.kiosk_recovery.reconciled",
            extra={
                "action": action.value,
                "changed": changed,
                "success": success,
                "safe_mode": record.safe_mode,
                "failure_count": record.failure_count,
                "status_code": record.status_code,
                "error_code": error_code,
            },
        )
        return RecoveryResult(action, record, changed, success, error_code)

from __future__ import annotations

import logging
from dataclasses import dataclass
from enum import Enum

from xaac_thinclient.config.models import SystemConfig

_LOGGER = logging.getLogger(__name__)


class SupervisorState(Enum):
    DISABLED = "disabled"
    STARTING = "starting"
    RUNNING = "running"
    RESTARTING = "restarting"
    FAILED = "failed"


class SupervisorEvent(Enum):
    ENABLE = "enable"
    STARTED = "started"
    EXITED = "exited"
    LAUNCH_FAILED = "launch_failed"
    HEALTHY = "healthy"
    TICK = "tick"
    DISABLE = "disable"


class SupervisorAction(Enum):
    NONE = "none"
    START = "start"
    RESTART = "restart"
    ENTER_SAFE_MODE = "enter_safe_mode"


@dataclass(frozen=True, slots=True)
class SupervisorSnapshot:
    state: SupervisorState
    restart_times: tuple[float, ...] = ()
    consecutive_failures: int = 0
    next_restart_at: float | None = None
    safe_mode: bool = False
    status_code: str = "SUPERVISOR-OFF"


@dataclass(frozen=True, slots=True)
class SupervisorDecision:
    snapshot: SupervisorSnapshot
    action: SupervisorAction
    delay_seconds: float = 0.0


class KioskSupervisorService:
    """Màquina d'estats pura per supervisar el mode quiosc.

    No crea processos ni depén de systemd. El consumidor executa l'acció
    tipada retornada i torna a informar del resultat mitjançant un nou event.
    """

    @staticmethod
    def initial(config: SystemConfig) -> SupervisorSnapshot:
        enabled = config.kiosk_enabled and config.kiosk_auto_restart
        return SupervisorSnapshot(
            state=SupervisorState.STARTING if enabled else SupervisorState.DISABLED,
            status_code="SUPERVISOR-STARTING" if enabled else "SUPERVISOR-OFF",
        )

    def transition(
        self,
        config: SystemConfig,
        snapshot: SupervisorSnapshot,
        event: SupervisorEvent,
        *,
        now: float,
    ) -> SupervisorDecision:
        if now < 0:
            raise ValueError("now must be non-negative")

        if event is SupervisorEvent.DISABLE or not (
            config.kiosk_enabled and config.kiosk_auto_restart
        ):
            return self._decision(
                SupervisorSnapshot(
                    state=SupervisorState.DISABLED,
                    status_code="SUPERVISOR-OFF",
                ),
                SupervisorAction.NONE,
                event,
            )

        if snapshot.safe_mode:
            return self._decision(snapshot, SupervisorAction.NONE, event)

        if event is SupervisorEvent.ENABLE:
            new = SupervisorSnapshot(
                state=SupervisorState.STARTING,
                restart_times=snapshot.restart_times,
                status_code="SUPERVISOR-STARTING",
            )
            return self._decision(new, SupervisorAction.START, event)

        if event in (SupervisorEvent.STARTED, SupervisorEvent.HEALTHY):
            new = SupervisorSnapshot(
                state=SupervisorState.RUNNING,
                restart_times=self._within_window(config, snapshot.restart_times, now),
                consecutive_failures=0,
                status_code="SUPERVISOR-RUNNING",
            )
            return self._decision(new, SupervisorAction.NONE, event)

        if event in (SupervisorEvent.EXITED, SupervisorEvent.LAUNCH_FAILED):
            times = self._within_window(config, snapshot.restart_times, now)
            if len(times) >= config.kiosk_restart_limit:
                new = SupervisorSnapshot(
                    state=SupervisorState.FAILED,
                    restart_times=times,
                    consecutive_failures=snapshot.consecutive_failures + 1,
                    safe_mode=True,
                    status_code="SUPERVISOR-SAFE-001",
                )
                return self._decision(new, SupervisorAction.ENTER_SAFE_MODE, event)

            failures = snapshot.consecutive_failures + 1
            delay = min(
                config.kiosk_restart_backoff_seconds * (2 ** (failures - 1)),
                float(config.kiosk_restart_window_seconds),
            )
            new = SupervisorSnapshot(
                state=SupervisorState.RESTARTING,
                restart_times=(*times, now),
                consecutive_failures=failures,
                next_restart_at=now + delay,
                status_code="SUPERVISOR-BACKOFF",
            )
            return self._decision(new, SupervisorAction.NONE, event, delay)

        if event is SupervisorEvent.TICK:
            if (
                snapshot.state is SupervisorState.RESTARTING
                and snapshot.next_restart_at is not None
                and now >= snapshot.next_restart_at
            ):
                new = SupervisorSnapshot(
                    state=SupervisorState.STARTING,
                    restart_times=self._within_window(config, snapshot.restart_times, now),
                    consecutive_failures=snapshot.consecutive_failures,
                    status_code="SUPERVISOR-RESTART",
                )
                return self._decision(new, SupervisorAction.RESTART, event)
            return self._decision(snapshot, SupervisorAction.NONE, event)

        return self._decision(snapshot, SupervisorAction.NONE, event)

    @staticmethod
    def _within_window(
        config: SystemConfig, restart_times: tuple[float, ...], now: float
    ) -> tuple[float, ...]:
        threshold = now - config.kiosk_restart_window_seconds
        return tuple(value for value in restart_times if value >= threshold)

    @staticmethod
    def _decision(
        snapshot: SupervisorSnapshot,
        action: SupervisorAction,
        event: SupervisorEvent,
        delay_seconds: float = 0.0,
    ) -> SupervisorDecision:
        _LOGGER.info(
            "system.kiosk_supervisor.transition",
            extra={
                "event": event.value,
                "state": snapshot.state.value,
                "action": action.value,
                "safe_mode": snapshot.safe_mode,
                "failure_count": snapshot.consecutive_failures,
                "status_code": snapshot.status_code,
            },
        )
        return SupervisorDecision(snapshot, action, delay_seconds)

    def status_values(
        self, snapshot: SupervisorSnapshot
    ) -> tuple[tuple[str, str], ...]:
        return (
            ("Kiosk supervisor state", snapshot.state.value),
            ("Kiosk supervisor safe mode", str(snapshot.safe_mode).lower()),
            ("Kiosk supervisor failures", str(snapshot.consecutive_failures)),
            ("Kiosk supervisor status code", snapshot.status_code),
        )

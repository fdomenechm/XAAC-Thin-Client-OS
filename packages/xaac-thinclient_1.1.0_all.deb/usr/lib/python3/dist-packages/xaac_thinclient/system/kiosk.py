from __future__ import annotations

import logging
from dataclasses import dataclass
from enum import Enum

from xaac_thinclient.config.models import SystemConfig

_LOGGER = logging.getLogger(__name__)


class KioskMode(Enum):
    DISABLED = "disabled"
    ENFORCED = "enforced"
    RECOVERABLE = "recoverable"


@dataclass(frozen=True, slots=True)
class KioskPolicy:
    mode: KioskMode
    enabled: bool
    force_fullscreen: bool
    allow_window_close: bool
    allow_settings: bool
    allow_emergency_exit: bool
    allow_power_actions: bool
    status_code: str


class KioskPolicyService:
    """Resol una política quiosc immutable sense modificar el sistema.

    La via d'eixida d'emergència és deliberadament local: una política remota
    no pot eliminar l'últim mecanisme administratiu de recuperació.
    """

    def resolve(self, config: SystemConfig) -> KioskPolicy:
        if not config.kiosk_enabled:
            policy = KioskPolicy(
                mode=KioskMode.DISABLED,
                enabled=False,
                force_fullscreen=False,
                allow_window_close=True,
                allow_settings=True,
                allow_emergency_exit=True,
                allow_power_actions=True,
                status_code="KIOSK-OFF",
            )
        else:
            recoverable = config.kiosk_emergency_exit_enabled
            policy = KioskPolicy(
                mode=KioskMode.RECOVERABLE if recoverable else KioskMode.ENFORCED,
                enabled=True,
                force_fullscreen=True,
                allow_window_close=False,
                allow_settings=False,
                allow_emergency_exit=recoverable,
                allow_power_actions=config.kiosk_power_actions_enabled,
                status_code="KIOSK-RECOVERY" if recoverable else "KIOSK-LOCKED",
            )
        _LOGGER.info(
            "system.kiosk.resolved",
            extra={
                "mode": policy.mode.value,
                "enabled": policy.enabled,
                "emergency_exit": policy.allow_emergency_exit,
                "power_actions": policy.allow_power_actions,
                "status_code": policy.status_code,
            },
        )
        return policy

    def status_values(self, config: SystemConfig) -> tuple[tuple[str, str], ...]:
        policy = self.resolve(config)
        return (
            ("Kiosk mode", policy.mode.value),
            ("Kiosk fullscreen enforced", str(policy.force_fullscreen).lower()),
            ("Kiosk emergency exit", str(policy.allow_emergency_exit).lower()),
            ("Kiosk power actions", str(policy.allow_power_actions).lower()),
            ("Kiosk status code", policy.status_code),
        )

from __future__ import annotations

import logging
from dataclasses import dataclass
from enum import Enum
from typing import Protocol

from xaac_thinclient.system.kiosk import KioskPolicy

_LOGGER = logging.getLogger(__name__)


class KioskExitReason(Enum):
    USER = "user"
    ADMINISTRATIVE = "administrative"
    APPLICATION = "application"


class KioskWindow(Protocol):
    def fullscreen(self) -> None: ...

    def set_decorated(self, setting: bool) -> None: ...


@dataclass(frozen=True, slots=True)
class KioskRuntimeState:
    fullscreen_applied: bool
    decorations_hidden: bool
    user_close_blocked: bool
    emergency_exit_available: bool
    status_code: str


class KioskRuntimeService:
    """Aplica la política quiosc a una finestra sense dependre de GTK.

    Les decisions de tancament es mantenen explícites. El tancament intern de
    l'aplicació sempre és possible; l'eixida administrativa només ho és quan
    la política local conserva la via de recuperació.
    """

    def apply(self, window: KioskWindow, policy: KioskPolicy) -> KioskRuntimeState:
        if policy.force_fullscreen:
            window.fullscreen()
            window.set_decorated(False)

        state = KioskRuntimeState(
            fullscreen_applied=policy.force_fullscreen,
            decorations_hidden=policy.force_fullscreen,
            user_close_blocked=not policy.allow_window_close,
            emergency_exit_available=policy.allow_emergency_exit,
            status_code="KIOSK-RUNTIME-LOCKED" if policy.enabled else "KIOSK-RUNTIME-OFF",
        )
        _LOGGER.info(
            "system.kiosk.runtime.applied",
            extra={
                "fullscreen": state.fullscreen_applied,
                "decorations_hidden": state.decorations_hidden,
                "user_close_blocked": state.user_close_blocked,
                "emergency_exit": state.emergency_exit_available,
                "status_code": state.status_code,
            },
        )
        return state

    @staticmethod
    def allows_exit(policy: KioskPolicy, reason: KioskExitReason) -> bool:
        if reason is KioskExitReason.APPLICATION:
            return True
        if reason is KioskExitReason.ADMINISTRATIVE:
            return policy.allow_emergency_exit
        return policy.allow_window_close

    def should_inhibit_close(
        self,
        policy: KioskPolicy,
        reason: KioskExitReason = KioskExitReason.USER,
    ) -> bool:
        allowed = self.allows_exit(policy, reason)
        _LOGGER.info(
            "system.kiosk.close.resolved",
            extra={
                "reason": reason.value,
                "allowed": allowed,
                "status_code": "KIOSK-CLOSE-ALLOW" if allowed else "KIOSK-CLOSE-BLOCK",
            },
        )
        return not allowed

    def status_values(self, state: KioskRuntimeState) -> tuple[tuple[str, str], ...]:
        return (
            ("Kiosk runtime fullscreen", str(state.fullscreen_applied).lower()),
            ("Kiosk runtime decorations hidden", str(state.decorations_hidden).lower()),
            ("Kiosk runtime close blocked", str(state.user_close_blocked).lower()),
            ("Kiosk runtime emergency exit", str(state.emergency_exit_available).lower()),
            ("Kiosk runtime status code", state.status_code),
        )

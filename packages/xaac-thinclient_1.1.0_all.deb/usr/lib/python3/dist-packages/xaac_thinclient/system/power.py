from __future__ import annotations

import logging
import os
import subprocess
from dataclasses import dataclass
from enum import Enum
from typing import Callable, Sequence

from xaac_thinclient.system.kiosk import KioskPolicy

_LOGGER = logging.getLogger(__name__)


class PowerAction(Enum):
    POWEROFF = "poweroff"
    REBOOT = "reboot"


class PowerDecision(Enum):
    ALLOWED = "allowed"
    BLOCKED = "blocked"


@dataclass(frozen=True, slots=True)
class PowerPlan:
    action: PowerAction
    decision: PowerDecision
    command: tuple[str, ...]
    status_code: str


@dataclass(frozen=True, slots=True)
class PowerResult:
    action: PowerAction
    attempted: bool
    succeeded: bool
    status_code: str
    return_code: int | None = None


CommandRunner = Callable[..., subprocess.CompletedProcess[str]]


class PowerActionService:
    """Executa accions d'energia tipades sense shell ni arguments externs.

    La política quiosc és l'única font d'autorització. Les ordres són fixes i
    no poden ser alterades per configuració local o remota.
    """

    _COMMANDS: dict[PowerAction, tuple[str, ...]] = {
        PowerAction.POWEROFF: ("systemctl", "poweroff"),
        PowerAction.REBOOT: ("systemctl", "reboot"),
    }
    _KIOSK_HELPERS: dict[PowerAction, str] = {
        PowerAction.POWEROFF: "/usr/local/sbin/xaac-kiosk-poweroff",
        PowerAction.REBOOT: "/usr/local/sbin/xaac-kiosk-reboot",
    }

    def __init__(
        self,
        *,
        runner: CommandRunner = subprocess.run,
        timeout_seconds: float = 10.0,
        helper_available: Callable[[str], bool] | None = None,
    ) -> None:
        if timeout_seconds <= 0:
            raise ValueError("timeout_seconds must be positive")
        self._runner = runner
        self._timeout_seconds = timeout_seconds
        self._helper_available = helper_available or (
            lambda path: os.path.isfile(path) and os.access(path, os.X_OK)
        )

    def _command_for(self, action: PowerAction) -> tuple[str, ...]:
        helper = self._KIOSK_HELPERS[action]
        if self._helper_available(helper):
            return ("sudo", "-n", helper)
        return self._COMMANDS[action]

    def plan(self, policy: KioskPolicy, action: PowerAction) -> PowerPlan:
        allowed = policy.allow_power_actions
        plan = PowerPlan(
            action=action,
            decision=PowerDecision.ALLOWED if allowed else PowerDecision.BLOCKED,
            command=self._command_for(action),
            status_code="POWER-READY" if allowed else "POWER-POLICY-001",
        )
        _LOGGER.info(
            "system.power.planned",
            extra={
                "action": action.value,
                "decision": plan.decision.value,
                "status_code": plan.status_code,
            },
        )
        return plan

    def execute(self, policy: KioskPolicy, action: PowerAction) -> PowerResult:
        plan = self.plan(policy, action)
        if plan.decision is PowerDecision.BLOCKED:
            return PowerResult(action, False, False, plan.status_code)

        try:
            completed = self._runner(
                list(plan.command),
                check=False,
                capture_output=True,
                text=True,
                timeout=self._timeout_seconds,
                shell=False,
            )
        except (OSError, subprocess.SubprocessError):
            _LOGGER.exception(
                "system.power.execution_failed",
                extra={"action": action.value, "status_code": "POWER-EXEC-001"},
            )
            return PowerResult(action, True, False, "POWER-EXEC-001")

        succeeded = completed.returncode == 0
        status_code = "POWER-REQUESTED" if succeeded else "POWER-REJECTED-001"
        _LOGGER.info(
            "system.power.executed",
            extra={
                "action": action.value,
                "succeeded": succeeded,
                "return_code": completed.returncode,
                "status_code": status_code,
            },
        )
        return PowerResult(
            action=action,
            attempted=True,
            succeeded=succeeded,
            status_code=status_code,
            return_code=completed.returncode,
        )

    def status_values(self, policy: KioskPolicy) -> tuple[tuple[str, str], ...]:
        return (
            ("Power actions allowed", str(policy.allow_power_actions).lower()),
            (
                "Power actions status code",
                "POWER-READY" if policy.allow_power_actions else "POWER-POLICY-001",
            ),
        )

from __future__ import annotations

import logging
import os
import tempfile
from dataclasses import dataclass
from enum import Enum
from pathlib import Path

from xaac_thinclient.config.models import SystemConfig

_LOGGER = logging.getLogger(__name__)


class SessionAction(Enum):
    NO_CHANGE = "no-change"
    INSTALL = "install"
    REMOVE = "remove"


@dataclass(frozen=True, slots=True)
class SessionPlan:
    action: SessionAction
    destination: Path
    content: str | None
    reason: str


@dataclass(frozen=True, slots=True)
class SessionResult:
    action: SessionAction
    changed: bool
    destination: Path
    success: bool
    error_code: str | None = None


class DedicatedSessionService:
    """Reconcilia un descriptor XDG de sessió sense shell ni privilegis."""

    FILE_NAME = "xaac-thinclient.desktop"
    MANAGED_MARKER = "X-XAAC-Managed=true"

    def __init__(self, *, data_home: Path | None = None, executable: str = "xaac-thinclient") -> None:
        base = data_home or Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
        self.destination = base.expanduser() / "xsessions" / self.FILE_NAME
        self.executable = executable

    def plan(self, config: SystemConfig) -> SessionPlan:
        expected = self.render(config) if config.dedicated_session_enabled else None
        current = self._read_current()
        if expected is None:
            managed = current is not None and self.MANAGED_MARKER in current
            if managed:
                return SessionPlan(SessionAction.REMOVE, self.destination, None, "disabled-managed-present")
            return SessionPlan(SessionAction.NO_CHANGE, self.destination, None, "disabled-absent" if current is None else "disabled-foreign-present")
        if current == expected:
            return SessionPlan(SessionAction.NO_CHANGE, self.destination, expected, "already-current")
        return SessionPlan(SessionAction.INSTALL, self.destination, expected, "missing-or-outdated")

    def apply(self, config: SystemConfig) -> SessionResult:
        plan = self.plan(config)
        try:
            if plan.action is SessionAction.INSTALL:
                self._atomic_write(plan.content or "")
            elif plan.action is SessionAction.REMOVE:
                self.destination.unlink(missing_ok=True)
            changed = plan.action is not SessionAction.NO_CHANGE
            _LOGGER.info("system.session.reconciled", extra={"action": plan.action.value, "changed": changed, "success": True})
            return SessionResult(plan.action, changed, self.destination, True)
        except OSError:
            _LOGGER.warning("system.session.failed", extra={"action": plan.action.value, "changed": False, "success": False, "error_code": "SESSION-IO-001"})
            return SessionResult(plan.action, False, self.destination, False, "SESSION-IO-001")

    def render(self, config: SystemConfig) -> str:
        name = config.dedicated_session_name
        return ("[Desktop Entry]\nType=Application\n"
                f"Name={name}\nComment=Dedicated XAAC thin client session\n"
                f"Exec={self.executable}\nTryExec={self.executable}\n"
                "DesktopNames=XAAC;\nTerminal=false\n"
                f"{self.MANAGED_MARKER}\n")

    def status_values(self, config: SystemConfig) -> tuple[tuple[str, str], ...]:
        plan = self.plan(config)
        return (("Dedicated session configured", str(config.dedicated_session_enabled).lower()),
                ("Dedicated session name", config.dedicated_session_name),
                ("Dedicated session state", plan.reason),
                ("Dedicated session action", plan.action.value))

    def _read_current(self) -> str | None:
        try:
            return self.destination.read_text(encoding="utf-8")
        except (FileNotFoundError, OSError):
            return None

    def _atomic_write(self, content: str) -> None:
        self.destination.parent.mkdir(parents=True, exist_ok=True)
        fd, temporary = tempfile.mkstemp(prefix=".xaac-session-", dir=self.destination.parent, text=True)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                handle.write(content)
                handle.flush()
                os.fsync(handle.fileno())
            os.chmod(temporary, 0o600)
            os.replace(temporary, self.destination)
        finally:
            Path(temporary).unlink(missing_ok=True)

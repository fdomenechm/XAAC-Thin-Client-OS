from __future__ import annotations

from enum import Enum, auto


class ApplicationEvent(Enum):
    """
    Esdeveniments que el controlador pot comunicar a la interfície.
    """

    STATE_CHANGED = auto()

    NETWORK_CHECKING = auto()
    NETWORK_CHANGED = auto()

    DNS_CHECKING = auto()
    DNS_CHANGED = auto()

    RDP_CHECKING = auto()
    RDP_AVAILABILITY_CHANGED = auto()

    SMARTCARD_CHANGED = auto()

    SESSION_CONNECTING = auto()
    SESSION_STARTED = auto()
    SESSION_FINISHED = auto()

    ERROR = auto()
from __future__ import annotations

from dataclasses import dataclass, field

from xaac_thinclient.config.models import (
    ThinClientConfig,
    UserPreferences,
)
from xaac_thinclient.core.runtime import ApplicationRuntime
from xaac_thinclient.config.policy import ConfigurationMetadata
from xaac_thinclient.services.configuration import ConfigService
from xaac_thinclient.services.container import ApplicationServices


@dataclass(frozen=True, slots=True)
class ApplicationContext:
    """Agrupa les dependències principals de l'aplicació.

    El context es construeix en el punt d'entrada i s'injecta al controlador.
    Això manté la creació de dependències fora de la lògica d'orquestració i
    facilita substituir-les per dobles de prova.
    """

    config: ThinClientConfig
    preferences: UserPreferences
    config_service: ConfigService
    services: ApplicationServices
    runtime: ApplicationRuntime
    configuration_metadata: ConfigurationMetadata = field(
        default_factory=ConfigurationMetadata.system_defaults
    )

    @classmethod
    def create(
        cls,
        *,
        config: ThinClientConfig,
        preferences: UserPreferences,
        config_service: ConfigService,
        services: ApplicationServices | None = None,
        runtime: ApplicationRuntime | None = None,
        configuration_metadata: ConfigurationMetadata | None = None,
    ) -> ApplicationContext:
        """Crea un context complet, amb dependències per defecte si cal."""
        return cls(
            config=config,
            preferences=preferences,
            config_service=config_service,
            services=(
                services
                if services is not None
                else ApplicationServices.create_default()
            ),
            runtime=(
                runtime
                if runtime is not None
                else ApplicationRuntime.create_default()
            ),
            configuration_metadata=(
                configuration_metadata
                if configuration_metadata is not None
                else ConfigurationMetadata.system_defaults()
            ),
        )

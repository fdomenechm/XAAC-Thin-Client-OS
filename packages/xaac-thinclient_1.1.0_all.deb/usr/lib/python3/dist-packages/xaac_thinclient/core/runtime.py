from __future__ import annotations

from concurrent.futures import Executor, ThreadPoolExecutor
from dataclasses import dataclass
from typing import Callable

from gi.repository import GLib


TimerCallback = Callable[[], bool]


@dataclass(frozen=True, slots=True)
class ApplicationRuntime:
    """Agrupa els recursos d'execució de l'aplicació.

    El controlador rep els executors i les operacions de temporització ja
    construïts. Això evita que haja de decidir com es creen i facilita la
    injecció de dobles de prova.
    """

    service_executor: Executor
    rdp_executor: Executor
    timeout_add_seconds: Callable[[int, TimerCallback], int]
    source_remove: Callable[[int], bool]

    @classmethod
    def create_default(cls) -> ApplicationRuntime:
        """Crea els recursos utilitzats en producció."""
        return cls(
            service_executor=ThreadPoolExecutor(
                max_workers=2,
                thread_name_prefix="xaac-services",
            ),
            rdp_executor=ThreadPoolExecutor(
                max_workers=1,
                thread_name_prefix="xaac-rdp",
            ),
            timeout_add_seconds=GLib.timeout_add_seconds,
            source_remove=GLib.source_remove,
        )

    def shutdown(self) -> None:
        """Tanca els executors propietat del runtime."""
        self.service_executor.shutdown(
            wait=False,
            cancel_futures=True,
        )
        self.rdp_executor.shutdown(
            wait=False,
            cancel_futures=True,
        )

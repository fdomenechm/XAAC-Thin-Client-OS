from __future__ import annotations

import subprocess
from dataclasses import replace
from pathlib import Path
from collections.abc import Callable
from concurrent.futures import Future
from threading import RLock

from gi.repository import GLib

from xaac_thinclient.config.models import UserPreferences
from xaac_thinclient.core.context import ApplicationContext
from xaac_thinclient.core.errors import ApplicationErrors, ErrorCategory
from xaac_thinclient.core.events import ApplicationEvent
from xaac_thinclient.core.state import (
    ApplicationPhase,
    ApplicationState,
)
from xaac_thinclient.services.diagnostics import DiagnosticReport
from xaac_thinclient.services.dns import (
    DnsStatus,
)
from xaac_thinclient.services.logging import get_logger
from xaac_thinclient.i18n import _
from xaac_thinclient.rdp.exit_codes import is_normal_session_exit
from xaac_thinclient.system.power import PowerAction, PowerResult
from xaac_thinclient.services.monitors import (
    connected_monitor_count,
)
from xaac_thinclient.services.network import (
    NetworkStatus,
)
from xaac_thinclient.services.smartcard import SmartCardStatus
from xaac_thinclient.services.rdp import (
    RdpAvailability,
    RdpSessionResult,
)


logger = get_logger(__name__)

EventCallback = Callable[
    [ApplicationEvent, ApplicationState],
    None,
]
# NOTE:
# SESSION_STARTED s'emet únicament quan FreeRDP ha superat la fase de
# postconnexió gràfica. Crear el procés xfreerdp no és suficient per donar
# la sessió per establida.

class ApplicationController:
    """
    Coordina l'estat, els serveis i les sessions RDP
    de l'aplicació.

    El controlador és propietari dels serveis, els executors,
    els temporitzadors i les transicions d'estat.
    """

    def __init__(
        self,
        context: ApplicationContext,
    ) -> None:
        self.context = context

        self.config = context.config
        self.preferences = context.preferences
        self.config_service = context.config_service
        self.services = context.services
        self.runtime = context.runtime
        self.configuration_metadata = context.configuration_metadata

        self.network_service = self.services.network
        self.dns_service = self.services.dns
        self.remote_desktop_backend = self.services.remote_desktop
        # Àlies temporal per mantindre compatibilitat interna.
        self.rdp_service = self.remote_desktop_backend
        self.diagnostic_service = self.services.diagnostics
        self.smartcard_service = self.services.smartcard
        self.power_service = self.services.power

        self.state = ApplicationState(
            phase=ApplicationPhase.STARTING,
            smartcard_enabled=self.config.smartcard.enabled,
            smartcard_required=self.config.smartcard.required,
            smartcard_ready=not self.config.smartcard.required,
            status_message=_("Starting services…"),
        )

        self._closed = False

        self._event_callbacks: list[EventCallback] = []
        self._event_lock = RLock()

        self._network_check_running = False
        self._network_timer_id: int | None = None
        self._smartcard_timer_id: int | None = None
        self._smartcard_check_running = False
        self._last_smartcard_result: tuple[object, ...] | None = None

        self._dns_check_running = False
        self._rdp_check_running = False
        # Generació comuna de les comprovacions de salut (xarxa/DNS/RDP).
        # S'incrementa quan comença una connexió perquè cap resultat que
        # haguera quedat en vol abans de l'intent puga sobreescriure l'estat
        # de la sessió quan aquesta falle ràpidament (p. ex. contrasenya
        # incorrecta).
        self._health_check_generation = 0
        self._server_selection_generation = 0
        self._selected_server_id = self.config.default_server_id

        # Després d'un intent de sessió iniciat des d'un servidor que ja
        # havia superat la comprovació RDP, una fallada recuperable (per
        # exemple, credencials incorrectes) no ha de permetre que una
        # comprovació TCP periòdica posterior bloquege el formulari. En eixe
        # mode les comprovacions continuen sent útils per al diagnòstic, però
        # no són autoritatives sobre l'estat visible de la sessió.
        self._rdp_retry_mode = False

        # Últims resultats reals de les comprovacions.
        # S'utilitzen per evitar actualitzacions i logs repetits.
        self._last_network_result: (
                tuple[bool, str | None, str | None, str | None]
                | None
        ) = None

        self._last_dns_result: (
                tuple[bool, tuple[str, ...], str | None]
                | None
        ) = None

        self._last_rdp_result: (
                tuple[bool, str | None]
                | None
        ) = None



    def _update_state(
            self,
            *,
            event: ApplicationEvent = ApplicationEvent.STATE_CHANGED,
            **changes: object,
    ) -> ApplicationState:
        self.state = self.state.updated(**changes)
        self._emit(event)
        return self.state

    @property
    def selected_server_id(self) -> str:
        return self._selected_server_id

    @property
    def available_servers(self):
        return self.config.servers

    def select_server(self, server_id: str) -> bool:
        server = next((item for item in self.config.servers if item.server_id == server_id and item.enabled), None)
        if server is None:
            logger.warning("Servidor seleccionat desconegut o deshabilitat: %s", server_id)
            return False
        if server_id == self._selected_server_id and self.config.device.server == server.host:
            return True

        self._selected_server_id = server_id
        self._server_selection_generation += 1
        self._rdp_retry_mode = False
        self._dns_check_running = False
        self._rdp_check_running = False
        self._last_dns_result = None
        self._last_rdp_result = None
        self.config = replace(
            self.config,
            device=replace(self.config.device, server=server.host),
            rdp=replace(self.config.rdp, port=server.port, domain=server.domain or self.config.rdp.domain),
        )
        logger.info("Servidor RDP seleccionat: id=%s host=%s port=%s", server.server_id, server.host, server.port)
        self._update_state(
            event=ApplicationEvent.STATE_CHANGED,
            dns_resolved=False, resolved_addresses=(), dns_error=None,
            rdp_available=False, rdp_error=None,
            status_message=_("Resolving server…"), error_message=None, current_error=None,
        )
        if self.state.network_connected:
            self._schedule_dns_check()
        return True

    def create_diagnostic_report(self) -> DiagnosticReport:
        """Construeix un informe per mostrar-lo sense desar-lo encara."""
        return self.diagnostic_service.generate(
            config=self.config,
            state=self.state,
            configuration_metadata=self.configuration_metadata,
        )

    def generate_diagnostic_report(
        self,
        destination: Path | None = None,
    ) -> Path:
        """Genera i desa un informe de diagnòstic segur per a suport."""
        report_path = self.diagnostic_service.generate_and_save(
            config=self.config,
            state=self.state,
            configuration_metadata=self.configuration_metadata,
            destination=destination,
        )
        logger.info(
            "Informe de diagnòstic generat: %s",
            report_path,
        )
        return report_path

    def save_user_preferences(
        self,
        username: str,
        remember_username: bool,
    ) -> None:
        preferences = UserPreferences(
            username=username,
            remember_username=remember_username,
        )

        self.config_service.save_user_preferences(preferences)
        self.preferences = preferences

    @staticmethod
    def get_monitor_count() -> int:
        try:
            return connected_monitor_count()
        except (OSError, subprocess.SubprocessError):
            return 1


    def request_poweroff(self) -> PowerResult:
        """Sol·licita un apagat controlat segons la política quiosc efectiva."""
        result = self.power_service.execute(self._resolve_kiosk_policy(), PowerAction.POWEROFF)
        if result.succeeded:
            logger.info("Apagat del terminal sol·licitat correctament")
        else:
            logger.warning(
                "No s'ha pogut sol·licitar l'apagat del terminal: %s",
                result.status_code,
            )
        return result

    def _resolve_kiosk_policy(self):
        from xaac_thinclient.system.kiosk import KioskPolicyService
        return KioskPolicyService().resolve(self.config.system)

    def disconnect_rdp(self) -> None:
        if not self.state.rdp_session_running:
            return

        logger.info(
            "Sol·licitant el tancament de la sessió RDP"
        )

        self.remote_desktop_backend.disconnect()

    def shutdown(self) -> None:
        logger.info(
            "Tancant el controlador de l'aplicació"
        )
        if self._closed:
            return

        self._closed = True

        self._update_state(
            phase=ApplicationPhase.STOPPING,
            status_message=_("Closing…"),
        )

        self.remote_desktop_backend.disconnect()

        if self._network_timer_id is not None:
            self.runtime.source_remove(self._network_timer_id)
            self._network_timer_id = None

        if self._smartcard_timer_id is not None:
            self.runtime.source_remove(self._smartcard_timer_id)
            self._smartcard_timer_id = None

        self.runtime.shutdown()
        logger.info(
            "Controlador tancat correctament"
        )

    def subscribe(
            self,
            callback: EventCallback,
    ) -> None:
        """
        Registra una funció que rebrà els esdeveniments
        generats pel controlador.
        """
        with self._event_lock:
            if callback not in self._event_callbacks:
                self._event_callbacks.append(callback)

    def unsubscribe(
            self,
            callback: EventCallback,
    ) -> None:
        """
        Elimina una subscripció existent.
        """
        with self._event_lock:
            try:
                self._event_callbacks.remove(callback)
            except ValueError:
                pass

    def _emit(
            self,
            event: ApplicationEvent,
    ) -> None:
        """
        Envia l'esdeveniment a totes les funcions subscrites.

        Es copia la llista per evitar problemes si una subscripció
        s'elimina mentre s'està emetent l'esdeveniment.
        """
        with self._event_lock:
            callbacks = tuple(self._event_callbacks)

        for callback in callbacks:
            try:
                callback(event, self.state)
            except Exception:
                logger.exception(
                    "Error en executar un callback "
                    "de l'esdeveniment %s",
                    event.name,
                )

    def start(self) -> None:
        """
        Inicia els serveis periòdics del controlador.
        """
        if self._closed:
            return

        logger.info("Iniciant monitorització de xarxa")
        self._start_network_monitoring()
        self._start_smartcard_monitoring()

    def _start_smartcard_monitoring(self) -> None:
        if not self.config.smartcard.enabled:
            return

        self._schedule_smartcard_check()
        retry_interval = max(1, int(self.config.network.retry_interval))
        self._smartcard_timer_id = self.runtime.timeout_add_seconds(
            retry_interval,
            self._schedule_smartcard_check,
        )

    def _schedule_smartcard_check(self) -> bool:
        if self._closed:
            return False
        if self.state.rdp_session_running or self._smartcard_check_running:
            return True
        if not self.config.smartcard.enabled:
            return False

        self._smartcard_check_running = True
        future = self.runtime.service_executor.submit(
            self.smartcard_service.get_status,
            enabled=True,
            required=self.config.smartcard.required,
            preferred_reader=self.config.smartcard.preferred_reader,
        )
        future.add_done_callback(self._on_smartcard_check_finished)
        return True

    def _on_smartcard_check_finished(
        self,
        future: Future[SmartCardStatus],
    ) -> None:
        try:
            status = future.result()
        except Exception as error:
            logger.exception("Error inesperat en comprovar Smart Card")
            status = SmartCardStatus(
                enabled=True,
                pcsc_available=False,
                pcscd_running=False,
                required=self.config.smartcard.required,
                preferred_reader=self.config.smartcard.preferred_reader,
                error=str(error),
            )
        if not self._closed:
            GLib.idle_add(self._apply_smartcard_status, status)

    def _apply_smartcard_status(self, status: SmartCardStatus) -> bool:
        self._smartcard_check_running = False
        if self._closed:
            return False

        current = (
            status.pcsc_available,
            status.pcscd_running,
            status.reader_count,
            status.card_present,
            status.status_code.value,
            status.error,
        )
        if current == self._last_smartcard_result:
            return False
        previous_status = (
            self._last_smartcard_result[4]
            if self._last_smartcard_result is not None
            else "unknown"
        )
        self._last_smartcard_result = current
        self._audit_smartcard_transition(previous_status, status)

        ready = status.ready
        required_error = status.required_error()
        error_message = _(required_error) if required_error else status.error

        application_error = (
            ApplicationErrors.smartcard_unavailable(error_message)
            if required_error is not None
            else None
        )
        current_error = application_error
        if current_error is None and (
            self.state.current_error is not None
            and self.state.current_error.category is not ErrorCategory.SMARTCARD
        ):
            current_error = self.state.current_error

        self._update_state(
            event=ApplicationEvent.SMARTCARD_CHANGED,
            smartcard_enabled=True,
            smartcard_required=self.config.smartcard.required,
            smartcard_ready=ready,
            smartcard_pcsc_available=status.pcsc_available,
            smartcard_pcscd_running=status.pcscd_running,
            smartcard_reader_count=status.reader_count,
            smartcard_detected_reader_count=status.detected_reader_count,
            smartcard_eligible_reader_count=status.eligible_reader_count,
            smartcard_reader_mode=status.reader_mode.value,
            smartcard_preferred_reader_matched=status.preferred_reader_matched,
            smartcard_readers=status.reader_names,
            smartcard_readers_with_card=status.readers_with_card,
            smartcard_card_present=status.card_present,
            smartcard_policy_mode=status.policy_mode.value,
            smartcard_effective_requirements=status.effective_requirements,
            smartcard_status_code=status.status_code.value,
            smartcard_status_detail=status.status_detail,
            smartcard_error=error_message,
            current_error=current_error,
        )
        return False

    @staticmethod
    def _audit_smartcard_transition(
        previous_status: str,
        status: SmartCardStatus,
    ) -> None:
        fields = " ".join(
            f"{key}={value}" for key, value in status.audit_fields
        )
        logger.info(
            "smartcard_state_changed previous=%s %s",
            previous_status,
            fields,
        )

    def _start_network_monitoring(self) -> None:
        """
        Executa una comprovació immediata i programa
        les comprovacions periòdiques.
        """
        self._schedule_network_check()

        retry_interval = max(
            1,
            int(self.config.network.retry_interval),
        )

        self._network_timer_id = self.runtime.timeout_add_seconds(
            retry_interval,
            self._schedule_network_check,
        )

    def _schedule_network_check(self) -> bool:
        """
        Envia la consulta de xarxa a l'executor.

        Retorna True perquè el temporitzador GLib continue actiu.
        """
        if self._closed:
            return False

        if self.state.rdp_session_running:
            return True

        if self._network_check_running:
            return True

        self._network_check_running = True

        # La comprovació periòdica es fa en segon pla.
        # Conservem l'últim estat visible per evitar
        # un refresc innecessari de la interfície.
        future = self.runtime.service_executor.submit(
            self.network_service.get_status
        )

        generation = self._health_check_generation
        future.add_done_callback(
            lambda completed, generation=generation: self._on_network_check_finished(
                completed, generation
            )
        )

        return True

    def _on_network_check_finished(
            self,
            future: Future[NetworkStatus],
            generation: int | None = None,
    ) -> None:
        try:
            status = future.result()
        except Exception as error:
            logger.exception(
                "Error inesperat en comprovar la xarxa"
            )

            status = NetworkStatus(
                connected=False,
                error=str(error),
            )

        if self._closed or (
                generation is not None
                and generation != self._health_check_generation
        ):
            return

        GLib.idle_add(
            self._apply_network_status,
            status,
            generation,
        )

    def _apply_network_status(
            self,
            status: NetworkStatus,
            generation: int | None = None,
    ) -> bool:
        if (
                self._closed
                or (
                    generation is not None
                    and generation != self._health_check_generation
                )
        ):
            return False

        self._network_check_running = False

        # Una comprovació de xarxa iniciada abans de connectar pot acabar
        # després que la sessió RDP ja haja començat. En eixe cas el resultat
        # és obsolet per a la màquina d'estats de la sessió i no ha de
        # substituir CONNECTING/CONNECTED per READY o ERROR.
        if self.state.rdp_session_running:
            return False

        logger.debug(
            "Estat de xarxa: connected=%s, "
            "interface=%s, ip=%s, error=%s",
            status.connected,
            status.interface,
            status.ip_address,
            status.error,
        )

        application_error = None
        error_message = None
        if not status.connected:
            application_error = ApplicationErrors.network_unavailable(
                status.error,
            )
            error_message = application_error.user_message

        current_result = (
            status.connected,
            status.interface,
            status.ip_address,
            error_message,
        )

        network_changed = (
                current_result != self._last_network_result
        )

        if not network_changed:
            # La xarxa continua igual, però mantenim
            # la cadena periòdica DNS → RDP.
            if status.connected:
                self._schedule_dns_check()

            return False

        self._last_network_result = current_result

        if status.connected:
            # Un canvi real de xarxa invalida qualsevol excepció temporal de
            # reintent creada per una sessió anterior. La nova cadena
            # xarxa → DNS → RDP tornarà a establir l'estat autoritatiu.
            self._rdp_retry_mode = False
            self._update_state(
                event=ApplicationEvent.NETWORK_CHANGED,
                phase=ApplicationPhase.READY,
                network_connected=True,
                network_interface=status.interface,
                local_ip=status.ip_address,
                network_error=None,
                status_message=_("Ready"),
                error_message=None,
                current_error=None,
            )

            self._schedule_dns_check()

        else:
            self._rdp_retry_mode = False
            self._last_dns_result = None
            self._last_rdp_result = None

            self._update_state(
                event=ApplicationEvent.NETWORK_CHANGED,
                phase=ApplicationPhase.ERROR,
                network_connected=False,
                network_interface=None,
                local_ip=None,
                network_error=error_message,
                dns_resolved=False,
                resolved_addresses=(),
                dns_error=None,
                rdp_available=False,
                rdp_error=None,
                status_message=_("No network"),
                error_message=error_message,
                current_error=application_error,
            )


        return False

    def _schedule_dns_check(self) -> bool:
        """
        Executa la resolució DNS en un fil secundari.
        """
        if self._closed:
            return False

        if self.state.rdp_session_running:
            return True

        if self._dns_check_running:
            return True

        if not self.state.network_connected:
            return True

        self._dns_check_running = True

        # Conservem els últims estats DNS i RDP visibles
        # mentre es repeteix la comprovació en segon pla.
        future = self.runtime.service_executor.submit(
            self.dns_service.resolve,
            self.config.device.server,
        )

        server_generation = self._server_selection_generation
        health_generation = self._health_check_generation
        future.add_done_callback(
            lambda completed, server_generation=server_generation, health_generation=health_generation:
                self._on_dns_check_finished(
                    completed, server_generation, health_generation
                )
        )

        return True

    def _on_dns_check_finished(
            self,
            future: Future[DnsStatus],
            server_generation: int | None = None,
            health_generation: int | None = None,
    ) -> None:
        try:
            status = future.result()

        except Exception as error:
            logger.exception(
                "Error inesperat durant la consulta DNS"
            )

            status = DnsStatus(
                resolved=False,
                hostname=self.config.device.server,
                error=str(error),
            )

        if (
                self._closed
                or (
                    server_generation is not None
                    and server_generation != self._server_selection_generation
                )
                or (
                    health_generation is not None
                    and health_generation != self._health_check_generation
                )
        ):
            return

        GLib.idle_add(
            self._apply_dns_status,
            status,
            server_generation,
            health_generation,
        )

    def _apply_dns_status(
            self,
            status: DnsStatus,
            server_generation: int | None = None,
            health_generation: int | None = None,
    ) -> bool:
        if (
                self._closed
                or (
                    server_generation is not None
                    and server_generation != self._server_selection_generation
                )
                or (
                    health_generation is not None
                    and health_generation != self._health_check_generation
                )
        ):
            return False

        self._dns_check_running = False

        # Evitem que una resolució DNS iniciada abans de la connexió
        # sobreescriga l'estat de la sessió RDP mentre aquesta està activa.
        if self.state.rdp_session_running:
            return False

        addresses = tuple(status.addresses)

        application_error = None
        error_message = None
        if not status.resolved:
            application_error = ApplicationErrors.dns_resolution_failed(
                status.error,
            )
            error_message = application_error.user_message

        current_result = (
            status.resolved,
            addresses,
            error_message,
        )

        dns_changed = (
                current_result != self._last_dns_result
        )

        if dns_changed:
            if status.resolved:
                logger.info(
                    "Servidor resolt: servidor=%s, adreces=%s",
                    status.hostname,
                    ", ".join(addresses),
                )
            else:
                logger.warning(
                    "No s'ha pogut resoldre el servidor %s: %s",
                    status.hostname,
                    error_message,
                )

            self._last_dns_result = current_result

        else:
            logger.debug(
                "Estat DNS sense canvis: servidor=%s, "
                "resolt=%s, adreces=%s",
                status.hostname,
                status.resolved,
                ", ".join(addresses),
            )

        if not dns_changed:
            # No actualitzem la GUI si el resultat DNS
            # és exactament igual, però continuem la
            # comprovació del servei RDP.
            if status.resolved:
                self._schedule_rdp_check()

            return False

        if status.resolved:
            # Si el resultat DNS ha canviat (només arribem ací quan
            # dns_changed és True), tornem al flux normal de validació RDP.
            self._rdp_retry_mode = False
            self._update_state(
                event=ApplicationEvent.DNS_CHANGED,
                phase=ApplicationPhase.READY,
                dns_resolved=True,
                resolved_addresses=addresses,
                dns_error=None,
                rdp_available=False,
                rdp_error=None,
                status_message=_("Server resolved"),
                error_message=None,
                current_error=None,
            )

            self._schedule_rdp_check()

        else:
            self._rdp_retry_mode = False
            self._update_state(
                event=ApplicationEvent.DNS_CHANGED,
                phase=ApplicationPhase.ERROR,
                dns_resolved=False,
                resolved_addresses=(),
                dns_error=error_message,
                rdp_available=False,
                rdp_error=None,
                status_message=_("Server not resolved"),
                error_message=error_message,
                current_error=application_error,
            )

        return False
    def _schedule_rdp_check(self) -> bool:
        """
        Comprova en un fil secundari si el port RDP
        configurat està disponible.
        """
        if self._closed:
            return False

        if self.state.rdp_session_running:
            return True

        if self._rdp_check_running:
            return True

        if not self.state.network_connected:
            return True

        if not self.state.dns_resolved:
            return True

        self._rdp_check_running = True

        # Conservem l'últim estat RDP visible mentre
        # repetim la comprovació en segon pla.
        future = self.runtime.service_executor.submit(
            self.remote_desktop_backend.check_availability,
            self.config.device.server,
            self.config.rdp.port,
            self.config.network.connect_timeout,
        )

        server_generation = self._server_selection_generation
        health_generation = self._health_check_generation
        future.add_done_callback(
            lambda completed, server_generation=server_generation, health_generation=health_generation:
                self._on_rdp_check_finished(
                    completed, server_generation, health_generation
                )
        )

        return True

    def _on_rdp_check_finished(
            self,
            future: Future[RdpAvailability],
            server_generation: int | None = None,
            health_generation: int | None = None,
    ) -> None:
        try:
            status = future.result()

        except Exception as error:
            logger.exception(
                "Error inesperat en comprovar el servei RDP"
            )

            status = RdpAvailability(
                available=False,
                server=self.config.device.server,
                port=self.config.rdp.port,
                error=str(error),
            )

        if (
                self._closed
                or (
                    server_generation is not None
                    and server_generation != self._server_selection_generation
                )
                or (
                    health_generation is not None
                    and health_generation != self._health_check_generation
                )
        ):
            return

        GLib.idle_add(
            self._apply_rdp_status,
            status,
            server_generation,
            health_generation,
        )

    def _apply_rdp_status(
            self,
            status: RdpAvailability,
            server_generation: int | None = None,
            health_generation: int | None = None,
    ) -> bool:
        if (
                self._closed
                or (
                    server_generation is not None
                    and server_generation != self._server_selection_generation
                )
                or (
                    health_generation is not None
                    and health_generation != self._health_check_generation
                )
        ):
            return False

        self._rdp_check_running = False

        # Una comprovació RDP que ja estava en vol quan l'usuari prem
        # Connectar pot finalitzar després. No permetem que eixe callback
        # restaure READY/ERROR mentre CONNECTING o CONNECTED són propietaris
        # de l'estat visible de la sessió.
        if self.state.rdp_session_running:
            return False

        application_error = None
        error_message = None
        if not status.available:
            application_error = ApplicationErrors.rdp_unavailable(
                status.error,
            )
            error_message = application_error.user_message

        current_result = (
            status.available,
            error_message,
        )

        # Després d'una fallada recuperable d'una sessió que s'havia iniciat
        # des d'un endpoint RDP validat, la disponibilitat TCP periòdica és
        # només informativa. Sobretot després d'un error NLA/credencials,
        # Windows/FreeRDP pot produir un fals negatiu breu al sondeig del port.
        # No deixem que eixe resultat substituïsca l'error de sessió ni que
        # desactive Connectar. La xarxa i el DNS continuen sent autoritatius i
        # cancel·len aquest mode si realment desapareixen.
        if self._rdp_retry_mode:
            if current_result != self._last_rdp_result:
                if status.available:
                    logger.debug(
                        "Comprovació RDP disponible durant mode de reintent: "
                        "servidor=%s, port=%s",
                        status.server,
                        status.port,
                    )
                else:
                    logger.warning(
                        "Comprovació RDP no disponible ignorada durant mode "
                        "de reintent: servidor=%s, port=%s, error=%s",
                        status.server,
                        status.port,
                        error_message,
                    )
                self._last_rdp_result = current_result
            return False

        rdp_changed = (
                current_result != self._last_rdp_result
        )

        if rdp_changed:
            if status.available:
                if self._last_rdp_result is None:
                    logger.info(
                        "Servei RDP disponible: "
                        "servidor=%s, port=%s",
                        status.server,
                        status.port,
                    )
                else:
                    logger.info(
                        "Servei RDP disponible de nou: "
                        "servidor=%s, port=%s",
                        status.server,
                        status.port,
                    )
            else:
                logger.warning(
                    "Servei RDP no disponible: servidor=%s, "
                    "port=%s, error=%s",
                    status.server,
                    status.port,
                    error_message,
                )

            self._last_rdp_result = current_result

        else:
            logger.debug(
                "Estat RDP sense canvis: servidor=%s, "
                "port=%s, disponible=%s",
                status.server,
                status.port,
                status.available,
            )

        if not rdp_changed:
            # El resultat és idèntic: no tornem
            # a notificar ni a redibuixar la GUI.
            return False

        if status.available:
            self._update_state(
                event=ApplicationEvent.RDP_AVAILABILITY_CHANGED,
                phase=ApplicationPhase.READY,
                rdp_available=True,
                rdp_error=None,
                status_message=_("Ready"),
                error_message=None,
                current_error=None,
            )

        else:
            # El sondeig TCP del port RDP és deliberadament informatiu.
            # Un timeout/refused puntual no prova que FreeRDP no puga
            # establir la sessió (i en alguns entorns produeix falsos
            # negatius). Conservem el resultat per a diagnòstic, però no
            # convertim l'aplicació en ERROR ni bloquegem Connectar.
            self._update_state(
                event=ApplicationEvent.RDP_AVAILABILITY_CHANGED,
                phase=ApplicationPhase.READY,
                rdp_available=False,
                rdp_error=error_message,
                status_message=_("Ready"),
                error_message=None,
                current_error=None,
            )

        return False

    def connect_rdp(
            self,
            username: str,
            password: str,
    ) -> bool:
        """
        Inicia una sessió RDP en un fil secundari.

        La contrasenya no es guarda en ApplicationState,
        en configuració ni en els logs.
        """
        if self._closed:
            return False

        username = username.strip()

        if not username or not password:
            application_error = ApplicationErrors.incomplete_credentials()
            self._update_state(
                event=ApplicationEvent.ERROR,
                phase=ApplicationPhase.ERROR,
                status_message=_("Incomplete credentials"),
                error_message=application_error.user_message,
                session_error=application_error.user_message,
                current_error=application_error,
            )
            return False

        try:
            self.services.freerdp_capabilities.audit_configuration(self.config)
        except Exception as error:
            # L'auditoria mai ha d'impedir una connexió ni exposar detalls locals.
            logger.warning(
                "freerdp_compatibility_audit_failed error_type=%s",
                type(error).__name__,
            )

        if not self.state.can_connect:
            application_error = ApplicationErrors.connection_not_ready()
            error_message = application_error.user_message

            self._update_state(
                event=ApplicationEvent.ERROR,
                phase=ApplicationPhase.ERROR,
                status_message=_("Cannot connect"),
                error_message=error_message,
                session_error=error_message,
                current_error=application_error,
            )
            return False

        monitor_count = self.get_monitor_count()

        # Qualsevol comprovació de salut iniciada abans d'aquest clic deixa
        # de ser autoritativa. Si una contrasenya incorrecta fa fallar
        # FreeRDP molt ràpid, un callback antic no ha de poder convertir el
        # servidor en "RDP no disponible" i bloquejar el reintent.
        self._health_check_generation += 1
        self._network_check_running = False
        self._dns_check_running = False
        self._rdp_check_running = False

        logger.info(
            "Sol·licitada sessió RDP: servidor=%s, "
            "monitors=%s",
            self.config.device.server,
            monitor_count,
        )

        self._update_state(
            event=ApplicationEvent.SESSION_CONNECTING,
            phase=ApplicationPhase.CONNECTING,
            rdp_session_running=True,
            session_return_code=None,
            session_error=None,
            status_message=_("Connecting to {server}…").format(
                server=self.config.device.server,
            ),
            error_message=None,
            current_error=None,
        )

        future = self.runtime.rdp_executor.submit(
            self.remote_desktop_backend.connect,
            self.config,
            username,
            password,
            monitor_count,
            self._on_rdp_process_started,
        )

        future.add_done_callback(
            self._on_rdp_session_finished
        )

        return True

    def _on_rdp_process_started(self) -> None:
        """
        El backend RDP crida aquest mètode des del fil secundari quan
        FreeRDP ha superat la fase de postconnexió gràfica. Traslladem el
        canvi al fil principal.
        """

        if self._closed:
            return

        GLib.idle_add(
            self._apply_rdp_session_started
        )

    def _apply_rdp_session_started(self) -> bool:
        if self._closed:
            return False

        # El procés pot haver finalitzat abans que GTK processe
        # aquest callback. En aquest cas, l'esdeveniment d'inici
        # ja és obsolet i no s'ha d'aplicar.
        if (
                self.state.phase != ApplicationPhase.CONNECTING
                or not self.state.rdp_session_running
        ):
            logger.debug(
                "Ignorant inici RDP obsolet: phase=%s, running=%s",
                self.state.phase.name,
                self.state.rdp_session_running,
            )
            return False

        logger.info(
            "Sessió RDP establida amb %s",
            self.config.device.server,
        )

        self._update_state(
            event=ApplicationEvent.SESSION_STARTED,
            phase=ApplicationPhase.CONNECTED,
            rdp_session_running=True,
            session_return_code=None,
            session_error=None,
            status_message=_("Remote session active"),
            error_message=None,
            current_error=None,
        )
        self._rdp_retry_mode = False

        return False

    def _on_rdp_session_finished(
            self,
            future: Future[RdpSessionResult],
    ) -> None:
        try:
            result = future.result()

        except Exception as error:
            logger.exception(
                "Error inesperat durant la sessió RDP"
            )

            result = RdpSessionResult(
                started=False,
                error=str(error),
            )

        if self._closed:
            return

        GLib.idle_add(
            self._apply_rdp_session_result,
            result,
        )

    def _apply_rdp_session_result(
            self,
            result: RdpSessionResult,
    ) -> bool:
        if self._closed:
            return False

        if not result.started:
            # L'intent només podia haver començat si l'endpoint RDP estava
            # disponible en el moment del clic. Una fallada de sessió
            # recuperable (inclosa una contrasenya incorrecta) ha de permetre
            # corregir les credencials i reintentar indefinidament sense que
            # el sondeig TCP periòdic puga bloquejar de nou el formulari.
            self._rdp_retry_mode = bool(self.state.rdp_available)

            if result.error_code == "PRINTER-001":
                application_error = (
                    ApplicationErrors.printer_redirection_required(
                        result.error,
                    )
                )
            elif result.error_code == "AUDIO-001":
                application_error = ApplicationErrors.audio_playback_required(
                    result.error,
                )
            elif result.error_code == "MICROPHONE-001":
                application_error = ApplicationErrors.microphone_required(
                    result.error,
                )
            elif result.error_code == "VIDEO-001":
                application_error = ApplicationErrors.video_required(
                    result.error,
                )
            elif result.error_code == "VIDEO-002":
                application_error = (
                    ApplicationErrors.video_capability_unavailable(
                        result.error,
                    )
                )
            else:
                application_error = ApplicationErrors.session_start_failed(
                    result.error,
                )
            error_message = application_error.user_message

            logger.error(
                "La sessió RDP no s'ha iniciat [%s]: %s",
                application_error.code,
                result.error or error_message,
            )

            self._update_state(
                event=ApplicationEvent.ERROR,
                phase=ApplicationPhase.ERROR,
                rdp_session_running=False,
                session_return_code=result.return_code,
                session_error=error_message,
                status_message=_("Connection error"),
                error_message=error_message,
                current_error=application_error,
            )

        elif result.cancelled:
            logger.info(
                "Sessió RDP cancel·lada"
            )

            self._update_state(
                event=ApplicationEvent.SESSION_FINISHED,
                phase=ApplicationPhase.READY,
                rdp_session_running=False,
                session_return_code=result.return_code,
                session_error=None,
                status_message=_("Session cancelled"),
                error_message=None,
                current_error=None,
            )

        elif is_normal_session_exit(result.return_code):
            logger.info(
                "Sessió RDP tancada correctament amb codi %s",
                result.return_code,
            )

            self._update_state(
                event=ApplicationEvent.SESSION_FINISHED,
                phase=ApplicationPhase.READY,
                rdp_session_running=False,
                session_return_code=result.return_code,
                session_error=None,
                status_message=(
                    _("The remote session was closed successfully.")
                ),
                error_message=None,
                current_error=None,
            )

        else:
            application_error = ApplicationErrors.session_interrupted(
                result.return_code,
            )
            error_message = application_error.user_message

            logger.warning(error_message)

            self._update_state(
                event=ApplicationEvent.SESSION_FINISHED,
                phase=ApplicationPhase.ERROR,
                rdp_session_running=False,
                session_return_code=result.return_code,
                session_error=error_message,
                status_message=error_message,
                error_message=error_message,
                current_error=application_error,
            )

        # Només refem immediatament la cadena de salut després d'una sessió
        # que realment s'havia establit. Un error d'arrancada/autenticació no
        # és una evidència que el servidor RDP haja deixat d'estar disponible
        # i una comprovació TCP immediata pot produir falsos negatius que
        # impedirien corregir la contrasenya i reintentar. Les comprovacions
        # periòdiques continuen actives i tornaran a validar la disponibilitat.
        if result.started or result.connection_established:
            self._schedule_network_check()

        return False



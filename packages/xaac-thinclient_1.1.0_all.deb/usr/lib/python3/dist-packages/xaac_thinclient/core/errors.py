from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto

from xaac_thinclient.i18n import _


class ErrorCategory(Enum):
    """Àrea funcional on s'ha produït l'error."""

    NETWORK = auto()
    DNS = auto()
    RDP_AVAILABILITY = auto()
    CREDENTIALS = auto()
    SESSION = auto()
    SMARTCARD = auto()
    PRINTERS = auto()
    AUDIO = auto()
    VIDEO = auto()
    INTERNAL = auto()


class ErrorSeverity(Enum):
    """Impacte de l'error sobre el funcionament de l'aplicació."""

    WARNING = auto()
    ERROR = auto()
    CRITICAL = auto()


@dataclass(frozen=True, slots=True)
class ApplicationError:
    """Error estructurat que pot consumir la GUI o un diagnòstic."""

    code: str
    category: ErrorCategory
    severity: ErrorSeverity
    recoverable: bool
    user_message: str
    technical_detail: str | None = None


class ApplicationErrors:
    """Fàbrica centralitzada dels errors coneguts de l'aplicació."""

    @staticmethod
    def network_unavailable(detail: str | None = None) -> ApplicationError:
        return ApplicationError(
            code="NET-001",
            category=ErrorCategory.NETWORK,
            severity=ErrorSeverity.WARNING,
            recoverable=True,
            user_message=(
                detail
                or _("No active IPv4 interface is available.")
            ),
            technical_detail=detail,
        )

    @staticmethod
    def dns_resolution_failed(detail: str | None = None) -> ApplicationError:
        return ApplicationError(
            code="DNS-001",
            category=ErrorCategory.DNS,
            severity=ErrorSeverity.WARNING,
            recoverable=True,
            user_message=(
                detail
                or _("The server could not be resolved.")
            ),
            technical_detail=detail,
        )

    @staticmethod
    def rdp_unavailable(detail: str | None = None) -> ApplicationError:
        return ApplicationError(
            code="RDP-001",
            category=ErrorCategory.RDP_AVAILABILITY,
            severity=ErrorSeverity.WARNING,
            recoverable=True,
            user_message=(
                detail
                or _("The RDP service is not available.")
            ),
            technical_detail=detail,
        )


    @staticmethod
    def smartcard_unavailable(detail: str | None = None) -> ApplicationError:
        return ApplicationError(
            code="SC-001",
            category=ErrorCategory.SMARTCARD,
            severity=ErrorSeverity.WARNING,
            recoverable=True,
            user_message=detail or _("The required smart card is not available."),
            technical_detail=detail,
        )

    @staticmethod
    def incomplete_credentials() -> ApplicationError:
        return ApplicationError(
            code="AUTH-001",
            category=ErrorCategory.CREDENTIALS,
            severity=ErrorSeverity.WARNING,
            recoverable=True,
            user_message=_("A username and password are required."),
        )

    @staticmethod
    def connection_not_ready() -> ApplicationError:
        return ApplicationError(
            code="RDP-002",
            category=ErrorCategory.RDP_AVAILABILITY,
            severity=ErrorSeverity.WARNING,
            recoverable=True,
            user_message=_("The RDP server is not available."),
        )


    @staticmethod
    def printer_redirection_required(
        detail: str | None = None,
    ) -> ApplicationError:
        return ApplicationError(
            code="PRINTER-001",
            category=ErrorCategory.PRINTERS,
            severity=ErrorSeverity.ERROR,
            recoverable=True,
            user_message=_("A required local printer is not available."),
            technical_detail=detail,
        )

    @staticmethod
    def audio_playback_required(
        detail: str | None = None,
    ) -> ApplicationError:
        return ApplicationError(
            code="AUDIO-001",
            category=ErrorCategory.AUDIO,
            severity=ErrorSeverity.ERROR,
            recoverable=True,
            user_message=_("A required local audio output is not available."),
            technical_detail=detail,
        )

    @staticmethod
    def microphone_required(
        detail: str | None = None,
    ) -> ApplicationError:
        return ApplicationError(
            code="MICROPHONE-001",
            category=ErrorCategory.AUDIO,
            severity=ErrorSeverity.ERROR,
            recoverable=True,
            user_message=_("A required local microphone is not available."),
            technical_detail=detail,
        )

    @staticmethod
    def video_required(
        detail: str | None = None,
    ) -> ApplicationError:
        return ApplicationError(
            code="VIDEO-001",
            category=ErrorCategory.VIDEO,
            severity=ErrorSeverity.ERROR,
            recoverable=True,
            user_message=_("A required local camera is not available."),
            technical_detail=detail,
        )

    @staticmethod
    def video_capability_unavailable(
        detail: str | None = None,
    ) -> ApplicationError:
        return ApplicationError(
            code="VIDEO-002",
            category=ErrorCategory.VIDEO,
            severity=ErrorSeverity.ERROR,
            recoverable=True,
            user_message=_(
                "The installed FreeRDP client does not support video redirection."
            ),
            technical_detail=detail,
        )

    @staticmethod
    def session_start_failed(detail: str | None = None) -> ApplicationError:
        return ApplicationError(
            code="SESSION-001",
            category=ErrorCategory.SESSION,
            severity=ErrorSeverity.ERROR,
            recoverable=True,
            user_message=_("The RDP session could not be started."),
            technical_detail=detail,
        )

    @staticmethod
    def session_interrupted(return_code: int | None) -> ApplicationError:
        message = _(
            "The RDP session was interrupted (code {code})."
        ).format(code=return_code)

        return ApplicationError(
            code="SESSION-002",
            category=ErrorCategory.SESSION,
            severity=ErrorSeverity.ERROR,
            recoverable=True,
            user_message=message,
            technical_detail=(
                f"xfreerdp return code: {return_code}"
            ),
        )

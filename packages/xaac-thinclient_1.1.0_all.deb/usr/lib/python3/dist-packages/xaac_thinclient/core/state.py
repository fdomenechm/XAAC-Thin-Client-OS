from __future__ import annotations

from dataclasses import dataclass, field, replace
from enum import Enum, auto

from xaac_thinclient.core.errors import ApplicationError
from xaac_thinclient.i18n import _


class ApplicationPhase(Enum):
    STARTING = auto()
    READY = auto()
    CHECKING_NETWORK = auto()
    CHECKING_DNS = auto()
    CHECKING_RDP = auto()
    CONNECTING = auto()
    CONNECTED = auto()
    ERROR = auto()
    STOPPING = auto()


@dataclass(frozen=True, slots=True)
class ApplicationState:
    phase: ApplicationPhase = ApplicationPhase.STARTING

    network_connected: bool = False
    network_interface: str | None = None
    local_ip: str | None = None
    network_error: str | None = None

    dns_resolved: bool = False
    resolved_addresses: tuple[str, ...] = ()
    dns_error: str | None = None

    smartcard_enabled: bool = False
    smartcard_required: bool = False
    smartcard_ready: bool = True
    smartcard_pcsc_available: bool = False
    smartcard_pcscd_running: bool = False
    smartcard_reader_count: int = 0
    smartcard_detected_reader_count: int = 0
    smartcard_eligible_reader_count: int = 0
    smartcard_reader_mode: str = "any"
    smartcard_preferred_reader_matched: bool = True
    smartcard_readers: tuple[str, ...] = ()
    smartcard_readers_with_card: tuple[str, ...] = ()
    smartcard_card_present: bool = False
    smartcard_policy_mode: str = "disabled"
    smartcard_effective_requirements: tuple[str, ...] = ()
    smartcard_status_code: str = "disabled"
    smartcard_status_detail: str = "Smart card support is disabled."
    smartcard_error: str | None = None

    rdp_available: bool = False
    rdp_error: str | None = None
    rdp_session_running: bool = False

    session_return_code: int | None = None
    session_error: str | None = None

    status_message: str = field(default_factory=lambda: _("Starting…"))
    error_message: str | None = None
    current_error: ApplicationError | None = None

    @property
    def can_connect(self) -> bool:
        return (
            self.network_connected
            and self.dns_resolved
            # La comprovació TCP del port RDP és només diagnòstica.
            # Pot donar falsos negatius (firewall, saturació temporal,
            # particularitats del servidor) i no ha de bloquejar un intent
            # real de FreeRDP. Xarxa + DNS + política de smartcard són els
            # únics prerequisits locals per habilitar Connectar.
            and (not self.smartcard_required or self.smartcard_ready)
            and not self.rdp_session_running
            and self.phase
            not in (
                ApplicationPhase.CONNECTING,
                ApplicationPhase.CONNECTED,
                ApplicationPhase.STOPPING,
            )
        )

    def updated(self, **changes: object) -> "ApplicationState":
        return replace(self, **changes)
class XaacThinClientError(Exception):
    pass

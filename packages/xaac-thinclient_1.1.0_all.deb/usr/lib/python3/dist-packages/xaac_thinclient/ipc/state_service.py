"""Session D-Bus state contract for XAAC Thin Client Remote.

The Dock consumes this read-only API to present Remote state without inspecting
GTK widgets, processes or FreeRDP implementation details.  The service never
exposes credentials or user-facing/localised error text.
"""
from __future__ import annotations

import json
from collections.abc import Mapping
from typing import Any

from xaac_thinclient.core.errors import ErrorCategory
from xaac_thinclient.core.events import ApplicationEvent
from xaac_thinclient.core.state import ApplicationPhase, ApplicationState

REMOTE_DBUS_NAME = "org.xaac.ThinClient"
REMOTE_DBUS_PATH = "/org/xaac/ThinClient"
REMOTE_DBUS_INTERFACE = "org.xaac.ThinClient1"
REMOTE_INTERFACE_VERSION = 1

INTROSPECTION_XML = f"""
<node>
  <interface name="{REMOTE_DBUS_INTERFACE}">
    <method name="GetState">
      <arg name="state_json" type="s" direction="out"/>
    </method>
    <signal name="StateChanged">
      <arg name="state_json" type="s"/>
    </signal>
  </interface>
</node>
"""


def remote_state_payload(state: ApplicationState) -> dict[str, object]:
    """Return the stable, non-secret public snapshot for *state*."""

    if state.rdp_session_running or state.phase is ApplicationPhase.CONNECTED:
        runtime_state = "active"
    elif state.phase is ApplicationPhase.CONNECTING:
        runtime_state = "connecting"
    elif state.phase is ApplicationPhase.STOPPING:
        runtime_state = "stopped"
    elif state.phase is ApplicationPhase.STARTING:
        runtime_state = "starting"
    elif state.phase is ApplicationPhase.ERROR:
        # Network/DNS/server-health failures do not make the Remote application
        # unavailable.  The local login/recovery UI remains a valid destination
        # from the Dock.  Only an actual connection/session error is surfaced as
        # a remote-session error state.
        category = state.current_error.category if state.current_error else None
        if category in {ErrorCategory.CREDENTIALS, ErrorCategory.SESSION}:
            runtime_state = "error"
        else:
            runtime_state = "available"
    else:
        runtime_state = "available"

    payload: dict[str, object] = {
        "interface_version": REMOTE_INTERFACE_VERSION,
        "state": runtime_state,
        "network_connected": bool(state.network_connected),
        "server_available": bool(state.rdp_available),
        "session_active": bool(state.rdp_session_running),
    }
    if runtime_state == "error" and state.current_error is not None:
        payload["last_error"] = state.current_error.code
    return payload


class RemoteStateDbusService:
    """Publish :func:`remote_state_payload` on the current session bus."""

    def __init__(self, controller: Any) -> None:
        self._controller = controller
        self._connection: Any | None = None
        self._registration_id = 0
        self._owner_id = 0
        self._Gio: Any | None = None
        self._GLib: Any | None = None
        self._node_info: Any | None = None

    def start(self) -> None:
        if self._connection is not None:
            return
        import gi

        gi.require_version("Gio", "2.0")
        from gi.repository import Gio, GLib

        connection = Gio.bus_get_sync(Gio.BusType.SESSION, None)
        node_info = Gio.DBusNodeInfo.new_for_xml(INTROSPECTION_XML)
        registration_id = connection.register_object(
            REMOTE_DBUS_PATH,
            node_info.interfaces[0],
            self._handle_method_call,
            None,
            None,
        )
        owner_id = Gio.bus_own_name_on_connection(
            connection,
            REMOTE_DBUS_NAME,
            Gio.BusNameOwnerFlags.NONE,
            None,
            None,
        )

        self._Gio = Gio
        self._GLib = GLib
        self._connection = connection
        self._node_info = node_info
        self._registration_id = int(registration_id)
        self._owner_id = int(owner_id)
        self._controller.subscribe(self._on_controller_event)

    def close(self) -> None:
        try:
            self._controller.unsubscribe(self._on_controller_event)
        except Exception:
            pass
        if self._connection is not None and self._registration_id:
            try:
                self._connection.unregister_object(self._registration_id)
            except Exception:
                pass
        if self._Gio is not None and self._owner_id:
            try:
                self._Gio.bus_unown_name(self._owner_id)
            except Exception:
                pass
        self._registration_id = 0
        self._owner_id = 0
        self._connection = None

    def get_state(self) -> Mapping[str, object]:
        return remote_state_payload(self._controller.state)

    def _state_json(self) -> str:
        return json.dumps(
            self.get_state(),
            ensure_ascii=True,
            separators=(",", ":"),
            sort_keys=True,
        )

    def _handle_method_call(
        self,
        _connection: Any,
        _sender: str,
        _object_path: str,
        _interface_name: str,
        method_name: str,
        _parameters: Any,
        invocation: Any,
    ) -> None:
        if method_name == "GetState":
            invocation.return_value(self._GLib.Variant("(s)", (self._state_json(),)))
            return
        invocation.return_dbus_error(
            f"{REMOTE_DBUS_INTERFACE}.UnknownMethod",
            "Unknown XAAC Thin Client Remote method.",
        )

    def _on_controller_event(
        self,
        _event: ApplicationEvent,
        _state: ApplicationState,
    ) -> None:
        if self._connection is None or self._GLib is None:
            return
        try:
            self._connection.emit_signal(
                None,
                REMOTE_DBUS_PATH,
                REMOTE_DBUS_INTERFACE,
                "StateChanged",
                self._GLib.Variant("(s)", (self._state_json(),)),
            )
        except Exception:
            # State publication is observational only and must never affect the
            # Remote UI/session controller.
            return

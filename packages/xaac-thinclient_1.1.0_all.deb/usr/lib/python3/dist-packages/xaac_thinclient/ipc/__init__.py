"""Public local IPC contracts for XAAC Thin Client Remote."""

from xaac_thinclient.ipc.state_service import (
    REMOTE_DBUS_INTERFACE,
    REMOTE_DBUS_NAME,
    REMOTE_DBUS_PATH,
    REMOTE_INTERFACE_VERSION,
    RemoteStateDbusService,
    remote_state_payload,
)

__all__ = [
    "REMOTE_DBUS_INTERFACE",
    "REMOTE_DBUS_NAME",
    "REMOTE_DBUS_PATH",
    "REMOTE_INTERFACE_VERSION",
    "RemoteStateDbusService",
    "remote_state_payload",
]

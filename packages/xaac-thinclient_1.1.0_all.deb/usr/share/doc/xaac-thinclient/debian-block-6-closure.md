# Tancament del Bloc 6 — paquet Debian

La Fase 6.8 congela el contracte de distribució del paquet `xaac-thinclient`.
No incorpora funcionalitat d'aplicació: valida que allò desenvolupat entre les
fases 6.1 i 6.7 es pot construir, inspeccionar, instal·lar, actualitzar i retirar
seguint el cicle de vida de Debian.

## Validació reproduïble

El punt d'entrada és:

```sh
./scripts/validate-debian-package.sh --source
./scripts/build-deb.sh
./scripts/validate-debian-package.sh --deb dist/xaac-thinclient_1.1.0_all.deb
```

`--source` no modifica el sistema. Comprova els manifests, la sintaxi dels
scripts, els permisos executables i l'absència de caches, logs, claus privades o
altres residus de construcció.

`build-deb.sh` delega en `--build`, que executa `dpkg-buildpackage --no-sign -b` i audita el `.deb` resultant. Després publica en `dist/` tant el paquet com `xaac-thinclient_1.1.0_all.evidence.json`, que registra el SHA-256 i la resta d'evidència de construcció. La construcció requereix les dependències declarades en `Build-Depends`; no les instal·la ni accedeix a la xarxa.

`--deb` inspecciona un paquet ja construït amb `dpkg-deb`. Verifica la identitat,
l'arquitectura, els entrypoints, la unitat systemd d'usuari, la configuració
inicial i l'absència d'artefactes prohibits.

## Prova de cicle de vida en una màquina neta

Les proves d'instal·lació s'han de fer en una VM o contenidor Debian 13
prescindible, mai sobre el lloc de treball de desenvolupament:

```sh
sudo apt install ./xaac-thinclient_1.1.0_all.deb
sudo apt install --reinstall ./xaac-thinclient_1.1.0_all.deb
sudo apt remove xaac-thinclient
sudo apt purge xaac-thinclient
```

Abans i després de cada operació cal comprovar `/etc/xaac-thinclient`, les còpies
`*.pre-vN.bak`, l'estat global de `xaac-thinclient.service` i els missatges de
`dpkg`. La política del projecte conserva configuracions i backups fins i tot en
`purge`; una retirada destructiva requeriria una decisió administrativa separada.

## Actualització i rollback

Una actualització vàlida executa les migracions després de desempaquetar el nou
codi. Les migracions són seqüencials, idempotents, atòmiques i rebutgen esquemes futurs sense sobreescriure'ls.

El rollback del binari es fa instal·lant explícitament una versió anterior del
`.deb` o fixant-la mitjançant APT. No es redueix automàticament la versió de
l'esquema de configuració: abans del rollback s'ha de verificar que la versió
anterior entén l'esquema existent o restaurar una còpia compatible.

## Lliurables del Bloc 6

- paquet Debian natiu i sense construcció com a root;
- recursos i configuració inicial neutra;
- entrypoints i integració d'escriptori;
- servei systemd d'usuari;
- migracions versionades;
- scripts de manteniment Debian;
- repositori APT signat i transaccional;
- auditoria final reproduïble.

Amb aquesta fase, el Bloc 6 queda tancat. La generació de la imatge Debian 13,
l'instal·lador i l'adaptació al Dell Wyse 3040 pertanyen al Bloc 7.

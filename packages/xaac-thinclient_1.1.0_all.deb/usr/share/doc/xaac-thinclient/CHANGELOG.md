## 2026-08-30 — contracte d'estat per al Dock i configuració canònica

- Afegit el contracte D-Bus de sessió de només lectura `org.xaac.ThinClient1` (`GetState` i `StateChanged`) perquè XAAC Thin Client Dock puga consultar l'estat de Remote sense inspeccionar processos, widgets ni FreeRDP.
- L'estat Remote continua sent `available` davant errors de xarxa, DNS o disponibilitat RDP: aquests errors no han de desactivar la superfície local de recuperació.
- La publicació D-Bus és best-effort i una fallada del bus no impedeix que la GUI Remote es mostre.
- El directori canònic de configuració passa a ser `/etc/xaac-remote`; el paquet Debian, migrador, scripts i documentació utilitzen ja aquesta ruta.
- El contracte no exposa credencials, textos d'error localitzats ni detalls tècnics sensibles.

## 2026-08-29 — artefactes Debian locals en `dist/`

- `scripts/build-deb.sh` deixa de proposar o dependre de la còpia del paquet a `XAAC Thin Client OS/packages/`.
- El paquet validat es publica ara exclusivament dins de `dist/` del mateix projecte.
- Cada construcció genera al costat `xaac-thinclient_<versió>_all.evidence.json`, amb esquema `xaac-build-evidence/v1`, SHA-256, mida, versió, arquitectura, data UTC i resultat de les auditories.
- La validació final s'executa sobre el `.deb` ja publicat a `dist/`, evitant que altres projectes consumisquen un artefacte no auditat.
- Actualitzats tests i documentació d'empaquetat/release.

## 2026-08-29 — identitat XAAC Thin Client Remote al diàleg «Quant a»

- Actualitzat el nom visible del producte a **XAAC Thin Client Remote** en la finestra «Quant a», el contingut interior, l'enllaç del projecte, els textos de llicència, diagnòstic i la resta de textos visibles/documentació del projecte.
- El botó que obri la finestra «Quant a» mostra ara **Quant a v.1.1.0** (traduït segons la llengua activa) en lloc del nom del producte i la versió.
- Actualitzats els catàlegs de català, castellà i anglés i les proves de regressió associades.

## 2026-08-29 — cursor d’espera immediat en totes les accions de botó

- Unificat el feedback visual de la finestra principal perquè **Connectar**, **Quant a**, **Diagnòstics** i **Apagar/Tancar** activen el cursor d’espera en el mateix instant del clic.
- Les operacions que poden bloquejar o preparar una transició es difereixen un cicle de GTK amb `GLib.idle_add`, de manera que el cursor i el bloqueig del botó es pinten abans d’executar el treball.
- El flux de **Connectar** manté un estat pendent propi perquè les comprovacions asíncrones de xarxa/DNS/RDP no puguen retirar el cursor d’espera entre el clic i l’inici real de la connexió.
- **Quant a** i **Diagnòstics** bloquegen temporalment el botó premut i restauren l’estat en completar-se o fallar l’acció.
- Els botons de tancament dels diàlegs **Quant a**, **Llicència** i **Diagnòstics**, així com **Copiar** i **Desar una còpia**, apliquen el mateix patró d’espera immediata.
- Els botons de confirmació i cancel·lació del diàleg d’apagat també entren en estat d’espera abans de processar la resposta.
- Afegides proves de regressió per garantir la cobertura del patró en tots els botons principals i auxiliars.

## 2026-08-29 — logotip principal configurable

- Afegida la clau `application.logo` als fitxers `config.ini` de desenvolupament i als valors per defecte del paquet Debian.
- El logotip principal de la finestra es resol en temps d'execució des de la configuració, amb `xaac-thinclient-logo.png` com a valor i fallback per defecte.
- Es permet seleccionar un recurs empaquetat, una ruta relativa al directori de configuració o una ruta absoluta.
- `xaac-thinclient-logo.png` s'ha actualitzat amb fons transparent i el text `THIN CLIENT REMOTE`, tant a `assets/images/` com als recursos Python empaquetats.
- Afegides proves de regressió per al valor per defecte, la lectura des de l'INI, la selecció d'un logotip alternatiu i el fallback quan el fitxer configurat no existeix.

## 2026-08-23 — feedback visual i protecció de l'apagat

- En prémer **Apagar** (o **Tancar** en desenvolupament), el botó es bloqueja immediatament contra dobles clics i el cursor mostra l'estat d'espera mentre es prepara el diàleg de confirmació.
- Mentre el diàleg modal està obert, el botó principal continua deshabilitat per impedir diàlegs duplicats.
- En confirmar l'apagat, el botó de confirmació queda deshabilitat i el cursor passa a espera abans d'executar l'acció d'energia.
- En cancel·lació, rebuig, error d'execució o excepció inesperada, es restauren el cursor i els controls. Si l'apagat és acceptat, l'estat ocupat es manté fins que el sistema es deté.
- Afegides proves de regressió específiques per al feedback d'ocupat i la protecció contra dobles clics del flux d'apagat.

## 2026-08-22 — recuperació correcta dels intents RDP fallits

- Corregida la comprovació prèvia RDP perquè el sondeig TCP del port siga només diagnòstic: un timeout o fals negatiu ja no mostra «RDP no disponible», no posa l'aplicació en ERROR i no bloqueja el botó Connectar. La disponibilitat real de la sessió la determina FreeRDP en l'intent de connexió.

### Correcció de recuperació després d'error d'autenticació RDP

- Afegit un mode explícit de reintent després d'una fallada de sessió
  recuperable: les comprovacions RDP periòdiques continuen executant-se i
  registrant-se, però no poden substituir l'error de sessió ni deshabilitar
  **Connectar** mentre l'usuari corregeix les credencials.
- El mode de reintent es manté encara que un sondeig TCP RDP produïsca un fals
  negatiu uns segons després de l'error d'autenticació, i només deixa de ser
  aplicable quan s'estableix una sessió real, canvia el servidor o canvia de
  manera real la xarxa/DNS.
- Una fallada d'autenticació o d'arrancada de FreeRDP conserva l'últim estat real de disponibilitat del servidor i permet reintentar immediatament.
- Les comprovacions de xarxa, DNS i RDP que ja estaven en vol abans de prémer **Connectar** queden invalidades perquè un resultat obsolet no puga marcar el servidor com a no disponible després d'una contrasenya incorrecta.
- La cadena de salut xarxa → DNS → RDP només es força immediatament després d'una sessió que realment s'havia establit; en els errors d'inici continua funcionant el monitoratge periòdic normal.


- `SESSION_STARTED` ja no s'emet en crear el procés `xfreerdp3`; només s'emet quan FreeRDP arriba a la inicialització gràfica posterior a la postconnexió RDP.
- Mentre la connexió encara no s'ha establit, la interfície conserva `CONNECTING`, el cursor d'espera i el botó **Connectar** deshabilitat.
- Els codis de fallada inicial de FreeRDP X11 (autenticació, TLS, DNS, accés, servidor arrancant, etc.) no entren en el bucle de reconnexió automàtica si la sessió no havia arribat a establir-se.
- El codi `143` deixa de confondre's amb una terminació `SIGTERM`: en FreeRDP X11 és una fallada TLS i es tracta com a error de connexió.
- `stdout` i `stderr` de FreeRDP es consumeixen en temps real per detectar la postconnexió sense bloquejar el procés; les línies `INFO/DEBUG/TRACE` utilitzades per a la detecció continuen fora del logging normal.
- Afegides proves de regressió per a credencials incorrectes, fallades TLS, detecció de postconnexió i reconnexió després d'una sessió realment establida.

## 2026-08-22 — feedback visual immediat en iniciar la connexió RDP

- Correcció d'UX de connexió: les comprovacions asíncrones de xarxa, DNS i RDP ja no poden cancel·lar prematurament el cursor d'espera mentre s'inicia una sessió.
- `scripts/build-deb.sh` neteja artefactes abans de validar i mostra en directe el progrés de `dpkg-buildpackage`, mantenint la ruta final del `.deb` de forma segura.

- En prémer **Connectar**, el cursor passa immediatament a estat d'espera abans de persistir preferències o iniciar les comprovacions RDP.
- El botó **Connectar** queda deshabilitat de manera immediata per impedir dobles clics i sol·licituds duplicades.
- El cursor d'espera es manté exclusivament durant la fase `CONNECTING` i es restaura en connexió establida, finalització, error o rebuig de la sol·licitud.
- Afegides proves de regressió específiques per al feedback d'ocupat i el fallback quan la connexió no arriba a iniciar-se.

## 2026-08-12 — script oficial de construcció del paquet Debian

- Afegit `scripts/build-deb.sh` com a punt d'entrada únic per construir
  `xaac-thinclient_<versió>_all.deb`.
- El script reutilitza `validate-debian-package.sh` per a la neteja, auditoria
  de l'arbre font, construcció i validació final del `.deb`.
- En finalitzar mostra ruta, mida, SHA-256 i el comandament de còpia cap a
  `XAAC Thin Client OS/packages/`.

## 2026-08-12 — visor intern de la llicència EUPL 1.2

- L'enllaç de la pestanya «Llicència» ja no obri un navegador extern.
- Afegit un diàleg modal intern amb el text íntegre de la EUPL 1.2, desplaçable, només lectura i amb botons de tancament explícits per al mode quiosc.
- El text es distribueix com a recurs local del paquet i coincideix byte a byte amb el fitxer `LICENSE` del projecte.
- El flux funciona igual en desenvolupament i en producció, sense accés web.

## 2026-08-12 — modals quiosc i apagat del terminal

- Els diàlegs «Quant a» i «Diagnòstics» incorporen un botó de tancament propi
  al `Gtk.HeaderBar`, independent de les decoracions de finestra del sistema.
- `PowerActionService` prefereix els helpers privilegiats fixos de XAAC Thin
  Client OS quan estan instal·lats i manté `systemctl` com a fallback genèric.
- Les ordres d’energia continuen sense shell ni arguments configurables.

# Changelog

## [1.1.0] - 2026-08-29

### Changed

- El constructor oficial publica el `.deb` i el JSON d'evidència en `dist/`, sense copiar artefactes a XAAC Thin Client OS.
- Actualitzada la versió del projecte, del paquet Debian i dels catàlegs de traducció a 1.1.0.
- El títol predeterminat de la finestra principal passa a ser `XAAC Thin Client Sessió Remota`.
- El títol principal es tradueix com `XAAC Thin Client Sesión Remota` en espanyol i `XAAC Thin Client Remote Session` en anglès.

### Release

- Artefactes esperats: `dist/xaac-thinclient_1.1.0_all.deb` i `dist/xaac-thinclient_1.1.0_all.evidence.json`.

## [1.0.0] - 2026-08-07

### Changed

- Consolidada la versió estable 1.0.0 en `pyproject.toml`, `src/xaac_thinclient/__init__.py`, traduccions i `debian/changelog`.
- Reestructurat el repositori perquè continga exclusivament XAAC Thin Client Remote, el seu entorn de desenvolupament, proves, documentació i empaquetat Debian.
- Eliminades les plantilles i scripts de construcció d'ISO Debian 13, clonació, primer inici, expansió de rootfs, recuperació de sistema i perfil Dell Wyse 3040.
- Eliminades les eines pròpies de publicació d'un repositori APT; el lliurable oficial passa a ser exclusivament el paquet `.deb`.
- Actualitzades les guies d'instal·lació, proves, empaquetat, release i estructura del repositori.
- `bootstrap-dev.sh` invoca explícitament l'intèrpret de `fix-project-permissions.sh` per evitar fallades quan una extracció ZIP no conserva el bit executable.

### Release

- Artefacte esperat: `xaac-thinclient_1.0.0_all.deb`.

## Unreleased

### Changed

- Consolidada `docs/architecture.md` com a document de referència de l'arquitectura real: capes, composició de dependències, configuració, preparació i execució RDP, seguretat, quiosc, diagnòstic, integracions i regles d'extensió.
- Substituït el README històric acumulatiu per una portada de producte orientada a administradors i desenvolupadors.
- Afegits inici ràpid, requisits, funcionalitats, seguretat, configuració, diagnòstic, branding, traduccions, proves, empaquetat, arquitectura i índex documental.
- Eliminades del README principal les notes de fases internes, conservades en el changelog i en la documentació tècnica.
- Reorganitzada la documentació amb un índex modular en `docs/`.
- Afegides guies temàtiques per arquitectura, instal·lació, configuració, branding, diagnòstic, desenvolupament, proves, empaquetat, imatge Debian, traduccions, roadmap i releases.
- Arxivada la documentació històrica de proves de la fase 2.
- Afegits `CONTRIBUTING.md`, `SECURITY.md` i `.editorconfig`.
- Mantingudes les rutes tècniques existents requerides pels tests, scripts i manifests Debian.

- Separats el logo corporatiu de l'entitat i el logo propi de XAAC Thin Client Remote utilitzat exclusivament al diàleg Quant a.
- Substituït Gtk.AboutDialog per un diàleg propi compacte, amb logotip dimensionat, pestanyes i llicència centrada amb hipervincle.

## Unreleased — logging FreeRDP contextual

- El `stderr` de FreeRDP es classifica línia per línia.
- Els avisos de terminal/XKB sempre es mantenen només en `DEBUG`.
- Els avisos de certificat TOFU, fallback Kerberos i tancament voluntari es mantenen només en `DEBUG` quan la sessió ha finalitzat correctament.
- Els errors desconeguts o de connexió continuen registrant-se com a `WARNING`.
- Els detalls operatius de xarxa, rendiment, gràfics, teclat i porta-retalls passen de `INFO` a `DEBUG`.
## Filtratge de soroll tècnic de FreeRDP

- Els errors inofensius de `set_terminal_nonblock` i els avisos XKB sense codi RDP deixen d'aparéixer en nivells `INFO` i superiors.
- Els missatges coneguts es conserven resumits a nivell `DEBUG`.
- Els errors reals de connexió, autenticació, TLS/NLA, certificats i canals continuen registrant-se com a advertiments.
- Afegides proves de regressió per evitar ocultar diagnòstics rellevants.

## Correcció del botó de tancament i del peu d'aplicació

- El botó **Tanca** en mode desenvolupament tanca sempre la finestra i finalitza l'aplicació GTK de manera ordenada.
- S'ha afegit un fallback explícit quan la finestra no té una aplicació associada.
- Els botons **Quant a**, **Diagnòstic** i **Tanca/Apaga** es distribueixen ara en tres espais homogenis.
- El contingut intern dels tres botons queda centrat visualment.


- Separa la configuració neutral del paquet Debian del perfil de producció de la imatge Debian 13: el `.deb` conserva `development` i polítiques desactivades, mentre el hook de la imatge activa `production`, quiosc, apagada i autoinici.

## [0.1.0] - Botó d'apagat/tancament segons entorn

- Afegit un botó inferior amb la icona `system-shutdown-symbolic`.
- En mode `development`, el botó tanca ordenadament l'aplicació.
- En mode `production`, demana confirmació i sol·licita l'apagat del terminal.
- Els tres controls inferiors —Quant a, Diagnòstic i Apaga/Tanca— queden agrupats a la dreta.
- Afegit `application.mode` amb valors `development` i `production`.
- La configuració de desenvolupament usa `development`; la configuració Debian empaquetada usa `production`, mode quiosc i accions d'energia habilitades.
- Afegides traduccions i proves de regressió.
## Unreleased

- Converteix la versió del peu en un botó discret amb icona.
- Afig un diàleg natiu «Quant a» amb versió, autoria, llicència EUPL-1.2, web i logotip.


## Sessió RDP: tancament normal amb codi 12

- El codi d’eixida 12 de FreeRDP es tracta com un tancament normal de la sessió.
- La interfície mostra «Sessió remota tancada correctament» en lloc d’un error.
- El codi tècnic es conserva en l’estat i en el registre de diagnòstic.

- Registre configurable mitjançant la secció `[logging]` de `config.ini`.
- Precedència opcional de `XAAC_LOG_LEVEL` per a diagnòstics temporals.
- Eliminat el nivell `INFO` forçat durant l'arrencada.
- Reconfiguració idempotent dels handlers sense duplicació.
## Correcció de compatibilitat GFX amb FreeRDP 3.30

- Afegida verificació funcional dels modes `/gfx:AVC420` i `/gfx:AVC444` anunciats per FreeRDP.
- Quan el parser real rebutja un codec anunciat, la capacitat s'elimina de la instantània i el selector degrada automàticament a `/gfx`.
- La prova no contacta cap servidor remot: utilitza `127.0.0.1:1` i diferencia errors de parseig d'errors de transport.
- Afegida cobertura de regressió per codecs anunciats però rebutjats pel parser.

## Compatibilitat FreeRDP 3.30 i entorn Python 3.13

- Corregits els arguments gràfics de FreeRDP per usar els valors canònics `/gfx:AVC420` i `/gfx:AVC444`.
- Actualitzades les proves de selecció gràfica, rendiment i enduriment de comandes.
- Mantingut l'entorn de desenvolupament Python 3.13 definit en `pyproject.toml`.
- Mantinguda la normalització portable de permisos per a Zorin OS 17, Zorin OS 18 i Debian 13.

## Fase 7.5-r1 — Correcció del backend de clonació en proves

- Separat el backend de fitxers regulars del backend de dispositius de bloc reals.
- Les operacions sobre fitxers temporals autoritzats ja no requereixen privilegis de `root`.
- Els dispositius reals continuen exigint `root`, desmuntatge segur i confirmació `--force`.
- La restauració sobre fitxers és atòmica i no usa `oflag=direct`.
- Corregit l'ordre de validació perquè `--force` es comprove abans dels privilegis.

## Fase 7.5 — Clonació i desplegament massiu

- Afegida preparació reutilitzable de la imatge mestra abans de capturar-la.
- Incorporades captura atòmica i compressió `zstd`, `xz` o sense compressió.
- Generats SHA-256, manifest de traçabilitat i `bmap` opcional.
- Afegides verificació i inspecció d'imatges sense operacions destructives.
- Incorporada restauració protegida per privilegis, bloqueig, desmuntatge, capacitat i `--force`.
- Afegida descompressió en flux, sincronització i relectura de particions.
- Incorporada expansió idempotent de la partició arrel després de la clonació.
- Documentat el procediment de desplegament massiu i afegides 30 proves específiques.

## Fase 7.2 — Construcció automatitzada de la imatge Debian 13

- Afegida una plantilla reproduïble `live-build` per a Debian 13/Trixie `amd64`.
- Integrats el paquet local XAAC, FreeRDP 3, GTK 4, sessió gràfica i xarxa.
- Incorporats APT segur, límits de journald i enduriment conservador del sistema.
- Neutralitzada la identitat única de la imatge mestra abans de clonació.
- Afegit un constructor amb validació de plataforma, SHA-256, bloqueig i espai de treball aïllat.
- Generats ISO híbrida, suma SHA-256, manifest de traçabilitat i metadades reproduïbles.
- Afegida neteja protegida per marcador i un validador independent d'imatge.
- Afegides 29 proves específiques.

## Fase 7.1.4-r1 — Correcció del registre d’auditoria

- El registre persistent és ara de millor esforç i no pot ocultar l’error real d’APT.
- La manca de permisos sobre `/var/lib` o `/var/log` no interromp entorns de prova sense privilegis.
- Afegides proves de regressió per a instal·lació correcta i fallada transaccional.

## Fase 7.1.3 — Prevalidació transaccional i contenció de fallades

- Afegida una simulació APT obligatòria abans de la instal·lació real.
- Registrat l’estat previ del paquet per diferenciar instal·lacions noves i actualitzacions.
- Incorporada una recuperació conservadora de paquets nous parcialment instal·lats.
- Protegides les versions preexistents davant fallades d’actualització.
- Afegides 9 proves específiques.

## Fase 6.5 — Migracions de configuració

- Afegit un esquema INI versionat amb versió actual `1`.
- Incorporat un motor seqüencial i idempotent de migracions.
- Escriptura atòmica, còpia prèvia i conservació de permisos.
- Rebuig segur de fitxers malformats, no regulars o de versions futures.
- Diagnòstic i auditoria estructurada sense valors sensibles.
- Afegides 8 proves específiques.

## Fase 5.6 — Supervisió i autorecuperació del mode quiosc


## Fase 5.8 — Tancament del Bloc 5

- Afegit `SystemLifecycleService` per agregar política, supervisor i recuperació.
- Nous estats estables: `disabled`, `ready`, `degraded` i `safe-mode`.
- Diagnòstic final del Bloc 5 amb degradació segura i fallada tancada.
- API pública del subsistema `system` completada i validada.
- Afegides proves de tancament i integració del bloc.

- Afegida una màquina d'estats immutable per supervisar la sessió quiosc.
- Incorporats límit temporal de reinicis, backoff exponencial i mode segur.
- Afegits diagnòstic estable, auditoria estructurada i política remota validada.
- Afegides proves específiques de transicions, límits i degradació segura.

## Fase 4.14.7 — Tancament del Bloc 4.14

- Consolidat el contracte públic estable de gestió remota.
- Documentat el pipeline complet d’esquema, signatura, vigència, rollback, identitat i telemetria.
- Fixades les invariants de validació prèvia, revalidació de cache/rollback i absència de dades sensibles.
- Mantinguts els mecanismes d’emmagatzematge i rollback com a detalls interns.
- Afegides 6 proves transversals de tancament.

## Fase 4.14.6 — Telemetria remota

- Afegit un esquema immutable i versionat d'esdeveniments de telemetria.
- Enviament opcional per HTTPS, desactivat per defecte.
- Cua local atòmica amb permisos 0600, límit configurable i reenviament FIFO.
- Telemetria sanititzada sense credencials, usuaris, servidor RDP, IP, tokens ni detalls d'error.
- Integració no bloquejant amb la resolució de configuració remota.
- Afegides 8 proves i documentació específica.

## Fase 4.14.4 — Rollback de polítiques remotes

- Afegit `policy_revision` opcional i signat als documents versionats.
- Afegit historial local atòmic i limitat de polítiques validades.
- Recuperació des de la revisió vàlida més alta quan fallen remot i cache.
- Revalidació obligatòria d’esquema, signatura i vigència durant el rollback.
- Protecció configurable contra regressions de revisió.
- Nous diagnòstics de font rollback, revisió i candidats comprovats.
- Afegides 8 proves específiques.

## Fase 4.14.3 — Caducitat de polítiques remotes

- Afegides metadades `issued_at` i `expires_at` a l'esquema versionat.
- Les dates temporals formen part del payload canònic signat Ed25519.
- Nova validació immutable de vigència amb tolerància de rellotge configurable.
- Rebuig segur de polítiques futures, caducades o amb finestres incoherents.
- La memòria cau només s'aplica si continua vigent.
- Nous resultats de diagnòstic de vigència i huit proves de regressió.

## Fase 4.14.2 — Signatura de polítiques remotes

- Verificació Ed25519 abans d'aplicar o guardar polítiques remotes.
- Clau pública de confiança i identificador configurables localment.
- Detecció de manipulació, signatures mal formades i claus desconegudes.
- Verificació equivalent de la memòria cau.
- Compatibilitat controlada amb documents sense signatura quan no és obligatòria.
- 8 proves noves.

## Phase 4.13.5 - RDP security auditing

- Added immutable, structured and sanitised RDP security audit events and reports.
- Audits TLS, security mode, credential transport, command hardening, pre-flight, execution and reconnect retries.
- Audit fields reject sensitive names and control characters.
- Integrated preparation audit into `RdpSessionPlan` and execution audit into `RdpSessionResult`.
- Added six security-audit regression tests and dedicated documentation.


## Fase 4.13.4 — Enduriment de la comanda FreeRDP

- Afegits `RdpCommandHardener`, `RdpCommandHardeningPolicy` i `RdpCommandHardeningReport`.
- Validació final per allowlist després de la normalització.
- Bloqueig de secrets en arguments, wrappers, opcions desconegudes i caràcters de control.
- Executable restringit a `xfreerdp3` i ús obligatori de `/from-stdin:force`.
- Integració del resultat immutable en `RdpSessionPlan` i diagnòstic sanititzat.
- Afegides 6 proves de regressió i documentació específica.
## Fase 4.13.3 — Gestió de credencials

- Afegit un contenidor efímer i redaccionat per a la contrasenya RDP.
- El secret continua absent de la comanda, el pla, els diagnòstics i l’auditoria.
- El buffer propietat de l’executor s’esborra després de l’execució, errors i reconnexions.
- Rebutjats caràcters de control que podrien alterar el protocol `/from-stdin:force`.
- Publicada una política immutable i sanititzada de transport de credencials.
- Afegides proves de representació redaccionada, esborrat, transport i validació.

## Fase 4.13.1 — Validació TLS i certificats
## Fase 4.13.2 — NLA i modes de seguretat

- Afegida `RdpSecurityPolicy` immutable i el seu resolutor dedicat.
- Corregit `security_mode = negotiate`: la negociació automàtica de FreeRDP no emet `/sec:negotiate`.
- Separats explícitament NLA, TLS forçat i negociació automàtica.
- Afegits advertiments auditables quan NLA queda desactivat o la seguretat es negocia.
- Integrat el diagnòstic sanititzat dins de `RdpSessionPlan`.
- Publicats els nous contractes en l'API estable del subsistema RDP.
- Afegides 6 proves específiques i actualitzada la prova transversal de l'API pública.


- Política TLS immutable i diagnòstic sanititzat.
- Correcció de `strict` a la sintaxi FreeRDP `/cert:deny`.
- Nom esperat opcional del certificat i validació contra injecció.
- Advertiments auditables per `/cert:ignore`.
- Sis proves noves.

## Fase 4.12.7 — tancament del bloc Rendiment i experiència RDP

- Consolidada l'API pública estable dels perfils, maquinari, xarxa, gràfics, pantalla i reconnexió.
- Documentat el pipeline adaptatiu complet i les seues invariants de seguretat i compatibilitat.
- Confirmada la immutabilitat dels artefactes i l'absència de credencials o identitat de sessió.
- Protegides les regressions de multimonitor, degradació gràfica i reutilització del pla en reconnexions.
- Tancat formalment el Bloc 4.12 sense introduir responsabilitats del Bloc 4.13.
- Afegides proves transversals de tancament.

## Fase 4.12.6 — Reconnexió automàtica i recuperació de sessió

- Afegida política immutable `RdpReconnectPolicy` al `RdpSessionPlan`.
- Afegits intents limitats amb backoff exponencial i retard màxim.
- La recuperació reutilitza el pla preparat sense repetir pre-flight ni polítiques.
- La contrasenya continua enviant-se exclusivament per `stdin` en cada procés.
- `disconnect()` cancel·la el procés actiu i les esperes de reconnexió.
- Afegits diagnòstics, configuració remota i 8 tests de regressió.

## Fase 4.12.5 — Multimonitor i escalat avançat

- Afegit `RdpDisplayPlan` immutable i `RdpDisplayPlanner`.
- Conservat `multimon=enabled` com `/multimon:force`.
- Afegit escalat DPI amb `/scale-desktop` i `/scale-device`.
- Detectades resolucions mixtes i conflictes no bloquejants amb resolució dinàmica.
- Integrats diagnòstic, política remota i validació de configuració.
- Afegides 8 proves de regressió.


## Fase 4.12.3 — Detecció de qualitat de xarxa

- Afegits `RdpNetworkQualityDetector`, `RdpNetworkQualitySnapshot` i `RdpNetworkQuality`.
- Mesura limitada i sense shell de latència, pèrdua i mostres ICMP cap al servidor RDP.
- Classificació immutable en `excellent`, `good`, `fair`, `poor` o `unknown`.
- Integració en `RdpSessionPlan`, diagnòstic sanititzat i auditoria.
- Degradació segura quan `ping` no existeix, ICMP està bloquejat o la resposta no es pot interpretar.
- Activació en producció i injecció determinista per als tests.
- El perfil `auto` encara no canvia en funció de la xarxa.
- Afegides 10 proves de regressió.

## Fase 4.12.2 — Detecció de maquinari

- Afegit `RdpHardwareDetector` amb inventari immutable de CPU, RAM, GPU i pantalles.
- Integrat `RdpHardwareInventory` en `RdpSessionPlan` i en el diagnòstic sanititzat.
- Afegida degradació no bloquejant quan `/proc`, sysfs o `xrandr` no estan disponibles.
- Mantingut el perfil `auto` sense decisions automàtiques fins a completar la detecció de xarxa.
- Afegides 9 proves de detecció, immutabilitat, fallback i integració.
## Fase 4.12.1 — Perfils de rendiment RDP

- Afegit `PerformanceProfile` amb els modes `auto`, `lan`, `wan`, `low-bandwidth` i `quality`.
- Afegit `RdpPerformanceProfileResolver` immutable i determinista.
- Integració del perfil efectiu abans de la degradació de capacitats i de la construcció de la comanda.
- Diagnòstic i auditoria del perfil sol·licitat, efectiu i camps modificats.
- Compatibilitat amb configuracions antigues: l'absència de `performance_profile` equival a `auto`.
- Camp administrable per política remota.
- Afegides 9 proves de regressió.

## Correcció multimonitor posterior al Bloc 4.11

- El mode explícit `rdp.multimon=enabled` genera `/multimon:force` en FreeRDP 3.
- El mode `auto` conserva `/multimon` només quan es detecten diversos monitors.
- Corregida la detecció de l'ajuda `/multimon[:force]`.
- Afegides proves de regressió per als tres modes.

# Changelog

## Fase 4.11.6 — Tancament del Bloc 4.11

- Consolidat el cicle complet `prepare -> pre-flight -> plan -> execute`.
- Publicada una API estable del paquet `xaac_thinclient.rdp` per als artefactes immutables de preparació.
- Documentades les invariants, els límits de responsabilitat i la transició cap al Bloc 4.12.
- Afegides proves transversals de contracte, immutabilitat, privacitat i execució sense mutació.
- Confirmada la compatibilitat de `FreeRdpBackend` amb el contracte complet `RemoteDesktopBackend`.
- Tancat formalment el Bloc 4.11 de sessió RDP.

## Fase 4.11.5 — Execució RDP separada

- Separada la preparació immutable de la sessió de l'execució del procés.
- Afegit `RdpSessionExecutor`, responsable exclusivament d'arrancar, alimentar, supervisar i finalitzar FreeRDP.
- Afegit `FreeRdpBackend.execute_session_plan()` per executar plans ja preparats sense repetir polítiques ni pre-flight.
- `connect()` es manté com a façana compatible que prepara i delega.
- Les credencials només existeixen durant l'execució i continuen enviant-se per stdin.
- Centralitzada la protecció contra sessions concurrents i la desconnexió.
- Mantinguda la compatibilitat amb la vista històrica `_process`.
- Ampliat el contracte `RemoteDesktopBackend` amb preparació i execució explícites.
- Afegits 7 tests específics d'execució.

## Fase 4.11.4 — Pre-flight

- Afegit un informe immutable únic `RdpPreflightReport`.
- Comprovacions prèvies de DNS, connectivitat TCP, executable FreeRDP, smartcard/PCSC, PKCS#11, USB i càmera.
- Estats canònics `pass`, `warning`, `fail` i `skipped`, amb codis estables.
- Les dependències obligatòries bloquegen la preparació abans d'executar FreeRDP.
- Les incidències opcionals es conserven com advertiments i diagnòstic sanititzat.
- El contenidor de producció activa el pre-flight i reutilitza els serveis compartits.
- Afegits 8 tests específics.

## Fase 4.11.3 — RdpSessionPlan immutable

- Afegit `RdpSessionPlan` com a representació immutable completa de la sessió preparada.
- El pla conté la comanda final, la configuració efectiva, funcionalitats degradades, advertiments i diagnòstic sanititzat.
- Afegits `RdpSessionWarning`, `RdpSessionDiagnostic` i `RdpSessionPlanError` amb codis estables.
- La contrasenya queda exclosa del pla i de la comanda; només es conserva l'ús segur de l'entrada estàndard.
- `FreeRdpBackend.connect()` consumeix ara el pla preparat sense alterar encara la responsabilitat d'execució.
- Integrades la degradació segura de capacitats i les validacions obligatòries d'àudio, vídeo i impressores en la preparació.
- Afegits 7 tests específics d'immutabilitat, seguretat, diagnòstic, degradació i bloqueig.

## Fase 4.11.2 — Normalització de paràmetres FreeRDP

- Afegit `FreeRdpArgumentNormalizer` com a component independent, determinista i reutilitzable.
- Els paràmetres d'una sola instància i els toggles oposats resolen conflictes amb la regla estable «últim valor efectiu».
- Eliminats duplicats exactes i ordenades canònicament les redireccions repetibles.
- El mode pantalla completa preval sobre amplària i alçària explícites; dimensions incompletes es rebutgen.
- Validada la presència coherent de servidor, usuari i entrada segura de credencials per `stdin`.
- Bloquejada explícitament qualsevol serialització de contrasenyes en la comanda.
- La normalització és idempotent i s'aplica sempre al resultat del builder definitiu.
- Afegides deu proves específiques de conflictes, ordre, coherència, privacitat i integració.

## Fase 4.11.1 — Builder definitiu de la comanda FreeRDP

- Creat un únic `FreeRdpCommandBuilder` autoritatiu per construir la invocació efectiva de FreeRDP.
- Afegits `RdpCommandRequest` i `RdpCommand` immutables, sense cap camp de contrasenya.
- `FreeRdpBackend` manté l'API pública existent i delega en el nou builder.
- Conservats l'ordre estable dels arguments, les polítiques remotes, la degradació segura i totes les redireccions.
- Mantingut un adaptador mínim per compatibilitat amb cridades antigues.
- Afegides sis proves específiques d'immutabilitat, privacitat, delegació, determinisme i compatibilitat.

## Fase 4.10.5 — Diagnòstic complet de FreeRDP

- Consolida versió detectada, salut, cobertura, memòria cau i compatibilitat.
- Manté l’auditoria segura: només publica si la versió és coneguda.
- Afig quatre proves de diagnòstic i privacitat.

## Fase 4.10.4 — Auditoria de discrepàncies de capacitats FreeRDP

- Afegida auditoria estructurada de canvis entre configuració efectiva i capacitats detectades.
- Els resultats idèntics es dedupliquen per evitar soroll en els logs.
- Es registren transicions de compatibilitat, connexió permesa, capacitats sol·licitades, no suportades i bloquejants.
- L'auditoria s'executa abans de cada intent de connexió i mai bloqueja la sessió per una fallada pròpia.
- No es registren rutes, eixida bruta de FreeRDP, servidor, usuari ni credencials.
- Afegides quatre proves específiques.

## Fase 4.10.3 — Validació de configuració segons capacitats de FreeRDP

- Afegit un resultat immutable de compatibilitat entre la configuració efectiva i les capacitats detectades.
- Separades les capacitats sol·licitades, no suportades i bloquejants.
- Les funcions opcionals incompatibles es diagnostiquen sense bloquejar la sessió.
- Les polítiques explícitament obligatòries generen una incompatibilitat bloquejant.
- Afegits camps estables d'auditoria sense rutes ni eixida bruta de FreeRDP.
- Ampliat el diagnòstic amb compatibilitat, connexió permesa i llistes de discrepàncies.
- Afegides quatre proves noves.

## Fase 4.10.2 — Memòria cau segura de capacitats de FreeRDP

- Afegida una instantània en memòria de procés amb TTL configurable per evitar executar repetidament `xfreerdp3 /help` i `/buildconfig`.
- Afegits refresc forçat i invalidació explícita per a actualitzacions del sistema o canvis d’empaquetat.
- El diagnòstic diferencia resultats `live` i `cache` i publica l’antiguitat arrodonida de la instantània.
- La memòria cau només conserva l’estat immutable ja sanejat; no persisteix eixida bruta, rutes addicionals ni dades d’usuari.
- Afegides quatre proves noves.

## Fase 4.10.1 — Detecció base de capacitats de FreeRDP

- Ampliat el servei existent de detecció d’RDPECAM amb un catàleg immutable de capacitats consumides per XAAC.
- Detectats de manera passiva els canals Smartcard, clipboard, unitats, USB, àudio d’eixida, micròfon, multimon i RDPECAM a partir de `/help`, `/buildconfig` i plugins instal·lats.
- Afegits recompte estable, consulta genèrica `supports()` i camps segurs per a auditoria estructurada.
- El diagnòstic publica cada capacitat per separat i manté l’evidència limitada a resultats operatius.
- Els errors de detecció ja no incorporen textos lliures del sistema; només exposen el tipus estable de l’excepció.
- Afegides quatre proves noves.

## Fase 4.9.9 — compatibilitat binària passiva del mòdul PKCS#11

- Afegida inspecció mínima de la capçalera ELF sense carregar ni executar la biblioteca.
- Detectada la classe de 32 o 64 bits i comparada amb la del procés local.
- Afegits codis estables: `not-checked`, `compatible`, `invalid-format`, `bitness-mismatch` i `inspection-failed`.
- El diagnòstic publica compatibilitat i bits mantenint oculta la ruta completa.
- No es resolen símbols, no s'inicialitza PKCS#11 i no es consulten tokens, certificats, claus ni PIN.
- Afegides quatre proves noves.

## Fase 4.9.8 — disponibilitat local segura del mòdul PKCS#11

- Afegit `Pkcs11ModuleService` per comprovar la disponibilitat local del mòdul configurat sense carregar-lo.
- Afegits codis estables: `not-configured`, `available`, `not-found`, `not-a-file`, `not-readable` i `check-failed`.
- El diagnòstic publica només el nom base, la disponibilitat, el codi i el detall estable.
- La ruta completa no apareix en diagnòstic i no es consulten tokens, certificats, claus ni PIN.
- Afegides 4 proves noves.

## Fase 4.9.5 — Auditoria estructurada de transicions Smartcard

- Afegits camps d'auditoria estables per a estat, política, infraestructura PC/SC, servei, recompte de lectors, presència de targeta i compliment de la política obligatòria.
- El controlador registra únicament transicions reals d'estat i evita repetir esdeveniments idèntics en cada comprovació periòdica.
- Els registres no inclouen noms de lector, missatges variables del proveïdor, ATR, certificats, PIN ni identitat de la targeta.
- L'esdeveniment `smartcard_state_changed` inclou l'estat anterior i el nou estat mitjançant camps `clau=valor` aptes per a diagnòstic i correlació.
- Afegides quatre proves específiques.

## Fase 4.9.4 — Política obligatòria de Smartcard

- Afegit `SmartCardPolicyMode` amb els modes efectius `disabled`, `optional` i `required`.
- Centralitzats els recursos obligatoris de la política (`pcsc`, `reader` i `card`) en la instantània immutable Smartcard.
- El bloqueig de connexió usa ara missatges estables derivats de `SmartCardStatusCode`, sense dependre del text variable de `libpcsclite` o del sistema.
- Les polítiques opcionals continuen permetent la connexió encara que no hi haja targeta, lector o servei PC/SC disponible.
- El diagnòstic exporta el mode efectiu i els requisits que bloquegen la sessió.
- Mantinguda la privacitat: no es consulta ni es mostra ATR, PIN, certificat o identitat de la targeta.
- Afegides quatre proves específiques.

## Fase 4.9.3 — Codis estables d’estat Smartcard

- Afegit `SmartCardStatusCode` amb estats estables per a subsistema desactivat, disponibilitat, infraestructura PC/SC, lector, targeta i errors de detecció.
- Diferenciades explícitament la biblioteca absent, el servei `pcscd` inaccessible, l’absència de lectors, el lector preferit no disponible i la targeta no inserida.
- Afegides descripcions de diagnòstic independents dels missatges variables del sistema i de `libpcsclite`.
- Propagats el codi i el detall d’estat a l’estat immutable de l’aplicació i a l’informe de diagnòstic.
- Mantinguda l’auditoria segura: no es consulta ni s’exposa ATR, certificat, PIN o identitat de la targeta.
- Afegides quatre proves específiques.

## Fase 4.9.2 — Instantània local PC/SC i diagnòstic de lectors

- Propagada a l’estat de l’aplicació una instantània PC/SC reutilitzable amb disponibilitat de biblioteca, estat de `pcscd`, recompte i noms de lectors.
- Identificats els lectors amb targeta present sense consultar ATR, certificats, PIN ni identitat de la targeta.
- Diagnòstic ampliat amb l’estat complet de la pila local PC/SC i els lectors detectats.
- Mantinguda una representació immutable i d’ordre estable per evitar resultats inconsistents.
- Afegida cobertura de tests del servei, controlador i informe de diagnòstic.

## Fase 4.9.1 — Configuració base de Smartcard

- Centralitzada la semàntica efectiva de detecció obligatòria i redirecció RDP.
- Validació segura de dependències i del filtre de lector preferit.
- Auditoria de polítiques remotes de smartcard sense exposar dades del lector.
- Diagnòstic ampliat amb política, valor efectiu i origen de cada camp.
- Cobertura de tests per configuració, validació, redirecció i auditoria.

## Fase 4.8.8 — tancament i consolidació del bloc de teclat

- Centralitzada la normalització dels noms de distribució per a configuració explícita, detecció XKB i fallback per idioma.
- El catàleg intern d'àlies és immutable i exposa un contracte públic estable mitjançant `supported_layouts()`.
- Afegida la consulta `is_supported()` per validar àlies, KLID directes i layouts personalitzats sense construir una sessió RDP.
- Endurida la regressió de configuracions XKB múltiples, variants catalanes, espais i guions baixos.
- Revisada la compatibilitat amb `/kbd:layout` de FreeRDP 3 i tancat formalment el bloc 4.8.
- Afegits nou casos de prova de consolidació.


## Fase 4.8.6 — catàleg ampliat de distribucions de teclat

- Ampliat el catàleg d'àlies a distribucions habituals d'Europa, Amèrica i Àsia oriental.
- Afegit suport diferenciat per portugués de Portugal i Brasil, anglés dels EUA i Regne Unit, castellà d'Espanya i llatinoamericà, i variants regionals de francés i alemany.
- Els noms XKB habituals (`se`, `dk`, `cz`, `ua`, `jp`, `kr`, etc.) es converteixen als identificadors KLID corresponents de Windows.
- Les configuracions explícites accepten indistintament guions i guions baixos, sense afectar els identificadors hexadecimals ni el mode `auto`.
- La validació, les polítiques remotes, el diagnòstic, l'auditoria i l'argument `/kbd:layout` reutilitzen el mateix catàleg central.
- Afegides catorze proves específiques.


## Fase 4.7.8 — auditoria estructurada del porta-retalls

- La política efectiva del porta-retalls es registra abans de construir l'ordre FreeRDP.
- Els missatges d'auditoria utilitzen camps estables `clau=valor` i no inclouen credencials ni contingut copiat.
- Es registren el perfil, el mode, les direccions efectives, les sobreescriptures i les normalitzacions.
- Les polítiques desactivades o restringides generen esdeveniments específics per facilitar el suport.
- L'aplicació registra quan una política de porta-retalls prové del servidor remot o de la memòria cau validada.
- Afegides cinc proves específiques. Amb aquesta fase queda tancat el bloc 4.7.


## Fase 4.7.7 — normalització preventiva de polítiques desactivades

- Les polítiques `custom` amb `enabled = false` es normalitzen internament a `direction = off` i `files = off`.
- La normalització no modifica el fitxer de configuració ni el comportament de FreeRDP, que continua rebent `-clipboard`.
- El diagnòstic diferencia les normalitzacions preventives dels valors sobreescrits per un perfil.
- S'exporten `Policy normalized` i `Normalized settings` per facilitar auditories.
- Les polítiques habilitades i els perfils administratius conserven exactament la semàntica anterior.
- Afegides cinc proves específiques.


## Fase 4.6.8 — correcció detecció RDPECAM

- Corregida la detecció de plugins RDPECAM: `Path.glob()` ja no es considera suport disponible només perquè existeix el directori de plugins.
- La capacitat RDPECAM només es marca com disponible quan FreeRDP l'anuncia o existeix realment un fitxer de plugin coincident.
- Afegida una prova de regressió per a directoris de plugins existents sense RDPECAM.
- Actualitzat el test de construcció de comanda perquè injecte explícitament una capacitat RDPECAM disponible.

# Changelog

## Fase 4.6.7 — enduriment final de la detecció de vídeo

- Els nodes V4L2 es validen estrictament amb el patró segur `/dev/videoN`.
- La detecció aplica una ordenació numèrica estable (`video2` abans de `video10`).
- Els nodes duplicats, inesperats o fora de `/dev` s'ignoren i s'exporten al diagnòstic.
- Els noms de càmera provinents de sysfs es normalitzen per evitar salts de línia i caràcters de control en els informes.
- Una entrada de nom invàlida ja no interromp la detecció de la resta de càmeres.
- Afegides sis proves específiques.

## Fase 4.6.6 — instantània efectiva de la política de vídeo

- Afegit `VideoPolicyMode` amb els modes estables `disabled` i `enabled`.
- La política exposa els recursos obligatoris que tenen efecte real.
- `required = true` amb `enabled = false` es registra com a requisit ignorat i no activa la càmera implícitament.
- L'informe de diagnòstic mostra `Policy mode`, `Effective required resources` i `Ignored requirements`.
- Es manté intacta la política `VIDEO-001`, la detecció V4L2 i la generació `/dvc:rdpecam`.
- Afegides cinc proves específiques.

## Fase 4.6.5 — errors estructurats i presentació accionable de vídeo

- Afegida la categoria funcional `ErrorCategory.VIDEO`.
- `VIDEO-001` es transforma en un `ApplicationError` específic sense perdre el missatge tècnic original del backend.
- La interfície mostra un títol, una explicació i una acció recomanada específics per a càmeres obligatòries no disponibles.
- El detall V4L2 queda reservat al diagnòstic i al tooltip tècnic.
- Els errors de vídeo no retornen el focus al camp de contrasenya.
- Actualitzats i compilats els catàlegs en català, castellà i anglés.
- Afegides tres proves específiques.

## Fase 4.6.4 — codis estables de diagnòstic de vídeo

- Afegit `VideoStatusCode` amb els estats `disabled`, `ready`, `no-camera` i `detection-failed`.
- Afegides descripcions estables per a cada estat, independents dels textos d'error del sistema.
- L'informe de diagnòstic exporta ara `Status code` i `Status detail` per a vídeo.
- Es manté intacta la semàntica de `ready`, la política `required` i el codi `VIDEO-001`.
- Afegides quatre proves específiques i ampliada la prova de diagnòstic.

## Fase 4.6.3 — política obligatòria de vídeo

- Afegida validació prèvia de càmeres quan `video.required = true`.
- La sessió es bloqueja abans d'executar FreeRDP si no hi ha cap càmera local.
- Els errors de detecció V4L2 es conserven com a detall de l'error.
- Afegit el codi estructurat `VIDEO-001`.
- La detecció prèvia només s'executa quan el vídeo és obligatori.
- La mateixa instantània de vídeo es reutilitza en construir l'ordre FreeRDP.
- Afegides cinc proves específiques.

## Fase 4.6.2 — Detecció local i diagnòstic de vídeo/webcam

- `VideoRedirectionService` detecta nodes locals V4L2 a `/dev/video*`.
- Els noms descriptius es llegeixen des de `/sys/class/video4linux`; si no estan disponibles, es conserva el nom del node.
- Nova instantània immutable `VideoRedirectionStatus` amb disponibilitat, preparació, dispositius detectats i error de detecció.
- La detecció no s'executa quan la redirecció de vídeo està desactivada.
- L'informe de diagnòstic inclou càmeres detectades, disponibilitat, estat `ready` i errors.
- El backend RDP i el diagnòstic comparteixen la mateixa instància de `VideoRedirectionService`.
- S'han afegit sis proves específiques.

## Fase 4.5.7 — Enduriment final de la detecció d'àudio

## Fase 4.6.1 — Model i configuració segura de vídeo/webcam

- Nou `VideoRedirectionConfig` immutable amb `enabled` i `required`.
- Nou `VideoRedirectionService` injectable.
- Redirecció de càmera mitjançant el canal dinàmic FreeRDP `/dvc:rdpecam`.
- Nova secció `[video]` i compatibilitat amb l'opció antiga `rdp.webcam`.
- Suport de configuració remota per a `video.enabled` i `video.required`.
- El servei de vídeo es comparteix amb el backend FreeRDP.
- Nou proves automatitzades.


- `AudioRedirectionService` consulta només els recursos habilitats: `sinks` per a reproducció i `sources` per a enregistrament.
- Una fallada en un recurs desactivat ja no pot invalidar la política activa.
- Les ordres `pactl` s'executen amb `LC_ALL=C` i `LANG=C` per estabilitzar el parser en sistemes traduïts.
- Els errors sense missatge conserven almenys el nom de l'excepció per facilitar el diagnòstic.
- Es manté l'ordre estable dels arguments FreeRDP i tota la compatibilitat de configuració.
- S'han afegit cinc proves de casos límit.

## Fase 4.5.6 — Instantània efectiva de la política d'àudio

- S'ha afegit `AudioPolicyMode` amb els modes `disabled`, `playback`, `recording` i `playback+recording`.
- La política exposa els recursos obligatoris que tenen efecte real.
- Els requisits configurats sobre recursos desactivats s'identifiquen explícitament com a ignorats.
- L'informe de diagnòstic exporta el mode efectiu, els requisits aplicats i els requisits ignorats.
- No es modifica el comportament de connexió ni la compatibilitat amb configuracions anteriors.
- S'han afegit cinc proves específiques.

## Fase 4.5.5 — Errors estructurats i presentació accionable d'àudio

- Els bloquejos de reproducció i micròfon es classifiquen en la categoria funcional `AUDIO`.
- El controlador transforma `AUDIO-001` i `MICROPHONE-001` en errors estructurats sense alterar el detall original del backend.
- La interfície mostra títols, explicacions i accions diferents per a l'eixida d'àudio i el micròfon.
- Els detalls de `pactl` es mantenen exclusivament per al diagnòstic i no apareixen en el missatge principal.
- Els errors de recursos d'àudio no retornen el focus al camp de contrasenya.
- S'han afegit sis proves específiques.

# Changelog

## Fase 4.5.4 — Codis estables i diagnòstic complet d'àudio

- S'han afegit codis globals estables: `disabled`, `ready`, `partial`, `audio-service-unavailable` i `no-enabled-devices`.
- Cada recurs disposa també d'un codi independent: `disabled`, `ready`, `audio-service-unavailable` o `no-device`.
- El diagnòstic exporta els codis i les explicacions de reproducció i enregistrament sense interpretar missatges lliures.
- La disponibilitat parcial diferencia quan només els altaveus o només el micròfon estan preparats.
- Quan tots dos recursos estan desactivats no es consulta `pactl`.
- S'han afegit sis proves específiques.

## Fase 4.5.3 — Polítiques obligatòries d'àudio i micròfon

- `playback_required` bloqueja la sessió abans d'executar FreeRDP si no hi ha cap dispositiu de reproducció disponible.
- `recording_required` bloqueja la sessió si no hi ha cap micròfon local real disponible.
- Els errors retornen els codis estables `AUDIO-001` i `MICROPHONE-001`.
- Els errors del servidor d'àudio conserven el detall tècnic retornat per `pactl`.
- La detecció prèvia només s'executa quan hi ha algun recurs obligatori.
- Una única instantània d'àudio es reutilitza durant la validació i la construcció de la comanda FreeRDP.
- El diagnòstic mostra els estats efectius `Playback ready` i `Recording ready`.
- S'han afegit set proves específiques i s'ha ampliat la prova de diagnòstic.

## Fase 4.5.2 — Detecció local i diagnòstic d'àudio

- `AudioRedirectionService` detecta dispositius locals mitjançant `pactl`.
- La detecció és compatible amb PulseAudio i amb PipeWire mitjançant `pipewire-pulse`.
- Es diferencien dispositius de reproducció i micròfons reals.
- Les fonts virtuals acabades en `.monitor` no es consideren micròfons.
- Es detecten els dispositius predeterminats i es dedupliquen noms sense distingir majúscules.
- Nova instantània immutable `AudioRedirectionStatus`.
- L'informe de diagnòstic mostra backend, disponibilitat, dispositius i errors de detecció.
- El backend RDP i el diagnòstic comparteixen la mateixa instància del servei d'àudio.
- S'han afegit sis proves específiques.

## Fase 4.5.1 — Model i configuració segura d'àudio

- S'ha afegit la secció `[audio]` amb reproducció, enregistrament i polítiques `required`.
- Nou model immutable `AudioRedirectionConfig`.
- Nou servei injectable `AudioRedirectionService`.
- FreeRDP genera `/sound` i `/microphone` exclusivament des de la política d'àudio efectiva.
- Compatibilitat de lectura amb les opcions antigues `rdp.audio` i `rdp.microphone`.
- La configuració remota pot administrar els quatre camps d'àudio.
- S'han afegit proves unitàries i d'integració.

## Fase 4.4.8 — Instantània efectiva de la política d’impressores

- Afig modes estables de política: `all`, `allowlist`, `default-only` i `allowlist+default-only`.
- Exporta la llista blanca efectiva després de normalitzar-la.
- Identifica entrades ignorades per ser invàlides o duplicades.
- Inclou el mode i el codi d’estat en el registre de bloqueig RDP.
- Amplia l’informe de diagnòstic amb la política realment aplicada.

## Fase 4.4.7 — Codis estables de diagnòstic d'impressores

- Afegit `PrinterStatusCode` per identificar l'estat de la redirecció sense analitzar missatges textuals.
- Es diferencien els estats `disabled`, `ready`, `cups-unavailable`, `no-printers`, `no-authorised-printer` i `no-default-printer`.
- L'informe de diagnòstic exporta el codi estable i una explicació segura per a suport.
- Es manté intacta la semàntica de `ready` i la política obligatòria de fases anteriors.
- Afegides sis proves específiques.

## Fase 4.4.6.1 — Correcció de preservació del missatge d'error

- El controlador torna a conservar el text original retornat pel backend per a `PRINTER-001`.
- El missatge amigable continua sent responsabilitat exclusiva del presentador de la interfície.
- Es manté el detall tècnic en `ApplicationError.technical_detail` per al diagnòstic.
- Corregida la regressió detectada per `test_apply_rdp_session_result_preserves_printer_error_category`.

## Fase 4.4.6 — Presentació accionable dels errors d'impressores

- Afegit un presentador d'errors independent de GTK i reutilitzable.
- `PRINTER-001` mostra un missatge segur que explica el requisit i indica com resoldre'l.
- El detall tècnic de CUPS deixa d'aparéixer en el text principal i es conserva per al diagnòstic.
- El botó de diagnòstic es destaca quan existeix informació tècnica útil.
- Els errors d'impressores no tornen el focus al camp de contrasenya, perquè les credencials no són la causa.
- Afegides tres proves específiques.

## Fase 4.4.5 — Errors estructurats de política d'impressores

- La política obligatòria d'impressores retorna el codi estable `PRINTER-001`.
- S'ha afegit la categoria funcional `PRINTERS` al model centralitzat d'errors.
- El controlador conserva la causa d'impressió i no la converteix en un error genèric de sessió.
- La GUI i els informes de diagnòstic poden mostrar la causa tècnica exacta per a suport.
- Es manté la compatibilitat amb els backends que no proporcionen `error_code`.

## Fase 4.4.4 — robustesa i seguretat dels noms d'impressora

- Força `LC_ALL=C` i `LANG=C` en `lpstat` per obtindre una eixida estable.
- Ignora cues CUPS amb noms no segurs per a FreeRDP.
- Deduplica cues i arguments `/printer` sense distingir majúscules.
- Normalitza espais i duplicats en `allowed_printers`.
- Una llista blanca configurada però invàlida bloqueja totes les cues en lloc de permetre-les.
- Sis proves noves.

## Fase 4.4.3 - Política obligatòria d'impressores i comprovació prèvia

- Afegida l'opció `printers.required`, configurable localment o remotament.
- La sessió es bloqueja abans d'executar FreeRDP si la impressora és obligatòria i CUPS no està disponible.
- La sessió també es bloqueja quan cap cua local compleix la llista blanca o el filtre de cua predeterminada.
- Amb `required = false` es conserva el comportament no bloquejant anterior.
- La detecció CUPS es reutilitza durant tot l'intent de connexió i només s'executa una vegada.
- El diagnòstic mostra si la redirecció d'impressores és obligatòria.
- Afegides set proves específiques.

## Fase 4.4.2 - Diagnòstic de redirecció d'impressores

- Afegida una secció específica d'impressores a l'informe de diagnòstic.
- L'informe mostra cues detectades, redirigides, rebutjades, cua predeterminada i errors de CUPS.
- Afegit l'estat `ready` per detectar llistes blanques sense cap coincidència.
- El backend FreeRDP i el diagnòstic comparteixen la mateixa instància injectable del servei d'impressores.
- Afegides cinc proves específiques.

## Fase 4.4.1 - Redirecció segura d'impressores

- Afegit descobriment de cues locals CUPS mitjançant `lpstat`.
- Afegida selecció per llista blanca i opció de redirigir només la impressora predeterminada.
- FreeRDP rep arguments explícits `/printer:<cua>` en lloc de compartir totes les impressores.
- Mantinguda compatibilitat temporal amb l'antic camp `rdp.printers`.
- Afegida configuració local/remota i sis proves específiques.

## Fase 4.3.3 - Redirecció segura d'emmagatzematge

- Redirecció RDPDR de memòries USB, discos extraïbles i CD/DVD.
- Descobriment segur de muntatges sota arrels administratives.
- Suport per a mitjans presents en iniciar la sessió i hotplug.
- Configuració local/remota, diagnòstic i proves.

## Fase 4.3.1

- Afegida infraestructura de configuració USB segura amb llistes VID:PID, política remota, validació i diagnòstic.


## Fase 4.2 revisada — Smart Card PC/SC nativa

- Eliminat l'ús de `pcsc_scan` i el parseig de la seua eixida.
- Nova integració directa amb `libpcsclite` mitjançant `ctypes`.
- Afegit un contracte `SmartCardProvider` injectable i proves sense maquinari.
- Eliminats processos persistents, timeouts i traces repetitives.
- Detecció directa de lectors i targetes inserides.
## Internacionalització

- Afegit GNU gettext amb `msgid` en anglés.
- Afegides traduccions completes al català, castellà i anglés.
- Externalitzades les cadenes visibles de la GUI i els errors mostrats a l'usuari.
- Afegits scripts d'actualització i compilació dels catàlegs.
- Evitada una doble execució accidental de la consulta DNS en el controlador.


## 0.1.0

- Estructura inicial.
- Finestra GTK4 mínima.

## Fase 3.3

- Afegit `ApplicationContext` per agrupar configuració, preferències, serveis i runtime.
- `ApplicationController` pot rebre el context complet mitjançant injecció de dependències.
- El punt d'entrada construeix explícitament el context abans de crear el controlador.
- Mantinguda temporalment la signatura anterior del controlador per compatibilitat amb els tests existents.
- Eliminada una doble execució accidental de la comprovació de xarxa.

## Fase 3.4

- `ApplicationController` exigeix ara un `ApplicationContext` obligatori.
- Eliminada la construcció antiga amb dependències individuals.
- Eliminats els àlies temporals dels executors; el controlador usa `ApplicationRuntime` directament.
- Adaptats els tests del controlador a la construcció mitjançant context.

## Fase 3.5

- Afegit un model centralitzat d'errors amb codi estable, categoria,
  severitat, recuperabilitat, missatge per a l'usuari i detall tècnic.
- Afegida la fàbrica `ApplicationErrors` per als errors coneguts de
  xarxa, DNS, disponibilitat RDP, credencials i sessions.
- `ApplicationState` incorpora ara `current_error`.
- `ApplicationController` publica errors estructurats i els elimina
  automàticament quan el servei es recupera.
- Afegits cinc tests específics del sistema d'errors.
- Recuperada la importació necessària de `UserPreferences` en el
  controlador.

## Fase 3.6 — Sistema de diagnòstic

- Afegit `DiagnosticService` per generar informes de suport.
- Afegits `DiagnosticReport` i `DiagnosticSection`.
- Els informes inclouen versió, sistema, xarxa, DNS, RDP, error actual i últimes línies del log.
- Els informes no inclouen usuari, contrasenya ni altres credencials.
- Afegit `DiagnosticService` a `ApplicationServices`.
- Afegit `ApplicationController.generate_diagnostic_report()`.
- Afegits set tests del sistema de diagnòstic.

## Fase 3.7

- Afegit el contracte `RemoteDesktopBackend` per desacoblar el controlador de FreeRDP.
- Reanomenada la implementació concreta a `FreeRdpBackend`.
- Mantingut `RdpService` com a àlies temporal de compatibilitat.
- `ApplicationServices` exposa ara el backend mitjançant `remote_desktop`.
- El controlador utilitza el contracte genèric per comprovar, connectar i desconnectar sessions.

## Fase 3.8 - Configuració remota

- Afegit `RemoteConfigurationService` amb superposicions JSON validades.
- La configuració local continua sent sempre la base i el mecanisme de reserva.
- Afegida memòria cau atòmica de l'última configuració remota vàlida.
- HTTPS és obligatori per defecte; HTTP només es permet explícitament per a desenvolupament.
- `device_name` no es pot modificar remotament perquè identifica físicament el terminal.
- Afegida la secció `[remote_config]` a `config.ini`.

## Fase 3.9 — Diagnòstic gràfic

- Afegida una finestra modal per visualitzar l'informe de diagnòstic.
- Afegit un botó «Diagnòstic» a la finestra principal.
- L'informe es desa automàticament i es pot copiar al porta-retalls.
- Afegida l'opció de desar una còpia en una ubicació triada per l'usuari.
- Afegides traduccions en català, castellà i anglés.
- Afegit un nom de fitxer suggerit estable als informes.

- Redissenyat el peu de la finestra principal: versió alineada a l'esquerra i accés a diagnòstic discret amb icona simbòlica.

## Fase 4.0 - Política i seguretat de configuració

- Afegits els àmbits `SYSTEM`, `USER` i `REMOTE`.
- Afegida una política central de camps configurables.
- La configuració remota utilitza ara una llista blanca estricta.
- Les claus remotes desconegudes o no autoritzades es rebutgen i es registren.
- Afegides metadades sobre l'origen efectiu dels valors.
- L'informe de diagnòstic mostra origen, claus aplicades i claus rebutjades.
- Afegits tests de política, seguretat i procedència de configuració.

## Fase 4.1 — Visualització i rendiment RDP

- Afegida configuració de resolució en mode finestra (`width`, `height`).
- Afegit canvi dinàmic de resolució i `smart sizing`.
- Afegida profunditat de color configurable (16, 24 o 32 bits).
- Afegits perfils de xarxa FreeRDP: `auto`, `modem`, `broadband`,
  `broadband-low`, `broadband-high`, `wan` i `lan`.
- Afegides polítiques de ClearType, composició, fons de pantalla,
  animacions, arrossegament de finestres, temes i cache de bitmap.
- Integració completa amb configuració local, configuració remota,
  política de la Fase 4.0, diagnòstic i construcció de l'ordre FreeRDP.
- Afegides validacions i nou conjunt de proves automatitzades.


## Fase 4.2 — Smart Card

S'ha afegit monitorització periòdica PC/SC, detecció de `pcscd`, lectors i targetes, lector preferit, redirecció `/smartcard`, bloqueig opcional de la connexió quan la targeta és obligatòria, configuració remota autoritzada, indicador en temps real i informació de diagnòstic.

## Fase 4.3.2 — Redirecció USB segura

- Detecció directa de dispositius USB mitjançant `/sys/bus/usb/devices`.
- Selecció per llista blanca `VID:PID` i exclusió per llista bloquejada.
- Bloqueig preventiu de dispositius HID, hubs i controladors sense fil.
- Integració amb FreeRDP 3.5 mitjançant `/usb:id:<vid>:<pid>#...`.
- Diagnòstic de dispositius detectats, redirigits i rebutjats.
- Servei USB injectable i proves específiques.

## Fase 4.6.8 — FreeRDP capability detection

- Added `FreeRdpCapabilityService` with initial RDPECAM detection through
  `xfreerdp3 /buildconfig`, `/help`, and installed client plug-ins.
- Added a dedicated `FreeRDP capabilities` diagnostic section.
- Added structured error `VIDEO-002` when video redirection is enabled but
  the installed FreeRDP client lacks RDPECAM support.
- RDP sessions are now blocked before launch when RDPECAM is unavailable,
  preventing silent or misleading connection failures.
- Preserved `VIDEO-001` for required local-camera availability failures.

### Correcció posterior de la Fase 4.6.8

- Quan `video.enabled = true` i `video.required = false`, l'absència de RDPECAM ja no bloqueja la sessió RDP: la connexió continua sense afegir `/dvc:rdpecam`.
- `VIDEO-002` queda reservat a configuracions amb vídeo obligatori (`video.required = true`).
- La comprovació de capacitat RDPECAM es realitza abans de validar la càmera local obligatòria, de manera que els errors `VIDEO-002` i `VIDEO-001` siguen deterministes.
- Afegides proves de regressió per comprovar tant la degradació opcional com el bloqueig obligatori.

### Correcció de diagnòstic en temps d'execució de la Fase 4.6.8

- La política efectiva de vídeo es resol ara en un únic punt del backend i
  també s'aplica quan `build_command()` s'utilitza directament.
- Una configuració opcional sense RDPECAM queda garantida sense
  `/dvc:rdpecam` en la comanda final.
- La comanda efectiva de FreeRDP es registra en
  `~/.local/state/xaac-thinclient/xaac-thinclient.log` sense incloure la
  contrasenya.
- La sortida d'error de FreeRDP ja no es descarta: es registra i es mostra com
  a error de connexió quan el procés finalitza amb un codi no zero.

## Fase 4.6.8 — neteja final de diagnòstic

- La sortida bruta de `stdout` i `stderr` de FreeRDP ja no es mostra en la interfície de login.
- La GUI presenta únicament errors estructurats de XAAC; el detall tècnic queda reservat al log i a `ApplicationError.technical_detail`.
- La línia de comandes efectiva de FreeRDP passa de nivell `INFO` a `DEBUG`.
- Es mantenen la captura de diagnòstic al log i les correccions de detecció de RDPECAM.
- Afegida una prova de regressió que impedeix exposar missatges interns de FreeRDP en pantalla.

### Fase 4.6.8 — estabilització dels tests localitzats

- Els tests del controlador ja no depenen de textos literals en anglés per als errors de sessió, àudio, micròfon i vídeo.
- Les comprovacions utilitzen els missatges generats per `ApplicationErrors`, mantenint la validació dels codis, categories i detalls tècnics.
- Això evita fallades quan la interfície s'executa en català o en una altra traducció disponible.

## Fase 4.7.1 — Política independent del porta-retalls

- Afegida la secció `[clipboard]` amb l'opció `enabled`.
- Mantinguda la compatibilitat amb l'opció anterior `rdp.clipboard` quan no existeix la nova secció.
- La política es pot distribuir mitjançant configuració remota amb la llista blanca de la Fase 4.0.
- FreeRDP rep explícitament `+clipboard` o `-clipboard` segons la política efectiva.
- Afegides proves de càrrega, compatibilitat, valor predeterminat, política remota i construcció de l'ordre.

## Fase 4.7.2 — Estat efectiu i diagnòstic del porta-retalls

- Afegit `ClipboardRedirectionService` com a única font per construir la política i els arguments de FreeRDP.
- Incorporats els modes estables `enabled` i `disabled` mitjançant `ClipboardPolicyMode`.
- Incorporats codis d'estat estables mitjançant `ClipboardStatusCode`.
- L'informe de diagnòstic inclou política efectiva, estat, disponibilitat i argument aplicat a FreeRDP.
- El backend RDP deixa de construir directament `+clipboard` i `-clipboard`.
- Afegides cinc proves de política, estat, integració RDP i diagnòstic.


## Fase 4.7.3 — Control direccional del porta-retalls

- Afegides les opcions `clipboard.direction` i `clipboard.files`.
- Admesos els modes `all`, `local`, `remote` i `off`.
- El text i els fitxers es poden restringir independentment.
- Mantinguda la compatibilitat exacta: `all/all` continua generant `+clipboard`.
- Les polítiques restringides generen `/clipboard:direction-to:...,files-to:...`.
- Integració amb configuració local, configuració remota i diagnòstic.


## Fase 4.7.4 — Perfils administratius del porta-retalls

- Afegida l'opció `clipboard.profile`.
- Incorporats els perfils `custom`, `full`, `text-only`, `local-to-remote`,
  `remote-to-local` i `disabled`.
- El perfil `custom` manté la compatibilitat completa amb `enabled`, `direction`
  i `files`.
- Els perfils resolen una política efectiva única abans de construir la comanda
  FreeRDP.
- Afegit suport de configuració remota i informació del perfil en diagnòstic.
- Afegides set proves de càrrega, validació, resolució, política remota i diagnòstic.

## Fase 4.7.5 — Traçabilitat de la política del porta-retalls

- L'informe de diagnòstic mostra l'origen efectiu de `clipboard.enabled`,
  `clipboard.profile`, `clipboard.direction` i `clipboard.files`.
- Els orígens es presenten com `system`, `remote` o `cache` sense exposar
  informació sensible.
- Afegit l'indicador `Remotely managed` per identificar ràpidament si alguna
  part de la política efectiva prové de la configuració central o de la seua
  còpia validada en memòria cau.
- La traçabilitat es conserva per camp, de manera que una política híbrida
  local/remota queda representada correctament.
- Afegides quatre proves de diagnòstic i procedència.

## Fase 4.7.6 — Detecció de paràmetres sobreescrits pels perfils

- Afegit `ClipboardPolicyResolution` per distingir entre configuració declarada
  i política efectiva.
- Els perfils administratius informen quins camps (`enabled`, `direction` o
  `files`) han estat sobreescrits realment.
- El perfil `custom` continua aplicant tots els camps sense cap sobreescriptura.
- El diagnòstic mostra `Profile overrides settings` i `Overridden settings`.
- Mantinguda la compatibilitat de l'API existent `get_policy()`.
- Afegides cinc proves de resolució, compatibilitat i diagnòstic.

## Fase 4.8.1 — Configuració del teclat RDP

- Nova secció `[keyboard]` amb `layout = auto`.
- Resolució segura d'àlies de teclat català, espanyol, anglés dels EUA, francés i alemany.
- Acceptació d'identificadors de distribució Windows explícits en format `0x00000000`.
- Anunci de la distribució al servidor mitjançant `/kbd:layout:<id>` de FreeRDP 3.
- Gestió de `keyboard.layout` mitjançant política remota.
- Inclusió de la configuració i distribució efectiva en l'informe de diagnòstic.
- Validació anticipada de distribucions desconegudes i cobertura específica de tests.

## Fase 4.8.2 — Detecció del teclat local

- El mode `keyboard.layout = auto` prioritza ara la distribució XKB real del thin client.
- La detecció consulta, per ordre, `XKB_DEFAULT_LAYOUT`, `localectl` i `setxkbmap`.
- Es reconeix la variant catalana d'XKB (`layout=es`, `variant=cat`) i s'anuncia com a teclat català de Windows.
- Quan la detecció local no està disponible, es manté el fallback compatible a `application.language`.
- Les distribucions configurades explícitament no executen cap detecció local.
- El diagnòstic mostra l'origen, la distribució i la variant detectades sense incloure dades sensibles.
- Afegida cobertura de tests per a entorn, `localectl`, `setxkbmap`, variant catalana i fallback.

## Fase 4.8.3 — Estat estructurat del teclat

- Afegit `KeyboardStatusCode` amb els codis estables `configured`, `local-detected` i `language-fallback`.
- Cada resolució de teclat incorpora una descripció estable independent dels textos de les eines del sistema.
- El diagnòstic mostra el codi i el detall de l'estat efectiu del teclat.
- Es manté intacta la detecció XKB, el fallback per idioma i l'argument FreeRDP `/kbd:layout:<id>`.
- Afegides quatre proves específiques per a configuració explícita, detecció local, fallback i diagnòstic.

## Fase 4.8.4 — Traçabilitat administrativa del teclat

- L'informe de diagnòstic mostra l'origen efectiu de `keyboard.layout`.
- Els orígens es representen amb valors estables: `system`, `remote` o `cache`.
- Afegit l'indicador `Keyboard remotely managed` per distingir una configuració local d'una política central o de la seua còpia validada en memòria cau.
- La traçabilitat no modifica la detecció XKB, el fallback per idioma ni l'argument FreeRDP efectiu.
- Afegides proves per als orígens de sistema, política remota i memòria cau.

## Fase 4.8.5 — Auditoria segura del teclat

- Afegit un registre estructurat de la resolució efectiva del teclat abans de construir la comanda FreeRDP.
- L'auditoria inclou configuració declarada, layout efectiu, identificador Windows, mode automàtic, origen de detecció i codi d'estat.
- Quan s'utilitza el fallback per idioma es genera un esdeveniment específic per facilitar el diagnòstic administratiu.
- Les polítiques remotes i les seues còpies validades en memòria cau registren l'origen de `keyboard.layout`.
- No es registren credencials, text escrit, variables completes d'entorn ni cap altra dada personal.
- Afegides quatre proves específiques d'auditoria, integració RDP i política remota.

## Fase 4.8.7 — layouts personalitzats de Windows

- Afegida la sintaxi administrativa `custom:0xNNNNNNNN` per anunciar qualsevol KLID vàlid de Windows sense ampliar el catàleg intern.
- Els identificadors personalitzats es validen estrictament: prefix `0x` i exactament huit dígits hexadecimals.
- Es manté la compatibilitat amb els KLID directes ja admesos (`0xNNNNNNNN`).
- Els valors personalitzats funcionen també mitjançant polítiques remotes, diagnòstic, auditoria i generació de `/kbd:layout`.
- Afegides quatre proves específiques.

## Fase 4.9.6 — Resolució determinista del lector preferit

- Afegit `SmartCardReaderMode` amb els modes estables `any` i `preferred`.
- Separat el nombre total de lectors PC/SC detectats del nombre de lectors elegibles després d'aplicar `preferred_reader`.
- Afegit l'indicador estable de coincidència del lector preferit.
- El diagnòstic mostra el mode de selecció, la coincidència i els recomptes detectat/elegible.
- L'auditoria incorpora només mode, recomptes i booleans; no registra noms de lector ni dades de la targeta.
- Afegides quatre proves específiques.

## Fase 4.9.7 — Configuració base de PKCS#11

- Afegida l'opció `smartcard.pkcs11_module` per declarar una biblioteca PKCS#11 local.
- La ruta es valida com a absoluta, sense caràcters de control i amb longitud limitada.
- La política pot gestionar-se remotament i conserva traçabilitat per camp.
- El diagnòstic només mostra si està configurada i el nom base de la biblioteca, no la ruta completa.
- En aquesta fase el mòdul no es carrega i no es consulten tokens, certificats, PIN ni claus.
- Afegides quatre proves específiques.


## Fase 4.10.6 — degradació segura i tancament del bloc FreeRDP

- Afegit un pla immutable de degradació segura de capacitats opcionals.
- Les funcions opcionals no suportades es desactiven abans de construir la comanda RDP.
- Les capacitats obligatòries no suportades bloquegen la connexió amb `FREERDP-CAP-001`.
- El diagnòstic publica les capacitats degradades i el seu recompte.
- L'auditoria conserva només camps estables, sense rutes, servidor, usuari ni eixida bruta.
- Tancat el Bloc 4.10 de detecció i compatibilitat de FreeRDP.

## Fase 4.12.4 — Selecció de gràfics i còdecs

- Afegida selecció immutable i conservadora del pipeline gràfic FreeRDP.
- Integrades capacitats GFX, AVC420 i AVC444 detectades des de l'ajuda real de FreeRDP.
- Selecció basada en perfil, maquinari, qualitat de xarxa i superfície de visualització.
- Mode thin-client per a maquinari limitat, AVC420 per a WAN/xarxa degradada i AVC444 només en escenaris segurs.
- Degradació segura al pipeline tradicional quan GFX no està disponible.
- Diagnòstic i advertiments estables dins de RdpSessionPlan.

## Correcció posterior a la Fase 4.12.7 — tancament voluntari sense reconnexió

- L'executor RDP diferencia ara una fallada recuperable d'un tancament voluntari informat per FreeRDP.
- `ERRINFO_LOGOFF_BY_USER`, `ERRINFO_RPC_INITIATED_LOGOFF` i `ERRINFO_RPC_INITIATED_DISCONNECT` finalitzen la sessió sense iniciar el backoff de reconnexió.
- Els errors reals de transport continuen utilitzant la política de reconnexió configurada.
- Afegides proves de regressió per evitar l'obertura automàtica d'una nova sessió després del logoff.

### Hotfix Fase 4.13.4 — compatibilitat de l'enduriment

- Restaurat el conjunt estable de `__all__` del paquet públic `xaac_thinclient.rdp`.
- Mantinguda la importació compatible dels tipus d'enduriment sense publicar-los com a contractes estables.
- Admesa la família oficial `/clipboard:*` de FreeRDP 3.
- Els arguments retornats per un servei de clipboard injectable es validen com a arguments de confiança exactes, mantenint el bloqueig de secrets, controls i opcions desconegudes externes.
- Corregides les regressions en auditoria i proves del servei de clipboard.

## Fase 4.13.6 — Tancament del bloc de seguretat RDP

- Consolidat el pipeline TLS, certificats, NLA, credencials, enduriment i auditoria.
- Fixades les invariants de seguretat del `RdpSessionPlan` i de l'execució sense shell.
- Confirmat el contracte públic estable de polítiques TLS, seguretat i credencials.
- Mantinguts l'enduriment i l'auditoria com a mecanismes interns importables sense ampliar `__all__`.
- Afegida documentació transversal en `docs/rdp-security-block-lifecycle.md`.
- Afegides sis proves de tancament del Bloc 4.13.


## Fase 4.14.1 — Esquema versionat de polítiques remotes

- Afegit l'esquema immutable `RemotePolicyDocument` amb versió actual 1.
- El format nou separa `schema_version` de l'objecte `policy`.
- Rebuig segur de versions futures, embolcalls parcials i metadades superiors desconegudes.
- Compatibilitat explícita amb documents històrics, classificats com a versió 0.
- La versió efectiva i l'estat legacy queden disponibles en el resultat i en l'auditoria.
- La memòria cau versionada es valida abans de ser aplicada.
- Afegida documentació i huit proves específiques.

## Fase 4.14.5 — Identitat del dispositiu

- Afegida una identitat persistent, immutable i local per a cada Thin Client.
- Afegit el destinatari signat `target` a l'esquema de polítiques remotes.
- Rebuig segur de polítiques destinades a un altre dispositiu.
- Integració de la identitat en URL, capçalera HTTP, cache i rollback.
- Afegides 8 proves de persistència, vinculació i manipulació criptogràfica.

## Fase 5.1 — Arrencada automàtica

- Afegida política immutable `[system]` per activar l'arrencada i establir un retard segur.
- Afegit reconciliador XDG idempotent amb escriptura atòmica i permisos 0600.
- Sense execució d'ordres de sistema ni ús de shell.
- Degradació segura amb `AUTOSTART-IO-001`, diagnòstic estable i auditoria sense dades sensibles.
- Els camps poden ser governats per política remota.
- Afegides huit proves específiques.

## Fase 5.2 — Sessió gràfica dedicada

- Afegida política immutable per publicar una sessió XDG dedicada i definir-ne el nom visible.
- L'ordre executable és fixa, sense shell ni possibilitat d'injecció mitjançant política remota.
- Afegit reconciliador idempotent amb escriptura atòmica, permisos 0600 i protecció de descriptors aliens.
- Degradació segura amb `SESSION-IO-001`, estat estable per a diagnòstic i auditoria sense dades sensibles.
- Els dos camps nous poden ser governats per política remota.
- Afegides huit proves específiques.

## Fase 5.3 — Política base de mode quiosc

- Afegida una política immutable per resoldre les restriccions de la interfície en mode quiosc.
- El mode actiu força pantalla completa, bloqueja el tancament ordinari i oculta la configuració.
- La via d'eixida d'emergència és local i no pot ser desactivada per política remota.
- Les accions d'apagat i reinici són explícitament opt-in.
- Afegits estats i codis estables per a diagnòstic i auditoria sense dades sensibles.
- Aquesta fase no executa ordres, no usa shell i no modifica encara el gestor de finestres o d'accés.
- Afegides huit proves específiques.

## Fase 5.4 — Aplicació efectiva del mode quiosc

- Afegit `KioskRuntimeService`, independent de GTK, per aplicar la política quiosc a qualsevol finestra compatible.
- Aplicació real de pantalla completa i ocultació de decoracions quan el mode quiosc està actiu.
- Bloqueig explícit del tancament ordinari de la finestra.
- Conservació del tancament intern segur de l'aplicació.
- Eixida administrativa local amb `Ctrl+Alt+Shift+Q`, sotmesa a la política local de recuperació.
- Afegits codis estables de diagnòstic i auditoria no sensible.
- Afegides huit proves específiques de runtime quiosc.

## Fase 5.5 — Accions d'energia controlades

- Afegit `PowerActionService` amb accions tipades d'apagada i reinici.
- Les ordres són fixes, s'executen sense shell i amb temps màxim acotat.
- La política quiosc bloqueja l'execució abans de crear cap procés quan les accions no estan autoritzades.
- Afegida degradació segura amb codis estables de política, execució i rebuig del sistema.
- Auditoria estructurada sense stdout, stderr, usuaris, rutes ni dades de sessió.
- Afegides onze proves específiques.

## Fase 5.7 — Persistència i recuperació del mode segur

- Afegit `KioskRecoveryService` per conservar el mode segur entre reinicis.
- Estat versionat en JSON sota XDG State, amb escriptura atòmica i permisos 0600.
- Els documents corruptes, desconeguts o futurs degraden de forma segura i mantenen el bloqueig.
- La recuperació només pot autoritzar-se localment; la política remota no pot netejar l'estat.
- Diagnòstic i auditoria estructurats sense rutes, usuaris, servidors ni dades sensibles.
- Afegides tretze proves específiques.

## Fase 6.1 — Estructura del paquet Debian

- Afegit l'esquelet declaratiu `debian/` per al paquet font i binari `xaac-thinclient`.
- Configurada una construcció sense privilegis amb `debhelper` 13 i `pybuild`.
- Declarada l'arquitectura `all` i les dependències d'execució necessàries.
- Alineada la versió Debian nativa amb la versió publicada en `pyproject.toml`.
- No s'han afegit scripts de manteniment, serveis ni operacions de xarxa.
- Afegida documentació de límits i huit proves específiques.
- Corregida la compatibilitat dels tests amb Python 3.10 eliminant la dependència directa de `tomllib`.

## Fase 6.2 — Instal·lació de recursos Debian

- Recursos visuals integrats dins del paquet Python.
- Configuració inicial neutra per a `/etc/xaac-remote`.
- Manifest declaratiu d'instal·lació i documentació Debian.
- Cobertura de tests per a rutes, permisos i absència de dades locals.

## Fase 6.3 — Entrypoints i integració d'escriptori

- Consolidat `xaac-thinclient` com a únic entrypoint executable del paquet.
- Afegida una entrada `.desktop` sense terminal, shell ni arguments dinàmics.
- Instal·lació declarativa de l'entrada gràfica i de la icona del projecte.
- Alineat `StartupWMClass` amb l'identificador GTK `org.xaac.thinclient`.
- Documentats els límits respecte de systemd, sessions i scripts Debian.
- Afegides huit proves específiques.

## Fase 6.8 — Tancament del Bloc 6

- Afegit un validador reproduïble de l'arbre font, la construcció binària i el paquet `.deb`.
- Auditada la identitat, arquitectura i càrrega útil obligatòria del paquet.
- Rebutjats caches, logs, VCS i material criptogràfic privat en font i binari.
- Documentat el cicle d'instal·lació, reinstal·lació, retirada, `purge`, actualització i rollback en un entorn Debian 13 aïllat.
- Congelat el contracte de lliurament i tancat formalment el Bloc 6.
- Afegides huit proves específiques.

## Fase 7.1 — Instal·lador base del Thin Client

- Afegit un instal·lador de sistema separat del paquet Debian.
- Validació estricta de Debian 13 i arquitectura `amd64` abans de modificar el sistema.
- Verificació de la identitat i arquitectura del paquet `.deb` local.
- Instal·lació no interactiva, sense recomanats, sense shell dinàmic ni descàrrega de scripts externs.
- Exclusió mútua amb `flock` per impedir instal·lacions simultànies.
- Afegit mode de simulació `--dry-run` i documentació dels límits de la fase.
- Afegides nou proves específiques.

## Fase 7.1.2 — Integritat del paquet d’instal·lació

- Afegida verificació SHA-256 opcional del paquet `.deb` abans d’invocar APT.
- Validació estricta d’empremtes de 64 caràcters hexadecimals.
- Comparació normalitzada i fallada tancada davant discrepàncies.
- La verificació s’executa abans de requerir root, adquirir el bloqueig o modificar el sistema.
- `--sha256` queda restringit al mode `--install-package` i només es pot declarar una vegada.
- Sense fitxers d’empremtes, descàrregues ni execució dinàmica de shell.
- Afegides nou proves específiques.

## Fase 7.1.4 — Instal·lador integral i cicle de vida

- Afegits modes d'estat, verificació, reinstal·lació i desinstal·lació.
- Implementada verificació posterior de dpkg, fitxers, configuració i servei systemd.
- Conservació de configuració per defecte i purge només mitjançant opció explícita.
- Afegits informes estructurats d'estat i registre persistent d'auditoria amb permisos restrictius.
- Integrats dry-run, bloqueig i validació d'opcions en tot el cicle de vida.
- Tancat el subbloc 7.1 de l'instal·lador.
- Afegides vint proves específiques de cicle de vida.

## Fase 7.3 — Adaptació completa al Dell Wyse 3040

- Afegida detecció estricta i no identificadora del Dell Wyse 3040 mitjançant DMI.
- Incorporat un perfil de maquinari condicional, idempotent i testejable sobre un arbre alternatiu.
- Afegits microcodi Intel, firmware gràfic, d'àudio i de xarxa, i eines de diagnòstic de vídeo, eMMC, sensors i SMART.
- Configurats zram, TRIM, thermald, journal volàtil acotat i ajustos conservadors de memòria i eMMC.
- Afegits serveis systemd per aplicar el perfil abans de la sessió gràfica i registrar un diagnòstic no sensible.
- Mantinguda la compatibilitat de la imatge amb maquinari amd64 genèric: el perfil no s'aplica sense coincidència DMI.
- Afegida documentació de validació física i trenta proves específiques.

## Fase 7.4 — Provisionament, identitat i primer arrencament

- Afegida neutralització explícita de la imatge mestra abans de clonació.
- Implementada generació idempotent de `machine-id` i identitat XAAC aleatòria de 256 bits.
- Afegit hostname únic derivat sense exposar l'identificador complet del dispositiu.
- Incorporat provisionament inicial abans de la sessió gràfica i estat persistent restrictiu.
- Afegida obtenció opcional de política exclusivament per HTTPS amb verificació SHA-256.
- Implementada degradació segura sense xarxa i reintents temporitzats amb retard aleatori.
- Rebutjades configuracions amb claus desconegudes, duplicades, rutes simbòliques o valors insegurs.
- Afegits estat i diagnòstic estructurats sense identificadors ni dades sensibles.
- Afegida documentació operativa i trenta proves específiques.

## Fase 7.6 — Recuperació i restauració

- Afegit un motor de recuperació que reutilitza la restauració segura de la Fase 7.5.
- Incorporats diagnòstic previ, restauració completa de fàbrica i restauració amb preservació selectiva.
- Afegida còpia restrictiva de configuració XAAC, xarxa i certificats, amb rebuig de rutes insegures.
- Incorporada descàrrega exclusivament HTTPS amb verificació SHA-256 obligatòria i escriptura atòmica.
- Afegits estat persistent, historial d'auditoria i diagnòstic systemd abans de la sessió gràfica.
- Mantinguda la confirmació destructiva explícita: cap servei restaura automàticament un disc.
- Afegida documentació operativa i cobertura específica de recuperació.

## Fase 7.7 — Validació final i lliurament

- Auditoria final reproduïble del Bloc 7.
- Validació de coherència entre scripts i imatge Debian 13.
- Informe d’acceptació estructurat i paquet de lliurament amb SHA-256.
- Detecció de residus de construcció, identitats no neutralitzades i rutes insegures.

## Correcció de configuració neutra i recursos visuals

- Restaurada la configuració empaquetada a mode de desenvolupament i polítiques de quiosc/apagat desactivades per defecte.
- Sincronitzat `assets/css/style.css` amb el recurs CSS inclòs dins del paquet Python.
- El mode de producció i les polítiques de quiosc continuen aplicant-se des de la imatge o el procés de provisionament, no des del paquet base.

## Selecció de múltiples servidors RDP

- Afegit `servers.ini` amb una llista administrativa de destinacions RDP.
- Afegit selector desplegable de servidor en la finestra d'inici de sessió.
- Cada destinació pot definir nom visible, host, port, domini i estat habilitat.
- El canvi de servidor reinicia de manera segura les comprovacions DNS i RDP.
- Els resultats asíncrons obsolets del servidor anterior es descarten.
- Es manté compatibilitat amb el camp històric `device.server` quan no existeix `servers.ini`.


## Documentation
- Added comprehensive configuration guide (phase 15.5).


## 15.7
- Added diagnostics guide.


## 15.8
- Added comprehensive development guide.


## [15.8] - Documentation
- Expanded testing guide.


## [15.9] Packaging documentation
- Added comprehensive packaging guide.


## 15.10
- Afegida la guia Image Builder.


## [15.11]
- Documentació: afegida guia de roadmap i traçabilitat.


## 15.12 - Release 1.0.0
- Prepared stable Release 1.0.0 documentation and release checklist.

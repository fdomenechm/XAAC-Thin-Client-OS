# Fase 6.4 — Servei systemd d’usuari

XAAC és una aplicació gràfica i, per tant, s’instal·la com una unitat de
**systemd d’usuari**. No s’executa com a `root`, no crea una sessió gràfica
artificial i no incorpora variables `DISPLAY` o `DBUS_SESSION_BUS_ADDRESS`
fixades. La unitat només s’inicia dins d’una sessió gràfica existent.

La unitat instal·lada és:

`/usr/lib/systemd/user/xaac-thinclient.service`

## Cicle de vida

La unitat està vinculada a `graphical-session.target` mitjançant `After`,
`PartOf` i `WantedBy`. `ExecStart` apunta directament a
`/usr/bin/xaac-thinclient`, sense wrappers ni shell.

El reinici és `on-failure`, amb una espera de tres segons i un límit de cinc
intents cada trenta segons. Un tancament normal de XAAC no provoca un bucle de
reinici. `TimeoutStopSec` i `KillMode=mixed` permeten acabar també els processos
fills que no hagen respost durant el tancament ordenat.

## Enduriment

La unitat aplica `NoNewPrivileges`, `PrivateTmp`, `ProtectSystem=strict`,
`ProtectHome=read-only`, proteccions del nucli, `RestrictSUIDSGID`,
`LockPersonality` i `UMask=0077`.

L’accés d’escriptura queda limitat als directoris que el disseny actual usa per
preferències, estat, autoinici i descriptor de sessió. Les rutes porten el
prefix `-` perquè la seua absència inicial no impedisca arrancar; XAAC les crea
de manera segura quan són necessàries.

No s’aplica `PrivateDevices`: FreeRDP pot necessitar càmera, smartcard, àudio o
redirecció USB segons la política local. Tampoc es restringeix la xarxa, perquè
la connexió RDP i les polítiques remotes formen part de la funció principal.

## Activació

La fase instal·la la unitat però no força la seua activació. Els scripts Debian
i la política d’habilitació es tractaran en una fase posterior. Per a una prova
manual dins de la sessió gràfica:

```sh
systemctl --user daemon-reload
systemctl --user enable --now xaac-thinclient.service
```

Per consultar l’estat i els registres de systemd:

```sh
systemctl --user status xaac-thinclient.service
journalctl --user -u xaac-thinclient.service
```

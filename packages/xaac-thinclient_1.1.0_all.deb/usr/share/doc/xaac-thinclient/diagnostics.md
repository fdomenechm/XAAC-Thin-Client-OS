# Diagnostics

## Overview
This guide describes logging, diagnostics, troubleshooting and information collection.

### Logging
- Configurable log levels.
- Console and file outputs.
- Structured messages.

### Troubleshooting
- Configuration validation
- Policy diagnostics
- FreeRDP invocation
- GTK startup
- USB, printer, audio, video, smartcard, multi-monitor

### Support bundle
Collect logs, configuration (excluding secrets), version and environment.

# Fase 6.2 — Instal·lació dels recursos del paquet Debian

Aquesta fase defineix el mapa d'instal·lació sense introduir encara serveis
`systemd`, scripts de manteniment ni migracions.

## Destinacions

- El codi Python, les traduccions i els recursos visuals s'instal·len com a part
  del paquet `xaac_thinclient` mitjançant `pybuild`.
- La configuració inicial s'instal·la en `/etc/xaac-thinclient` a partir de
  `debian/defaults/`.
- La documentació seleccionada s'instal·la en
  `/usr/share/doc/xaac-thinclient` mitjançant `debian/xaac-thinclient.docs`.

## Principis de seguretat

Els fitxers inicials de `/etc` són neutres: no contenen noms d'usuari, noms de
dispositiu, servidors ni credencials. Les funcions sensibles, inclosa la
redirecció de vídeo, romanen desactivades per defecte.

Els recursos gràfics ja no depenen de la ubicació de l'arbre font ni del
directori de treball. `paths.py` els resol dins del mateix paquet Python.

## Fora de l'abast

La creació de directoris d'estat, canvis de propietari, migracions, unitats
`systemd` i accions de `postinst` es tractaran en fases posteriors.

# Configuration Guide

This document describes the configuration model of XAAC Thin Client Remote 1.1.0.

## Configuration sources
- Default application settings.
- Local configuration files.
- Remote policies (highest priority where applicable).

## Main areas
- Connection parameters.
- FreeRDP options.
- Display, multimonitor and scaling.
- Audio, printer, USB, smartcard and camera redirection.
- Branding.
- Logging and diagnostics.
- Language and translations.

## Configuration precedence
1. Built-in defaults.
2. Local configuration.
3. Remote policies.
4. Runtime validation.

## Best practices
- Prefer remote policies in managed deployments.
- Avoid manual edits while kiosk mode is active.
- Validate changes before mass deployment.


# Instal·lació

Aquesta guia descriu els procediments suportats per instal·lar **XAAC Thin Client Remote 1.1.0** i preparar un entorn de desenvolupament. La plataforma de producció de referència és **Debian 13 amd64**.

## 1. Modalitats suportades

| Modalitat | Finalitat |
|---|---|
| Paquet Debian `.deb` | Instal·lació de producció |
| Codi font + `.venv` | Desenvolupament i proves |

La construcció o instal·lació d'una ISO no forma part d'aquest projecte.

## 2. Requisits de producció

El paquet Debian declara les dependències reals en `debian/control`, incloent FreeRDP 3, GTK 4, PyGObject i `python3-cryptography`.

Abans d'instal·lar, és recomanable comprovar:

```bash
python3 --version
xfreerdp3 /version || xfreerdp /version
```

## 3. Instal·lació des d'un paquet Debian

Construïu primer el paquet seguint [Empaquetat Debian](packaging.md). Després:

```bash
sudo apt install ./xaac-thinclient_1.1.0_all.deb
```

Per reinstal·lar:

```bash
sudo apt install --reinstall ./xaac-thinclient_1.1.0_all.deb
```

APT resol les dependències declarades del paquet usant les fonts configurades al sistema.

## 4. Instal·lador auxiliar

El projecte conserva `scripts/install-thinclient.sh` per validar i instal·lar un `.deb` local de manera controlada.

Comproveu les opcions disponibles:

```bash
./scripts/install-thinclient.sh --help
```

Per validar prèviament l'entorn:

```bash
./scripts/install-thinclient.sh --check
```

Quan el paquet s'ha transportat per un canal extern, pot verificar-se amb una empremta coneguda mitjançant `--sha256 <empremta-sha256>`.

## 5. Fitxers instal·lats

El paquet instal·la, entre altres:

- `xaac-thinclient` i `xaac-thinclient-migrate`;
- configuració inicial a `/etc/xaac-thinclient/`;
- llançador `.desktop`;
- servei systemd d'usuari;
- recursos gràfics i documentació.

Consulteu `debian/xaac-thinclient.install`, `debian/xaac-thinclient.docs` i [Estructura del paquet Debian](debian-package-structure.md).

## 6. Execució

Des d'una sessió gràfica:

```bash
xaac-thinclient
```

La configuració empaquetada és deliberadament neutra i segura. Els modes administrats o de quiosc s'han de configurar mitjançant els mecanismes propis de XAAC Thin Client Remote, no mitjançant una imatge de sistema operatiu inclosa en aquest repositori.

## 7. Entorn de desenvolupament

El projecte exigeix Python **3.13**.

```bash
git clone <URL_DEL_REPOSITORI>
cd xaac-thinclient
./scripts/bootstrap-dev.sh
source .venv/bin/activate
```

Si l'entorn ja està creat:

```bash
source .venv/bin/activate
./scripts/test.sh
```

Per executar l'aplicació des del repositori:

```bash
./scripts/run-dev.sh
```

Consulteu [Desenvolupament](development.md).

## 8. Actualització

Construïu el nou `.deb` i instal·leu-lo amb APT:

```bash
sudo apt install ./xaac-thinclient_1.1.0_all.deb
```

Els scripts de manteniment i les migracions de configuració s'encarreguen de preservar la compatibilitat definida pel paquet.

## 9. Desinstal·lació

```bash
sudo apt remove xaac-thinclient
```

Per eliminar també la configuració gestionada pel paquet:

```bash
sudo apt purge xaac-thinclient
```

Reviseu sempre si existeixen dades locals o polítiques administratives que cal conservar abans d'un `purge`.

## 10. Verificació postinstal·lació

```bash
command -v xaac-thinclient
command -v xaac-thinclient-migrate
dpkg -s xaac-thinclient
dpkg -L xaac-thinclient
```

Confirmeu també que els fitxers requerits a `/etc/xaac-thinclient/` són regulars, llegibles i no exposen secrets.

## 11. Resolució d'incidències

Si l'aplicació no inicia:

1. executeu-la des d'un terminal;
2. valideu la configuració;
3. confirmeu la presència de GTK 4/PyGObject i FreeRDP 3;
4. consulteu [Diagnòstic](diagnostics.md).

Si falla la construcció del paquet, executeu:

```bash
./scripts/validate-debian-package.sh --source
```

i reviseu [Empaquetat Debian](packaging.md).

# Fase 6.3 — Entrypoints i integració d'escriptori

## Objectiu

Publicar una única ordre estable, `xaac-thinclient`, i integrar-la amb els menús
gràfics de Debian sense duplicar la lògica d'arrencada ni introduir wrappers de shell.

## Entrypoint executable

L'ordre es declara en `pyproject.toml`:

```toml
[project.scripts]
xaac-thinclient = "xaac_thinclient.__main__:main"
```

El backend de construcció genera l'executable en `/usr/bin`. El mòdul
`xaac_thinclient.__main__` retorna el codi d'eixida de l'aplicació i també permet
l'execució equivalent amb `python3 -m xaac_thinclient`.

## Entrada d'escriptori

El paquet instal·la `xaac-thinclient.desktop` en `/usr/share/applications`.
L'entrada executa exclusivament `xaac-thinclient`, no usa terminal, no incorpora
arguments procedents de configuració i declara l'identificador gràfic estable
`org.xaac.thinclient`.

## Icona

La imatge ja distribuïda amb l'aplicació s'instal·la en
`/usr/share/pixmaps/xaac-thinclient.png`. No es descarrega ni es genera cap
recurs durant la instal·lació.

## Límits de la fase

Aquesta fase no crea serveis systemd, sessions gràfiques, scripts de
manteniment ni modificacions d'autoinici. Eixes responsabilitats continuen
separades per a les fases posteriors del Bloc 6.

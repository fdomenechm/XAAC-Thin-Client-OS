# Fase 6.6 — Scripts de manteniment Debian

## Objectiu

Integrar les migracions i el servei systemd d'usuari amb el cicle de vida de
`dpkg`, sense executar codi interactiu, perdre configuracions locals ni deixar
el paquet en un estat incoherent per una dada antiga malformada.

## Scripts

- `preinst`: no modifica configuracions. Reserva un punt segur per a futures
  comprovacions prèvies.
- `postinst`: executa `xaac-thinclient-migrate` sobre els tres INI de sistema,
  recarrega systemd d'usuari i habilita globalment la unitat.
- `prerm`: deshabilita globalment la unitat només en eliminació o
  desconfiguració; no ho fa durant una actualització.
- `postrm`: recarrega systemd i conserva backups i dades d'usuari.

## Degradació segura

El migrador torna un codi distint de zero davant configuracions invàlides o de
versions futures, però `postinst` només emet un avís. El fitxer queda intacte i
la instal·lació pot completar-se. Les migracions correctes continuen sent
atòmiques, idempotents i auditables.

## Límits

La fase no crea usuaris, no inicia una sessió gràfica, no modifica el `$HOME`
de cap usuari i no elimina fitxers locals durant `purge`.

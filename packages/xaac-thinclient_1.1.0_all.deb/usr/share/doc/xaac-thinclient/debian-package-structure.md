# Fase 6.1 — Estructura del paquet Debian

Aquesta fase introdueix únicament l'esquelet declaratiu necessari perquè XAAC
Thin Client puga convertir-se posteriorment en un paquet Debian reproduïble.
No instal·la encara recursos en rutes del sistema, no crea serveis, no executa
scripts de manteniment i no construeix cap repositori APT.

## Contracte inicial

- paquet font i binari: `xaac-thinclient`;
- arquitectura binària: `all`, perquè el codi propi és Python pur;
- sistema de construcció: `debhelper` compatibilitat 13 amb `pybuild`;
- construcció sense privilegis mitjançant `Rules-Requires-Root: no`;
- format font natiu `3.0 (native)`;
- versió Debian alineada amb la versió Python `1.1.0`;
- dependències d'execució declarades, sense descàrregues ni scripts ocults.

## Límits de la fase

Queden reservats per a fases posteriors:

- el mapa definitiu de fitxers sota `/usr`, `/etc` i `/var`;
- la unitat `systemd`;
- les migracions de configuració;
- els scripts `preinst`, `postinst`, `prerm` i `postrm`;
- la construcció, signatura i publicació del repositori APT.

Els fitxers Debian són dades estàtiques. No alteren l'arquitectura de
l'aplicació, les polítiques remotes, el diagnòstic ni l'auditoria en temps
d'execució.

# Fase 6.5 — Migracions de configuració

XAAC incorpora un esquema versionat per als fitxers INI instal·lats pel paquet Debian.
La versió actual és `1` i es declara en la secció `[xaac]` amb
`schema_version = 1`.

El motor de migració és explícit, seqüencial i idempotent. Una configuració sense
metadades es considera versió `0`; la migració inicial només afig les metadades i
preserva opcions, valors, seccions desconegudes i comentaris existents.

Abans d'una escriptura es crea, quan correspon, una còpia `*.pre-vN.bak`. La
substitució és atòmica, conserva els permisos i sincronitza fitxer i directori.
No se segueixen enllaços simbòlics ni es modifiquen fitxers no regulars.

Les configuracions malformades o amb una versió superior a la suportada fallen
de manera tancada: no s'escriu res i el resultat ofereix diagnòstic i auditoria
estructurada sense exposar cap valor de configuració.

En aquesta fase el motor queda disponible com a API Python. La invocació des de
`postinst` o altres scripts Debian es reserva per a la Fase 6.6.

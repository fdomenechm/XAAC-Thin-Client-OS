# XAAC Thin Client Remote

**Client RDP lleuger, segur i administrable per a terminals Debian.**

XAAC Thin Client Remote és una aplicació gràfica basada en **Python 3.13**, **GTK 4** i **FreeRDP 3**. Està dissenyada per convertir equips de recursos limitats —especialment el **Dell Wyse 3040**— en terminals d'accés a escriptoris remots, amb una interfície simple, mode quiosc, polítiques administratives, diagnòstic integrat i degradació segura.

La versió estable actual és **1.1.0**. El projecte cobreix exclusivament l'aplicació XAAC Thin Client Remote, el seu entorn de desenvolupament i la construcció del paquet Debian `.deb`.

## Característiques principals

- Interfície gràfica GTK 4 orientada a l'ús en mode quiosc.
- Connexions RDP mitjançant FreeRDP 3.
- Compatibilitat amb pantalla completa, multimonitor, escalat i resolució dinàmica.
- Perfils automàtics de rendiment, xarxa i gràfics.
- Reconnexió automàtica davant interrupcions transitòries.
- Redirecció configurable d'àudio, micròfon, vídeo, impressores, unitats, USB, porta-retalls i smartcard.
- Selecció de distribució de teclat per a la sessió remota.
- Validació TLS, modes de seguretat RDP i credencials fora de la línia d'ordres.
- Configuració local, preferències d'usuari i polítiques remotes amb llista blanca.
- Signatura Ed25519, vigència, revisió, memòria cau i rollback de polítiques remotes.
- Identitat persistent del dispositiu i telemetria mínima opcional.
- Registre configurable i informes de diagnòstic sanititzats.
- Arrencada automàtica, sessió dedicada, supervisió i recuperació del mode quiosc.
- Empaquetat Debian i eines per construir, validar, clonar i recuperar imatges Debian 13.
- Branding i traduccions mitjançant GNU gettext.

## Requisits

### Entorn de producció

- Debian 13 o una distribució compatible.
- FreeRDP 3, amb l'executable `xfreerdp3`.
- GTK 4 i PyGObject.
- Python **3.13**.
- Accés de xarxa al servidor RDP.

Algunes funcions necessiten components addicionals, com CUPS per a impressores, PC/SC per a smartcards o suport RDPECAM en la compilació de FreeRDP per a vídeo.

### Entorn de desenvolupament

El projecte fixa Python 3.13 en `.python-version` i en `pyproject.toml`. En Debian o Zorin, l'script següent instal·la les dependències del sistema i prepara l'entorn virtual:

```bash
./scripts/install-dev.sh
```

També es pot preparar un entorn que ja dispose de les dependències del sistema amb:

```bash
./scripts/bootstrap-dev.sh
```

## Inici ràpid en desenvolupament

```bash
git clone <URL-DEL-REPOSITORI>
cd xaac-thinclient
./scripts/install-dev.sh
./scripts/run-dev.sh
```

Sense utilitzar els scripts auxiliars:

```bash
PYTHONPATH=src python3.13 -m xaac_thinclient
```

La configuració d'exemple per a desenvolupament es troba en `config/`.

> L'URL pública del repositori s'incorporarà quan es publique la versió estable.

## Instal·lació del paquet Debian

Quan es disposa d'un paquet construït:

```bash
sudo apt install ./xaac-thinclient_<versió>_all.deb
```

El paquet instal·la l'aplicació, els recursos, la configuració de sistema, les entrades d'escriptori i els components necessaris per a la integració amb Debian. La configuració de producció es gestiona mitjançant els fitxers i polítiques propis de XAAC Thin Client Remote.

Consulteu la [guia d'instal·lació](docs/installation.md), la [guia d'empaquetat](docs/packaging.md) i la [documentació Debian de referència](docs/reference/README.md).

## Configuració

La configuració segueix un model per àmbits:

1. **SYSTEM**: configuració administrativa local, habitualment en `/etc/xaac-remote/`.

XAAC Thin Client Remote també publica un contracte d'estat local de només lectura
al bus de sessió (`org.xaac.ThinClient1`, objecte `/org/xaac/ThinClient`). El Dock
l'utilitza per mostrar `available`, `connecting`, `active` o `error`; una fallada
de xarxa/DNS/servidor no converteix Remote en no disponible. La publicació és
best-effort i mai bloqueja l'aparició de la GUI principal.
2. **REMOTE**: subconjunt autoritzat que pot proporcionar el servidor de gestió.
3. **USER**: preferències personals admeses, emmagatzemades segons XDG.

La configuració local és sempre la base. Una política remota només pot modificar claus incloses explícitament en la llista blanca. Si el servei remot falla, l'aplicació intenta usar una memòria cau validada o una revisió anterior vàlida; si no és possible, continua amb la configuració local.

Fitxers d'exemple:

```text
config/
├── config.ini
├── device.ini
├── servers.ini
└── user.ini
```

Exemple mínim:

```ini
[application]
language = ca
logo = xaac-thinclient-logo.png
mode = development

[rdp]
domain = exemple.local
port = 3389
fullscreen = true
multimon = auto
security_mode = nla
certificate_mode = tofu

[remote_config]
enabled = false
```

La referència completa es desenvolupa en la [guia de configuració](docs/configuration.md).

## Execució i mode quiosc

En desenvolupament, l'aplicació es pot executar amb:

```bash
./scripts/run-dev.sh
```

En producció, XAAC Thin Client Remote pot habilitar, segons la configuració administrativa:

- arrencada automàtica;
- sessió gràfica dedicada;
- política de mode quiosc;
- supervisió i reinici amb límits;
- mode segur i recuperació;
- accions controlades d'apagat i reinici.

Aquestes funcions estan desactivades o configurades de manera conservadora en la configuració neutral del repositori. Consulteu la [documentació del sistema](docs/reference/README.md).

## Seguretat

XAAC Thin Client Remote aplica diverses mesures de protecció:

- la contrasenya RDP no forma part de la línia d'ordres;
- la comanda de FreeRDP es normalitza i valida mitjançant una llista d'opcions autoritzades;
- els informes i esdeveniments d'auditoria exclouen credencials i dades sensibles;
- les polítiques remotes poden exigir signatura Ed25519 i període de vigència;
- la configuració remota no pot substituir claus administratives protegides;
- USB, unitats, impressores, smartcards i porta-retalls estan sotmesos a polítiques explícites;
- les fallades de components opcionals degraden la funcionalitat sense exposar la sessió.

Les vulnerabilitats s'han de comunicar seguint [SECURITY.md](SECURITY.md).

## Diagnòstic i registre

El sistema de diagnòstic recopila informació útil sobre:

- versió i entorn d'execució;
- xarxa i DNS;
- configuració efectiva i origen de les polítiques;
- capacitats de FreeRDP;
- dispositius i canals de redirecció;
- sessió RDP i últim error estructurat;
- fragments recents del registre.

Per defecte, els informes es desen en:

```text
~/.local/state/xaac-thinclient/
```

El nivell de registre es controla amb la secció `[logging]` o temporalment amb `XAAC_LOG_LEVEL`:

```bash
XAAC_LOG_LEVEL=DEBUG ./scripts/run-dev.sh
```

Consulteu la [guia de diagnòstic](docs/diagnostics.md).

## Branding

El projecte diferencia entre:

- el logotip principal de l'entitat o organisme que desplega el terminal;
- el logotip propi de XAAC Thin Client Remote mostrat en el diàleg «Quant a»;
- el títol, autoria i altres metadades configurables del producte.

Els recursos empaquetats es troben en `src/xaac_thinclient/resources/`. Consulteu la [guia de branding](docs/branding.md) abans de substituir-los.

## Traduccions

Les cadenes visibles utilitzen GNU gettext. Els identificadors originals són en anglés i els catàlegs inclosos cobreixen català, castellà i anglés.

Per actualitzar-los:

```bash
./scripts/update-translations.sh
# Reviseu manualment els fitxers .po
./scripts/compile-translations.sh
```

Els catàlegs es troben en `src/xaac_thinclient/locale/`. Vegeu la [guia de traduccions](docs/translations.md).

## Proves

La suite cobreix configuració, polítiques, serveis, construcció de la comanda RDP, seguretat, redireccions, diagnòstic, mode quiosc i empaquetat Debian.

Amb l'entorn virtual preparat:

```bash
./scripts/test.sh
```

Per executar una selecció:

```bash
./scripts/test.sh tests/test_command_builder.py
./scripts/test.sh -k remote_policy
```

El projecte exigeix Python 3.13 per evitar diferències entre entorns. Consulteu la [guia de proves](docs/testing.md).

## Empaquetat Debian

El resultat de producció d'aquest repositori és el paquet Debian de XAAC Thin Client Remote. El projecte inclou:

- metadades i scripts del paquet sota `debian/`;
- validació de l'arbre font i del paquet amb `scripts/validate-debian-package.sh`;
- construcció reproduïble del `.deb` mitjançant `dpkg-buildpackage`;
- configuració inicial neutra, entrypoints, integració d'escriptori i servei systemd d'usuari.

Construcció recomanada:

```bash
./scripts/build-deb.sh
```

Els artefactes finals es publiquen dins de `dist/`:

```text
dist/
├── xaac-thinclient_1.1.0_all.deb
└── xaac-thinclient_1.1.0_all.evidence.json
```

El JSON d'evidència registra versió, arquitectura, nom de l'artefacte, mida, SHA-256, data UTC de construcció i resultat de les auditories. El projecte **no copia automàticament** el paquet a XAAC Thin Client OS; la integració consumeix explícitament l'artefacte de `dist/`. La construcció d'imatges ISO, clonació o personalització del sistema operatiu es gestiona en projectes independents.

Consulteu [Empaquetat](docs/packaging.md) i [Release 1.1.0](docs/release.md).

## Arquitectura del projecte

```text
Interfície GTK 4
        │
        ▼
Controlador i estat de l'aplicació
        │
        ▼
Serveis de configuració, dispositius i diagnòstic
        │
        ▼
Pla de sessió, seguretat i construcció de la comanda
        │
        ▼
FreeRDP 3
```

La configuració es resol de manera separada abans de preparar la sessió:

```text
Configuració de sistema
        +
Política remota validada
        +
Preferències d'usuari autoritzades
        │
        ▼
Configuració efectiva immutable
```

La descripció detallada es troba en [docs/architecture.md](docs/architecture.md).

## Estructura del repositori

```text
xaac-thinclient/
├── config/       # Configuració d'exemple per al desenvolupament
├── debian/       # Metadades natives del paquet Debian
├── docs/         # Documentació modular i referència tècnica
├── scripts/      # Desenvolupament, proves, traduccions i empaquetat Debian
├── src/          # Codi font i recursos de l'aplicació
└── tests/        # Suite automatitzada
```

Vegeu [docs/repository-layout.md](docs/repository-layout.md) per als criteris de manteniment.

## Documentació

El punt d'entrada de la documentació és [docs/README.md](docs/README.md).

| Àrea | Document |
|---|---|
| Arquitectura | [docs/architecture.md](docs/architecture.md) |
| Instal·lació | [docs/installation.md](docs/installation.md) |
| Configuració | [docs/configuration.md](docs/configuration.md) |
| Branding | [docs/branding.md](docs/branding.md) |
| Diagnòstic | [docs/diagnostics.md](docs/diagnostics.md) |
| Desenvolupament | [docs/development.md](docs/development.md) |
| Proves | [docs/testing.md](docs/testing.md) |
| Empaquetat | [docs/packaging.md](docs/packaging.md) |
| Traduccions | [docs/translations.md](docs/translations.md) |
| Roadmap | [docs/roadmap.md](docs/roadmap.md) |
| Releases | [docs/release.md](docs/release.md) |

## Contribució

Abans de proposar canvis:

1. prepareu l'entorn amb Python 3.13;
2. mantingueu separades la lògica, la interfície i l'accés al sistema;
3. no introduïu credencials ni dades sensibles en logs, diagnòstics o proves;
4. afegiu proves de regressió proporcionals al canvi;
5. executeu la suite abans de lliurar-lo.

Les normes completes es troben en [CONTRIBUTING.md](CONTRIBUTING.md).

## Llicència

XAAC Thin Client Remote es distribueix sota la **European Union Public Licence 1.2 (EUPL-1.2)**. Consulteu [LICENSE](LICENSE).

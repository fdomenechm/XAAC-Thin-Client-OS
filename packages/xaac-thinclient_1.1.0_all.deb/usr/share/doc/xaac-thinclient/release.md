# Release 1.1.0

Aquesta guia defineix el tancament de la release estable **XAAC Thin Client Remote 1.1.0**.

## Abast

La release publica l'aplicació XAAC Thin Client Remote com a paquet Debian. No inclou construcció d'ISO, clonació, recuperació de sistema, personalització de Debian ni publicació d'un repositori APT.

## Checklist

1. Confirmar `version = "1.1.0"` en `pyproject.toml`.
2. Confirmar `__version__ = "1.1.0"` en `src/xaac_thinclient/__init__.py`.
3. Confirmar `xaac-thinclient (1.1.0)` en `debian/changelog`.
4. Actualitzar i compilar traduccions.
5. Executar la suite completa amb `./scripts/test.sh`.
6. Executar `./scripts/validate-debian-package.sh --source`.
7. Construir i publicar amb `./scripts/build-deb.sh`.
8. Confirmar que `dist/` conté el `.deb` i el JSON d'evidència.
9. Validar explícitament `dist/xaac-thinclient_1.1.0_all.deb` amb `--deb`.
10. Verificar que el SHA-256 del JSON coincideix amb el paquet.
11. Instal·lar el paquet en un Debian 13 net i fer una prova funcional.
12. Crear el tag Git `v1.1.0` només després de superar totes les validacions.

## Artefacte final

```text
dist/xaac-thinclient_1.1.0_all.deb
dist/xaac-thinclient_1.1.0_all.evidence.json
```

Comprovació manual opcional del checksum:

```bash
sha256sum dist/xaac-thinclient_1.1.0_all.deb
```

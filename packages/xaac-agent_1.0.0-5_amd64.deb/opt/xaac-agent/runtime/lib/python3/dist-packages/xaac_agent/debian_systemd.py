from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any


class DebianSystemdPolicyError(ValueError):
    """Raised when the definitive systemd policy is incomplete or unsafe."""


@dataclass(frozen=True, slots=True)
class DebianSystemdPolicy:
    service_unit: str
    service_type: str
    service_user: str
    service_group: str
    supplementary_groups: tuple[str, ...]
    runtime_python: Path
    runtime_directory: Path
    configuration: Path
    network_online: bool
    watchdog_seconds: int
    restart: str
    restart_seconds: int
    start_limit_interval_seconds: int
    start_limit_burst: int
    timeout_start_seconds: int
    timeout_stop_seconds: int
    kill_mode: str
    oom_policy: str
    private_runtime: bool
    system_python_modified: bool
    tasks_max: int
    limit_nofile: int
    memory_high: str
    memory_max: str
    memory_swap_max: str
    wyse_drop_in: str
    wyse_tasks_max: int
    wyse_limit_nofile: int
    wyse_memory_high: str
    wyse_memory_max: str
    wyse_memory_swap_max: str
    helper_service_unit: str
    helper_socket_unit: str
    helper_socket_path: Path
    helper_socket_group: str
    helper_socket_mode: str
    socket_activation: bool
    helper_peer_user: str
    helper_peer_credentials: str
    helper_capability_bounding_set: tuple[str, ...]
    helper_runtime_parent: Path
    helper_runtime_parent_owner: str
    helper_runtime_parent_group: str
    helper_runtime_parent_mode: str
    helper_vpn_admin: Path
    helper_vpn_writable_root: Path
    helper_vpn_allowed_modes: tuple[str, ...]
    no_new_privileges: bool
    protect_system: str
    protect_home: bool
    private_tmp: bool
    lock_personality: bool
    restrict_suid_sgid: bool
    empty_capability_bounding_set: bool
    writable_paths: tuple[Path, ...]

    @classmethod
    def load(cls, path: Path) -> "DebianSystemdPolicy":
        try:
            raw: Any = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise DebianSystemdPolicyError("debian_systemd_policy_invalid") from exc
        if not isinstance(raw, dict) or raw.get("schema_version") != 1:
            raise DebianSystemdPolicyError("debian_systemd_schema_invalid")
        service = raw.get("service")
        resources = raw.get("resources")
        wyse = raw.get("wyse_3040")
        helper = raw.get("privileged_helper")
        hardening = raw.get("hardening")
        if not all(isinstance(item, dict) for item in (service, resources, wyse, helper, hardening)):
            raise DebianSystemdPolicyError("debian_systemd_sections_invalid")
        writable = hardening.get("writable_paths")
        if not isinstance(writable, list):
            raise DebianSystemdPolicyError("debian_systemd_writable_paths_invalid")
        return cls(
            service_unit=str(service.get("unit", "")), service_type=str(service.get("type", "")),
            service_user=str(service.get("user", "")), service_group=str(service.get("group", "")),
            supplementary_groups=tuple(str(item) for item in service.get("supplementary_groups", [])),
            runtime_python=Path(str(service.get("runtime_python", ""))),
            runtime_directory=Path(str(service.get("runtime_directory", ""))),
            configuration=Path(str(service.get("configuration", ""))),
            network_online=service.get("network_online") is True,
            watchdog_seconds=int(service.get("watchdog_seconds", 0)), restart=str(service.get("restart", "")),
            restart_seconds=int(service.get("restart_seconds", 0)),
            start_limit_interval_seconds=int(service.get("start_limit_interval_seconds", 0)),
            start_limit_burst=int(service.get("start_limit_burst", 0)),
            timeout_start_seconds=int(service.get("timeout_start_seconds", 0)),
            timeout_stop_seconds=int(service.get("timeout_stop_seconds", 0)),
            kill_mode=str(service.get("kill_mode", "")), oom_policy=str(service.get("oom_policy", "")),
            private_runtime=service.get("private_runtime") is True,
            system_python_modified=service.get("system_python_modified") is True,
            tasks_max=int(resources.get("tasks_max", 0)), limit_nofile=int(resources.get("limit_nofile", 0)),
            memory_high=str(resources.get("memory_high", "")), memory_max=str(resources.get("memory_max", "")),
            memory_swap_max=str(resources.get("memory_swap_max", "")),
            wyse_drop_in=str(wyse.get("drop_in", "")), wyse_tasks_max=int(wyse.get("tasks_max", 0)),
            wyse_limit_nofile=int(wyse.get("limit_nofile", 0)), wyse_memory_high=str(wyse.get("memory_high", "")),
            wyse_memory_max=str(wyse.get("memory_max", "")), wyse_memory_swap_max=str(wyse.get("memory_swap_max", "")),
            helper_service_unit=str(helper.get("service_unit", "")), helper_socket_unit=str(helper.get("socket_unit", "")),
            helper_socket_path=Path(str(helper.get("socket_path", ""))),
            helper_socket_group=str(helper.get("socket_group", "")), helper_socket_mode=str(helper.get("socket_mode", "")),
            socket_activation=helper.get("socket_activation") is True,
            helper_peer_user=str(helper.get("peer_user", "")),
            helper_peer_credentials=str(helper.get("peer_credentials", "")),
            helper_capability_bounding_set=tuple(str(item) for item in helper.get("capability_bounding_set", [])),
            helper_runtime_parent=Path(str(helper.get("runtime_parent", ""))),
            helper_runtime_parent_owner=str(helper.get("runtime_parent_owner", "")),
            helper_runtime_parent_group=str(helper.get("runtime_parent_group", "")),
            helper_runtime_parent_mode=str(helper.get("runtime_parent_mode", "")),
            helper_vpn_admin=Path(str(helper.get("vpn_admin", ""))),
            helper_vpn_writable_root=Path(str(helper.get("vpn_writable_root", ""))),
            helper_vpn_allowed_modes=tuple(str(item) for item in helper.get("vpn_allowed_modes", [])),
            no_new_privileges=hardening.get("no_new_privileges") is True,
            protect_system=str(hardening.get("protect_system", "")), protect_home=hardening.get("protect_home") is True,
            private_tmp=hardening.get("private_tmp") is True, lock_personality=hardening.get("lock_personality") is True,
            restrict_suid_sgid=hardening.get("restrict_suid_sgid") is True,
            empty_capability_bounding_set=hardening.get("empty_capability_bounding_set") is True,
            writable_paths=tuple(Path(str(item)) for item in writable),
        )

    def validate(self) -> None:
        if (self.service_unit, self.service_type, self.service_user, self.service_group) != (
            "xaac-agent.service", "notify", "xaac-agent", "xaac-agent"
        ):
            raise DebianSystemdPolicyError("debian_systemd_service_identity_invalid")
        if self.supplementary_groups != ("xaac-command", "xaac-ipc"):
            raise DebianSystemdPolicyError("debian_systemd_service_groups_invalid")
        if (self.runtime_python != Path("/opt/xaac-agent/runtime/bin/python3.13")
                or self.runtime_directory != Path("/run/xaac-agent/runtime")
                or self.configuration != Path("/etc/xaac-agent/agent.ini")):
            raise DebianSystemdPolicyError("debian_systemd_private_runtime_invalid")
        if not self.network_online or self.watchdog_seconds != 90:
            raise DebianSystemdPolicyError("debian_systemd_liveness_invalid")
        if self.restart != "on-failure" or not 5 <= self.restart_seconds <= 60:
            raise DebianSystemdPolicyError("debian_systemd_restart_invalid")
        if self.start_limit_interval_seconds < 60 or not 1 <= self.start_limit_burst <= 10:
            raise DebianSystemdPolicyError("debian_systemd_start_limit_invalid")
        if self.timeout_start_seconds <= 0 or self.timeout_stop_seconds <= 0 or self.kill_mode != "mixed":
            raise DebianSystemdPolicyError("debian_systemd_shutdown_invalid")
        if self.oom_policy != "stop" or not self.private_runtime or self.system_python_modified:
            raise DebianSystemdPolicyError("debian_systemd_runtime_policy_invalid")
        if not (32 <= self.tasks_max <= 128 and 512 <= self.limit_nofile <= 4096):
            raise DebianSystemdPolicyError("debian_systemd_resources_invalid")
        if (self.wyse_tasks_max >= self.tasks_max or self.wyse_limit_nofile >= self.limit_nofile or self.wyse_drop_in != "20-wyse-3040-resources.conf"):
            raise DebianSystemdPolicyError("debian_systemd_wyse_resources_invalid")
        if (self.helper_service_unit, self.helper_socket_unit, self.helper_socket_path, self.helper_socket_group, self.helper_socket_mode) != (
            "xaac-privileged-helper.service", "xaac-privileged-helper.socket", Path("/run/xaac-agent/privileged.sock"), "xaac-command", "0660"
        ) or not self.socket_activation:
            raise DebianSystemdPolicyError("debian_systemd_helper_invalid")
        if (self.helper_peer_user != "xaac-agent" or self.helper_peer_credentials != "SO_PEERCRED"
                or self.helper_capability_bounding_set != ("CAP_SYS_BOOT",)
                or self.helper_runtime_parent != Path("/run/xaac-agent")
                or (self.helper_runtime_parent_owner, self.helper_runtime_parent_group, self.helper_runtime_parent_mode)
                != ("root", "xaac-command", "0750")
                or self.helper_vpn_admin != Path("/usr/local/sbin/xaac-vpn-admin")
                or self.helper_vpn_writable_root != Path("/etc/xaac")
                or self.helper_vpn_allowed_modes != ("disabled", "optional", "required")):
            raise DebianSystemdPolicyError("debian_systemd_helper_security_invalid")
        if not all((self.no_new_privileges, self.protect_home, self.private_tmp, self.lock_personality, self.restrict_suid_sgid, self.empty_capability_bounding_set)) or self.protect_system != "strict":
            raise DebianSystemdPolicyError("debian_systemd_hardening_invalid")
        expected = {Path("/run/xaac-agent/runtime"), Path("/var/lib/xaac-agent"), Path("/var/cache/xaac-agent"), Path("/var/log/xaac-agent")}
        if set(self.writable_paths) != expected or len(self.writable_paths) != len(expected):
            raise DebianSystemdPolicyError("debian_systemd_writable_paths_invalid")
        if any(not path.is_absolute() or ".." in path.parts for path in self.writable_paths):
            raise DebianSystemdPolicyError("debian_systemd_path_unsafe")

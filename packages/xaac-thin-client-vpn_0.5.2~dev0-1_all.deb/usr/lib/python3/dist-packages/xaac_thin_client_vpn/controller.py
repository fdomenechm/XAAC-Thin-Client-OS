"""Presentation controller independent from GTK."""

from __future__ import annotations

from collections.abc import Callable

from xaac_thin_client_vpn.domain import (
    AuthInput,
    EphemeralCredentials,
    ManagerCapabilities,
    UiSnapshot,
    VpnStatus,
    snapshot_from_status,
    validate_auth_input,
)
from xaac_thin_client_vpn.ipc import VpnManagerClient


SnapshotCallback = Callable[[UiSnapshot], None]


class VpnController:
    """Coordinates the GUI form with the manager contract."""

    def __init__(
        self,
        manager: VpnManagerClient,
        *,
        on_snapshot: SnapshotCallback | None = None,
    ) -> None:
        self._manager = manager
        self._on_snapshot = on_snapshot
        self._capabilities: ManagerCapabilities | None = None
        self._unsubscribe: Callable[[], None] | None = None

    @property
    def capabilities(self) -> ManagerCapabilities:
        if self._capabilities is None:
            self._capabilities = self._manager.get_capabilities()
        return self._capabilities

    def start(self) -> UiSnapshot:
        self._unsubscribe = self._manager.subscribe_status(self._status_changed)
        status = self._manager.get_status()
        snapshot = self._snapshot(status)
        self._emit(snapshot)
        return snapshot

    def stop(self) -> None:
        if self._unsubscribe is not None:
            self._unsubscribe()
            self._unsubscribe = None

    def submit(self, auth: AuthInput) -> UiSnapshot:
        validation = validate_auth_input(auth)
        if not validation.valid:
            snapshot = UiSnapshot(
                state=self._snapshot(self._manager.get_status()).state,
                message=validation.message,
                can_submit=True,
                can_disconnect=False,
            )
            self._emit(snapshot)
            return snapshot

        credentials = EphemeralCredentials.from_text(
            auth.username.strip(),
            auth.password,
            auth.otp.strip(),
        )
        try:
            self._manager.connect(credentials)
        finally:
            # Required even though a conforming manager clears after consuming.
            # clear() is idempotent and keeps ownership rules explicit.
            credentials.clear()

        return self._snapshot(self._manager.get_status())

    def disconnect(self) -> UiSnapshot:
        self._manager.disconnect()
        return self._snapshot(self._manager.get_status())

    def _status_changed(self, status: VpnStatus) -> None:
        self._emit(self._snapshot(status))

    def _snapshot(self, status: VpnStatus) -> UiSnapshot:
        return snapshot_from_status(
            status,
            allow_disconnect=self.capabilities.allow_disconnect,
        )

    def _emit(self, snapshot: UiSnapshot) -> None:
        if self._on_snapshot is not None:
            self._on_snapshot(snapshot)

"""Authentication field presentation policy, independent from GTK."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class AuthFieldSpec:
    key: str
    secret: bool


USERNAME_FIELD = AuthFieldSpec("username", False)
PASSWORD_FIELD = AuthFieldSpec("password", True)
OTP_FIELD = AuthFieldSpec("otp", False)

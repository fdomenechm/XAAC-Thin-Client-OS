"""Visual branding resources shared by the GTK application."""

from __future__ import annotations

from pathlib import Path


RESOURCE_DIR = Path(__file__).resolve().parents[1] / "resources"
ORGANIZATION_LOGO = RESOURCE_DIR / "organization-logo.png"

GLOBAL_CSS = """
* {
    font-family: "Roboto";
}

.organization-logo {
    margin-top: 2px;
    margin-bottom: 6px;
}
"""

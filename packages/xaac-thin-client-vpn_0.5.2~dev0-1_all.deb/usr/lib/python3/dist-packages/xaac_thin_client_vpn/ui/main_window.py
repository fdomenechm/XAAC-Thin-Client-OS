"""GTK 4 authentication window for XAAC Thin Client VPN."""

from __future__ import annotations

import gi

gi.require_version("Gtk", "4.0")
from gi.repository import Gtk  # noqa: E402

from xaac_thin_client_vpn.controller import VpnController
from xaac_thin_client_vpn.domain import AuthInput, UiSnapshot, UiState
from xaac_thin_client_vpn.i18n import _
from xaac_thin_client_vpn.ipc import VpnManagerClient
from xaac_thin_client_vpn.startup import EXIT_CONNECTED, EXIT_SKIPPED, can_skip

from .branding import ORGANIZATION_LOGO
from .fields import OTP_FIELD, PASSWORD_FIELD, USERNAME_FIELD, AuthFieldSpec


class MainWindow(Gtk.ApplicationWindow):
    """Small kiosk-friendly authentication window."""

    def __init__(
        self,
        *,
        application: Gtk.Application,
        manager: VpnManagerClient,
    ) -> None:
        super().__init__(application=application)
        self.set_title("XAAC Thin Client VPN")
        self.set_default_size(500, 455)
        self.set_resizable(False)

        self._controller = VpnController(manager, on_snapshot=self._apply_snapshot)
        self.connect("close-request", self._on_close_request)

        content = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=14,
            margin_top=30,
            margin_bottom=30,
            margin_start=42,
            margin_end=42,
        )

        organization_logo = Gtk.Picture.new_for_filename(str(ORGANIZATION_LOGO))
        organization_logo.set_content_fit(Gtk.ContentFit.CONTAIN)
        organization_logo.set_can_shrink(True)
        organization_logo.set_size_request(390, 110)
        organization_logo.add_css_class("organization-logo")
        content.append(organization_logo)

        self._profile_label = Gtk.Label()
        self._profile_label.add_css_class("dim-label")
        content.append(self._profile_label)

        self._username = self._entry(USERNAME_FIELD, _("Username"))
        self._password = self._entry(PASSWORD_FIELD, _("Password"))
        self._otp = self._entry(OTP_FIELD, _("OTP code"))

        content.append(self._username)
        content.append(self._password)
        content.append(self._otp)

        self._status = Gtk.Label()
        self._status.set_wrap(True)
        self._status.set_justify(Gtk.Justification.CENTER)
        content.append(self._status)

        buttons = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=10,
            homogeneous=True,
        )
        self._connect_button = Gtk.Button(label=_("Connect"))
        self._connect_button.add_css_class("suggested-action")
        self._connect_button.connect("clicked", self._on_connect_clicked)
        buttons.append(self._connect_button)

        self._disconnect_button = Gtk.Button(label=_("Disconnect"))
        self._disconnect_button.connect("clicked", self._on_disconnect_clicked)
        buttons.append(self._disconnect_button)

        self._skip_button = Gtk.Button(label=_("Skip VPN"))
        self._skip_button.connect("clicked", self._on_skip_clicked)
        buttons.append(self._skip_button)
        content.append(buttons)

        self.set_child(content)

        capabilities = self._controller.capabilities
        self._policy = capabilities.policy
        self._skip_button.set_visible(can_skip(capabilities.policy))
        self._profile_label.set_label(_("Profile: {name}").format(name=capabilities.profile_name))
        self._controller.start()

    @staticmethod
    def _entry(spec: AuthFieldSpec, placeholder: str) -> Gtk.Entry | Gtk.PasswordEntry:
        if spec.secret:
            # Gtk.PasswordEntry provides the conventional trailing eye button.
            # The password remains hidden by default and is revealed only while
            # the user explicitly activates the peek control.
            entry = Gtk.PasswordEntry()
            entry.set_show_peek_icon(True)
            entry.set_placeholder_text(placeholder)
            entry.set_hexpand(True)
            return entry

        entry = Gtk.Entry()
        entry.set_placeholder_text(placeholder)
        entry.set_hexpand(True)
        entry.set_visibility(True)
        entry.set_input_purpose(Gtk.InputPurpose.FREE_FORM)
        return entry

    def _on_connect_clicked(self, _button: Gtk.Button) -> None:
        auth = AuthInput(
            username=self._username.get_text(),
            password=self._password.get_text(),
            otp=self._otp.get_text(),
        )

        # Password and OTP are transient. OTP is visible while being entered,
        # but both values are removed from GTK widgets immediately on submit.
        self._password.set_text("")
        self._otp.set_text("")
        self._controller.submit(auth)

    def _on_disconnect_clicked(self, _button: Gtk.Button) -> None:
        self._controller.disconnect()

    def _on_skip_clicked(self, _button: Gtk.Button) -> None:
        if can_skip(self._policy):
            self._finish(EXIT_SKIPPED)

    def _apply_snapshot(self, snapshot: UiSnapshot) -> None:
        self._status.set_label(snapshot.message)
        self._connect_button.set_sensitive(snapshot.can_submit)
        self._disconnect_button.set_sensitive(snapshot.can_disconnect)

        editable = snapshot.state not in {UiState.WORKING, UiState.CONNECTED}
        self._username.set_sensitive(editable)
        self._password.set_sensitive(editable)
        self._otp.set_sensitive(editable)

        if snapshot.state is UiState.CONNECTED:
            self._password.set_text("")
            self._otp.set_text("")
            self._finish(EXIT_CONNECTED)

    def _finish(self, exit_code: int) -> None:
        self._controller.stop()
        self._password.set_text("")
        self._otp.set_text("")
        application = self.get_application()
        if application is not None and hasattr(application, "complete"):
            application.complete(exit_code)

    def _on_close_request(self, _window: Gtk.Window) -> bool:
        if can_skip(self._policy):
            self._finish(EXIT_SKIPPED)
            return True
        return True

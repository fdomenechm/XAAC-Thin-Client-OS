"""Internationalisation helpers based on GNU gettext.

English is the source language.  Catalan and Spanish are shipped initially.
Additional languages can be added by creating another locale/<lang>/LC_MESSAGES
catalogue without changing application logic.
"""

from __future__ import annotations

import gettext as _gettext
import os
from pathlib import Path
from typing import Iterable

DOMAIN = "xaac-thin-client-vpn"
LOCALE_DIR = Path(__file__).resolve().parent / "locale"

_translation: _gettext.NullTranslations = _gettext.NullTranslations()


def _normalise_language(value: str) -> str:
    """Convert common locale forms into a gettext-friendly language tag."""
    value = value.strip()
    if not value:
        return ""
    value = value.split(".", 1)[0].split("@", 1)[0]
    return value.replace("-", "_")


def detect_languages() -> list[str]:
    """Return language preferences from the process environment."""
    language = os.environ.get("LANGUAGE", "")
    if language:
        values = [_normalise_language(item) for item in language.split(":")]
        return [value for value in values if value]

    for name in ("LC_ALL", "LC_MESSAGES", "LANG"):
        value = _normalise_language(os.environ.get(name, ""))
        if value and value not in {"C", "POSIX"}:
            return [value]
    return ["en"]


def configure_i18n(languages: Iterable[str] | None = None) -> None:
    """Select the active translation.

    Missing catalogues fall back to the English source strings.
    """
    global _translation

    selected = list(languages) if languages is not None else detect_languages()
    selected = [_normalise_language(value) for value in selected if value]
    _translation = _gettext.translation(
        DOMAIN,
        localedir=str(LOCALE_DIR),
        languages=selected or ["en"],
        fallback=True,
    )


def gettext(message: str) -> str:
    """Translate one application message with the active catalogue."""
    return _translation.gettext(message)


# Conventional short alias used throughout UI/domain presentation code.
_ = gettext

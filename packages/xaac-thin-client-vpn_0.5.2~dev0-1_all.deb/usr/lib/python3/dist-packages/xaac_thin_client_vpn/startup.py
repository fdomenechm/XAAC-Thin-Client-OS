"""Exit codes shared with the XAAC Thin Client OS startup gate."""

from __future__ import annotations

from xaac_thin_client_vpn.domain import VpnPolicy, VpnState

EXIT_CONNECTED = 0
EXIT_SKIPPED = 10


def can_skip(policy: VpnPolicy) -> bool:
    return policy is VpnPolicy.OPTIONAL


def should_finish_after_status(state: VpnState) -> bool:
    return state is VpnState.CONNECTED

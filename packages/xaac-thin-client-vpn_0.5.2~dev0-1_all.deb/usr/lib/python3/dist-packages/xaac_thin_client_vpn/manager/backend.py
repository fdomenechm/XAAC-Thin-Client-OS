"""Privileged VPN backend boundary owned by xaac-vpn-manager."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

from xaac_thin_client_vpn.domain import EphemeralCredentials


@dataclass(frozen=True, slots=True)
class BackendConnection:
    """Non-secret result from a successful VPN backend connection."""

    remote_endpoint: str = ""


class VpnBackendError(RuntimeError):
    """Base class for backend failures."""


class AuthenticationFailed(VpnBackendError):
    pass


class OtpFailed(VpnBackendError):
    pass


class ProfileUnavailable(VpnBackendError):
    pass


class NetworkUnavailable(VpnBackendError):
    pass


class ConnectionFailed(VpnBackendError):
    pass


class VpnBackend(Protocol):
    """Backend API consumed exclusively by the privileged manager."""

    def connect(self, credentials: EphemeralCredentials) -> BackendConnection:
        """Consume ephemeral credentials and establish the configured VPN."""

    def disconnect(self) -> None:
        """Disconnect the manager-owned VPN session."""


class DevelopmentBackend:
    """Deterministic backend for manager development and tests.

    This is intentionally separate from the GUI mock: it exercises the real
    manager state machine while avoiding OpenVPN 3 and root privileges.
    """

    def connect(self, credentials: EphemeralCredentials) -> BackendConnection:
        username, password, otp = credentials.as_utf8()
        try:
            if not username or not password or not otp:
                raise AuthenticationFailed("missing credentials")
            if password == "fail":
                raise AuthenticationFailed("simulated authentication failure")
            if otp == "000000":
                raise OtpFailed("simulated OTP failure")
            return BackendConnection(remote_endpoint="vpn.example.invalid")
        finally:
            username = password = otp = ""

    def disconnect(self) -> None:
        return None

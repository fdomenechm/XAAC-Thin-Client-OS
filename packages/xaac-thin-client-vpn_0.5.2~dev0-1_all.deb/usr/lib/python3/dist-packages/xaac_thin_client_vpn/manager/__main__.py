"""Entry point for xaac-vpn-manager."""

from __future__ import annotations

import argparse
from pathlib import Path

from .backend import DevelopmentBackend
from .config import DEFAULT_CONFIG_PATH, load_manager_config
from .core import ManagerCore
from .dbus_service import DbusManagerService
from .openvpn3_backend import OpenVpn3Backend


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="xaac-vpn-manager")
    parser.add_argument(
        "--config",
        type=Path,
        default=DEFAULT_CONFIG_PATH,
        help="administrative TOML configuration",
    )
    parser.add_argument(
        "--development",
        action="store_true",
        help="use the deterministic development backend instead of OpenVPN 3",
    )
    return parser


def main() -> int:
    args = _parser().parse_args()

    if args.development:
        core = ManagerCore(DevelopmentBackend())
    else:
        config = load_manager_config(args.config)
        core = ManagerCore(
            OpenVpn3Backend(config.openvpn3),
            policy=config.policy,
            profile_name=config.profile_name,
            allow_disconnect=config.allow_disconnect,
        )

    return DbusManagerService(core).run()


if __name__ == "__main__":
    raise SystemExit(main())

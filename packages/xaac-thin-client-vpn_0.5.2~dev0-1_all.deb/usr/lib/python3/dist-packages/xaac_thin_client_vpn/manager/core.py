"""Transport-independent xaac-vpn-manager state machine."""

from __future__ import annotations

from collections.abc import Callable

from xaac_thin_client_vpn.domain import (
    EphemeralCredentials,
    ManagerCapabilities,
    VpnErrorCode,
    VpnPolicy,
    VpnState,
    VpnStatus,
)
from xaac_thin_client_vpn.ipc.contract import PROTOCOL_VERSION

from .backend import (
    AuthenticationFailed,
    ConnectionFailed,
    NetworkUnavailable,
    OtpFailed,
    ProfileUnavailable,
    VpnBackend,
)


StatusListener = Callable[[VpnStatus], None]


class ManagerCore:
    """Authoritative VPN policy/state logic, independent from D-Bus and OpenVPN."""

    def __init__(
        self,
        backend: VpnBackend,
        *,
        policy: VpnPolicy = VpnPolicy.OPTIONAL,
        profile_name: str = "XAAC VPN",
        allow_disconnect: bool = True,
    ) -> None:
        self._backend = backend
        self._capabilities = ManagerCapabilities(
            protocol_version=PROTOCOL_VERSION,
            policy=policy,
            profile_name=profile_name,
            allow_disconnect=allow_disconnect,
        )
        self._status = VpnStatus(VpnState.DISCONNECTED)
        self._listeners: list[StatusListener] = []

    def capabilities(self) -> ManagerCapabilities:
        return self._capabilities

    def status(self) -> VpnStatus:
        return self._status

    def add_listener(self, listener: StatusListener) -> Callable[[], None]:
        self._listeners.append(listener)

        def unsubscribe() -> None:
            try:
                self._listeners.remove(listener)
            except ValueError:
                pass

        return unsubscribe

    def connect(self, credentials: EphemeralCredentials) -> VpnStatus:
        if self._capabilities.policy is VpnPolicy.DISABLED:
            credentials.clear()
            return self._error(VpnErrorCode.OPERATION_NOT_ALLOWED)

        if self._status.state in {
            VpnState.CONNECTING,
            VpnState.AUTHENTICATING,
            VpnState.DISCONNECTING,
        }:
            credentials.clear()
            return self._error(VpnErrorCode.BUSY)

        self._set_status(VpnStatus(VpnState.CONNECTING))
        self._set_status(VpnStatus(VpnState.AUTHENTICATING))
        try:
            connection = self._backend.connect(credentials)
        except AuthenticationFailed:
            return self._error(VpnErrorCode.AUTH_FAILED)
        except OtpFailed:
            return self._error(VpnErrorCode.OTP_FAILED)
        except ProfileUnavailable:
            return self._error(VpnErrorCode.PROFILE_UNAVAILABLE)
        except NetworkUnavailable:
            return self._error(VpnErrorCode.NETWORK_UNAVAILABLE)
        except ConnectionFailed:
            return self._error(VpnErrorCode.CONNECTION_FAILED)
        except Exception:
            # Deliberately do not expose backend details to the GUI or logs here.
            return self._error(VpnErrorCode.INTERNAL_ERROR)
        finally:
            credentials.clear()

        self._set_status(
            VpnStatus(VpnState.CONNECTED, remote_endpoint=connection.remote_endpoint)
        )
        return self._status

    def disconnect(self) -> VpnStatus:
        if not self._capabilities.allow_disconnect:
            return self._error(VpnErrorCode.OPERATION_NOT_ALLOWED)

        if self._status.state is VpnState.DISCONNECTED:
            return self._status

        self._set_status(VpnStatus(VpnState.DISCONNECTING))
        try:
            self._backend.disconnect()
        except Exception:
            return self._error(VpnErrorCode.CONNECTION_FAILED)

        self._set_status(VpnStatus(VpnState.DISCONNECTED))
        return self._status

    def _error(self, code: VpnErrorCode) -> VpnStatus:
        self._set_status(VpnStatus(VpnState.ERROR, code))
        return self._status

    def _set_status(self, status: VpnStatus) -> None:
        self._status = status
        for listener in tuple(self._listeners):
            listener(status)

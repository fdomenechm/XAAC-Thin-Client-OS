"""Administrative configuration for xaac-vpn-manager.

Only non-secret policy and OpenVPN profile selectors are persisted here.
Passwords and OTP values are never accepted from configuration.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import tomllib

from xaac_thin_client_vpn.domain import VpnPolicy


DEFAULT_CONFIG_PATH = Path("/etc/xaac/vpn-manager.toml")
CREDENTIAL_MODES = {"static-challenge", "password-otp-concat"}
ADMIN_POLICY_VALUES = tuple(policy.value for policy in VpnPolicy)


@dataclass(frozen=True, slots=True)
class OpenVpn3Config:
    binary: str = "/usr/bin/openvpn3"
    profile: str = "XAAC VPN"
    credential_mode: str = "static-challenge"
    connect_timeout_seconds: int = 90

    def __post_init__(self) -> None:
        if not self.binary.startswith("/"):
            raise ValueError("openvpn3 binary must be an absolute path")
        if not self.profile.strip():
            raise ValueError("OpenVPN 3 profile name must not be empty")
        if self.credential_mode not in CREDENTIAL_MODES:
            raise ValueError(f"unsupported credential mode: {self.credential_mode}")
        if not 5 <= self.connect_timeout_seconds <= 300:
            raise ValueError("connect timeout must be between 5 and 300 seconds")


@dataclass(frozen=True, slots=True)
class ManagerConfig:
    policy: VpnPolicy = VpnPolicy.OPTIONAL
    profile_name: str = "XAAC VPN"
    allow_disconnect: bool = True
    openvpn3: OpenVpn3Config = OpenVpn3Config()


def load_manager_config(path: Path = DEFAULT_CONFIG_PATH) -> ManagerConfig:
    """Load the administrator-owned VPN policy and non-secret settings.

    ``manager.policy`` is the single administrative source of truth used
    by XAAC Thin Client VPN and XAAC Thin Client OS.  A future XAAC Thin
    Client Agent may update the same root-owned file atomically; user
    credentials are deliberately outside this configuration contract.
    """
    with path.open("rb") as fh:
        payload = tomllib.load(fh)

    manager = payload.get("manager", {})
    vpn = payload.get("openvpn3", {})

    return ManagerConfig(
        policy=VpnPolicy(str(manager.get("policy", VpnPolicy.OPTIONAL.value))),
        profile_name=str(manager.get("profile_name", "XAAC VPN")),
        allow_disconnect=bool(manager.get("allow_disconnect", True)),
        openvpn3=OpenVpn3Config(
            binary=str(vpn.get("binary", "/usr/bin/openvpn3")),
            profile=str(vpn.get("profile", "XAAC VPN")),
            credential_mode=str(vpn.get("credential_mode", "static-challenge")),
            connect_timeout_seconds=int(vpn.get("connect_timeout_seconds", 90)),
        ),
    )

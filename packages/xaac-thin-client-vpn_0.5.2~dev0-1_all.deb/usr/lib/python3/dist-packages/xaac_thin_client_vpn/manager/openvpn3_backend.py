"""OpenVPN 3 Linux backend owned exclusively by xaac-vpn-manager."""

from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path
import subprocess
from typing import Protocol

from xaac_thin_client_vpn.domain import EphemeralCredentials

from .backend import (
    AuthenticationFailed,
    BackendConnection,
    ConnectionFailed,
    ProfileUnavailable,
    VpnBackend,
)
from .config import OpenVpn3Config


@dataclass(frozen=True, slots=True)
class CommandResult:
    returncode: int
    stdout: str
    stderr: str


class CommandRunner(Protocol):
    def run(
        self,
        argv: tuple[str, ...],
        *,
        input_bytes: bytes | None = None,
        timeout: int | None = None,
    ) -> CommandResult:
        """Execute one non-shell command."""


class SubprocessCommandRunner:
    """Production command runner with no shell and no credential arguments."""

    def run(
        self,
        argv: tuple[str, ...],
        *,
        input_bytes: bytes | None = None,
        timeout: int | None = None,
    ) -> CommandResult:
        try:
            completed = subprocess.run(
                argv,
                input=input_bytes,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=timeout,
                check=False,
                shell=False,
                env={
                    "PATH": "/usr/sbin:/usr/bin:/sbin:/bin",
                    "LANG": "C.UTF-8",
                    "LC_ALL": "C.UTF-8",
                },
            )
        except subprocess.TimeoutExpired as exc:
            raise ConnectionFailed("OpenVPN 3 connection timed out") from exc
        except OSError as exc:
            raise ConnectionFailed("OpenVPN 3 executable could not be started") from exc

        return CommandResult(
            completed.returncode,
            completed.stdout.decode("utf-8", errors="replace"),
            completed.stderr.decode("utf-8", errors="replace"),
        )


class OpenVpn3Backend(VpnBackend):
    """Start and stop a pre-imported OpenVPN 3 Linux profile.

    Authentication data is sent only through the child process stdin.  It is
    never included in argv, environment variables, files, logs, or profile
    configuration.
    """

    def __init__(
        self,
        config: OpenVpn3Config,
        *,
        runner: CommandRunner | None = None,
    ) -> None:
        self._config = config
        self._runner = runner or SubprocessCommandRunner()

    def connect(self, credentials: EphemeralCredentials) -> BackendConnection:
        self._validate_runtime()
        payload = self._credential_payload(credentials)
        try:
            result = self._runner.run(
                (
                    self._config.binary,
                    "session-start",
                    "--config",
                    self._config.profile,
                ),
                input_bytes=payload,
                timeout=self._config.connect_timeout_seconds,
            )
        finally:
            # payload is immutable because subprocess APIs require bytes; keep
            # its lifetime strictly local and always clear mutable source data.
            payload = b""
            credentials.clear()

        if result.returncode != 0:
            self._raise_for_failure(result)

        return BackendConnection(remote_endpoint="")

    def disconnect(self) -> None:
        self._validate_runtime()
        result = self._runner.run(
            (
                self._config.binary,
                "session-manage",
                "--config",
                self._config.profile,
                "--disconnect",
            ),
            timeout=30,
        )
        if result.returncode != 0:
            self._raise_for_failure(result)

    def _credential_payload(self, credentials: EphemeralCredentials) -> bytes:
        username, password, otp = credentials.as_utf8()
        try:
            if not username or not password or not otp:
                raise AuthenticationFailed("missing credentials")

            if self._config.credential_mode == "static-challenge":
                # OpenVPN 3 prompts for username/password and then the static
                # challenge response when the imported profile requests it.
                text = f"{username}\n{password}\n{otp}\n"
            else:
                # Some gateways validate password+OTP as a single password.
                text = f"{username}\n{password}{otp}\n"

            return text.encode("utf-8")
        finally:
            username = password = otp = ""

    def _validate_runtime(self) -> None:
        binary = Path(self._config.binary)
        if not binary.is_file() or not os.access(binary, os.X_OK):
            raise ConnectionFailed("OpenVPN 3 executable is unavailable")

    @staticmethod
    def _raise_for_failure(result: CommandResult) -> None:
        combined = f"{result.stdout}\n{result.stderr}".lower()

        if "auth_failed" in combined or "authentication failed" in combined:
            raise AuthenticationFailed("OpenVPN authentication failed")

        if (
            "configuration profile" in combined
            and ("not found" in combined or "does not exist" in combined)
        ) or "config not found" in combined:
            raise ProfileUnavailable("OpenVPN profile is unavailable")

        raise ConnectionFailed("OpenVPN 3 command failed")

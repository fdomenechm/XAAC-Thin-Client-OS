"""Gio system D-Bus service exposing ManagerCore."""

from __future__ import annotations

from typing import Any

from xaac_thin_client_vpn.domain import EphemeralCredentials
from xaac_thin_client_vpn.ipc.contract import (
    DBUS_BUS_NAME,
    DBUS_INTERFACE,
    DBUS_OBJECT_PATH,
)
from xaac_thin_client_vpn.ipc.dbus_codec import (
    capabilities_to_mapping,
    status_to_mapping,
)

from .core import ManagerCore


INTROSPECTION_XML = f"""
<node>
  <interface name="{DBUS_INTERFACE}">
    <method name="GetCapabilities">
      <arg name="capabilities" type="a{{sv}}" direction="out"/>
    </method>
    <method name="GetStatus">
      <arg name="status" type="a{{sv}}" direction="out"/>
    </method>
    <method name="Connect">
      <arg name="username" type="s" direction="in"/>
      <arg name="password" type="s" direction="in"/>
      <arg name="otp" type="s" direction="in"/>
    </method>
    <method name="Disconnect"/>
    <signal name="StatusChanged">
      <arg name="status" type="a{{sv}}"/>
    </signal>
  </interface>
</node>
"""


def _gi() -> tuple[Any, Any]:
    import gi

    gi.require_version("Gio", "2.0")
    from gi.repository import Gio, GLib

    return Gio, GLib


def _variant_dict(GLib: Any, payload: dict[str, object]) -> object:
    values: dict[str, object] = {}
    for key, value in payload.items():
        if isinstance(value, bool):
            values[key] = GLib.Variant("b", value)
        elif isinstance(value, int):
            values[key] = GLib.Variant("u", value)
        else:
            values[key] = GLib.Variant("s", str(value))
    return GLib.Variant("(a{sv})", (values,))


class DbusManagerService:
    """Own the system-bus name and route calls to ManagerCore."""

    def __init__(self, core: ManagerCore) -> None:
        Gio, GLib = _gi()
        self._Gio = Gio
        self._GLib = GLib
        self._core = core
        self._connection: object | None = None
        self._registration_id = 0
        self._owner_id = 0
        self._node_info = Gio.DBusNodeInfo.new_for_xml(INTROSPECTION_XML)
        self._core.add_listener(self._emit_status)

    def run(self) -> int:
        self._owner_id = self._Gio.bus_own_name(
            self._Gio.BusType.SYSTEM,
            DBUS_BUS_NAME,
            self._Gio.BusNameOwnerFlags.NONE,
            self._on_bus_acquired,
            None,
            self._on_name_lost,
        )
        loop = self._GLib.MainLoop()
        self._loop = loop
        try:
            loop.run()
        finally:
            if self._owner_id:
                self._Gio.bus_unown_name(self._owner_id)
        return 0

    def _on_bus_acquired(self, connection: object, _name: str) -> None:
        self._connection = connection
        interface_info = self._node_info.interfaces[0]
        self._registration_id = connection.register_object(
            DBUS_OBJECT_PATH,
            interface_info,
            self._handle_method_call,
            None,
            None,
        )

    def _on_name_lost(self, _connection: object | None, _name: str) -> None:
        loop = getattr(self, "_loop", None)
        if loop is not None:
            loop.quit()

    def _handle_method_call(
        self,
        _connection: object,
        _sender: str,
        _object_path: str,
        _interface_name: str,
        method_name: str,
        parameters: object,
        invocation: object,
    ) -> None:
        try:
            if method_name == "GetCapabilities":
                invocation.return_value(
                    _variant_dict(
                        self._GLib,
                        capabilities_to_mapping(self._core.capabilities()),
                    )
                )
                return

            if method_name == "GetStatus":
                invocation.return_value(
                    _variant_dict(self._GLib, status_to_mapping(self._core.status()))
                )
                return

            if method_name == "Connect":
                username, password, otp = parameters.unpack()
                credentials = EphemeralCredentials.from_text(username, password, otp)
                try:
                    self._core.connect(credentials)
                finally:
                    credentials.clear()
                    username = password = otp = ""
                invocation.return_value(None)
                return

            if method_name == "Disconnect":
                self._core.disconnect()
                invocation.return_value(None)
                return

            invocation.return_dbus_error(
                f"{DBUS_INTERFACE}.UnknownMethod",
                "Unknown VPN manager method.",
            )
        except Exception:
            invocation.return_dbus_error(
                f"{DBUS_INTERFACE}.InternalError",
                "The VPN manager could not process the request.",
            )

    def _emit_status(self, status: object) -> None:
        if self._connection is None:
            return
        self._connection.emit_signal(
            None,
            DBUS_OBJECT_PATH,
            DBUS_INTERFACE,
            "StatusChanged",
            _variant_dict(self._GLib, status_to_mapping(status)),
        )

"""Phase 5 target validation model.

The checks in this module never request, persist or inspect user credentials.
They validate only installation, policy, permissions and OpenVPN 3 profile
availability.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum


class CheckState(StrEnum):
    PASS = "pass"
    WARN = "warn"
    FAIL = "fail"


@dataclass(frozen=True, slots=True)
class ValidationCheck:
    name: str
    state: CheckState
    detail: str = ""


@dataclass(frozen=True, slots=True)
class ValidationReport:
    checks: tuple[ValidationCheck, ...]

    @property
    def ok(self) -> bool:
        return all(check.state is not CheckState.FAIL for check in self.checks)

    @property
    def failures(self) -> tuple[ValidationCheck, ...]:
        return tuple(check for check in self.checks if check.state is CheckState.FAIL)

    @property
    def warnings(self) -> tuple[ValidationCheck, ...]:
        return tuple(check for check in self.checks if check.state is CheckState.WARN)


def check(condition: bool, name: str, *, success: str = "", failure: str = "") -> ValidationCheck:
    return ValidationCheck(
        name=name,
        state=CheckState.PASS if condition else CheckState.FAIL,
        detail=success if condition else failure,
    )


def warning(name: str, detail: str) -> ValidationCheck:
    return ValidationCheck(name=name, state=CheckState.WARN, detail=detail)

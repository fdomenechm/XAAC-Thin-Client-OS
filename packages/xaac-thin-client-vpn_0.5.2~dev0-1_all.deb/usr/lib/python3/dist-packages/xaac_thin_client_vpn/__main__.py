"""Application entry point."""

from __future__ import annotations

import sys

from xaac_thin_client_vpn.application import XaacThinClientVpnApplication


def main() -> int:
    """Run XAAC Thin Client VPN."""
    app = XaacThinClientVpnApplication()
    run_status = int(app.run(sys.argv))
    return app.exit_code if app.exit_code is not None else run_status


if __name__ == "__main__":
    raise SystemExit(main())

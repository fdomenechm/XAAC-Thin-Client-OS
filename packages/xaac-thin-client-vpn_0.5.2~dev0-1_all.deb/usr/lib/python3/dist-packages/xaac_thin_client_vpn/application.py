"""GTK application bootstrap."""

from __future__ import annotations

import os

import gi

gi.require_version("Gtk", "4.0")
from gi.repository import Gdk, Gio, Gtk  # noqa: E402

from xaac_thin_client_vpn.i18n import configure_i18n
from xaac_thin_client_vpn.ipc import DbusVpnManagerClient, MockVpnManagerClient
from xaac_thin_client_vpn.startup import EXIT_CONNECTED
from xaac_thin_client_vpn.ui.branding import GLOBAL_CSS
from xaac_thin_client_vpn.ui.main_window import MainWindow


class XaacThinClientVpnApplication(Gtk.Application):
    """Top-level GTK application.

    Production uses the system D-Bus manager. Development can explicitly select
    the in-process mock with XAac VPN development environment configuration.
    """

    APPLICATION_ID = "es.canals.xaac.ThinClientVPN"

    def __init__(self) -> None:
        configure_i18n()
        super().__init__(
            application_id=self.APPLICATION_ID,
            flags=Gio.ApplicationFlags.DEFAULT_FLAGS,
        )
        self.exit_code: int | None = None
        backend = os.environ.get("XAAC_VPN_GUI_BACKEND", "dbus").strip().lower()
        self._manager = MockVpnManagerClient() if backend == "mock" else DbusVpnManagerClient()


    @staticmethod
    def _install_global_css() -> None:
        """Apply the XAAC visual font policy to the whole GTK application."""
        display = Gdk.Display.get_default()
        if display is None:
            return
        provider = Gtk.CssProvider()
        provider.load_from_data(GLOBAL_CSS.encode("utf-8"))
        Gtk.StyleContext.add_provider_for_display(
            display,
            provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION,
        )

    def complete(self, exit_code: int = EXIT_CONNECTED) -> None:
        """Finish the pre-session VPN gate with a stable OS-facing exit code."""
        self.exit_code = exit_code
        self.quit()

    def do_activate(self) -> None:
        self._install_global_css()
        window = self.props.active_window
        if window is None:
            window = MainWindow(application=self, manager=self._manager)
        window.present()

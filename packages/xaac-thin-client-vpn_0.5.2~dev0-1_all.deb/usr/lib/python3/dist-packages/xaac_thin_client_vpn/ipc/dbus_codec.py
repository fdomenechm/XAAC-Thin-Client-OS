"""Pure-Python mapping between D-Bus payload values and domain models."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from xaac_thin_client_vpn.domain import (
    ManagerCapabilities,
    VpnErrorCode,
    VpnPolicy,
    VpnState,
    VpnStatus,
)


def capabilities_from_mapping(payload: Mapping[str, Any]) -> ManagerCapabilities:
    return ManagerCapabilities(
        protocol_version=int(payload["protocol_version"]),
        policy=VpnPolicy(str(payload["policy"])),
        profile_name=str(payload["profile_name"]),
        allow_disconnect=bool(payload["allow_disconnect"]),
    )


def capabilities_to_mapping(value: ManagerCapabilities) -> dict[str, object]:
    return {
        "protocol_version": value.protocol_version,
        "policy": value.policy.value,
        "profile_name": value.profile_name,
        "allow_disconnect": value.allow_disconnect,
    }


def status_from_mapping(payload: Mapping[str, Any]) -> VpnStatus:
    return VpnStatus(
        state=VpnState(str(payload["state"])),
        error_code=VpnErrorCode(str(payload.get("error_code", VpnErrorCode.NONE.value))),
        error_detail=str(payload.get("error_detail", "")),
        remote_endpoint=str(payload.get("remote_endpoint", "")),
    )


def status_to_mapping(value: VpnStatus) -> dict[str, object]:
    return {
        "state": value.state.value,
        "error_code": value.error_code.value,
        "error_detail": value.error_detail,
        "remote_endpoint": value.remote_endpoint,
    }

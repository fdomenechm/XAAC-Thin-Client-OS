"""Deterministic in-process manager used for development and tests.

It implements exactly the GUI-side Phase 1 contract.  It never persists
credentials and clears the credential buffers before returning from connect().
"""

from __future__ import annotations

from collections.abc import Callable

from xaac_thin_client_vpn.domain import (
    EphemeralCredentials,
    ManagerCapabilities,
    VpnErrorCode,
    VpnPolicy,
    VpnState,
    VpnStatus,
)

from .contract import PROTOCOL_VERSION, StatusCallback


class MockVpnManagerClient:
    """Synchronous simulated manager with predictable development outcomes.

    Development credentials:
      - password ``fail`` -> authentication error
      - OTP ``000000`` -> OTP error
      - any other non-empty values -> connected

    These are simulation rules only and are not security policy.
    """

    def __init__(self, *, policy: VpnPolicy = VpnPolicy.OPTIONAL) -> None:
        self._capabilities = ManagerCapabilities(
            protocol_version=PROTOCOL_VERSION,
            policy=policy,
            profile_name="XAAC VPN (simulada)",
            allow_disconnect=True,
        )
        self._status = VpnStatus(VpnState.DISCONNECTED)
        self._callbacks: list[StatusCallback] = []

    def get_capabilities(self) -> ManagerCapabilities:
        return self._capabilities

    def get_status(self) -> VpnStatus:
        return self._status

    def connect(self, credentials: EphemeralCredentials) -> None:
        self._set_status(VpnStatus(VpnState.CONNECTING))
        try:
            username, password, otp = credentials.as_utf8()
            self._set_status(VpnStatus(VpnState.AUTHENTICATING))
            if not username or not password or not otp:
                self._set_status(
                    VpnStatus(VpnState.ERROR, VpnErrorCode.INVALID_REQUEST)
                )
            elif password == "fail":
                self._set_status(VpnStatus(VpnState.ERROR, VpnErrorCode.AUTH_FAILED))
            elif otp == "000000":
                self._set_status(VpnStatus(VpnState.ERROR, VpnErrorCode.OTP_FAILED))
            else:
                self._set_status(
                    VpnStatus(
                        VpnState.CONNECTED,
                        remote_endpoint="vpn.example.invalid",
                    )
                )
        finally:
            credentials.clear()

    def disconnect(self) -> None:
        if not self._capabilities.allow_disconnect:
            self._set_status(
                VpnStatus(VpnState.ERROR, VpnErrorCode.OPERATION_NOT_ALLOWED)
            )
            return
        self._set_status(VpnStatus(VpnState.DISCONNECTING))
        self._set_status(VpnStatus(VpnState.DISCONNECTED))

    def subscribe_status(self, callback: StatusCallback) -> Callable[[], None]:
        self._callbacks.append(callback)

        def unsubscribe() -> None:
            try:
                self._callbacks.remove(callback)
            except ValueError:
                pass

        return unsubscribe

    def _set_status(self, status: VpnStatus) -> None:
        self._status = status
        for callback in tuple(self._callbacks):
            callback(status)

"""System D-Bus implementation of the GUI-side VPN manager client."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from xaac_thin_client_vpn.domain import EphemeralCredentials, ManagerCapabilities, VpnStatus

from .contract import (
    DBUS_BUS_NAME,
    DBUS_INTERFACE,
    DBUS_OBJECT_PATH,
    StatusCallback,
)
from .dbus_codec import capabilities_from_mapping, status_from_mapping


def _gi() -> tuple[Any, Any]:
    """Import GI lazily so domain/unit tests do not require a graphical runtime."""
    import gi

    gi.require_version("Gio", "2.0")
    from gi.repository import Gio, GLib

    return Gio, GLib


def _unpack_dict(variant: Any) -> dict[str, object]:
    """Recursively unpack a{sv} returned by GLib.Variant."""
    raw = variant.unpack()
    if isinstance(raw, tuple) and len(raw) == 1:
        raw = raw[0]
    return {
        str(key): value.unpack() if hasattr(value, "unpack") else value
        for key, value in dict(raw).items()
    }


class DbusVpnManagerClient:
    """Synchronous system-bus adapter satisfying :class:`VpnManagerClient`."""

    def __init__(self) -> None:
        Gio, _GLib = _gi()
        self._Gio = Gio
        self._proxy = Gio.DBusProxy.new_for_bus_sync(
            Gio.BusType.SYSTEM,
            Gio.DBusProxyFlags.NONE,
            None,
            DBUS_BUS_NAME,
            DBUS_OBJECT_PATH,
            DBUS_INTERFACE,
            None,
        )
        self._subscriptions: dict[StatusCallback, int] = {}

    def get_capabilities(self) -> ManagerCapabilities:
        result = self._call("GetCapabilities", None)
        return capabilities_from_mapping(_unpack_dict(result))

    def get_status(self) -> VpnStatus:
        result = self._call("GetStatus", None)
        return status_from_mapping(_unpack_dict(result))

    def connect(self, credentials: EphemeralCredentials) -> None:
        _Gio, GLib = _gi()
        username = password = otp = ""
        try:
            username, password, otp = credentials.as_utf8()
            params = GLib.Variant("(sss)", (username, password, otp))
            self._call("Connect", params)
        finally:
            # Python strings cannot be reliably zeroised. Keep their lifetime
            # constrained to this call and always clear the mutable source buffers.
            username = password = otp = ""
            credentials.clear()

    def disconnect(self) -> None:
        self._call("Disconnect", None)

    def subscribe_status(self, callback: StatusCallback) -> Callable[[], None]:
        def on_signal(
            _proxy: object,
            _sender_name: str | None,
            signal_name: str,
            parameters: object,
        ) -> None:
            if signal_name != "StatusChanged":
                return
            callback(status_from_mapping(_unpack_dict(parameters)))

        handler_id = self._proxy.connect("g-signal", on_signal)
        self._subscriptions[callback] = handler_id

        def unsubscribe() -> None:
            current = self._subscriptions.pop(callback, None)
            if current is not None:
                self._proxy.disconnect(current)

        return unsubscribe

    def _call(self, method: str, parameters: object | None) -> object:
        return self._proxy.call_sync(
            method,
            parameters,
            self._Gio.DBusCallFlags.NONE,
            -1,
            None,
        )

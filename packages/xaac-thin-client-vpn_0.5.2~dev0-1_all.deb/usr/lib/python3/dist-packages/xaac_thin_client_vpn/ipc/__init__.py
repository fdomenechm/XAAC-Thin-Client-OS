"""IPC contract and development adapters."""

from .contract import (
    DBUS_BUS_NAME,
    DBUS_INTERFACE,
    DBUS_OBJECT_PATH,
    PROTOCOL_VERSION,
    StatusCallback,
    VpnManagerClient,
)
from .dbus_client import DbusVpnManagerClient
from .mock import MockVpnManagerClient

__all__ = [
    "DBUS_BUS_NAME",
    "DBUS_INTERFACE",
    "DBUS_OBJECT_PATH",
    "DbusVpnManagerClient",
    "MockVpnManagerClient",
    "PROTOCOL_VERSION",
    "StatusCallback",
    "VpnManagerClient",
]

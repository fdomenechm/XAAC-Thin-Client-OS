"""Phase 1 IPC contract.

This module contains no D-Bus implementation.  It defines the dependency boundary the
GUI will use in Phase 2 and the future xaac-vpn-manager adapter must satisfy in Phase 3.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Protocol

from xaac_thin_client_vpn.domain import EphemeralCredentials, ManagerCapabilities, VpnStatus


PROTOCOL_VERSION = 1
DBUS_BUS_NAME = "org.xaac.ThinClient.VpnManager1"
DBUS_OBJECT_PATH = "/org/xaac/ThinClient/VpnManager1"
DBUS_INTERFACE = "org.xaac.ThinClient.VpnManager1"

StatusCallback = Callable[[VpnStatus], None]


class VpnManagerClient(Protocol):
    """Unprivileged GUI-side view of xaac-vpn-manager."""

    def get_capabilities(self) -> ManagerCapabilities:
        """Return policy/profile metadata and the negotiated protocol version."""

    def get_status(self) -> VpnStatus:
        """Return the current non-secret VPN status."""

    def connect(self, credentials: EphemeralCredentials) -> None:
        """Request a connection. The caller clears credentials after this returns."""

    def disconnect(self) -> None:
        """Request disconnection when allowed by administrative policy."""

    def subscribe_status(self, callback: StatusCallback) -> Callable[[], None]:
        """Subscribe to status changes and return an unsubscribe callback."""

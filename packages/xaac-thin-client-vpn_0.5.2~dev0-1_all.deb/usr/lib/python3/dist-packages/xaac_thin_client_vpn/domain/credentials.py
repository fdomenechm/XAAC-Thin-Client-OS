"""Ephemeral credential holder.

Credentials deliberately live outside the serialisable domain models.  The GUI should
create this object immediately before a connection request and erase its mutable
buffers immediately after the IPC layer has consumed them.
"""

from __future__ import annotations

from dataclasses import dataclass, field


def _to_buffer(value: str) -> bytearray:
    return bytearray(value.encode("utf-8"))


@dataclass(slots=True)
class EphemeralCredentials:
    """Mutable, non-persistent credentials with best-effort in-process zeroisation."""

    username: bytearray = field(repr=False)
    password: bytearray = field(repr=False)
    otp: bytearray = field(repr=False)

    @classmethod
    def from_text(cls, username: str, password: str, otp: str) -> EphemeralCredentials:
        return cls(_to_buffer(username), _to_buffer(password), _to_buffer(otp))

    def as_utf8(self) -> tuple[str, str, str]:
        """Decode just-in-time for the transport implementation."""
        return tuple(buf.decode("utf-8") for buf in (self.username, self.password, self.otp))  # type: ignore[return-value]

    def clear(self) -> None:
        """Overwrite all mutable buffers in place."""
        for buf in (self.username, self.password, self.otp):
            buf[:] = b"\x00" * len(buf)
            buf.clear()

    def __repr__(self) -> str:
        return "EphemeralCredentials(username=<redacted>, password=<redacted>, otp=<redacted>)"

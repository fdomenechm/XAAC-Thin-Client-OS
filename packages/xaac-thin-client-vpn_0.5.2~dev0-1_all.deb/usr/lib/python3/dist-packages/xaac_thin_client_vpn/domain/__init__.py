"""Domain types for XAAC Thin Client VPN."""

from .auth import AuthInput, ValidationResult, validate_auth_input
from .credentials import EphemeralCredentials
from .models import ManagerCapabilities, VpnErrorCode, VpnPolicy, VpnState, VpnStatus
from .session import UiSnapshot, UiState, snapshot_from_status

__all__ = [
    "AuthInput",
    "EphemeralCredentials",
    "ManagerCapabilities",
    "UiSnapshot",
    "UiState",
    "ValidationResult",
    "VpnErrorCode",
    "VpnPolicy",
    "VpnState",
    "VpnStatus",
    "snapshot_from_status",
    "validate_auth_input",
]

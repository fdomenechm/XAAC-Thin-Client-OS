"""Authentication form validation and non-secret presentation state."""

from __future__ import annotations

from dataclasses import dataclass

from xaac_thin_client_vpn.i18n import _


MIN_OTP_LENGTH = 4
MAX_OTP_LENGTH = 10


@dataclass(frozen=True, slots=True)
class AuthInput:
    """Raw values supplied by the GTK form immediately before submission."""

    username: str
    password: str
    otp: str


@dataclass(frozen=True, slots=True)
class ValidationResult:
    """Result of local, non-authoritative form validation."""

    valid: bool
    message: str = ""


def validate_auth_input(auth: AuthInput) -> ValidationResult:
    """Reject obviously incomplete input before creating credential buffers.

    The manager remains authoritative.  This validation only prevents malformed
    or empty requests and deliberately does not enforce a company-specific OTP
    format.
    """
    if not auth.username.strip():
        return ValidationResult(False, _("Enter your username."))
    if not auth.password:
        return ValidationResult(False, _("Enter your password."))
    if not auth.otp.strip():
        return ValidationResult(False, _("Enter the OTP code."))

    otp = auth.otp.strip()
    if not (MIN_OTP_LENGTH <= len(otp) <= MAX_OTP_LENGTH):
        return ValidationResult(False, _("The OTP code has an invalid length."))

    return ValidationResult(True)

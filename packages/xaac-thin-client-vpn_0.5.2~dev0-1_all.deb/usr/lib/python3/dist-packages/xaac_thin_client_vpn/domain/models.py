"""Domain models shared by the GUI and the future IPC client."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum


class VpnPolicy(StrEnum):
    """Administrative policy configured by XAAC Thin Client OS."""

    DISABLED = "disabled"
    OPTIONAL = "optional"
    REQUIRED = "required"


class VpnState(StrEnum):
    """Public lifecycle states exposed by xaac-vpn-manager."""

    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    AUTHENTICATING = "authenticating"
    CONNECTED = "connected"
    DISCONNECTING = "disconnecting"
    ERROR = "error"


class VpnErrorCode(StrEnum):
    """Stable error codes that the GUI can safely map to user-facing messages."""

    NONE = "none"
    INVALID_REQUEST = "invalid_request"
    AUTH_FAILED = "auth_failed"
    OTP_FAILED = "otp_failed"
    PROFILE_UNAVAILABLE = "profile_unavailable"
    NETWORK_UNAVAILABLE = "network_unavailable"
    CONNECTION_FAILED = "connection_failed"
    SERVICE_UNAVAILABLE = "service_unavailable"
    OPERATION_NOT_ALLOWED = "operation_not_allowed"
    BUSY = "busy"
    INTERNAL_ERROR = "internal_error"


@dataclass(frozen=True, slots=True)
class ManagerCapabilities:
    """Non-secret manager metadata read by the GUI at startup."""

    protocol_version: int
    policy: VpnPolicy
    profile_name: str
    allow_disconnect: bool


@dataclass(frozen=True, slots=True)
class VpnStatus:
    """Non-secret snapshot of the current manager state."""

    state: VpnState
    error_code: VpnErrorCode = VpnErrorCode.NONE
    error_detail: str = ""
    remote_endpoint: str = ""

    @property
    def connected(self) -> bool:
        return self.state is VpnState.CONNECTED

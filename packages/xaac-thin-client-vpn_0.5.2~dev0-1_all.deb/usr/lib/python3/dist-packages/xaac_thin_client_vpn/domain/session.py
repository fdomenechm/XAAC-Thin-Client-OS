"""GUI-side state machine.

This state is intentionally derived from the public manager status.  It contains
no credentials and is safe to retain for the lifetime of the process.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum

from xaac_thin_client_vpn.i18n import _

from .models import VpnErrorCode, VpnState, VpnStatus


class UiState(StrEnum):
    READY = "ready"
    WORKING = "working"
    CONNECTED = "connected"
    ERROR = "error"


@dataclass(frozen=True, slots=True)
class UiSnapshot:
    state: UiState
    message: str
    can_submit: bool
    can_disconnect: bool


def _error_message(error_code: VpnErrorCode | None) -> str:
    messages: dict[VpnErrorCode, str] = {
        VpnErrorCode.INVALID_REQUEST: _("The request is invalid."),
        VpnErrorCode.AUTH_FAILED: _("Incorrect username or password."),
        VpnErrorCode.OTP_FAILED: _("The OTP code is invalid."),
        VpnErrorCode.PROFILE_UNAVAILABLE: _("The VPN profile is unavailable."),
        VpnErrorCode.NETWORK_UNAVAILABLE: _("Network connectivity is unavailable."),
        VpnErrorCode.CONNECTION_FAILED: _("The VPN connection could not be established."),
        VpnErrorCode.SERVICE_UNAVAILABLE: _("The system VPN service is unavailable."),
        VpnErrorCode.OPERATION_NOT_ALLOWED: _("The operation is not allowed."),
        VpnErrorCode.BUSY: _("The VPN manager is busy."),
        VpnErrorCode.INTERNAL_ERROR: _("An internal error occurred."),
    }
    return messages.get(error_code, _("An error occurred."))


def snapshot_from_status(status: VpnStatus, *, allow_disconnect: bool = True) -> UiSnapshot:
    """Map manager states to stable translated UI behaviour."""
    if status.state is VpnState.CONNECTED:
        return UiSnapshot(
            UiState.CONNECTED,
            _("VPN connection established."),
            can_submit=False,
            can_disconnect=allow_disconnect,
        )

    if status.state in {
        VpnState.CONNECTING,
        VpnState.AUTHENTICATING,
        VpnState.DISCONNECTING,
    }:
        messages = {
            VpnState.CONNECTING: _("Connecting to the VPN…"),
            VpnState.AUTHENTICATING: _("Validating credentials…"),
            VpnState.DISCONNECTING: _("Disconnecting…"),
        }
        return UiSnapshot(UiState.WORKING, messages[status.state], False, False)

    if status.state is VpnState.ERROR:
        return UiSnapshot(UiState.ERROR, _error_message(status.error_code), True, False)

    return UiSnapshot(
        UiState.READY,
        _("Enter your credentials to connect."),
        True,
        False,
    )

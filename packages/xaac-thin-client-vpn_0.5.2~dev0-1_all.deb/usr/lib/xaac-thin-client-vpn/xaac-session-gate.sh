#!/bin/sh
set -eu

VPN_APP=${XAAC_VPN_APP:-/usr/bin/xaac-thin-client-vpn}
THIN_CLIENT=${XAAC_THIN_CLIENT_APP:-/usr/bin/xaac-thin-client}
CONFIG=${XAAC_VPN_CONFIG:-/etc/xaac/vpn-manager.toml}
POLICY=optional

# Administrative source of truth.  Environment override exists only as a
# development fallback when no system configuration file is available.
if [ -r "$CONFIG" ]; then
    configured=$(awk -F '"' '/^[ 	]*policy[ 	]*=/ { print $2; exit }' "$CONFIG" 2>/dev/null || true)
    [ -n "$configured" ] && POLICY=$configured
elif [ -n "${XAAC_VPN_POLICY:-}" ]; then
    POLICY=$XAAC_VPN_POLICY
fi

case "$POLICY" in
    disabled)
        exec "$THIN_CLIENT"
        ;;
    optional|required)
        ;;
    *)
        echo "ERROR: política VPN desconeguda: $POLICY" >&2
        exit 2
        ;;
esac

# GUI exit contract:
#   0 = VPN connected / continue
#   10 = user skipped optional VPN
# other = failure/cancel
if "$VPN_APP"; then
    VPN_RC=0
else
    VPN_RC=$?
fi

case "$VPN_RC" in
    0)
        exec "$THIN_CLIENT"
        ;;
    10)
        if [ "$POLICY" = "optional" ]; then
            exec "$THIN_CLIENT"
        fi
        echo "ERROR: la VPN és obligatòria i no es pot ometre." >&2
        exit 10
        ;;
    *)
        echo "ERROR: XAAC Thin Client VPN ha finalitzat amb codi $VPN_RC." >&2
        exit "$VPN_RC"
        ;;
esac

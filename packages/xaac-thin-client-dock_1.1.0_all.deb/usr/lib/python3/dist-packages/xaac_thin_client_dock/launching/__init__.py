"""Controlled application launching layer."""

from xaac_thin_client_dock.launching.launcher import (
    ControlledApplicationLauncher,
    create_default_launcher,
)
from xaac_thin_client_dock.launching.model import LaunchResult, LaunchStatus
from xaac_thin_client_dock.launching.ports import ApplicationLauncher
from xaac_thin_client_dock.launching.process import (
    CurrentProcessIdentity,
    IdentityProvider,
    InstancePresenter,
    LinuxProcProcessInspector,
    NoOpInstancePresenter,
    ProcessInspector,
    ProcessSpawner,
    SpawnedProcess,
    SubprocessSpawner,
)

__all__ = [
    "ApplicationLauncher",
    "ControlledApplicationLauncher",
    "CurrentProcessIdentity",
    "IdentityProvider",
    "InstancePresenter",
    "LaunchResult",
    "LaunchStatus",
    "LinuxProcProcessInspector",
    "NoOpInstancePresenter",
    "ProcessInspector",
    "ProcessSpawner",
    "SpawnedProcess",
    "SubprocessSpawner",
    "create_default_launcher",
]

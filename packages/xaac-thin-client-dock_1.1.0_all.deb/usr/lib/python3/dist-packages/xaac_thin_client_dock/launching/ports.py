"""Controlled application launching boundary for XAAC Thin Client Dock."""

from __future__ import annotations

from typing import TYPE_CHECKING, Protocol, runtime_checkable

if TYPE_CHECKING:
    from xaac_thin_client_dock.components import ComponentId
    from xaac_thin_client_dock.launching.model import LaunchResult


@runtime_checkable
class ApplicationLauncher(Protocol):
    """Launch or present an authorised XAAC component."""

    def launch(self, component_id: ComponentId | str) -> LaunchResult:
        """Request controlled launch/presentation of one authorised component."""

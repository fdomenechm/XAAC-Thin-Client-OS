"""Immutable launch results for XAAC Thin Client Dock."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum

from xaac_thin_client_dock.components import ComponentId


class LaunchStatus(StrEnum):
    """Machine-readable result of one controlled launch request."""

    STARTED = "started"
    ALREADY_RUNNING = "already_running"
    DISABLED = "disabled"
    UNAVAILABLE = "unavailable"
    BLOCKED_ROOT = "blocked_root"
    BLOCKED_PREREQUISITE = "blocked_prerequisite"
    FAILED = "failed"


@dataclass(frozen=True, slots=True)
class LaunchResult:
    """Snapshot returned by the controlled launcher."""

    component_id: ComponentId
    status: LaunchStatus
    pid: int | None = None
    presented: bool = False
    error: str | None = None

    def __post_init__(self) -> None:
        if self.pid is not None and self.pid <= 0:
            raise ValueError("pid must be greater than zero")

        if self.status is LaunchStatus.STARTED:
            if self.pid is None:
                raise ValueError("started result must include pid")
            if self.presented:
                raise ValueError("newly started component cannot be marked presented")
            if self.error is not None:
                raise ValueError("started result cannot include error")
            return

        if self.status is LaunchStatus.ALREADY_RUNNING:
            if self.pid is None:
                raise ValueError("already-running result must include pid")
            if self.error is not None:
                raise ValueError("already-running result cannot include error")
            return

        if self.pid is not None:
            raise ValueError(f"{self.status.value} result cannot include pid")
        if self.presented:
            raise ValueError(f"{self.status.value} result cannot be marked presented")

        if self.status is LaunchStatus.FAILED:
            if not self.error:
                raise ValueError("failed result must include error")
        elif self.error is not None:
            raise ValueError(f"{self.status.value} result cannot include error")

"""System adapters used by the controlled launcher.

The concrete adapters are intentionally small and privilege-free.  They do not
use a shell, sudo, pkexec or any other elevation mechanism.
"""

from __future__ import annotations

import os
import subprocess
from pathlib import Path
from typing import Protocol, runtime_checkable


@runtime_checkable
class SpawnedProcess(Protocol):
    """Minimal process handle required by the launcher."""

    @property
    def pid(self) -> int:
        """Operating-system process identifier."""

    def poll(self) -> int | None:
        """Return exit status, or ``None`` while the process is alive."""


@runtime_checkable
class ProcessSpawner(Protocol):
    """Start one already-resolved executable without privilege elevation."""

    def spawn(self, executable: str) -> SpawnedProcess:
        """Start the executable and return its process handle."""


class SubprocessSpawner:
    """Start a GUI component directly, never through a command shell."""

    def spawn(self, executable: str) -> subprocess.Popen[bytes]:
        return subprocess.Popen(
            [executable],
            close_fds=True,
            start_new_session=True,
        )


@runtime_checkable
class ProcessInspector(Protocol):
    """Find an existing instance belonging to the current user."""

    def find(self, executable: str, uid: int) -> int | None:
        """Return one matching PID, or ``None`` when no instance is found."""


class LinuxProcProcessInspector:
    """Inspect Linux ``/proc`` without executing helper commands.

    Matching is based on the resolved ``/proc/<pid>/exe`` target and the real
    UID reported by ``/proc/<pid>/status``.  Processes owned by other users are
    deliberately ignored.
    """

    def __init__(self, proc_root: str | Path = "/proc") -> None:
        self._proc_root = Path(proc_root)

    def find(self, executable: str, uid: int) -> int | None:
        try:
            expected = Path(executable).resolve(strict=False)
        except OSError:
            expected = Path(executable)

        try:
            entries = tuple(self._proc_root.iterdir())
        except OSError:
            return None

        for entry in entries:
            if not entry.name.isdigit():
                continue

            pid = int(entry.name)
            if pid == os.getpid():
                continue

            try:
                process_uid = _read_real_uid(entry / "status")
                if process_uid != uid:
                    continue
            except (OSError, ValueError):
                continue

            if _matches_process_executable(entry, expected):
                return pid

        return None


def _matches_process_executable(process_dir: Path, expected: Path) -> bool:
    """Match native binaries and interpreter-backed script entry points."""

    try:
        target = Path(os.readlink(process_dir / "exe")).resolve(strict=False)
        if target == expected:
            return True
    except OSError:
        pass

    try:
        raw_cmdline = (process_dir / "cmdline").read_bytes()
    except OSError:
        return False

    arguments = [
        part.decode("utf-8", errors="surrogateescape")
        for part in raw_cmdline.split(b"\0")
        if part
    ]

    # Native executables normally match /proc/<pid>/exe.  Interpreter-backed
    # console scripts (Python or POSIX shebangs) normally put the script path
    # in argv[1], so checking only the first two entries avoids accidental
    # matches against later user/configuration arguments.
    for argument in arguments[:2]:
        candidate = Path(argument)
        if not candidate.is_absolute():
            continue
        try:
            candidate = candidate.resolve(strict=False)
        except OSError:
            pass
        if candidate == expected:
            return True

    return False


def _read_real_uid(status_path: Path) -> int:
    with status_path.open("r", encoding="utf-8", errors="replace") as stream:
        for line in stream:
            if line.startswith("Uid:"):
                fields = line.split()
                if len(fields) < 2:
                    break
                return int(fields[1])
    raise ValueError(f"real uid not found in {status_path}")


@runtime_checkable
class IdentityProvider(Protocol):
    """Expose the identity under which child processes would be started."""

    def effective_uid(self) -> int:
        """Return the effective user ID."""

    def real_uid(self) -> int:
        """Return the real user ID."""


class CurrentProcessIdentity:
    """Identity of the current Dock process."""

    def effective_uid(self) -> int:
        return os.geteuid()

    def real_uid(self) -> int:
        return os.getuid()


@runtime_checkable
class InstancePresenter(Protocol):
    """Request presentation of an already-running component window."""

    def present(self, pid: int) -> bool:
        """Return whether an existing instance was successfully presented."""


class NoOpInstancePresenter:
    """Safe default until kiosk/window-system integration supplies activation."""

    def present(self, pid: int) -> bool:
        return False

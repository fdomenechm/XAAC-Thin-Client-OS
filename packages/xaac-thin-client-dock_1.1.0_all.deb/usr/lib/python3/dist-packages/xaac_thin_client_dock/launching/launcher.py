"""Controlled launcher for authorised XAAC components."""

from __future__ import annotations

import threading

from xaac_thin_client_dock.components import (
    ComponentDiscovery,
    ComponentId,
    ComponentRegistry,
)
from xaac_thin_client_dock.launching.model import LaunchResult, LaunchStatus
from xaac_thin_client_dock.launching.process import (
    CurrentProcessIdentity,
    IdentityProvider,
    InstancePresenter,
    LinuxProcProcessInspector,
    NoOpInstancePresenter,
    ProcessInspector,
    ProcessSpawner,
    SubprocessSpawner,
)


class ControlledApplicationLauncher:
    """Launch only registered, available XAAC components.

    The whole inspect/find/spawn sequence is protected by one lock so two GUI
    actions in the same Dock process cannot race into duplicate starts.
    Existing processes are searched by resolved executable path and current
    real UID before a new child is created.
    """

    __slots__ = (
        "_registry",
        "_discovery",
        "_spawner",
        "_inspector",
        "_identity",
        "_presenter",
        "_lock",
    )

    def __init__(
        self,
        registry: ComponentRegistry,
        discovery: ComponentDiscovery,
        spawner: ProcessSpawner | None = None,
        inspector: ProcessInspector | None = None,
        identity: IdentityProvider | None = None,
        presenter: InstancePresenter | None = None,
    ) -> None:
        self._registry = registry
        self._discovery = discovery
        self._spawner = spawner or SubprocessSpawner()
        self._inspector = inspector or LinuxProcProcessInspector()
        self._identity = identity or CurrentProcessIdentity()
        self._presenter = presenter or NoOpInstancePresenter()
        self._lock = threading.Lock()

    def launch(self, component_id: ComponentId | str) -> LaunchResult:
        """Launch or present one authorised component."""

        component = self._registry.get(component_id)

        with self._lock:
            if self._identity.effective_uid() == 0:
                return LaunchResult(
                    component_id=component.component_id,
                    status=LaunchStatus.BLOCKED_ROOT,
                )

            availability = self._discovery.inspect(component.component_id)
            if not availability.available or availability.resolved_path is None:
                return LaunchResult(
                    component_id=component.component_id,
                    status=LaunchStatus.UNAVAILABLE,
                )

            uid = self._identity.real_uid()
            try:
                existing_pid = self._inspector.find(
                    availability.resolved_path,
                    uid,
                )
            except OSError:
                # Failing open here could create a duplicate instance precisely
                # when process inspection is unavailable.  Preserve the
                # single-instance guarantee and report a structured failure.
                return LaunchResult(
                    component_id=component.component_id,
                    status=LaunchStatus.FAILED,
                    error="process_inspection_error",
                )

            if existing_pid is not None:
                try:
                    presented = bool(self._presenter.present(existing_pid))
                except OSError:
                    presented = False

                return LaunchResult(
                    component_id=component.component_id,
                    status=LaunchStatus.ALREADY_RUNNING,
                    pid=existing_pid,
                    presented=presented,
                )

            try:
                process = self._spawner.spawn(availability.resolved_path)
            except OSError as exc:
                return LaunchResult(
                    component_id=component.component_id,
                    status=LaunchStatus.FAILED,
                    error=_format_os_error(exc),
                )

            return LaunchResult(
                component_id=component.component_id,
                status=LaunchStatus.STARTED,
                pid=process.pid,
            )


def _format_os_error(exc: OSError) -> str:
    if exc.strerror:
        return exc.strerror
    return exc.__class__.__name__


def create_default_launcher(
    registry: ComponentRegistry,
    discovery: ComponentDiscovery,
    *,
    presenter: InstancePresenter | None = None,
) -> ControlledApplicationLauncher:
    """Create the standard privilege-free launcher."""

    return ControlledApplicationLauncher(
        registry=registry,
        discovery=discovery,
        presenter=presenter,
    )

"""Application-side kiosk confinement policy for XAAC Thin Client Dock.

Phase 4.3 deliberately keeps desktop/compositor-specific configuration outside
of the Dock.  This module defines the shortcuts that must never become escape
routes while the persistent Dock owns keyboard focus.  The GTK adapter maps
GDK key events to this pure policy; XAAC Thin Client OS remains responsible for
disabling equivalent *global* compositor/VT shortcuts in the dedicated kiosk
session.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class KioskKeyStroke:
    """Normalized key stroke independent from GTK/GDK numeric constants."""

    key: str
    alt: bool = False
    control: bool = False
    shift: bool = False
    super: bool = False

    def __post_init__(self) -> None:
        if not self.key.strip():
            raise ValueError("key must not be empty")

    @property
    def normalized_key(self) -> str:
        return self.key.strip().lower()


@dataclass(frozen=True, slots=True)
class KioskShortcutPolicy:
    """Block common desktop/session escape accelerators.

    The policy is intentionally conservative: ordinary navigation keys remain
    available, while desktop overview, window switching, terminal launchers,
    window menus, session actions and virtual-terminal chords are consumed if
    they reach the Dock window.
    """

    def blocks(self, stroke: KioskKeyStroke) -> bool:
        key = stroke.normalized_key

        # Super/Meta is the desktop-shell entry point on common Linux desktops.
        if stroke.super or key in {"super_l", "super_r", "meta_l", "meta_r"}:
            return True

        # Window-manager/session navigation and menus.
        if stroke.alt and key in {"tab", "iso_left_tab", "f1", "f2", "f4", "space"}:
            return True
        if stroke.control and key == "escape":
            return True
        if stroke.shift and key == "f10":
            return True
        if key in {"menu", "apps"}:
            return True

        # Common terminal/task/session accelerators.
        if stroke.control and stroke.alt and key in {"t", "delete"}:
            return True
        if stroke.control and stroke.shift and key == "escape":
            return True

        # Linux virtual-terminal switching.  The compositor/kernel may grab
        # these before GTK; blocking here is defense in depth, not the OS-level
        # replacement for dedicated-session hardening.
        if stroke.control and stroke.alt and key.startswith("f"):
            suffix = key[1:]
            if suffix.isdigit() and 1 <= int(suffix) <= 12:
                return True

        return False


DEFAULT_KIOSK_SHORTCUT_POLICY = KioskShortcutPolicy()


def create_default_kiosk_shortcut_policy() -> KioskShortcutPolicy:
    """Return the immutable default Phase 4.3 shortcut policy."""

    return DEFAULT_KIOSK_SHORTCUT_POLICY

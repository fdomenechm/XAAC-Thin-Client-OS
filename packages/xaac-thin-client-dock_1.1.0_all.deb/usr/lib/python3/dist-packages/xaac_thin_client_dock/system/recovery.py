"""Failure-recovery orchestration for the XAAC kiosk shell.

Phase 4.4 makes recovery an explicit system-layer responsibility.  Launch
failures, failed window presentation and process-watcher failures must never
remove or strand the persistent Dock.  Successful component processes remain
tracked through the Phase 4.2 window coordinator so the Dock is re-presented
when they terminate.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum

from xaac_thin_client_dock.launching import LaunchResult, LaunchStatus
from xaac_thin_client_dock.system.windowing import ComponentWindowCoordinator, ReturnToDock


class RecoveryReason(StrEnum):
    """Machine-readable reason why the Dock recovery path was used."""

    LAUNCH_FAILED = "launch_failed"
    COMPONENT_UNAVAILABLE = "component_unavailable"
    COMPONENT_DISABLED = "component_disabled"
    BLOCKED_ROOT = "blocked_root"
    PREREQUISITE_BLOCKED = "prerequisite_blocked"
    PRESENTATION_FAILED = "presentation_failed"
    WINDOW_TRACKING_FAILED = "window_tracking_failed"
    PROCESS_EXITED_EARLY = "process_exited_early"
    INVALID_RESULT = "invalid_result"


@dataclass(frozen=True, slots=True)
class RecoveryResult:
    """Outcome of handling one navigation result at the shell boundary."""

    recovered: bool
    watching: bool = False
    reason: RecoveryReason | None = None

    def __post_init__(self) -> None:
        if self.watching and not self.recovered:
            raise ValueError("watching recovery result must be recovered")
        if self.reason is None and not self.recovered:
            return
        if self.reason is None and not self.watching:
            raise ValueError("recovered result without watcher must include reason")


def _safe_return_to_dock(callback: ReturnToDock) -> bool:
    """Best-effort return that never lets recovery failures escape."""

    try:
        callback()
    except Exception:  # noqa: BLE001 - recovery boundary must be fail-safe.
        return False
    return True


@dataclass(frozen=True, slots=True)
class ComponentRecoveryCoordinator:
    """Recover the shell for every launcher/window-flow outcome.

    The Dock stays visible throughout component transitions, so immediate
    recovery means refresh/re-presenting the existing shell.  Successful
    processes are still watched; failed presentation of an already-running
    instance triggers an immediate return while preserving the watcher.
    """

    window_coordinator: ComponentWindowCoordinator

    def handle(self, result: object, return_to_dock: ReturnToDock) -> RecoveryResult:
        if not isinstance(result, LaunchResult):
            _safe_return_to_dock(return_to_dock)
            return RecoveryResult(
                recovered=True,
                reason=RecoveryReason.INVALID_RESULT,
            )

        if result.status is LaunchStatus.FAILED:
            _safe_return_to_dock(return_to_dock)
            return RecoveryResult(
                recovered=True,
                reason=RecoveryReason.LAUNCH_FAILED,
            )

        if result.status is LaunchStatus.DISABLED:
            _safe_return_to_dock(return_to_dock)
            return RecoveryResult(
                recovered=True,
                reason=RecoveryReason.COMPONENT_DISABLED,
            )

        if result.status is LaunchStatus.UNAVAILABLE:
            _safe_return_to_dock(return_to_dock)
            return RecoveryResult(
                recovered=True,
                reason=RecoveryReason.COMPONENT_UNAVAILABLE,
            )

        if result.status is LaunchStatus.BLOCKED_ROOT:
            _safe_return_to_dock(return_to_dock)
            return RecoveryResult(
                recovered=True,
                reason=RecoveryReason.BLOCKED_ROOT,
            )

        if result.status is LaunchStatus.BLOCKED_PREREQUISITE:
            _safe_return_to_dock(return_to_dock)
            return RecoveryResult(
                recovered=True,
                reason=RecoveryReason.PREREQUISITE_BLOCKED,
            )

        if result.status not in {
            LaunchStatus.STARTED,
            LaunchStatus.ALREADY_RUNNING,
        }:
            _safe_return_to_dock(return_to_dock)
            return RecoveryResult(
                recovered=True,
                reason=RecoveryReason.INVALID_RESULT,
            )

        try:
            watching = bool(
                self.window_coordinator.handle(result, return_to_dock)
            )
        except Exception:  # noqa: BLE001 - watcher setup must not strand the shell.
            _safe_return_to_dock(return_to_dock)
            return RecoveryResult(
                recovered=True,
                reason=RecoveryReason.WINDOW_TRACKING_FAILED,
            )

        # ProcessExitWatcher calls return_to_dock immediately when the process
        # already disappeared before subscription. In that case ``watching`` is
        # false and no second presentation request is necessary.
        if not watching:
            return RecoveryResult(
                recovered=True,
                reason=RecoveryReason.PROCESS_EXITED_EARLY,
            )

        # If an existing process could not be presented, the user must remain at
        # a usable Dock rather than be left waiting for a hidden/inaccessible app.
        if result.status is LaunchStatus.ALREADY_RUNNING and not result.presented:
            _safe_return_to_dock(return_to_dock)
            return RecoveryResult(
                recovered=True,
                watching=True,
                reason=RecoveryReason.PRESENTATION_FAILED,
            )

        return RecoveryResult(recovered=True, watching=True)


def create_default_recovery_coordinator() -> ComponentRecoveryCoordinator:
    """Create the standard failure-recovery coordinator."""

    from xaac_thin_client_dock.system.windowing import create_default_window_coordinator

    return ComponentRecoveryCoordinator(create_default_window_coordinator())

"""Kiosk and operating-system integration boundary."""

from __future__ import annotations

from typing import Protocol, runtime_checkable


@runtime_checkable
class KioskIntegration(Protocol):
    """Isolate kiosk/session integration from the GUI and application core."""

    def prepare(self) -> None:
        """Prepare the kiosk/session integration required by the Dock."""

    def restore(self) -> None:
        """Restore or release resources owned by the kiosk integration."""

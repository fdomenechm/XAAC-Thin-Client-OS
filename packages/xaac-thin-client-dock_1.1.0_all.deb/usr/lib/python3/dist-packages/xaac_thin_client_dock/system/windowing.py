"""Window-flow integration for the XAAC kiosk shell.

Phase 4.2 keeps desktop/window-system details outside GTK presentation and the
controlled launcher.  Existing GApplication instances are activated through
the session D-Bus by matching their bus owner PID; component process lifetime
is then watched so the Dock can be re-presented when the component exits.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
import importlib
from pathlib import Path
from threading import Lock, Thread
from time import sleep
from typing import Protocol, runtime_checkable

from xaac_thin_client_dock.launching import LaunchResult, LaunchStatus


ReturnToDock = Callable[[], None]


@runtime_checkable
class ApplicationActivationBus(Protocol):
    """Small session-bus boundary required to activate an existing GUI app."""

    def names(self) -> tuple[str, ...]:
        """Return current well-known/unique bus names."""

    def owner_pid(self, name: str) -> int | None:
        """Return the Unix PID owning *name*, or ``None`` when unavailable."""

    def activate(self, name: str) -> bool:
        """Request ``org.freedesktop.Application.Activate`` for *name*."""


class GioApplicationActivationBus:
    """GApplication activation over the current user's D-Bus session bus.

    PyGObject is loaded dynamically so importing the system layer remains safe
    for backend-only tests and does not turn GTK/GI into a module-level system
    dependency.
    """

    __slots__ = ("_connection", "_gio", "_glib")

    def __init__(self) -> None:
        self._connection = None
        self._gio = None
        self._glib = None

    def _ensure_connection(self):
        if self._connection is not None:
            return self._connection

        try:
            gi = importlib.import_module("gi")
            gi.require_version("Gio", "2.0")
            repository = importlib.import_module("gi.repository")
            Gio = repository.Gio
            GLib = repository.GLib
            connection = Gio.bus_get_sync(Gio.BusType.SESSION, None)
        except Exception as exc:  # noqa: BLE001 - desktop boundary is best effort.
            raise OSError("session_bus_unavailable") from exc

        self._gio = Gio
        self._glib = GLib
        self._connection = connection
        return connection

    def names(self) -> tuple[str, ...]:
        connection = self._ensure_connection()
        try:
            reply = connection.call_sync(
                "org.freedesktop.DBus",
                "/org/freedesktop/DBus",
                "org.freedesktop.DBus",
                "ListNames",
                None,
                self._glib.VariantType.new("(as)"),
                self._gio.DBusCallFlags.NONE,
                1000,
                None,
            )
            names = reply.unpack()[0]
            return tuple(str(name) for name in names)
        except Exception as exc:  # noqa: BLE001
            raise OSError("session_bus_list_failed") from exc

    def owner_pid(self, name: str) -> int | None:
        connection = self._ensure_connection()
        try:
            reply = connection.call_sync(
                "org.freedesktop.DBus",
                "/org/freedesktop/DBus",
                "org.freedesktop.DBus",
                "GetConnectionUnixProcessID",
                self._glib.Variant("(s)", (name,)),
                self._glib.VariantType.new("(u)"),
                self._gio.DBusCallFlags.NONE,
                1000,
                None,
            )
            return int(reply.unpack()[0])
        except Exception:  # noqa: BLE001 - a disappearing bus owner is normal.
            return None

    def activate(self, name: str) -> bool:
        connection = self._ensure_connection()
        object_path = "/" + name.replace(".", "/")
        try:
            connection.call_sync(
                name,
                object_path,
                "org.freedesktop.Application",
                "Activate",
                self._glib.Variant("(a{sv})", ({},)),
                None,
                self._gio.DBusCallFlags.NONE,
                1000,
                None,
            )
        except Exception:  # noqa: BLE001 - not every same-PID bus name is an app.
            return False
        return True


class SessionBusInstancePresenter:
    """Present an existing GApplication by matching its D-Bus owner PID."""

    __slots__ = ("_bus",)

    def __init__(self, bus: ApplicationActivationBus | None = None) -> None:
        self._bus = bus or GioApplicationActivationBus()

    def present(self, pid: int) -> bool:
        if pid <= 0:
            return False
        try:
            names = self._bus.names()
        except OSError:
            return False

        # Unique names (":1.42") are transport-level identities and do not map
        # to the standard GApplication object path.  Only well-known names are
        # valid candidates for org.freedesktop.Application activation.
        for name in names:
            if not name or name.startswith(":") or name == "org.freedesktop.DBus":
                continue
            if self._bus.owner_pid(name) != pid:
                continue
            if self._bus.activate(name):
                return True
        return False


@runtime_checkable
class ProcessIdentityProbe(Protocol):
    """Return a stable token for one Linux process lifetime."""

    def token(self, pid: int) -> str | None:
        """Return a stable token while *pid* is the same process, else ``None``."""


class LinuxProcProcessIdentityProbe:
    """Use Linux ``/proc/<pid>/stat`` start time to survive PID reuse safely."""

    __slots__ = ("_proc_root",)

    def __init__(self, proc_root: str | Path = "/proc") -> None:
        self._proc_root = Path(proc_root)

    def token(self, pid: int) -> str | None:
        if pid <= 0:
            return None
        try:
            raw = (self._proc_root / str(pid) / "stat").read_text(
                encoding="utf-8",
                errors="replace",
            )
        except OSError:
            return None

        # /proc/<pid>/stat field 2 (comm) is parenthesised and may itself contain
        # spaces.  Split only after the final ')' then select field 22 starttime.
        closing = raw.rfind(")")
        if closing < 0:
            return None
        trailing = raw[closing + 1 :].strip().split()
        # trailing[0] is field 3 (state); field 22 is therefore index 19.
        if len(trailing) <= 19:
            return None
        return trailing[19]


class ProcessExitWatcher:
    """Watch component lifetimes without blocking GTK or spawning helpers."""

    __slots__ = ("_probe", "_poll_interval", "_watched", "_lock")

    def __init__(
        self,
        probe: ProcessIdentityProbe | None = None,
        *,
        poll_interval: float = 0.25,
    ) -> None:
        if poll_interval <= 0:
            raise ValueError("poll_interval must be greater than zero")
        self._probe = probe or LinuxProcProcessIdentityProbe()
        self._poll_interval = float(poll_interval)
        self._watched: set[tuple[int, str]] = set()
        self._lock = Lock()

    def watch(self, pid: int, callback: ReturnToDock) -> bool:
        """Start one daemon watcher; deduplicate repeated requests for a PID."""

        token = self._probe.token(pid)
        if token is None:
            # The process may have exited between launch/presentation completion
            # and subscription. Returning to the Dock immediately is correct, but
            # a presentation callback failure must never escape this system boundary.
            try:
                callback()
            except Exception:  # noqa: BLE001 - recovery callbacks are best effort.
                pass
            return False

        key = (pid, token)
        with self._lock:
            if key in self._watched:
                return False
            self._watched.add(key)

        Thread(
            target=self._wait_for_exit,
            args=(pid, token, key, callback),
            name=f"xaac-dock-window-{pid}",
            daemon=True,
        ).start()
        return True

    def _wait_for_exit(
        self,
        pid: int,
        token: str,
        key: tuple[int, str],
        callback: ReturnToDock,
    ) -> None:
        try:
            while self._probe.token(pid) == token:
                sleep(self._poll_interval)
            try:
                callback()
            except Exception:  # noqa: BLE001 - watcher cleanup must always complete.
                pass
        finally:
            with self._lock:
                self._watched.discard(key)


@dataclass(frozen=True, slots=True)
class ComponentWindowCoordinator:
    """Translate successful launch results into controlled return-to-Dock flow."""

    watcher: ProcessExitWatcher

    def handle(self, result: object, return_to_dock: ReturnToDock) -> bool:
        """Track started/existing component processes and ignore other results."""

        if not isinstance(result, LaunchResult):
            return False
        if result.status not in {
            LaunchStatus.STARTED,
            LaunchStatus.ALREADY_RUNNING,
        }:
            return False
        if result.pid is None:
            return False
        return self.watcher.watch(result.pid, return_to_dock)


def create_default_window_coordinator() -> ComponentWindowCoordinator:
    """Create the standard process-return coordinator for the Dock shell."""

    return ComponentWindowCoordinator(ProcessExitWatcher())

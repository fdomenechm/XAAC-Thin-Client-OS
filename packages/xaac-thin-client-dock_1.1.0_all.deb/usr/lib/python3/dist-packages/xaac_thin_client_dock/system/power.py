"""Authorized system power-off boundary for XAAC Thin Client Dock.

The Dock never invokes ``sudo``, ``pkexec`` or a shell helper.  Power-off is
requested from systemd-logind on the system D-Bus, using its interactive
authorization flag so XAAC Thin Client OS can own the corresponding policy.
"""

from __future__ import annotations

import importlib
from typing import Protocol, runtime_checkable


LOGIND_DBUS_NAME = "org.freedesktop.login1"
LOGIND_DBUS_PATH = "/org/freedesktop/login1"
LOGIND_DBUS_INTERFACE = "org.freedesktop.login1.Manager"


@runtime_checkable
class PowerController(Protocol):
    """Small boundary required by the Dock to request system shutdown."""

    def power_off(self) -> None:
        """Request an authorized power-off of the appliance."""


class LogindPowerController:
    """Request power-off through systemd-logind on the system D-Bus."""

    __slots__ = ("_connection", "_gio", "_glib")

    def __init__(self) -> None:
        self._connection = None
        self._gio = None
        self._glib = None

    def _ensure_connection(self):
        if self._connection is not None:
            return self._connection

        try:
            gi = importlib.import_module("gi")
            gi.require_version("Gio", "2.0")
            repository = importlib.import_module("gi.repository")
            Gio = repository.Gio
            GLib = repository.GLib
            connection = Gio.bus_get_sync(Gio.BusType.SYSTEM, None)
        except Exception as exc:  # noqa: BLE001 - OS boundary becomes a safe UX error.
            raise OSError("system_bus_unavailable") from exc

        self._gio = Gio
        self._glib = GLib
        self._connection = connection
        return connection

    def power_off(self) -> None:
        """Call ``org.freedesktop.login1.Manager.PowerOff(true)``.

        ``interactive=true`` delegates authorization to the operating system's
        policy instead of elevating privileges inside the Dock.
        """
        connection = self._ensure_connection()
        try:
            connection.call_sync(
                LOGIND_DBUS_NAME,
                LOGIND_DBUS_PATH,
                LOGIND_DBUS_INTERFACE,
                "PowerOff",
                self._glib.Variant("(b)", (True,)),
                None,
                self._gio.DBusCallFlags.NONE,
                5000,
                None,
            )
        except Exception as exc:  # noqa: BLE001 - surface a controlled GUI failure.
            raise OSError("poweroff_failed") from exc


def create_default_power_controller() -> PowerController:
    """Create the standard authorized power controller for XAAC Thin Client OS."""
    return LogindPowerController()


__all__ = [
    "LOGIND_DBUS_INTERFACE",
    "LOGIND_DBUS_NAME",
    "LOGIND_DBUS_PATH",
    "LogindPowerController",
    "PowerController",
    "create_default_power_controller",
]

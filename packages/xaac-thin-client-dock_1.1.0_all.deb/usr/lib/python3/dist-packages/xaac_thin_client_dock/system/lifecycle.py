"""Dock process/window lifecycle derived from validated policy."""

from __future__ import annotations

from dataclasses import dataclass

from xaac_thin_client_dock.configuration import DockPolicy


@dataclass(frozen=True, slots=True)
class DockLifecycle:
    """Runtime lifecycle decisions derived from :class:`DockPolicy`.

    The system layer owns persistence semantics so the GTK adapter only receives
    the concrete behaviour it must enforce.  This keeps configuration parsing
    out of the presentation layer.
    """

    enabled: bool
    persistent: bool

    def __post_init__(self) -> None:
        if self.persistent and not self.enabled:
            raise ValueError("a persistent Dock must also be enabled")

    @classmethod
    def from_policy(cls, policy: DockPolicy) -> "DockLifecycle":
        """Translate validated Dock policy into runtime lifecycle behaviour."""

        return cls(enabled=policy.enabled, persistent=policy.required)

    @property
    def restricted_kiosk(self) -> bool:
        """Whether the Dock must apply application-side kiosk confinement."""

        return self.enabled and self.persistent

    @property
    def user_close_allowed(self) -> bool:
        """Whether a normal window-close request may terminate the Dock."""

        return self.enabled and not self.persistent

"""Operating-system and kiosk integration layer."""

from xaac_thin_client_dock.system.kiosk import (
    DEFAULT_KIOSK_SHORTCUT_POLICY,
    KioskKeyStroke,
    KioskShortcutPolicy,
    create_default_kiosk_shortcut_policy,
)
from xaac_thin_client_dock.system.lifecycle import DockLifecycle
from xaac_thin_client_dock.system.ports import KioskIntegration
from xaac_thin_client_dock.system.power import (
    LOGIND_DBUS_INTERFACE,
    LOGIND_DBUS_NAME,
    LOGIND_DBUS_PATH,
    LogindPowerController,
    PowerController,
    create_default_power_controller,
)
from xaac_thin_client_dock.system.recovery import (
    ComponentRecoveryCoordinator,
    RecoveryReason,
    RecoveryResult,
    create_default_recovery_coordinator,
)
from xaac_thin_client_dock.system.windowing import (
    ApplicationActivationBus,
    ComponentWindowCoordinator,
    GioApplicationActivationBus,
    LinuxProcProcessIdentityProbe,
    ProcessExitWatcher,
    ProcessIdentityProbe,
    SessionBusInstancePresenter,
    create_default_window_coordinator,
)

__all__ = [
    "ApplicationActivationBus",
    "ComponentRecoveryCoordinator",
    "ComponentWindowCoordinator",
    "DEFAULT_KIOSK_SHORTCUT_POLICY",
    "DockLifecycle",
    "GioApplicationActivationBus",
    "KioskKeyStroke",
    "KioskShortcutPolicy",
    "KioskIntegration",
    "LOGIND_DBUS_INTERFACE",
    "LOGIND_DBUS_NAME",
    "LOGIND_DBUS_PATH",
    "LogindPowerController",
    "PowerController",
    "LinuxProcProcessIdentityProbe",
    "ProcessExitWatcher",
    "ProcessIdentityProbe",
    "RecoveryReason",
    "RecoveryResult",
    "SessionBusInstancePresenter",
    "create_default_kiosk_shortcut_policy",
    "create_default_power_controller",
    "create_default_recovery_coordinator",
    "create_default_window_coordinator",
]

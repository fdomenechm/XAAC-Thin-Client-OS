"""Presentation-layer helpers for non-blocking Dock operations."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from threading import Thread
from typing import Protocol, runtime_checkable


Operation = Callable[[], object]
OperationCompletion = Callable[[Exception | None], None]
UiPoster = Callable[..., object]


@runtime_checkable
class OperationRunner(Protocol):
    """Run a potentially blocking operation and report completion on the UI side."""

    def submit(
        self,
        operation: Operation,
        completed: OperationCompletion,
    ) -> None:
        """Start *operation* and eventually call *completed* exactly once."""


@dataclass(frozen=True, slots=True)
class ImmediateOperationRunner:
    """Deterministic runner used when no graphical main loop owns scheduling."""

    def submit(
        self,
        operation: Operation,
        completed: OperationCompletion,
    ) -> None:
        error: Exception | None = None
        try:
            operation()
        except Exception as exc:  # noqa: BLE001 - boundary converts failures to UX state.
            error = exc
        completed(error)


@dataclass(frozen=True, slots=True)
class ThreadedOperationRunner:
    """Run work on a daemon thread and marshal completion back to the GTK loop."""

    post_to_ui: UiPoster

    def submit(
        self,
        operation: Operation,
        completed: OperationCompletion,
    ) -> None:
        def worker() -> None:
            error: Exception | None = None
            try:
                operation()
            except Exception as exc:  # noqa: BLE001 - do not strand busy UI on failure.
                error = exc
            self.post_to_ui(completed, error)

        Thread(
            target=worker,
            name="xaac-dock-operation",
            daemon=True,
        ).start()

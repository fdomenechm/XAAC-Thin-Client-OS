"""Presentation mapping for the formal backend component state contract.

The core component state determines whether an application can be opened.  A
component may additionally expose a functional status (Phase 5 onward) that
only enriches what the user sees; it never replaces launchability semantics.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass

from xaac_thin_client_dock.components import ComponentId
from xaac_thin_client_dock.state import ComponentState, ComponentStatus


@dataclass(frozen=True, slots=True)
class DockComponentVisualState:
    """Immutable GUI-safe visual state for one Dock navigation target."""

    component_id: ComponentId
    status: ComponentStatus
    label_key: str
    display_label: str
    css_class: str
    interactive: bool
    functional_status: str | None = None

    def __post_init__(self) -> None:
        if not self.label_key.strip():
            raise ValueError("label_key must not be empty")
        if not self.display_label.strip():
            raise ValueError("display_label must not be empty")
        if not self.css_class.strip():
            raise ValueError("css_class must not be empty")
        if self.functional_status is not None and not self.functional_status.strip():
            raise ValueError("functional_status must not be empty")


DEFAULT_STATUS_LABELS: Mapping[ComponentStatus, str] = {
    ComponentStatus.DISABLED: "Disabled",
    ComponentStatus.UNAVAILABLE: "Unavailable",
    ComponentStatus.IDLE: "Available",
    ComponentStatus.RUNNING: "Running",
    ComponentStatus.ERROR: "Error",
}

STATUS_LABEL_KEYS: Mapping[ComponentStatus, str] = {
    ComponentStatus.DISABLED: "status.disabled",
    ComponentStatus.UNAVAILABLE: "status.unavailable",
    ComponentStatus.IDLE: "status.idle",
    ComponentStatus.RUNNING: "status.running",
    ComponentStatus.ERROR: "status.error",
}

STATUS_CSS_CLASSES: Mapping[ComponentStatus, str] = {
    ComponentStatus.DISABLED: "xaac-state-disabled",
    ComponentStatus.UNAVAILABLE: "xaac-state-unavailable",
    ComponentStatus.IDLE: "xaac-state-idle",
    ComponentStatus.RUNNING: "xaac-state-running",
    ComponentStatus.ERROR: "xaac-state-error",
}

# Stable generic functional-state strings.  Component integrations own the
# normalisation into these values; presentation only maps them to UI metadata.
DEFAULT_FUNCTIONAL_STATUS_LABELS: Mapping[str, str] = {
    "ethernet_connected": "Ethernet connected",
    "wifi_connected": "Wi-Fi connected",
    "connected": "Connected",
    "connecting": "Connecting",
    "disconnected": "No network",
    "limited": "Limited connectivity",
    "error": "Network error",
    "vpn_not_required": "VPN not required",
    "vpn_disconnected": "VPN disconnected",
    "vpn_connecting": "VPN connecting",
    "vpn_connected": "VPN connected",
    "vpn_disconnecting": "VPN disconnecting",
    "vpn_error": "VPN error",
    "session_available": "Session available",
    "session_connecting": "Session connecting",
    "session_active": "Session active",
    "session_error": "Session error",
    "session_network_required": "Connect network first",
    "session_network_unavailable": "Network status unavailable",
    "session_vpn_required": "Connect VPN first",
    "session_vpn_unavailable": "VPN status unavailable",
}

FUNCTIONAL_STATUS_LABEL_KEYS: Mapping[str, str] = {
    key: f"functional.{key}" for key in DEFAULT_FUNCTIONAL_STATUS_LABELS
}

FUNCTIONAL_STATUS_CSS_CLASSES: Mapping[str, str] = {
    "ethernet_connected": "xaac-state-running",
    "wifi_connected": "xaac-state-running",
    "connected": "xaac-state-running",
    "connecting": "xaac-state-idle",
    "disconnected": "xaac-state-error",
    "limited": "xaac-state-idle",
    "error": "xaac-state-error",
    "vpn_not_required": "xaac-state-idle",
    "vpn_disconnected": "xaac-state-error",
    "vpn_connecting": "xaac-state-idle",
    "vpn_connected": "xaac-state-running",
    "vpn_disconnecting": "xaac-state-idle",
    "vpn_error": "xaac-state-error",
    "session_available": "xaac-state-idle",
    "session_connecting": "xaac-state-idle",
    "session_active": "xaac-state-running",
    "session_error": "xaac-state-error",
    "session_network_required": "xaac-state-error",
    "session_network_unavailable": "xaac-state-error",
    "session_vpn_required": "xaac-state-error",
    "session_vpn_unavailable": "xaac-state-error",
}


def build_component_visual_state(
    state: ComponentState,
    labels: Mapping[ComponentStatus, str] | None = None,
    functional_labels: Mapping[str, str] | None = None,
) -> DockComponentVisualState:
    """Translate one backend state into deterministic presentation metadata."""

    display_labels = DEFAULT_STATUS_LABELS if labels is None else labels

    # Only launchable components may surface a functional status.  Disabled or
    # unavailable component policy/discovery states remain authoritative.
    if state.launchable and state.functional_status in DEFAULT_FUNCTIONAL_STATUS_LABELS:
        functional_status = state.functional_status
        translated_functional = (
            DEFAULT_FUNCTIONAL_STATUS_LABELS
            if functional_labels is None
            else functional_labels
        )
        return DockComponentVisualState(
            component_id=state.component_id,
            status=state.status,
            label_key=FUNCTIONAL_STATUS_LABEL_KEYS[functional_status],
            display_label=translated_functional.get(
                functional_status,
                DEFAULT_FUNCTIONAL_STATUS_LABELS[functional_status],
            ),
            css_class=FUNCTIONAL_STATUS_CSS_CLASSES[functional_status],
            interactive=state.navigable,
            functional_status=functional_status,
        )

    display_label = display_labels.get(state.status, state.status.value.title())
    return DockComponentVisualState(
        component_id=state.component_id,
        status=state.status,
        label_key=STATUS_LABEL_KEYS[state.status],
        display_label=display_label,
        css_class=STATUS_CSS_CLASSES[state.status],
        interactive=state.navigable,
    )


def build_component_visual_states(
    states: Sequence[ComponentState],
    labels: Mapping[ComponentStatus, str] | None = None,
    functional_labels: Mapping[str, str] | None = None,
) -> tuple[DockComponentVisualState, ...]:
    """Translate an ordered backend state snapshot for the GUI."""

    seen: set[ComponentId] = set()
    visual_states: list[DockComponentVisualState] = []
    for state in states:
        if state.component_id in seen:
            raise ValueError(f"duplicate component state: {state.component_id.value}")
        seen.add(state.component_id)
        visual_states.append(
            build_component_visual_state(state, labels, functional_labels)
        )
    return tuple(visual_states)


def create_error_visual_state(
    component_id: ComponentId,
    labels: Mapping[ComponentStatus, str] | None = None,
) -> DockComponentVisualState:
    """Return a fail-closed visual state when a state snapshot cannot be read."""

    display_labels = DEFAULT_STATUS_LABELS if labels is None else labels
    return DockComponentVisualState(
        component_id=component_id,
        status=ComponentStatus.ERROR,
        label_key=STATUS_LABEL_KEYS[ComponentStatus.ERROR],
        display_label=display_labels.get(
            ComponentStatus.ERROR,
            DEFAULT_STATUS_LABELS[ComponentStatus.ERROR],
        ),
        css_class=STATUS_CSS_CLASSES[ComponentStatus.ERROR],
        interactive=False,
    )

"""Pure presentation models for the Dock window shell.

Phase 3.1 keeps the basic window geometry and behaviour independent from GTK
so it can be validated without a graphical session.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class DockWindowSpec:
    """Stable window-shell settings used by the concrete GUI adapter."""

    application_id: str = "org.xaac.ThinClientDock"
    title: str = "XAAC Thin Client Dock"
    default_width: int = 720
    default_height: int = 96
    decorated: bool = False
    resizable: bool = False

    def __post_init__(self) -> None:
        if not self.application_id.strip():
            raise ValueError("application_id must not be empty")
        if not self.title.strip():
            raise ValueError("title must not be empty")
        if self.default_width <= 0:
            raise ValueError("default_width must be greater than zero")
        if self.default_height <= 0:
            raise ValueError("default_height must be greater than zero")


DEFAULT_DOCK_WINDOW_SPEC = DockWindowSpec()

"""GTK 4 implementation of the XAAC Thin Client Dock presentation shell."""

from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from importlib.resources import files
from typing import Any

from xaac_thin_client_dock import __version__
from xaac_thin_client_dock.i18n import gettext_message

from xaac_thin_client_dock.components.registry import ComponentId
from xaac_thin_client_dock.presentation.component_state import (
    DockComponentVisualState,
    build_component_visual_states,
    create_error_visual_state,
)
from xaac_thin_client_dock.presentation.model import (
    DEFAULT_DOCK_WINDOW_SPEC,
    DockWindowSpec,
)
from xaac_thin_client_dock.presentation.navigation import DockNavigationItem
from xaac_thin_client_dock.presentation.localization import (
    DEFAULT_POWER_ACTION_LABELS,
    PowerActionLabels,
)
from xaac_thin_client_dock.presentation.operations import (
    ImmediateOperationRunner,
    OperationRunner,
    ThreadedOperationRunner,
)
from xaac_thin_client_dock.state import ComponentState, ComponentStatus


class GtkUnavailableError(RuntimeError):
    """Raised when the GTK 4/PyGObject runtime is not available."""


def _load_gtk() -> tuple[Any, Any, Any, Any]:
    """Load GTK lazily so non-GUI backend tests do not depend on PyGObject."""
    try:
        import gi

        gi.require_version("Gtk", "4.0")
        from gi.repository import Gdk, Gio, GLib, Gtk
    except (ImportError, ValueError) as exc:
        raise GtkUnavailableError(
            "GTK 4/PyGObject is required to run XAAC Thin Client Dock"
        ) from exc

    return Gtk, Gdk, Gio, GLib


def _load_stylesheet() -> str:
    """Return the packaged Dock stylesheet."""
    return (
        files("xaac_thin_client_dock.presentation")
        .joinpath("resources/dock.css")
        .read_text(encoding="utf-8")
    )


def _brand_wordmark_path() -> str:
    """Return the packaged XAAC wordmark image path."""
    return str(
        files("xaac_thin_client_dock.presentation").joinpath(
            "resources/xaac-wordmark.png"
        )
    )


NavigationAction = Callable[[ComponentId], object]
PowerOffAction = Callable[[], object]
StateReader = Callable[[], Sequence[ComponentState]]
NavigationResultHandler = Callable[[object, Callable[[], None]], object]
KioskShortcutBlocker = Callable[[str, bool, bool, bool, bool], bool]
UiPoster = Callable[..., object]


class GtkDockView:
    """Concrete GTK 4 shell with navigation, states and non-blocking busy UX."""

    def __init__(
        self,
        spec: DockWindowSpec = DEFAULT_DOCK_WINDOW_SPEC,
        *,
        navigation_items: Sequence[DockNavigationItem] = (),
        activate_component: NavigationAction | None = None,
        read_component_states: StateReader | None = None,
        non_unique: bool = False,
        development_mode: bool = False,
        persistent: bool = False,
        kiosk_restricted: bool = False,
        kiosk_shortcut_blocker: KioskShortcutBlocker | None = None,
        operation_runner: OperationRunner | None = None,
        status_labels: Mapping[ComponentStatus, str] | None = None,
        functional_status_labels: Mapping[str, str] | None = None,
        navigation_result_handler: NavigationResultHandler | None = None,
        power_off_action: PowerOffAction | None = None,
        power_labels: PowerActionLabels = DEFAULT_POWER_ACTION_LABELS,
    ) -> None:
        self._spec = spec
        self._navigation_items = tuple(navigation_items)
        self._activate_component = activate_component
        self._read_component_states = read_component_states
        self._non_unique = bool(non_unique)
        self._development_mode = bool(development_mode)
        self._persistent = bool(persistent)
        self._kiosk_restricted = bool(kiosk_restricted)
        if self._kiosk_restricted and not self._persistent:
            raise ValueError("restricted kiosk mode requires a persistent Dock")
        self._kiosk_shortcut_blocker = kiosk_shortcut_blocker
        self._application_held = False
        self._inhibit_cookie: int | None = None
        self._operation_runner = operation_runner or ImmediateOperationRunner()
        self._uses_default_operation_runner = operation_runner is None
        self._status_labels = None if status_labels is None else dict(status_labels)
        self._functional_status_labels = (
            None if functional_status_labels is None else dict(functional_status_labels)
        )
        self._navigation_result_handler = navigation_result_handler
        self._power_off_action = power_off_action
        self._power_labels = power_labels
        self._post_to_ui: UiPoster | None = None
        self._glib: Any | None = None
        self._state_refresh_source: int | None = None
        self._operation_in_progress = False
        self._busy_component_id: ComponentId | None = None
        self._application: Any | None = None
        self._window: Any | None = None
        self._buttons: dict[ComponentId, Any] = {}
        self._state_labels: dict[ComponentId, Any] = {}
        self._state_indicators: dict[ComponentId, Any] = {}
        self._visual_states: dict[ComponentId, DockComponentVisualState] = {}
        self._about_button: Any | None = None
        self._diagnostics_button: Any | None = None
        self._auxiliary_dialog: Any | None = None
        self._power_button: Any | None = None
        self._power_dialog: Any | None = None
        self._power_confirmation_open = False

    @property
    def spec(self) -> DockWindowSpec:
        """Return the immutable window specification."""
        return self._spec

    @property
    def non_unique(self) -> bool:
        """Return whether GTK uniqueness is disabled for development."""
        return self._non_unique

    @property
    def persistent(self) -> bool:
        """Return whether the Dock enforces the required persistent lifecycle."""
        return self._persistent

    @property
    def development_mode(self) -> bool:
        """Return whether development-only desktop behaviour is enabled."""
        return self._development_mode

    @property
    def kiosk_restricted(self) -> bool:
        """Return whether application-side kiosk confinement is active."""
        return self._kiosk_restricted

    @property
    def navigation_items(self) -> tuple[DockNavigationItem, ...]:
        """Return the immutable navigation snapshot rendered by this view."""
        return self._navigation_items

    @property
    def visual_states(self) -> tuple[DockComponentVisualState, ...]:
        """Return the latest visual state snapshot in navigation order."""
        return tuple(
            self._visual_states[item.component_id]
            for item in self._navigation_items
            if item.component_id in self._visual_states
        )

    @property
    def operation_in_progress(self) -> bool:
        """Return whether one navigation transition is currently executing."""
        return self._operation_in_progress

    def run(self) -> int:
        """Start the GTK application and return its exit status."""
        Gtk, Gdk, Gio, GLib = _load_gtk()
        self._post_to_ui = GLib.idle_add
        self._glib = GLib
        if self._uses_default_operation_runner:
            self._operation_runner = ThreadedOperationRunner(GLib.idle_add)

        application_kwargs: dict[str, object] = {
            "application_id": self._spec.application_id,
        }
        if self._non_unique:
            application_kwargs["flags"] = Gio.ApplicationFlags.NON_UNIQUE
        application = Gtk.Application(**application_kwargs)
        application.connect("activate", self._on_activate, Gtk, Gdk)
        application.connect("shutdown", self._on_shutdown)
        return int(application.run([]))

    def _on_activate(self, application: Any, Gtk: Any, Gdk: Any) -> None:
        """Build or re-present the single Dock shell window."""
        self._application = application
        if self._window is not None:
            self.refresh_component_states()
            self._window.present()
            return

        self._install_css(Gtk, Gdk)
        initial_states = self._read_visual_states()

        window = Gtk.ApplicationWindow(
            application=application,
            title=self._spec.title,
        )
        window.set_default_size(
            self._spec.default_width,
            self._spec.default_height,
        )
        window.set_decorated(self._spec.decorated)
        window.set_resizable(self._spec.resizable)
        window.add_css_class("xaac-dock-window")
        window.connect("close-request", self._on_close_request)
        if self._kiosk_restricted:
            self._install_kiosk_key_guard(window, Gtk, Gdk)
        self._window = window

        surface = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=16,
        )
        surface.add_css_class("xaac-dock-surface")
        surface.set_hexpand(True)
        surface.set_vexpand(True)

        brand = Gtk.Picture.new_for_filename(_brand_wordmark_path())
        brand.add_css_class("xaac-dock-brand")
        brand.set_size_request(96, 28)
        brand.set_content_fit(Gtk.ContentFit.CONTAIN)
        brand.set_can_shrink(True)
        brand.set_halign(Gtk.Align.CENTER)
        brand.set_valign(Gtk.Align.CENTER)

        about_button = Gtk.Button()
        about_button.add_css_class("xaac-dock-brand-button")
        about_button.set_hexpand(False)
        about_button.set_vexpand(False)
        about_button.set_halign(Gtk.Align.CENTER)
        about_button.set_valign(Gtk.Align.CENTER)
        about_button.set_tooltip_text(gettext_message("About XAAC"))
        about_button.set_child(brand)
        about_button.connect("clicked", self._on_about_clicked, Gtk)
        self._about_button = about_button
        surface.append(about_button)

        separator = Gtk.Separator(orientation=Gtk.Orientation.VERTICAL)
        separator.add_css_class("xaac-dock-separator")
        surface.append(separator)

        content = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=12,
        )
        content.set_hexpand(True)
        content.set_vexpand(True)
        content.set_homogeneous(True)
        content.add_css_class("xaac-dock-content")

        self._buttons.clear()
        self._state_labels.clear()
        self._state_indicators.clear()
        self._visual_states.clear()
        self._operation_in_progress = False
        self._busy_component_id = None

        for item in self._navigation_items:
            button = Gtk.Button()
            button.add_css_class("xaac-dock-navigation-button")
            button.set_hexpand(True)
            button.set_vexpand(True)
            button.set_tooltip_text(item.display_label)

            button_content = Gtk.Box(
                orientation=Gtk.Orientation.VERTICAL,
                spacing=2,
            )
            button_content.add_css_class("xaac-dock-navigation-content")
            button_content.set_halign(Gtk.Align.CENTER)
            button_content.set_valign(Gtk.Align.CENTER)

            title_row = Gtk.Box(
                orientation=Gtk.Orientation.HORIZONTAL,
                spacing=8,
            )
            title_row.add_css_class("xaac-dock-title-row")
            title_row.set_halign(Gtk.Align.CENTER)
            title_row.set_valign(Gtk.Align.CENTER)

            icon = Gtk.Image.new_from_icon_name(item.icon_name)
            icon.add_css_class("xaac-dock-navigation-icon")
            icon.set_pixel_size(22)
            title_row.append(icon)

            label = Gtk.Label(label=item.display_label)
            label.add_css_class("xaac-dock-navigation-label")
            title_row.append(label)
            button_content.append(title_row)

            state_row = Gtk.Box(
                orientation=Gtk.Orientation.HORIZONTAL,
                spacing=5,
            )
            state_row.add_css_class("xaac-dock-state-row")
            state_row.set_halign(Gtk.Align.CENTER)
            state_row.set_valign(Gtk.Align.CENTER)

            state_indicator = Gtk.Label(label="●")
            state_indicator.add_css_class("xaac-dock-state-indicator")
            state_row.append(state_indicator)

            state_label = Gtk.Label(label="")
            state_label.add_css_class("xaac-dock-state-label")
            state_row.append(state_label)
            button_content.append(state_row)

            button.set_child(button_content)
            button.connect("clicked", self._on_navigation_clicked, item.component_id)
            content.append(button)

            self._buttons[item.component_id] = button
            self._state_labels[item.component_id] = state_label
            self._state_indicators[item.component_id] = state_indicator

            visual_state = initial_states.get(item.component_id)
            if visual_state is None:
                visual_state = create_error_visual_state(
                    item.component_id,
                    labels=self._status_labels,
                )
            self._apply_visual_state(visual_state)

        surface.append(content)

        system_separator = Gtk.Separator(orientation=Gtk.Orientation.VERTICAL)
        system_separator.add_css_class("xaac-dock-power-separator")
        surface.append(system_separator)

        system_actions = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=8,
        )
        system_actions.add_css_class("xaac-dock-system-actions")
        system_actions.set_hexpand(False)
        system_actions.set_vexpand(False)
        system_actions.set_halign(Gtk.Align.CENTER)
        system_actions.set_valign(Gtk.Align.CENTER)

        diagnostics_button = Gtk.Button()
        diagnostics_button.add_css_class("xaac-dock-diagnostics-button")
        diagnostics_button.set_hexpand(False)
        diagnostics_button.set_vexpand(False)
        diagnostics_button.set_halign(Gtk.Align.CENTER)
        diagnostics_button.set_valign(Gtk.Align.CENTER)
        diagnostics_button.set_tooltip_text(
            gettext_message("View component diagnostics")
        )

        diagnostics_content = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=6,
        )
        diagnostics_content.add_css_class("xaac-dock-diagnostics-content")
        diagnostics_content.set_halign(Gtk.Align.CENTER)
        diagnostics_content.set_valign(Gtk.Align.CENTER)

        diagnostics_icon = Gtk.Image.new_from_icon_name(
            "utilities-system-monitor-symbolic"
        )
        diagnostics_icon.add_css_class("xaac-dock-diagnostics-icon")
        diagnostics_icon.set_pixel_size(18)
        diagnostics_content.append(diagnostics_icon)

        diagnostics_label = Gtk.Label(label=gettext_message("Diagnostics"))
        diagnostics_label.add_css_class("xaac-dock-diagnostics-label")
        diagnostics_content.append(diagnostics_label)

        diagnostics_button.set_child(diagnostics_content)
        diagnostics_button.connect("clicked", self._on_diagnostics_clicked, Gtk)
        self._diagnostics_button = diagnostics_button
        system_actions.append(diagnostics_button)

        if self._development_mode or self._power_off_action is not None:
            power_button = Gtk.Button()
            power_button.add_css_class("xaac-dock-power-button")
            power_button.set_hexpand(False)
            power_button.set_vexpand(False)
            power_button.set_halign(Gtk.Align.CENTER)
            power_button.set_valign(Gtk.Align.CENTER)
            power_button.set_tooltip_text(self._power_labels.button)

            power_content = Gtk.Box(
                orientation=Gtk.Orientation.HORIZONTAL,
                spacing=6,
            )
            power_content.add_css_class("xaac-dock-power-content")
            power_content.set_halign(Gtk.Align.CENTER)
            power_content.set_valign(Gtk.Align.CENTER)

            power_icon = Gtk.Image.new_from_icon_name("system-shutdown-symbolic")
            power_icon.add_css_class("xaac-dock-power-icon")
            power_icon.set_pixel_size(18)
            power_content.append(power_icon)

            power_label = Gtk.Label(label=self._power_labels.button)
            power_label.add_css_class("xaac-dock-power-label")
            power_content.append(power_label)

            power_button.set_child(power_content)
            power_button.connect("clicked", self._on_power_clicked, Gtk)
            self._power_button = power_button
            system_actions.append(power_button)

        surface.append(system_actions)

        window.set_child(surface)
        window.present()
        self._start_state_refresh_timer()

        if self._kiosk_restricted and self._inhibit_cookie is None:
            self._inhibit_cookie = self._inhibit_session_actions(
                application,
                window,
                Gtk,
            )

        # Hold only after the persistent shell was successfully constructed and
        # presented.  A construction error must never leave a headless process
        # alive merely because the hold happened too early.
        if self._persistent and not self._application_held:
            application.hold()
            self._application_held = True

    def _on_about_clicked(self, button: Any, Gtk: Any) -> None:
        """Open the global XAAC about information from the brand wordmark."""
        if not self._begin_auxiliary_dialog(button):
            return
        try:
            dialog = Gtk.MessageDialog(
                transient_for=self._window,
                modal=True,
                message_type=Gtk.MessageType.INFO,
                buttons=Gtk.ButtonsType.NONE,
                text=gettext_message("XAAC Thin Client OS"),
            )
            dialog.set_secondary_text(
                gettext_message("XAAC Thin Client Dock version {version}").format(
                    version=__version__,
                )
                + "\n\n"
                + gettext_message(
                    "Controlled shell for network, VPN and remote-session access."
                )
            )
            dialog.add_button(gettext_message("Close"), Gtk.ResponseType.CLOSE)
            dialog.connect("response", self._on_auxiliary_dialog_response)
            self._auxiliary_dialog = dialog
            self._restore_auxiliary_cursor()
            self._sync_auxiliary_button_sensitivity()
            self._sync_power_button_sensitivity()
            dialog.present()
        except Exception:
            self._finish_auxiliary_dialog()

    def _on_diagnostics_clicked(self, button: Any, Gtk: Any) -> None:
        """Show a safe Dock-level summary of the three managed components."""
        if not self._begin_auxiliary_dialog(button):
            return
        try:
            states = (
                tuple(self._read_component_states())
                if self._read_component_states is not None
                else ()
            )
            summary = self._render_diagnostics_summary(states)
            dialog = Gtk.MessageDialog(
                transient_for=self._window,
                modal=True,
                message_type=Gtk.MessageType.INFO,
                buttons=Gtk.ButtonsType.NONE,
                text=gettext_message("XAAC diagnostics"),
            )
            dialog.set_secondary_text(summary)
            dialog.add_button(gettext_message("Close"), Gtk.ResponseType.CLOSE)
            dialog.connect("response", self._on_auxiliary_dialog_response)
            self._auxiliary_dialog = dialog
            self._restore_auxiliary_cursor()
            self._sync_auxiliary_button_sensitivity()
            self._sync_power_button_sensitivity()
            dialog.present()
        except Exception:
            self._finish_auxiliary_dialog()

    def _render_diagnostics_summary(
        self,
        states: Sequence[ComponentState],
    ) -> str:
        """Render only non-secret component state suitable for local support."""
        labels = {item.component_id: item.display_label for item in self._navigation_items}
        lines = [
            gettext_message("Current component state"),
            "",
        ]
        if not states:
            lines.append(gettext_message("No component state is available."))
            return "\n".join(lines)

        by_id = {state.component_id: state for state in states}
        visual_by_id = {
            visual.component_id: visual
            for visual in build_component_visual_states(
                states,
                labels=self._status_labels,
                functional_labels=self._functional_status_labels,
            )
        }
        for item in self._navigation_items:
            state = by_id.get(item.component_id)
            label = labels.get(item.component_id, item.component_id.value)
            if state is None:
                lines.append(f"{label}: {gettext_message('Unavailable')}")
                continue
            visual = visual_by_id[state.component_id]
            lines.append(f"{label}: {visual.display_label}")
            if state.functional_error:
                lines.append(
                    f"  {gettext_message('Detail')}: {state.functional_error}"
                )
            elif state.error:
                lines.append(f"  {gettext_message('Detail')}: {state.error}")
        return "\n".join(lines)

    def _begin_auxiliary_dialog(self, button: Any) -> bool:
        if self._operation_in_progress or self._auxiliary_dialog is not None:
            return False
        button.set_sensitive(False)
        if self._window is not None:
            self._window.set_cursor_from_name("wait")
        return True

    def _restore_auxiliary_cursor(self) -> None:
        if self._window is not None:
            self._window.set_cursor_from_name(None)

    def _on_auxiliary_dialog_response(self, dialog: Any, _response_id: Any) -> None:
        try:
            dialog.destroy()
        finally:
            if dialog is self._auxiliary_dialog:
                self._auxiliary_dialog = None
            self._finish_auxiliary_dialog()

    def _finish_auxiliary_dialog(self) -> None:
        self._auxiliary_dialog = None
        self._restore_auxiliary_cursor()
        self._sync_auxiliary_button_sensitivity()
        self._sync_power_button_sensitivity()

    def _sync_auxiliary_button_sensitivity(self) -> None:
        enabled = not self._operation_in_progress and self._auxiliary_dialog is None
        if self._about_button is not None:
            self._about_button.set_sensitive(enabled)
        if self._diagnostics_button is not None:
            self._diagnostics_button.set_sensitive(enabled)

    def _install_kiosk_key_guard(self, window: Any, Gtk: Any, Gdk: Any) -> None:
        """Consume desktop escape accelerators if they reach the Dock window."""
        if self._kiosk_shortcut_blocker is None:
            return
        controller = Gtk.EventControllerKey()
        controller.connect("key-pressed", self._on_kiosk_key_pressed, Gdk)
        window.add_controller(controller)

    def _on_kiosk_key_pressed(
        self,
        _controller: Any,
        keyval: int,
        _keycode: int,
        state: Any,
        Gdk: Any,
    ) -> bool:
        """Normalize a GDK key event and apply the injected kiosk policy."""
        blocker = self._kiosk_shortcut_blocker
        if blocker is None:
            return False

        key_name = Gdk.keyval_name(keyval) or ""
        modifier_type = Gdk.ModifierType
        alt = bool(state & modifier_type.ALT_MASK)
        control = bool(state & modifier_type.CONTROL_MASK)
        shift = bool(state & modifier_type.SHIFT_MASK)
        super_mask = getattr(modifier_type, "SUPER_MASK", 0)
        meta_mask = getattr(modifier_type, "META_MASK", 0)
        super_pressed = bool(state & (super_mask | meta_mask))
        return bool(blocker(key_name, alt, control, shift, super_pressed))

    @staticmethod
    def _inhibit_session_actions(application: Any, window: Any, Gtk: Any) -> int | None:
        """Ask the graphical session not to expose logout/switch/suspend escapes."""
        flags_type = getattr(Gtk, "ApplicationInhibitFlags", None)
        if flags_type is None or not hasattr(application, "inhibit"):
            return None
        flags = (
            flags_type.LOGOUT
            | flags_type.SWITCH
            | flags_type.SUSPEND
            | flags_type.IDLE
        )
        try:
            cookie = application.inhibit(
                window,
                flags,
                "XAAC Thin Client Dock kiosk session",
            )
        except Exception:  # noqa: BLE001 - desktop session inhibition is best effort.
            return None
        return int(cookie) if cookie else None

    def _on_shutdown(self, application: Any) -> None:
        """Release runtime timers and session inhibition owned by this Dock."""
        self._application = None
        self._stop_state_refresh_timer()
        cookie = self._inhibit_cookie
        self._inhibit_cookie = None
        if cookie is None or not hasattr(application, "uninhibit"):
            return
        try:
            application.uninhibit(cookie)
        except Exception:
            return


    def _start_state_refresh_timer(self) -> None:
        """Refresh component state after boot races and later runtime changes."""
        if (
            self._read_component_states is None
            or self._glib is None
            or self._state_refresh_source is not None
        ):
            return
        try:
            self._state_refresh_source = int(
                self._glib.timeout_add_seconds(1, self._periodic_state_refresh)
            )
        except Exception:
            self._state_refresh_source = None

    def _stop_state_refresh_timer(self) -> None:
        source = self._state_refresh_source
        self._state_refresh_source = None
        if source is None or self._glib is None:
            return
        try:
            self._glib.source_remove(source)
        except Exception:
            return

    def _periodic_state_refresh(self) -> bool:
        """GTK timer callback; state transport failures remain presentation-safe."""
        if self._window is None:
            self._state_refresh_source = None
            return False
        self.refresh_component_states()
        return True

    def _on_close_request(self, window: Any) -> bool:
        """Keep a required Dock visible; allow normal close in optional mode."""
        if not self._persistent:
            return False

        # Alt+F4 / WM close requests must not remove the kiosk shell.  Re-present
        # the existing single window rather than creating another instance.
        self.refresh_component_states()
        window.present()
        return True

    def _on_navigation_clicked(
        self,
        _button: Any,
        component_id: ComponentId,
    ) -> None:
        """Start one guarded navigation operation without blocking the GTK loop."""
        if self._activate_component is None:
            self.refresh_component_states()
            return
        if not self._begin_navigation_operation(component_id):
            return

        result_box: dict[str, object] = {}

        def operation() -> object:
            result = self._activate_component(component_id)
            result_box["result"] = result
            return result

        def completed(error: Exception | None) -> None:
            # Busy state must be cleared before any recovery/presentation path.
            self._finish_navigation_operation(component_id)
            if error is not None:
                self._recover_navigation_failure(component_id)
                return
            if self._navigation_result_handler is None:
                return
            result = result_box.get("result")
            if result is None:
                self._recover_navigation_failure(component_id)
                return
            try:
                self._navigation_result_handler(
                    result,
                    self._request_return_to_dock,
                )
            except Exception:
                # A broken system/window integration layer must never make the
                # shell unusable. Keep the existing Dock alive and visible.
                self._recover_navigation_failure(component_id)

        try:
            self._operation_runner.submit(operation, completed)
        except Exception:  # noqa: BLE001 - restore the UI even if scheduling fails.
            self._finish_navigation_operation(component_id)
            self._recover_navigation_failure(component_id)

    def _recover_navigation_failure(self, component_id: ComponentId) -> None:
        """Restore a usable shell after an unexpected navigation-layer failure.

        The backend state reader remains authoritative, so recovery never invents
        a persistent functional state.  It guarantees only that busy UX is gone,
        the existing Dock is refreshed best-effort and the shell is presented.
        """
        self._operation_in_progress = False
        self._busy_component_id = None

        button = self._buttons.get(component_id)
        if button is not None:
            button.remove_css_class("xaac-operation-busy")

        if self._window is not None:
            try:
                self._window.set_cursor_from_name(None)
            except Exception:  # noqa: BLE001 - recovery must continue to present.
                pass

        try:
            self.refresh_component_states()
        except Exception:  # noqa: BLE001 - presentation itself is best effort.
            pass

        if self._window is not None:
            try:
                self._window.present()
            except Exception:  # noqa: BLE001 - never propagate recovery failures.
                pass

    def _request_return_to_dock(self) -> None:
        """Thread-safe request used by window/recovery coordinators."""
        if self._post_to_ui is None:
            self._present_dock_window()
            return
        try:
            self._post_to_ui(self._present_dock_window)
        except Exception:
            # Do not call GTK directly from a watcher/worker thread. The Dock is
            # deliberately never hidden, so a failed UI post still leaves a
            # usable persistent shell rather than risking unsafe cross-thread GTK.
            return

    def _present_dock_window(self) -> bool:
        """Refresh and present the existing Dock as the navigation home."""
        if self._window is None:
            return False
        self.refresh_component_states()
        self._window.present()
        return False

    def _begin_navigation_operation(self, component_id: ComponentId) -> bool:
        """Enter busy mode once and reject overlapping/double-click operations."""
        if self._operation_in_progress:
            return False

        visual_state = self._visual_states.get(component_id)
        if visual_state is not None and not visual_state.interactive:
            return False

        button = self._buttons.get(component_id)
        if button is None:
            return False

        self._operation_in_progress = True
        self._busy_component_id = component_id
        button.add_css_class("xaac-operation-busy")

        for rendered_button in self._buttons.values():
            rendered_button.set_sensitive(False)
        if self._about_button is not None:
            self._about_button.set_sensitive(False)
        if self._diagnostics_button is not None:
            self._diagnostics_button.set_sensitive(False)
        if self._power_button is not None:
            self._power_button.set_sensitive(False)

        if self._window is not None:
            self._window.set_cursor_from_name("wait")
        return True

    def _finish_navigation_operation(self, component_id: ComponentId) -> None:
        """Always leave busy mode and rebuild sensitivity from backend state."""
        button = self._buttons.get(component_id)
        if button is not None:
            button.remove_css_class("xaac-operation-busy")

        self._operation_in_progress = False
        self._busy_component_id = None

        if self._window is not None:
            self._window.set_cursor_from_name(None)

        self.refresh_component_states()

    def _on_power_clicked(self, _button: Any, Gtk: Any) -> None:
        """Open one shutdown confirmation before any power/exit action.

        GTK 4.10+ provides :class:`Gtk.AlertDialog`, the binding-friendly
        replacement for the deprecated ``Gtk.MessageDialog``/``Gtk.Dialog``
        API.  Debian 13 ships GTK 4.18, so use the async AlertDialog path in
        the real XAAC runtime.  A legacy fallback is kept only for older GTK 4
        development hosts.
        """
        if (
            self._operation_in_progress
            or self._power_confirmation_open
            or self._window is None
        ):
            return

        if not self._development_mode and self._power_off_action is None:
            return

        self._power_confirmation_open = True
        self._sync_auxiliary_button_sensitivity()
        self._sync_power_button_sensitivity()
        try:
            alert_dialog_type = getattr(Gtk, "AlertDialog", None)
            if alert_dialog_type is not None:
                dialog = alert_dialog_type()
                dialog.set_message(self._power_labels.confirmation_title)
                dialog.set_detail(self._power_labels.confirmation_message)
                dialog.set_modal(True)
                dialog.set_buttons(
                    [self._power_labels.cancel, self._power_labels.confirm]
                )
                # Cancel is both the Escape action and the safe keyboard
                # default.  Confirmation therefore always requires an
                # explicit choice by the user.
                dialog.set_cancel_button(0)
                dialog.set_default_button(0)
                self._power_dialog = dialog
                dialog.choose(
                    self._window,
                    None,
                    self._on_power_alert_chosen,
                    Gtk,
                )
                return

            # Compatibility fallback for GTK 4 versions older than 4.10.
            dialog = Gtk.MessageDialog(
                transient_for=self._window,
                modal=True,
                message_type=Gtk.MessageType.QUESTION,
                buttons=Gtk.ButtonsType.NONE,
                text=self._power_labels.confirmation_title,
            )
            dialog.set_secondary_text(self._power_labels.confirmation_message)
            dialog.add_button(self._power_labels.cancel, Gtk.ResponseType.CANCEL)
            dialog.add_button(self._power_labels.confirm, Gtk.ResponseType.OK)
            dialog.set_default_response(Gtk.ResponseType.CANCEL)
            dialog.connect("response", self._on_power_confirmation_response, Gtk)
            self._power_dialog = dialog
            dialog.present()
        except Exception as exc:
            # Do not make a broken confirmation path look like an inert button.
            # The GUI is restored immediately and the concrete GTK exception is
            # emitted to stderr so validate-gui.sh/dev.sh can expose it.
            import sys

            print(
                f"XAAC Thin Client Dock: unable to show power confirmation: {exc}",
                file=sys.stderr,
            )
            self._power_confirmation_open = False
            self._power_dialog = None
            self._sync_power_button_sensitivity()

    def _on_power_alert_chosen(
        self,
        dialog: Any,
        result: Any,
        Gtk: Any,
    ) -> None:
        """Handle the asynchronous response from ``Gtk.AlertDialog``."""
        confirmed = False
        try:
            confirmed = int(dialog.choose_finish(result)) == 1
        except Exception:
            # Closing/cancelling the dialog, or an async GTK error, is always
            # treated as cancellation.
            confirmed = False

        self._power_dialog = None
        self._power_confirmation_open = False
        self._complete_power_confirmation(confirmed, Gtk)

    def _complete_power_confirmation(self, confirmed: bool, Gtk: Any) -> None:
        """Apply the common result of either confirmation-dialog backend."""
        if not confirmed:
            self._sync_power_button_sensitivity()
            return

        if self._development_mode:
            self._exit_development_application()
            return

        self._start_power_off_operation(Gtk)

    def _exit_development_application(self) -> None:
        """Close the Dock process instead of powering off the development host."""
        application = self._application
        if application is None or not hasattr(application, "quit"):
            return

        # Give immediate feedback even if the desktop needs one more main-loop
        # iteration to complete Gtk.Application.quit().
        self._operation_in_progress = True
        self._busy_component_id = None
        if self._power_button is not None:
            self._power_button.add_css_class("xaac-operation-busy")
            self._power_button.set_sensitive(False)
        for rendered_button in self._buttons.values():
            rendered_button.set_sensitive(False)
        if self._window is not None:
            self._window.set_cursor_from_name("wait")

        try:
            application.quit()
        except Exception:
            # Development exit must never strand the UI in a busy state if a
            # non-standard application object rejects quit().
            self._finish_power_operation()

    def _on_power_confirmation_response(
        self,
        dialog: Any,
        response_id: Any,
        Gtk: Any,
    ) -> None:
        """Cancel safely or start the authorized shutdown operation."""
        try:
            dialog.destroy()
        except Exception:
            pass
        self._power_dialog = None
        self._power_confirmation_open = False

        self._complete_power_confirmation(
            response_id == Gtk.ResponseType.OK,
            Gtk,
        )

    def _start_power_off_operation(self, Gtk: Any) -> None:
        """Enter busy UX immediately and request system shutdown off the GTK loop."""
        if not self._begin_power_operation():
            return

        def operation() -> object:
            if self._power_off_action is None:
                raise RuntimeError("power_off_unavailable")
            return self._power_off_action()

        def completed(error: Exception | None) -> None:
            if error is None:
                # logind accepts the request before the machine actually powers
                # off. Keep the UI blocked to prevent duplicate system actions.
                return
            self._finish_power_operation()
            self._show_power_error(Gtk)

        try:
            self._operation_runner.submit(operation, completed)
        except Exception:
            self._finish_power_operation()
            self._show_power_error(Gtk)

    def _begin_power_operation(self) -> bool:
        if (
            self._operation_in_progress
            or self._power_button is None
            or self._power_off_action is None
        ):
            return False

        self._operation_in_progress = True
        self._busy_component_id = None
        self._power_button.add_css_class("xaac-operation-busy")
        self._power_button.set_sensitive(False)
        for rendered_button in self._buttons.values():
            rendered_button.set_sensitive(False)
        if self._about_button is not None:
            self._about_button.set_sensitive(False)
        if self._diagnostics_button is not None:
            self._diagnostics_button.set_sensitive(False)
        if self._window is not None:
            self._window.set_cursor_from_name("wait")
        return True

    def _finish_power_operation(self) -> None:
        if self._power_button is not None:
            self._power_button.remove_css_class("xaac-operation-busy")
        self._operation_in_progress = False
        self._busy_component_id = None
        if self._window is not None:
            self._window.set_cursor_from_name(None)
        self._sync_auxiliary_button_sensitivity()
        self.refresh_component_states()

    def _show_power_error(self, Gtk: Any) -> None:
        """Show a controlled error after restoring cursor and button sensitivity."""
        if self._window is None:
            return
        try:
            dialog = Gtk.MessageDialog(
                transient_for=self._window,
                modal=True,
                message_type=Gtk.MessageType.ERROR,
                buttons=Gtk.ButtonsType.NONE,
                text=self._power_labels.error_title,
            )
            dialog.set_secondary_text(self._power_labels.error_message)
            dialog.add_button(self._power_labels.close, Gtk.ResponseType.CLOSE)
            dialog.connect("response", self._destroy_dialog)
            dialog.present()
        except Exception:
            return

    @staticmethod
    def _destroy_dialog(dialog: Any, _response_id: Any) -> None:
        try:
            dialog.destroy()
        except Exception:
            return

    def _sync_power_button_sensitivity(self) -> None:
        if self._power_button is None:
            return
        self._power_button.set_sensitive(
            not self._operation_in_progress
            and not self._power_confirmation_open
            and self._auxiliary_dialog is None
        )

    def refresh_component_states(self) -> None:
        """Refresh all rendered controls from the injected state provider."""
        if not self._buttons:
            return
        states = self._read_visual_states()
        for item in self._navigation_items:
            visual_state = states.get(item.component_id)
            if visual_state is None:
                visual_state = create_error_visual_state(
                    item.component_id,
                    labels=self._status_labels,
                )
            self._apply_visual_state(visual_state)
        self._sync_auxiliary_button_sensitivity()
        self._sync_power_button_sensitivity()

    def _read_visual_states(self) -> dict[ComponentId, DockComponentVisualState]:
        if self._read_component_states is None:
            return {}
        try:
            states = tuple(self._read_component_states())
            visual_states = build_component_visual_states(
                states,
                labels=self._status_labels,
                functional_labels=self._functional_status_labels,
            )
        except Exception:  # noqa: BLE001 - state backend failure maps to safe Error UI.
            return {
                item.component_id: create_error_visual_state(
                    item.component_id,
                    labels=self._status_labels,
                )
                for item in self._navigation_items
            }
        return {state.component_id: state for state in visual_states}

    def _apply_visual_state(self, visual_state: DockComponentVisualState) -> None:
        component_id = visual_state.component_id
        button = self._buttons.get(component_id)
        state_label = self._state_labels.get(component_id)
        state_indicator = self._state_indicators.get(component_id)
        if button is None or state_label is None or state_indicator is None:
            return

        previous = self._visual_states.get(component_id)
        if previous is not None:
            button.remove_css_class(previous.css_class)
            state_label.remove_css_class(previous.css_class)
            state_indicator.remove_css_class(previous.css_class)

        button.add_css_class(visual_state.css_class)
        state_label.add_css_class(visual_state.css_class)
        state_indicator.add_css_class(visual_state.css_class)
        state_label.set_label(visual_state.display_label)
        button.set_sensitive(
            visual_state.interactive and not self._operation_in_progress
        )
        self._visual_states[component_id] = visual_state

    @staticmethod
    def _install_css(Gtk: Any, Gdk: Any) -> None:
        display = Gdk.Display.get_default()
        if display is None:
            raise RuntimeError("No graphical display is available")

        provider = Gtk.CssProvider()
        provider.load_from_string(_load_stylesheet())
        Gtk.StyleContext.add_provider_for_display(
            display,
            provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION,
        )


def create_gtk_dock_view(
    *,
    navigation_items: Sequence[DockNavigationItem] = (),
    activate_component: NavigationAction | None = None,
    read_component_states: StateReader | None = None,
    non_unique: bool = False,
    development_mode: bool = False,
    persistent: bool = False,
    kiosk_restricted: bool = False,
    kiosk_shortcut_blocker: KioskShortcutBlocker | None = None,
    operation_runner: OperationRunner | None = None,
    status_labels: Mapping[ComponentStatus, str] | None = None,
    functional_status_labels: Mapping[str, str] | None = None,
    navigation_result_handler: NavigationResultHandler | None = None,
    power_off_action: PowerOffAction | None = None,
    power_labels: PowerActionLabels = DEFAULT_POWER_ACTION_LABELS,
) -> GtkDockView:
    """Create the GTK implementation with injected navigation/state dependencies."""
    return GtkDockView(
        navigation_items=navigation_items,
        activate_component=activate_component,
        read_component_states=read_component_states,
        non_unique=non_unique,
        development_mode=development_mode,
        persistent=persistent,
        kiosk_restricted=kiosk_restricted,
        kiosk_shortcut_blocker=kiosk_shortcut_blocker,
        operation_runner=operation_runner,
        status_labels=status_labels,
        functional_status_labels=functional_status_labels,
        navigation_result_handler=navigation_result_handler,
        power_off_action=power_off_action,
        power_labels=power_labels,
    )

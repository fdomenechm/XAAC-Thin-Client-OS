"""GUI boundary for XAAC Thin Client Dock."""

from __future__ import annotations

from typing import Protocol, runtime_checkable


@runtime_checkable
class DockView(Protocol):
    """Represent the graphical shell without coupling it to system services."""

    def run(self) -> int:
        """Run the Dock user interface and return its process exit status."""

"""Presentation label localisation built on the Dock gettext catalogue."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

from xaac_thin_client_dock.components.registry import ComponentId
from xaac_thin_client_dock.i18n import gettext_message
from xaac_thin_client_dock.presentation.component_state import (
    DEFAULT_FUNCTIONAL_STATUS_LABELS,
    DEFAULT_STATUS_LABELS,
)
from xaac_thin_client_dock.presentation.navigation import DEFAULT_NAVIGATION_LABELS
from xaac_thin_client_dock.state import ComponentStatus

Translator = Callable[[str], str]


@dataclass(frozen=True, slots=True)
class PowerActionLabels:
    """Localized labels used by the Dock system power action."""

    button: str
    confirmation_title: str
    confirmation_message: str
    cancel: str
    confirm: str
    error_title: str
    error_message: str
    close: str


DEFAULT_POWER_ACTION_LABELS = PowerActionLabels(
    button="Shut down",
    confirmation_title="Are you sure you want to shut down the device?",
    confirmation_message="The device will shut down completely.",
    cancel="Cancel",
    confirm="Accept",
    error_title="Shutdown failed",
    error_message="Unable to shut down the device.",
    close="Close",
)


def build_localized_navigation_labels(
    translator: Translator = gettext_message,
) -> dict[ComponentId, str]:
    """Return translated navigation labels keyed by stable component id."""
    return {
        component_id: translator(source_label)
        for component_id, source_label in DEFAULT_NAVIGATION_LABELS.items()
    }


def build_localized_status_labels(
    translator: Translator = gettext_message,
) -> dict[ComponentStatus, str]:
    """Return translated component-status labels keyed by backend status."""
    return {
        status: translator(source_label)
        for status, source_label in DEFAULT_STATUS_LABELS.items()
    }


def build_localized_functional_status_labels(
    translator: Translator = gettext_message,
) -> dict[str, str]:
    """Return translated component functional-status labels."""
    return {
        status: translator(source_label)
        for status, source_label in DEFAULT_FUNCTIONAL_STATUS_LABELS.items()
    }


def build_localized_power_action_labels(
    translator: Translator = gettext_message,
) -> PowerActionLabels:
    """Return translated labels for the global Dock power action."""
    source = DEFAULT_POWER_ACTION_LABELS
    return PowerActionLabels(
        button=translator(source.button),
        confirmation_title=translator(source.confirmation_title),
        confirmation_message=translator(source.confirmation_message),
        cancel=translator(source.cancel),
        confirm=translator(source.confirm),
        error_title=translator(source.error_title),
        error_message=translator(source.error_message),
        close=translator(source.close),
    )


__all__ = [
    "DEFAULT_POWER_ACTION_LABELS",
    "PowerActionLabels",
    "build_localized_functional_status_labels",
    "build_localized_power_action_labels",
    "build_localized_navigation_labels",
    "build_localized_status_labels",
]

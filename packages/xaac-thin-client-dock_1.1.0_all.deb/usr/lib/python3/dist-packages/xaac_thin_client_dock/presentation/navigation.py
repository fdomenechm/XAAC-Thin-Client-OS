"""Navigation model and controller for the Dock main surface.

Phase 3.2 turns the Phase 3.1 content slot into registry-driven navigation.
GTK remains a rendering adapter: component order and launch delegation live in
pure/testable objects here.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import TYPE_CHECKING

from xaac_thin_client_dock.components.registry import ComponentId, ComponentRegistry

if TYPE_CHECKING:
    from xaac_thin_client_dock.launching.model import LaunchResult
    from xaac_thin_client_dock.launching.ports import ApplicationLauncher


@dataclass(frozen=True, slots=True)
class DockNavigationItem:
    """One stable navigation target rendered by the Dock GUI."""

    component_id: ComponentId
    label_key: str
    display_label: str
    icon_name: str
    order: int

    def __post_init__(self) -> None:
        if not self.label_key.strip():
            raise ValueError("label_key must not be empty")
        if not self.display_label.strip():
            raise ValueError("display_label must not be empty")
        if not self.icon_name.strip():
            raise ValueError("icon_name must not be empty")
        if "/" in self.icon_name or "\\" in self.icon_name:
            raise ValueError("icon_name must be a GTK icon name, not a path")
        if self.order < 0:
            raise ValueError("order must be zero or greater")


# These are deliberately fallback/source labels only. Phase 3.5 replaces the
# display-label resolution with the real locale/i18n layer while preserving
# label_key and component_id as the stable contract.
DEFAULT_NAVIGATION_LABELS: Mapping[ComponentId, str] = {
    ComponentId.NETWORK: "Network",
    ComponentId.VPN: "VPN",
    ComponentId.THIN_CLIENT: "Remote session",
}

# Use the same GTK symbolic icon family as XAAC Thin Client. This keeps line
# weight, geometry and rendering behaviour coherent across XAAC applications.
# Colour is applied by Dock CSS according to ComponentStatus, just as XAAC Thin
# Client colours symbolic network/server icons according to semantic state.
DEFAULT_NAVIGATION_ICON_NAMES: Mapping[ComponentId, str] = {
    ComponentId.NETWORK: "network-wired-symbolic",
    ComponentId.VPN: "network-vpn-symbolic",
    ComponentId.THIN_CLIENT: "computer-symbolic",
}

DEFAULT_NAVIGATION_ICON_NAME = "application-x-executable-symbolic"


def build_navigation_items(
    registry: ComponentRegistry,
    labels: Mapping[ComponentId, str] | None = None,
    icons: Mapping[ComponentId, str] | None = None,
) -> tuple[DockNavigationItem, ...]:
    """Build navigation directly from the authorised component registry."""

    display_labels = DEFAULT_NAVIGATION_LABELS if labels is None else labels
    icon_names = DEFAULT_NAVIGATION_ICON_NAMES if icons is None else icons
    items: list[DockNavigationItem] = []

    for component in registry:
        fallback = component.component_id.value.replace("_", " ").title()
        label = display_labels.get(component.component_id, fallback)
        icon_name = icon_names.get(
            component.component_id,
            DEFAULT_NAVIGATION_ICON_NAME,
        )
        items.append(
            DockNavigationItem(
                component_id=component.component_id,
                label_key=component.label_key,
                display_label=label,
                icon_name=icon_name,
                order=component.order,
            )
        )

    return tuple(items)


class DockNavigationController:
    """Delegate navigation activation to the controlled backend launcher."""

    __slots__ = ("_launcher",)

    def __init__(self, launcher: ApplicationLauncher) -> None:
        self._launcher = launcher

    def activate(self, component_id: ComponentId | str) -> LaunchResult:
        """Request launch/presentation of one registered component."""

        return self._launcher.launch(component_id)

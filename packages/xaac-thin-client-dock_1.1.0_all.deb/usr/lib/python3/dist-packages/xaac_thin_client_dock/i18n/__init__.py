"""gettext-based internationalisation for XAAC Thin Client Dock."""

from __future__ import annotations

import gettext
import os
from pathlib import Path
from collections.abc import Mapping

DOMAIN = "xaac-thin-client-dock"
LOCALE_DIR = Path(__file__).resolve().parent
SUPPORTED_LANGUAGES = frozenset({"ca", "es", "en"})
DEFAULT_LANGUAGE = "ca"

_translation: gettext.NullTranslations = gettext.translation(
    DOMAIN,
    localedir=LOCALE_DIR,
    languages=[DEFAULT_LANGUAGE],
    fallback=True,
)
_current_language = DEFAULT_LANGUAGE


def normalize_language(language: str | None) -> str | None:
    """Return a supported two-letter language code, or ``None`` if unknown."""
    if language is None:
        return None

    normalized = language.strip()
    if not normalized:
        return None

    # LANGUAGE may contain a priority list such as ``ca:es:en``.
    normalized = normalized.split(":", 1)[0]
    normalized = normalized.replace("_", "-")
    normalized = normalized.split(".", 1)[0]
    normalized = normalized.split("@", 1)[0]
    language_code = normalized.split("-", 1)[0].lower()
    if language_code in SUPPORTED_LANGUAGES:
        return language_code
    return None


def resolve_language(
    language: str | None = None,
    *,
    environ: Mapping[str, str] | None = None,
) -> str:
    """Resolve the Dock language from an explicit value or the OS session locale.

    The Dock follows the locale exported by XAAC Thin Client OS.  An explicit
    ``language`` is useful for tests and future configuration providers.
    """
    explicit = normalize_language(language)
    if explicit is not None:
        return explicit

    source = os.environ if environ is None else environ

    # LC_ALL has the highest POSIX locale precedence. LANGUAGE is considered
    # before LC_MESSAGES/LANG when no LC_ALL override exists, matching gettext
    # deployments that expose a language preference list.
    candidates: list[str | None] = []
    if source.get("LC_ALL"):
        candidates.append(source.get("LC_ALL"))
    else:
        candidates.extend(
            (
                source.get("LANGUAGE"),
                source.get("LC_MESSAGES"),
                source.get("LANG"),
            )
        )

    for candidate in candidates:
        resolved = normalize_language(candidate)
        if resolved is not None:
            return resolved

    return DEFAULT_LANGUAGE


def configure_language(
    language: str | None = None,
    *,
    environ: Mapping[str, str] | None = None,
) -> str:
    """Configure gettext and return the active language code."""
    global _translation, _current_language

    resolved = resolve_language(language, environ=environ)
    _translation = gettext.translation(
        DOMAIN,
        localedir=LOCALE_DIR,
        languages=[resolved],
        fallback=True,
    )
    _current_language = resolved
    return resolved


def current_language() -> str:
    """Return the currently configured language code."""
    return _current_language


def gettext_message(message: str) -> str:
    """Translate one user-facing message with the active gettext catalogue."""
    return _translation.gettext(message)


_ = gettext_message

__all__ = [
    "DEFAULT_LANGUAGE",
    "DOMAIN",
    "LOCALE_DIR",
    "SUPPORTED_LANGUAGES",
    "_",
    "configure_language",
    "current_language",
    "gettext_message",
    "normalize_language",
    "resolve_language",
]

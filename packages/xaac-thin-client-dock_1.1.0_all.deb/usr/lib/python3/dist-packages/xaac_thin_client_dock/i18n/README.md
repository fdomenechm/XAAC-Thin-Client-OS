# Internationalisation

XAAC Thin Client Dock uses GNU gettext, following the same localisation model as XAAC Thin Client.

Supported GUI languages in version 1.1.0 are:

- Catalan (`ca`)
- Spanish (`es`)
- English (`en`)

The Dock follows the locale exported by the XAAC Thin Client OS graphical session. Locale resolution honours `LC_ALL`, then gettext `LANGUAGE`, then `LC_MESSAGES`, then `LANG`. Locale variants such as `ca_ES.UTF-8`, `es_ES.UTF-8` and `en_GB.UTF-8` are normalised to the supported language code. If no supported locale can be resolved, Catalan is used as the safe project default.

Catalogue domain:

```text
xaac-thin-client-dock
```

Files:

```text
i18n/
├── xaac-thin-client-dock.pot
├── ca/LC_MESSAGES/
│   ├── xaac-thin-client-dock.po
│   └── xaac-thin-client-dock.mo
├── es/LC_MESSAGES/
│   ├── xaac-thin-client-dock.po
│   └── xaac-thin-client-dock.mo
└── en/LC_MESSAGES/
    ├── xaac-thin-client-dock.po
    └── xaac-thin-client-dock.mo
```

The stable backend identifiers and component registry remain language-independent. Only presentation strings are translated.

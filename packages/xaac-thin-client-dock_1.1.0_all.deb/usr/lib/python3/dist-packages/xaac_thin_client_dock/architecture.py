"""Internal architecture contract for XAAC Thin Client Dock.

Phase 1.2 defines the boundaries between subsystems. Later phases populate
those boundaries incrementally while preserving the same dependency direction.
Policy, component discovery and controlled launching now have concrete core
implementations; runtime state and the GTK shell are concrete. Block 4 now
implements persistent lifecycle, authorised window flow and application-side
kiosk confinement, while compositor/global-session hardening remains an OS
integration responsibility.
"""

from __future__ import annotations

from dataclasses import dataclass

from xaac_thin_client_dock.components import ComponentDiscovery
from xaac_thin_client_dock.configuration import ConfigurationProvider
from xaac_thin_client_dock.launching import ApplicationLauncher
from xaac_thin_client_dock.presentation import DockView
from xaac_thin_client_dock.state import ComponentStateProvider
from xaac_thin_client_dock.system import KioskIntegration, PowerController


@dataclass(frozen=True, slots=True)
class DockPorts:
    """Dependencies that form the internal boundary of the Dock application."""

    configuration: ConfigurationProvider
    discovery: ComponentDiscovery
    state: ComponentStateProvider
    launcher: ApplicationLauncher
    view: DockView
    kiosk: KioskIntegration
    power: PowerController

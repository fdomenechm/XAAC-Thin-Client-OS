"""Functional integration with XAAC Thin Client Network.

Phase 5.1 consumes the public XAAC Thin Client Network D-Bus API.  The Dock
never talks to NetworkManager directly and never imports the Network project.
The integration enriches the generic component state with a small functional
status while preserving the existing launchability contract.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, replace
from enum import StrEnum
import importlib
import json
from typing import Any, Protocol, runtime_checkable

from xaac_thin_client_dock.components import ComponentId
from xaac_thin_client_dock.launching import (
    ApplicationLauncher,
    LaunchResult,
    LaunchStatus,
)
from xaac_thin_client_dock.state import (
    ComponentState,
    ComponentStateProvider,
    ComponentStatus,
)


NETWORK_DBUS_NAME = "org.xaac.ThinClient.Network"
NETWORK_DBUS_PATH = "/org/xaac/ThinClient/Network"
NETWORK_DBUS_INTERFACE = "org.xaac.ThinClient.Network1"
NETWORK_DBUS_TIMEOUT_MS = 1000


class NetworkIntegrationError(RuntimeError):
    """Base class for Network integration failures."""


class NetworkServiceUnavailableError(NetworkIntegrationError):
    """Raised when the Network public D-Bus API cannot be reached."""


class NetworkContractError(NetworkIntegrationError, ValueError):
    """Raised when Network returns a malformed public payload."""


class NetworkMode(StrEnum):
    """Public XAAC Thin Client Network policy modes."""

    DISABLED = "disabled"
    OPTIONAL = "optional"
    REQUIRED = "required"


class NetworkFunctionalStatus(StrEnum):
    """Normalised Network state displayed by the Dock."""

    ETHERNET_CONNECTED = "ethernet_connected"
    WIFI_CONNECTED = "wifi_connected"
    CONNECTED = "connected"
    CONNECTING = "connecting"
    DISCONNECTED = "disconnected"
    LIMITED = "limited"
    ERROR = "error"


@runtime_checkable
class NetworkServiceClient(Protocol):
    """Small client boundary for the public Network D-Bus service."""

    def get_state(self) -> Mapping[str, object]:
        """Return the public ``GetState`` payload."""

    def get_policy_state(self) -> Mapping[str, object]:
        """Return the public ``GetPolicyState`` payload."""


class GioNetworkServiceClient:
    """Read XAAC Thin Client Network through the system D-Bus.

    PyGObject is loaded lazily so backend tests and imports do not require a
    graphical/GI runtime.  Only the XAAC public service is addressed here;
    NetworkManager remains exclusively behind XAAC Thin Client Network.
    """

    __slots__ = ("_connection", "_gio", "_glib", "_timeout_ms")

    def __init__(self, *, timeout_ms: int = NETWORK_DBUS_TIMEOUT_MS) -> None:
        if timeout_ms <= 0:
            raise ValueError("timeout_ms must be greater than zero")
        self._connection = None
        self._gio = None
        self._glib = None
        self._timeout_ms = int(timeout_ms)

    def _ensure_connection(self):
        if self._connection is not None:
            return self._connection

        try:
            gi = importlib.import_module("gi")
            gi.require_version("Gio", "2.0")
            repository = importlib.import_module("gi.repository")
            Gio = repository.Gio
            GLib = repository.GLib
            connection = Gio.bus_get_sync(Gio.BusType.SYSTEM, None)
        except Exception as exc:  # noqa: BLE001 - D-Bus boundary is normalised.
            raise NetworkServiceUnavailableError(
                "network_system_bus_unavailable"
            ) from exc

        self._gio = Gio
        self._glib = GLib
        self._connection = connection
        return connection

    def _call_json(self, method: str) -> Mapping[str, object]:
        connection = self._ensure_connection()
        try:
            reply = connection.call_sync(
                NETWORK_DBUS_NAME,
                NETWORK_DBUS_PATH,
                NETWORK_DBUS_INTERFACE,
                method,
                None,
                None,
                self._gio.DBusCallFlags.NONE,
                self._timeout_ms,
                None,
            )
            unpacked = reply.unpack()
        except Exception as exc:  # noqa: BLE001 - public API transport failure.
            raise NetworkServiceUnavailableError(
                f"network_dbus_{method.lower()}_failed"
            ) from exc

        return decode_network_json_reply(unpacked)

    def get_state(self) -> Mapping[str, object]:
        return self._call_json("GetState")

    def get_policy_state(self) -> Mapping[str, object]:
        return self._call_json("GetPolicyState")


def decode_network_json_reply(value: object) -> Mapping[str, object]:
    """Decode one D-Bus reply containing the Network JSON object.

    ``GLib.Variant.unpack()`` normally returns a one-element tuple containing
    the JSON string.  Accepting an already-decoded mapping keeps the boundary
    easy to exercise with test doubles and future compatible transports.
    """

    while isinstance(value, (tuple, list)) and len(value) == 1:
        value = value[0]

    if isinstance(value, bytes):
        try:
            value = value.decode("utf-8")
        except UnicodeError as exc:
            raise NetworkContractError("network reply is not valid UTF-8") from exc

    if isinstance(value, str):
        try:
            value = json.loads(value)
        except json.JSONDecodeError as exc:
            raise NetworkContractError("network reply is not valid JSON") from exc

    if not isinstance(value, Mapping):
        raise NetworkContractError("network reply must contain a JSON object")

    return {str(key): item for key, item in value.items()}


def parse_network_mode(payload: Mapping[str, object]) -> NetworkMode:
    """Return the validated Network mode from its public policy payload."""

    policy_state = payload.get("policy_state")
    if isinstance(policy_state, Mapping):
        payload = policy_state
    raw_mode = payload.get("mode")
    if not isinstance(raw_mode, str):
        raise NetworkContractError("network policy state has no string mode")
    try:
        return NetworkMode(raw_mode.strip().lower())
    except ValueError as exc:
        raise NetworkContractError(
            f"unsupported network policy mode: {raw_mode!r}"
        ) from exc


def _normalise_connectivity_value(value: object) -> str | None:
    if isinstance(value, bool):
        return "connected" if value else "disconnected"
    if isinstance(value, int):
        # NetworkManager NMState values and NMConnectivityState values.  The
        # XAAC API normally exposes strings, but accepting these values makes
        # the Dock resilient to a compatible numeric representation.
        nm_state = {
            0: "unknown",
            10: "unknown",
            20: "disconnected",
            30: "disconnected",
            40: "connecting",
            50: "connected-local",
            60: "connected-site",
            70: "connected-global",
        }
        if value in nm_state:
            return nm_state[value]
        nm_connectivity = {
            1: "disconnected",
            2: "limited",
            3: "limited",
            4: "connected-global",
        }
        return nm_connectivity.get(value)
    if not isinstance(value, str):
        return None
    normalised = value.strip().lower().replace("_", "-").replace(" ", "-")
    return normalised or None


def _read_mapping(payload: Mapping[str, object], key: str) -> Mapping[str, object] | None:
    value = payload.get(key)
    return value if isinstance(value, Mapping) else None


def _truthy_connected(value: object) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in {
            "1",
            "true",
            "yes",
            "connected",
            "up",
            "active",
        }
    return False


def _connection_medium(payload: Mapping[str, object]) -> str | None:
    nested_state = payload.get("state")
    if isinstance(nested_state, Mapping):
        nested = _connection_medium(nested_state)
        if nested is not None:
            return nested

    for key in (
        "connection_type",
        "primary_connection_type",
        "active_connection_type",
        "type",
    ):
        value = payload.get(key)
        if isinstance(value, str):
            medium = value.strip().lower().replace("_", "-")
            if medium in {"ethernet", "wired", "802-3-ethernet"}:
                return "ethernet"
            if medium in {"wifi", "wi-fi", "wireless", "802-11-wireless"}:
                return "wifi"

    wired_devices = payload.get("wired")
    if isinstance(wired_devices, (list, tuple)):
        for device in wired_devices:
            if isinstance(device, Mapping) and _truthy_connected(device.get("connected")):
                return "ethernet"

    wifi_devices = payload.get("wifi")
    if isinstance(wifi_devices, (list, tuple)):
        for device in wifi_devices:
            if isinstance(device, Mapping) and _truthy_connected(device.get("connected")):
                return "wifi"

    ethernet = _read_mapping(payload, "ethernet")
    if ethernet is not None and _truthy_connected(ethernet.get("connected")):
        return "ethernet"

    wifi = _read_mapping(payload, "wifi")
    if wifi is not None and _truthy_connected(wifi.get("connected")):
        return "wifi"

    active = _read_mapping(payload, "active_connection")
    if active is not None:
        nested = _connection_medium(active)
        if nested is not None:
            return nested

    return None


def infer_network_functional_status(
    payload: Mapping[str, object],
) -> NetworkFunctionalStatus:
    """Normalise Network's public state without exposing backend details."""

    # XAAC Thin Client Network 1.1.0 wraps the dataclass snapshot under
    # ``state`` together with API/component version metadata.
    nested_state = payload.get("state")
    if isinstance(nested_state, Mapping):
        payload = nested_state

    connectivity: str | None = None
    for key in ("connectivity", "state", "network_state", "manager_state"):
        connectivity = _normalise_connectivity_value(payload.get(key))
        if connectivity is not None:
            break

    if connectivity is None:
        network = _read_mapping(payload, "network")
        if network is not None:
            for key in ("connectivity", "state"):
                connectivity = _normalise_connectivity_value(network.get(key))
                if connectivity is not None:
                    break

    if connectivity in {
        "connected",
        "connected-local",
        "connected-site",
        "connected-global",
        "full",
        "online",
        "up",
    }:
        medium = _connection_medium(payload)
        if medium == "ethernet":
            return NetworkFunctionalStatus.ETHERNET_CONNECTED
        if medium == "wifi":
            return NetworkFunctionalStatus.WIFI_CONNECTED
        return NetworkFunctionalStatus.CONNECTED

    if connectivity in {"connecting", "configuring", "activating"}:
        return NetworkFunctionalStatus.CONNECTING

    if connectivity in {
        "disconnected",
        "disconnecting",
        "none",
        "offline",
        "down",
        "asleep",
    }:
        return NetworkFunctionalStatus.DISCONNECTED

    if connectivity in {"limited", "portal", "local", "site"}:
        return NetworkFunctionalStatus.LIMITED

    # A public explicit error should remain distinguishable from a normal
    # disconnected state.  Unknown/malformed connectivity is also an error in
    # the Dock integration contract rather than a guessed health state.
    if payload.get("error") not in (None, "", False):
        return NetworkFunctionalStatus.ERROR
    return NetworkFunctionalStatus.ERROR


@dataclass(frozen=True, slots=True)
class NetworkIntegratedStateProvider:
    """Enrich the generic Network component state through its public D-Bus API."""

    delegate: ComponentStateProvider
    client: NetworkServiceClient

    def _integrate_network_state(self, base: ComponentState) -> ComponentState:
        try:
            mode = parse_network_mode(self.client.get_policy_state())
        except NetworkIntegrationError:
            if not base.launchable:
                return base
            return replace(
                base,
                functional_status=NetworkFunctionalStatus.ERROR.value,
                functional_error="network_policy_state_unavailable",
            )

        if mode is NetworkMode.DISABLED:
            return ComponentState(
                component_id=ComponentId.NETWORK,
                enabled=False,
                available=False,
                running=False,
                status=ComponentStatus.DISABLED,
            )

        if not base.launchable:
            return base

        try:
            functional_status = infer_network_functional_status(
                self.client.get_state()
            )
        except NetworkIntegrationError:
            functional_status = NetworkFunctionalStatus.ERROR
            functional_error = "network_state_unavailable"
        else:
            functional_error = (
                "network_state_error"
                if functional_status is NetworkFunctionalStatus.ERROR
                else None
            )

        return replace(
            base,
            functional_status=functional_status.value,
            functional_error=functional_error,
        )

    def get_state(self, component_id: ComponentId | str) -> ComponentState:
        base = self.delegate.get_state(component_id)
        if base.component_id is not ComponentId.NETWORK:
            return base
        return self._integrate_network_state(base)

    def get_all_states(self) -> tuple[ComponentState, ...]:
        states = self.delegate.get_all_states()
        return tuple(
            self._integrate_network_state(state)
            if state.component_id is ComponentId.NETWORK
            else state
            for state in states
        )


@dataclass(frozen=True, slots=True)
class NetworkPolicyAwareLauncher:
    """Prevent launches when Network explicitly reports ``mode=disabled``.

    A transport failure does not pretend that the component is disabled.  The
    Network application remains the owner of its own policy enforcement and can
    still be opened for diagnosis; the state provider renders the D-Bus problem
    as a functional error.  A *known* disabled policy is always enforced here.
    """

    delegate: ApplicationLauncher
    client: NetworkServiceClient

    def launch(self, component_id: ComponentId | str) -> LaunchResult:
        try:
            resolved_id = (
                component_id
                if isinstance(component_id, ComponentId)
                else ComponentId(component_id)
            )
        except ValueError:
            # Preserve the delegate's established unknown-component behaviour.
            return self.delegate.launch(component_id)

        if resolved_id is ComponentId.NETWORK:
            try:
                mode = parse_network_mode(self.client.get_policy_state())
            except NetworkIntegrationError:
                return self.delegate.launch(resolved_id)
            if mode is NetworkMode.DISABLED:
                return LaunchResult(
                    component_id=ComponentId.NETWORK,
                    status=LaunchStatus.DISABLED,
                )

        return self.delegate.launch(resolved_id)


def create_default_network_integration(
    state_provider: ComponentStateProvider,
    launcher: ApplicationLauncher,
    *,
    client: NetworkServiceClient | None = None,
) -> tuple[NetworkIntegratedStateProvider, NetworkPolicyAwareLauncher]:
    """Compose the standard Phase 5.1 Network adapters around existing ports."""

    network_client = client or GioNetworkServiceClient()
    return (
        NetworkIntegratedStateProvider(state_provider, network_client),
        NetworkPolicyAwareLauncher(launcher, network_client),
    )


__all__ = [
    "GioNetworkServiceClient",
    "NETWORK_DBUS_INTERFACE",
    "NETWORK_DBUS_NAME",
    "NETWORK_DBUS_PATH",
    "NETWORK_DBUS_TIMEOUT_MS",
    "NetworkContractError",
    "NetworkFunctionalStatus",
    "NetworkIntegratedStateProvider",
    "NetworkIntegrationError",
    "NetworkMode",
    "NetworkPolicyAwareLauncher",
    "NetworkServiceClient",
    "NetworkServiceUnavailableError",
    "create_default_network_integration",
    "decode_network_json_reply",
    "infer_network_functional_status",
    "parse_network_mode",
]

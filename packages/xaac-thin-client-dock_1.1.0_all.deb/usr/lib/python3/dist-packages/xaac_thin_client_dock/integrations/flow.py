"""Complete cross-component flow integration for XAAC Thin Client Dock.

Phase 5.4 composes the Network, VPN and Thin Client integrations into one
explicit boundary.  Network/VPN prerequisite evaluation is diagnostic only:
XAAC Thin Client Remote must always remain reachable so it can show connection
errors while the Dock lets the user open Network or VPN to repair them.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from enum import StrEnum

from xaac_thin_client_dock.components import ComponentId
from xaac_thin_client_dock.integrations.network import (
    GioNetworkServiceClient,
    NetworkFunctionalStatus,
    NetworkIntegrationError,
    NetworkMode,
    NetworkServiceClient,
    create_default_network_integration,
    infer_network_functional_status,
    parse_network_mode,
)
from xaac_thin_client_dock.integrations.thin_client import (
    GioThinClientServiceClient,
    NavigationResultHandler,
    ThinClientFunctionalStatus,
    ThinClientServiceClient,
    ThinClientSessionWatcher,
    create_default_thin_client_integration,
)
from xaac_thin_client_dock.integrations.vpn import (
    GioVpnManagerClient,
    VpnFunctionalStatus,
    VpnIntegrationError,
    VpnMode,
    VpnServiceClient,
    create_default_vpn_integration,
    infer_vpn_functional_status,
    parse_vpn_mode,
)
from xaac_thin_client_dock.launching import (
    ApplicationLauncher,
    LaunchResult,
    LaunchStatus,
)
from xaac_thin_client_dock.state import ComponentState, ComponentStateProvider


class SessionPrerequisiteStatus(StrEnum):
    """Normalised readiness result for opening a new remote session."""

    READY = "ready"
    NETWORK_REQUIRED = "session_network_required"
    NETWORK_UNAVAILABLE = "session_network_unavailable"
    VPN_REQUIRED = "session_vpn_required"
    VPN_UNAVAILABLE = "session_vpn_unavailable"


@dataclass(frozen=True, slots=True)
class SessionPrerequisiteResult:
    """Immutable result of evaluating Network/VPN requirements."""

    status: SessionPrerequisiteStatus

    @property
    def ready(self) -> bool:
        return self.status is SessionPrerequisiteStatus.READY


@dataclass(frozen=True, slots=True)
class SessionPrerequisiteEvaluator:
    """Evaluate only public XAAC component state needed before a new session."""

    network_client: NetworkServiceClient
    vpn_client: VpnServiceClient

    def evaluate(self) -> SessionPrerequisiteResult:
        network_result = self._evaluate_network()
        if not network_result.ready:
            return network_result

        vpn_result = self._evaluate_vpn()
        if not vpn_result.ready:
            return vpn_result

        return SessionPrerequisiteResult(SessionPrerequisiteStatus.READY)

    def _evaluate_network(self) -> SessionPrerequisiteResult:
        try:
            mode = parse_network_mode(self.network_client.get_policy_state())
        except NetworkIntegrationError:
            return SessionPrerequisiteResult(
                SessionPrerequisiteStatus.NETWORK_UNAVAILABLE
            )

        if mode is not NetworkMode.REQUIRED:
            return SessionPrerequisiteResult(SessionPrerequisiteStatus.READY)

        try:
            status = infer_network_functional_status(self.network_client.get_state())
        except NetworkIntegrationError:
            return SessionPrerequisiteResult(
                SessionPrerequisiteStatus.NETWORK_UNAVAILABLE
            )

        if status in {
            NetworkFunctionalStatus.ETHERNET_CONNECTED,
            NetworkFunctionalStatus.WIFI_CONNECTED,
            NetworkFunctionalStatus.CONNECTED,
        }:
            return SessionPrerequisiteResult(SessionPrerequisiteStatus.READY)

        return SessionPrerequisiteResult(SessionPrerequisiteStatus.NETWORK_REQUIRED)

    def _evaluate_vpn(self) -> SessionPrerequisiteResult:
        try:
            mode = parse_vpn_mode(self.vpn_client.get_policy_state())
        except VpnIntegrationError:
            return SessionPrerequisiteResult(SessionPrerequisiteStatus.VPN_UNAVAILABLE)

        if mode is not VpnMode.REQUIRED:
            return SessionPrerequisiteResult(SessionPrerequisiteStatus.READY)

        try:
            status = infer_vpn_functional_status(
                self.vpn_client.get_state(),
                mode=mode,
            )
        except VpnIntegrationError:
            return SessionPrerequisiteResult(SessionPrerequisiteStatus.VPN_UNAVAILABLE)

        if status is VpnFunctionalStatus.CONNECTED:
            return SessionPrerequisiteResult(SessionPrerequisiteStatus.READY)

        return SessionPrerequisiteResult(SessionPrerequisiteStatus.VPN_REQUIRED)


@dataclass(frozen=True, slots=True)
class FullFlowIntegratedStateProvider:
    """Preserve Remote navigation independently of prerequisite diagnostics."""

    delegate: ComponentStateProvider
    prerequisites: SessionPrerequisiteEvaluator

    def _integrate_thin_client_state(self, base: ComponentState) -> ComponentState:
        # XAAC Thin Client OS 1.1.0 deliberately keeps Remote reachable even
        # when Network or VPN are unavailable.  Remote is the primary local
        # recovery surface: it reports the failed prerequisite while the Dock
        # lets the user open Network/VPN to repair it.  Prerequisite evaluation
        # is therefore diagnostic only and must never disable navigation.
        if base.navigation_block_reason is None:
            return base
        return replace(base, navigation_block_reason=None)

    def get_state(self, component_id: ComponentId | str) -> ComponentState:
        base = self.delegate.get_state(component_id)
        if base.component_id is not ComponentId.THIN_CLIENT:
            return base
        return self._integrate_thin_client_state(base)

    def get_all_states(self) -> tuple[ComponentState, ...]:
        states = self.delegate.get_all_states()
        return tuple(
            self._integrate_thin_client_state(state)
            if state.component_id is ComponentId.THIN_CLIENT
            else state
            for state in states
        )


@dataclass(frozen=True, slots=True)
class FullFlowAwareLauncher:
    """Delegate launches without cross-component connectivity gates."""

    delegate: ApplicationLauncher
    state_provider: ComponentStateProvider

    def launch(self, component_id: ComponentId | str) -> LaunchResult:
        # Launchability belongs to the component itself.  Network/VPN runtime
        # state never gates opening/presenting Remote; otherwise the user would
        # lose the very UI needed to diagnose and repair connectivity.
        return self.delegate.launch(component_id)


def create_default_full_flow_integration(
    state_provider: ComponentStateProvider,
    launcher: ApplicationLauncher,
    navigation_handler: NavigationResultHandler,
    *,
    network_client: NetworkServiceClient | None = None,
    vpn_client: VpnServiceClient | None = None,
    thin_client_client: ThinClientServiceClient | None = None,
    thin_client_watcher: ThinClientSessionWatcher | None = None,
) -> tuple[
    FullFlowIntegratedStateProvider,
    FullFlowAwareLauncher,
    NavigationResultHandler,
]:
    """Compose Phases 5.1–5.4 as one complete Dock component flow."""

    network = network_client or GioNetworkServiceClient()
    vpn = vpn_client or GioVpnManagerClient()
    thin_client = thin_client_client or GioThinClientServiceClient()

    integrated_state, integrated_launcher = create_default_network_integration(
        state_provider,
        launcher,
        client=network,
    )
    integrated_state, integrated_launcher = create_default_vpn_integration(
        integrated_state,
        integrated_launcher,
        client=vpn,
    )
    integrated_state, integrated_navigation = create_default_thin_client_integration(
        integrated_state,
        navigation_handler,
        client=thin_client,
        watcher=thin_client_watcher,
    )

    prerequisites = SessionPrerequisiteEvaluator(network, vpn)
    flow_state = FullFlowIntegratedStateProvider(integrated_state, prerequisites)
    flow_launcher = FullFlowAwareLauncher(integrated_launcher, flow_state)
    return flow_state, flow_launcher, integrated_navigation


__all__ = [
    "FullFlowAwareLauncher",
    "FullFlowIntegratedStateProvider",
    "SessionPrerequisiteEvaluator",
    "SessionPrerequisiteResult",
    "SessionPrerequisiteStatus",
    "create_default_full_flow_integration",
]

"""Functional integration with XAAC Thin Client Remote sessions.

Phase 5.3 keeps remote-session ownership inside XAAC Thin Client Remote.  The Dock
launches/presents the authorised GUI, consumes only its public session state and
uses that state to return the kiosk shell after a connection ends, is cancelled
or fails.  It never starts or controls a remote protocol directly.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass, replace
from enum import StrEnum
import importlib
import json
from threading import Lock, Thread
from time import sleep
from typing import Protocol, runtime_checkable

from xaac_thin_client_dock.components import ComponentId
from xaac_thin_client_dock.launching import LaunchResult, LaunchStatus
from xaac_thin_client_dock.state import ComponentState, ComponentStateProvider, ComponentStatus


# The Remote application keeps the existing public D-Bus contract for IPC
# compatibility; the executable name is independent from these identifiers.
THIN_CLIENT_DBUS_NAME = "org.xaac.ThinClient"
THIN_CLIENT_DBUS_PATH = "/org/xaac/ThinClient"
THIN_CLIENT_DBUS_INTERFACE = "org.xaac.ThinClient1"
THIN_CLIENT_DBUS_TIMEOUT_MS = 1000
THIN_CLIENT_SESSION_POLL_INTERVAL = 0.25
THIN_CLIENT_SESSION_MAX_CONSECUTIVE_FAILURES = 40


class ThinClientIntegrationError(RuntimeError):
    """Base class for Thin Client integration failures."""


class ThinClientServiceUnavailableError(ThinClientIntegrationError):
    """Raised when the Thin Client public session API cannot be reached."""


class ThinClientContractError(ThinClientIntegrationError, ValueError):
    """Raised when Thin Client returns a malformed public payload."""


class ThinClientFunctionalStatus(StrEnum):
    """Normalised remote-session states rendered by the Dock."""

    AVAILABLE = "session_available"
    CONNECTING = "session_connecting"
    ACTIVE = "session_active"
    ERROR = "session_error"


@runtime_checkable
class ThinClientServiceClient(Protocol):
    """Small client boundary for XAAC Thin Client Remote public runtime state."""

    def get_state(self) -> Mapping[str, object]:
        """Return the public remote-session state payload."""


class GioThinClientServiceClient:
    """Read XAAC Thin Client Remote state through the current session D-Bus."""

    __slots__ = (
        "_bus_name",
        "_connection",
        "_gio",
        "_interface",
        "_object_path",
        "_timeout_ms",
    )

    def __init__(
        self,
        *,
        bus_name: str = THIN_CLIENT_DBUS_NAME,
        object_path: str = THIN_CLIENT_DBUS_PATH,
        interface: str = THIN_CLIENT_DBUS_INTERFACE,
        timeout_ms: int = THIN_CLIENT_DBUS_TIMEOUT_MS,
    ) -> None:
        if not bus_name.strip():
            raise ValueError("bus_name must not be empty")
        if not object_path.startswith("/"):
            raise ValueError("object_path must be an absolute D-Bus path")
        if not interface.strip():
            raise ValueError("interface must not be empty")
        if timeout_ms <= 0:
            raise ValueError("timeout_ms must be greater than zero")

        self._bus_name = bus_name.strip()
        self._object_path = object_path
        self._interface = interface.strip()
        self._connection = None
        self._gio = None
        self._timeout_ms = int(timeout_ms)

    def _ensure_connection(self):
        if self._connection is not None:
            return self._connection

        try:
            gi = importlib.import_module("gi")
            gi.require_version("Gio", "2.0")
            repository = importlib.import_module("gi.repository")
            Gio = repository.Gio
            connection = Gio.bus_get_sync(Gio.BusType.SESSION, None)
        except Exception as exc:  # noqa: BLE001 - transport boundary normalised.
            raise ThinClientServiceUnavailableError(
                "thin_client_session_bus_unavailable"
            ) from exc

        self._gio = Gio
        self._connection = connection
        return connection

    def get_state(self) -> Mapping[str, object]:
        connection = self._ensure_connection()
        try:
            reply = connection.call_sync(
                self._bus_name,
                self._object_path,
                self._interface,
                "GetState",
                None,
                None,
                self._gio.DBusCallFlags.NONE,
                self._timeout_ms,
                None,
            )
            unpacked = reply.unpack()
        except Exception as exc:  # noqa: BLE001 - public API transport failure.
            raise ThinClientServiceUnavailableError(
                "thin_client_dbus_getstate_failed"
            ) from exc

        return decode_thin_client_json_reply(unpacked)


def decode_thin_client_json_reply(value: object) -> Mapping[str, object]:
    """Decode one D-Bus reply containing the Thin Client JSON object."""

    while isinstance(value, (tuple, list)) and len(value) == 1:
        value = value[0]

    if isinstance(value, bytes):
        try:
            value = value.decode("utf-8")
        except UnicodeError as exc:
            raise ThinClientContractError(
                "thin client reply is not valid UTF-8"
            ) from exc

    if isinstance(value, str):
        try:
            value = json.loads(value)
        except json.JSONDecodeError as exc:
            raise ThinClientContractError(
                "thin client reply is not valid JSON"
            ) from exc

    if not isinstance(value, Mapping):
        raise ThinClientContractError(
            "thin client reply must contain a JSON object"
        )

    return {str(key): item for key, item in value.items()}


def _normalise_state(value: object) -> str | None:
    if not isinstance(value, str):
        return None
    normalised = value.strip().lower().replace("_", "-").replace(" ", "-")
    return normalised or None


def _has_error(payload: Mapping[str, object]) -> bool:
    for key in ("error", "last_error", "error_message"):
        value = payload.get(key)
        if value not in (None, "", False, 0):
            return True
    return False


def _runtime_state(payload: Mapping[str, object]) -> str | None:
    for key in (
        "state",
        "status",
        "session_state",
        "connection_state",
        "remote_session_state",
    ):
        state = _normalise_state(payload.get(key))
        if state is not None:
            return state

    session = payload.get("session")
    if isinstance(session, Mapping):
        return _runtime_state(session)

    connected = payload.get("connected")
    if isinstance(connected, bool):
        return "active" if connected else "available"

    return None


def infer_thin_client_functional_status(
    payload: Mapping[str, object],
) -> ThinClientFunctionalStatus:
    """Normalise the public Thin Client state into Dock presentation states."""

    state = _runtime_state(payload)

    if state in {
        "active",
        "connected",
        "established",
        "session-active",
        "remote-session-active",
        "online",
    }:
        return ThinClientFunctionalStatus.ACTIVE

    if state in {
        "connecting",
        "authenticating",
        "starting",
        "launching",
        "negotiating",
        "reconnecting",
        "waiting",
        "waiting-for-credentials",
    }:
        return ThinClientFunctionalStatus.CONNECTING

    if state in {
        "available",
        "ready",
        "idle",
        "disconnected",
        "cancelled",
        "canceled",
        "closed",
        "ended",
        "session-ended",
        "logged-out",
        "logged-out-session",
        "stopped",
    }:
        if _has_error(payload):
            return ThinClientFunctionalStatus.ERROR
        return ThinClientFunctionalStatus.AVAILABLE

    if state in {
        "error",
        "failed",
        "failure",
        "connection-failed",
        "auth-failed",
        "authentication-failed",
        "timeout",
    }:
        return ThinClientFunctionalStatus.ERROR

    if _has_error(payload):
        return ThinClientFunctionalStatus.ERROR

    return ThinClientFunctionalStatus.ERROR


@dataclass(frozen=True, slots=True)
class ThinClientIntegratedStateProvider:
    """Enrich the generic Thin Client state with remote-session state."""

    delegate: ComponentStateProvider
    client: ThinClientServiceClient

    def _integrate_thin_client_state(self, base: ComponentState) -> ComponentState:
        if not base.launchable or base.status is ComponentStatus.ERROR:
            return base

        # When the GUI is not running there is no application-owned session-bus
        # endpoint to query.  Executable availability is therefore exactly the
        # functional state the user needs to see before opening it.
        if not base.running:
            return replace(
                base,
                functional_status=ThinClientFunctionalStatus.AVAILABLE.value,
                functional_error=None,
            )

        try:
            functional_status = infer_thin_client_functional_status(
                self.client.get_state()
            )
        except ThinClientIntegrationError:
            functional_status = ThinClientFunctionalStatus.ERROR
            functional_error = "thin_client_state_unavailable"
        else:
            functional_error = (
                "thin_client_state_error"
                if functional_status is ThinClientFunctionalStatus.ERROR
                else None
            )

        return replace(
            base,
            functional_status=functional_status.value,
            functional_error=functional_error,
        )

    def get_state(self, component_id: ComponentId | str) -> ComponentState:
        base = self.delegate.get_state(component_id)
        if base.component_id is not ComponentId.THIN_CLIENT:
            return base
        return self._integrate_thin_client_state(base)

    def get_all_states(self) -> tuple[ComponentState, ...]:
        states = self.delegate.get_all_states()
        return tuple(
            self._integrate_thin_client_state(state)
            if state.component_id is ComponentId.THIN_CLIENT
            else state
            for state in states
        )


@dataclass(slots=True)
class ThinClientSessionTransitionTracker:
    """Detect a completed/cancelled/failed session after an attempt started."""

    engaged: bool = False
    finished: bool = False

    def observe(self, status: ThinClientFunctionalStatus) -> bool:
        """Return ``True`` exactly once when control should return to the Dock."""

        if self.finished:
            return False

        if status in {
            ThinClientFunctionalStatus.CONNECTING,
            ThinClientFunctionalStatus.ACTIVE,
        }:
            self.engaged = True
            return False

        if self.engaged and status in {
            ThinClientFunctionalStatus.AVAILABLE,
            ThinClientFunctionalStatus.ERROR,
        }:
            self.finished = True
            return True

        return False


ReturnToDock = Callable[[], None]


class ThinClientSessionWatcher:
    """Watch functional session transitions without blocking the GTK main loop."""

    __slots__ = (
        "_client",
        "_lock",
        "_max_consecutive_failures",
        "_poll_interval",
        "_watched",
    )

    def __init__(
        self,
        client: ThinClientServiceClient,
        *,
        poll_interval: float = THIN_CLIENT_SESSION_POLL_INTERVAL,
        max_consecutive_failures: int = THIN_CLIENT_SESSION_MAX_CONSECUTIVE_FAILURES,
    ) -> None:
        if poll_interval <= 0:
            raise ValueError("poll_interval must be greater than zero")
        if max_consecutive_failures <= 0:
            raise ValueError("max_consecutive_failures must be greater than zero")
        self._client = client
        self._poll_interval = float(poll_interval)
        self._max_consecutive_failures = int(max_consecutive_failures)
        self._watched: set[int] = set()
        self._lock = Lock()

    def watch(self, pid: int, callback: ReturnToDock) -> bool:
        """Start one best-effort session watcher for a launched Thin Client PID."""

        if pid <= 0:
            return False
        with self._lock:
            if pid in self._watched:
                return False
            self._watched.add(pid)

        try:
            Thread(
                target=self._watch,
                args=(pid, callback),
                name=f"xaac-dock-thin-client-session-{pid}",
                daemon=True,
            ).start()
        except Exception:  # noqa: BLE001 - process watcher still guarantees recovery.
            with self._lock:
                self._watched.discard(pid)
            return False
        return True

    def _watch(self, pid: int, callback: ReturnToDock) -> None:
        tracker = ThinClientSessionTransitionTracker()
        consecutive_failures = 0
        try:
            while consecutive_failures < self._max_consecutive_failures:
                try:
                    status = infer_thin_client_functional_status(
                        self._client.get_state()
                    )
                except ThinClientIntegrationError:
                    consecutive_failures += 1
                else:
                    consecutive_failures = 0
                    if tracker.observe(status):
                        try:
                            callback()
                        except Exception:  # noqa: BLE001 - watcher cleanup must win.
                            pass
                        return
                sleep(self._poll_interval)
        finally:
            with self._lock:
                self._watched.discard(pid)


@runtime_checkable
class NavigationResultHandler(Protocol):
    """Existing shell recovery/window handler consumed by Phase 5.3."""

    def handle(self, result: object, return_to_dock: ReturnToDock) -> object:
        """Handle one navigation result and return its existing outcome."""


@dataclass(frozen=True, slots=True)
class ThinClientNavigationCoordinator:
    """Add functional-session return tracking to the existing recovery flow."""

    delegate: NavigationResultHandler
    watcher: ThinClientSessionWatcher

    def handle(self, result: object, return_to_dock: ReturnToDock) -> object:
        outcome = self.delegate.handle(result, return_to_dock)

        if (
            isinstance(result, LaunchResult)
            and result.component_id is ComponentId.THIN_CLIENT
            and result.status in {LaunchStatus.STARTED, LaunchStatus.ALREADY_RUNNING}
            and result.pid is not None
        ):
            # Failure to add the functional watcher is non-fatal: the existing
            # process-exit watcher installed by the delegate still guarantees a
            # safe return if the application terminates.
            self.watcher.watch(result.pid, return_to_dock)

        return outcome


def create_default_thin_client_integration(
    state_provider: ComponentStateProvider,
    navigation_handler: NavigationResultHandler,
    *,
    client: ThinClientServiceClient | None = None,
    watcher: ThinClientSessionWatcher | None = None,
) -> tuple[ThinClientIntegratedStateProvider, ThinClientNavigationCoordinator]:
    """Compose the standard Phase 5.3 state and session-return adapters."""

    thin_client = client or GioThinClientServiceClient()
    session_watcher = watcher or ThinClientSessionWatcher(thin_client)
    return (
        ThinClientIntegratedStateProvider(state_provider, thin_client),
        ThinClientNavigationCoordinator(navigation_handler, session_watcher),
    )


__all__ = [
    "GioThinClientServiceClient",
    "NavigationResultHandler",
    "THIN_CLIENT_DBUS_INTERFACE",
    "THIN_CLIENT_DBUS_NAME",
    "THIN_CLIENT_DBUS_PATH",
    "THIN_CLIENT_DBUS_TIMEOUT_MS",
    "THIN_CLIENT_SESSION_MAX_CONSECUTIVE_FAILURES",
    "THIN_CLIENT_SESSION_POLL_INTERVAL",
    "ThinClientContractError",
    "ThinClientFunctionalStatus",
    "ThinClientIntegratedStateProvider",
    "ThinClientIntegrationError",
    "ThinClientNavigationCoordinator",
    "ThinClientServiceClient",
    "ThinClientServiceUnavailableError",
    "ThinClientSessionTransitionTracker",
    "ThinClientSessionWatcher",
    "create_default_thin_client_integration",
    "decode_thin_client_json_reply",
    "infer_thin_client_functional_status",
]

"""Functional integration with XAAC Thin Client VPN.

Phase 5.2 keeps VPN ownership outside the Dock.  The Dock launches the
unprivileged XAAC Thin Client VPN GUI and consumes only policy/runtime state
from the privileged ``xaac-vpn-manager`` boundary.  It never controls
OpenVPN 3 directly, never receives credentials and never elevates privileges.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, replace
from enum import StrEnum
import importlib
import json
from typing import Protocol, runtime_checkable

from xaac_thin_client_dock.components import ComponentId
from xaac_thin_client_dock.launching import (
    ApplicationLauncher,
    LaunchResult,
    LaunchStatus,
)
from xaac_thin_client_dock.state import (
    ComponentState,
    ComponentStateProvider,
    ComponentStatus,
)


# Public endpoint exposed by XAAC Thin Client VPN 1.1.0.  The Dock consumes
# only this non-secret manager contract over the system bus.
VPN_DBUS_NAME = "org.xaac.ThinClient.VpnManager1"
VPN_DBUS_PATH = "/org/xaac/ThinClient/VpnManager1"
VPN_DBUS_INTERFACE = "org.xaac.ThinClient.VpnManager1"
VPN_DBUS_TIMEOUT_MS = 1000


class VpnIntegrationError(RuntimeError):
    """Base class for VPN integration failures."""


class VpnServiceUnavailableError(VpnIntegrationError):
    """Raised when the VPN manager public D-Bus API cannot be reached."""


class VpnContractError(VpnIntegrationError, ValueError):
    """Raised when the VPN manager returns a malformed public payload."""


class VpnMode(StrEnum):
    """Public XAAC Thin Client VPN policy modes."""

    DISABLED = "disabled"
    OPTIONAL = "optional"
    REQUIRED = "required"


class VpnFunctionalStatus(StrEnum):
    """Normalised VPN state rendered by the Dock."""

    NOT_REQUIRED = "vpn_not_required"
    DISCONNECTED = "vpn_disconnected"
    CONNECTING = "vpn_connecting"
    CONNECTED = "vpn_connected"
    DISCONNECTING = "vpn_disconnecting"
    ERROR = "vpn_error"


@runtime_checkable
class VpnServiceClient(Protocol):
    """Small client boundary for ``xaac-vpn-manager`` public state."""

    def get_state(self) -> Mapping[str, object]:
        """Return the public VPN runtime-state payload."""

    def get_policy_state(self) -> Mapping[str, object]:
        """Return the public VPN policy-state payload."""


class GioVpnManagerClient:
    """Read ``xaac-vpn-manager`` through the system D-Bus.

    The VPN manager is privileged while the Dock/GUI are not, therefore this
    adapter uses the system bus rather than trying to access OpenVPN directly.
    PyGObject is loaded lazily so pure backend tests remain GI-independent.

    Endpoint arguments are injectable to keep the Dock compatible with an
    installed manager exposing a legacy endpoint while the XAAC OS integration
    converges on the canonical Phase 5.2 contract.
    """

    __slots__ = (
        "_bus_name",
        "_connection",
        "_gio",
        "_interface",
        "_object_path",
        "_timeout_ms",
    )

    def __init__(
        self,
        *,
        bus_name: str = VPN_DBUS_NAME,
        object_path: str = VPN_DBUS_PATH,
        interface: str = VPN_DBUS_INTERFACE,
        timeout_ms: int = VPN_DBUS_TIMEOUT_MS,
    ) -> None:
        if not bus_name.strip():
            raise ValueError("bus_name must not be empty")
        if not object_path.startswith("/"):
            raise ValueError("object_path must be an absolute D-Bus path")
        if not interface.strip():
            raise ValueError("interface must not be empty")
        if timeout_ms <= 0:
            raise ValueError("timeout_ms must be greater than zero")

        self._bus_name = bus_name.strip()
        self._object_path = object_path
        self._interface = interface.strip()
        self._connection = None
        self._gio = None
        self._timeout_ms = int(timeout_ms)

    def _ensure_connection(self):
        if self._connection is not None:
            return self._connection

        try:
            gi = importlib.import_module("gi")
            gi.require_version("Gio", "2.0")
            repository = importlib.import_module("gi.repository")
            Gio = repository.Gio
            connection = Gio.bus_get_sync(Gio.BusType.SYSTEM, None)
        except Exception as exc:  # noqa: BLE001 - transport boundary normalised.
            raise VpnServiceUnavailableError("vpn_system_bus_unavailable") from exc

        self._gio = Gio
        self._connection = connection
        return connection

    def _call_json(self, method: str) -> Mapping[str, object]:
        connection = self._ensure_connection()
        try:
            reply = connection.call_sync(
                self._bus_name,
                self._object_path,
                self._interface,
                method,
                None,
                None,
                self._gio.DBusCallFlags.NONE,
                self._timeout_ms,
                None,
            )
            unpacked = reply.unpack()
        except Exception as exc:  # noqa: BLE001 - public API transport failure.
            raise VpnServiceUnavailableError(
                f"vpn_dbus_{method.lower()}_failed"
            ) from exc

        return decode_vpn_json_reply(unpacked)

    def get_state(self) -> Mapping[str, object]:
        # XAAC Thin Client VPN 1.1.0 exposes its runtime snapshot as
        # GetStatus() on the privileged manager service.
        return self._call_json("GetStatus")

    def get_policy_state(self) -> Mapping[str, object]:
        # The manager exposes policy together with its non-secret capabilities.
        # Normalise that payload to the common Dock {"mode": ...} boundary.
        capabilities = self._call_json("GetCapabilities")
        policy = capabilities.get("policy")
        if not isinstance(policy, str):
            raise VpnContractError("vpn capabilities have no string policy")
        return {**capabilities, "mode": policy}


def _unpack_dbus_value(value: object) -> object:
    """Recursively unwrap GLib.Variant values returned inside ``a{sv}``."""

    if hasattr(value, "unpack") and callable(getattr(value, "unpack")):
        try:
            return _unpack_dbus_value(value.unpack())
        except Exception as exc:  # noqa: BLE001 - normalise transport objects.
            raise VpnContractError("vpn reply contains an invalid D-Bus value") from exc
    if isinstance(value, Mapping):
        return {str(key): _unpack_dbus_value(item) for key, item in value.items()}
    if isinstance(value, tuple):
        unpacked = tuple(_unpack_dbus_value(item) for item in value)
        return unpacked[0] if len(unpacked) == 1 else unpacked
    if isinstance(value, list):
        unpacked = [_unpack_dbus_value(item) for item in value]
        return unpacked[0] if len(unpacked) == 1 else unpacked
    return value


def decode_vpn_json_reply(value: object) -> Mapping[str, object]:
    """Decode the VPN manager reply into a plain non-secret mapping.

    XAAC Thin Client VPN 1.1.0 returns ``a{sv}``, so values may still be nested
    ``GLib.Variant`` objects after unpacking the outer reply.  Legacy JSON
    string payloads remain accepted for compatibility and test doubles.
    """

    value = _unpack_dbus_value(value)

    if isinstance(value, bytes):
        try:
            value = value.decode("utf-8")
        except UnicodeError as exc:
            raise VpnContractError("vpn reply is not valid UTF-8") from exc

    if isinstance(value, str):
        try:
            value = json.loads(value)
        except json.JSONDecodeError as exc:
            raise VpnContractError("vpn reply is not valid JSON") from exc

    if not isinstance(value, Mapping):
        raise VpnContractError("vpn reply must contain an object mapping")

    return {str(key): _unpack_dbus_value(item) for key, item in value.items()}


def parse_vpn_mode(payload: Mapping[str, object]) -> VpnMode:
    """Return the validated VPN mode from a policy-state payload."""

    raw_mode = payload.get("mode")
    if not isinstance(raw_mode, str):
        raise VpnContractError("vpn policy state has no string mode")
    try:
        return VpnMode(raw_mode.strip().lower())
    except ValueError as exc:
        raise VpnContractError(f"unsupported vpn policy mode: {raw_mode!r}") from exc


def _normalise_state(value: object) -> str | None:
    if isinstance(value, bool):
        return "connected" if value else "disconnected"
    if not isinstance(value, str):
        return None
    normalised = value.strip().lower().replace("_", "-").replace(" ", "-")
    return normalised or None


def _has_error(payload: Mapping[str, object]) -> bool:
    for key in ("error", "last_error", "error_message"):
        value = payload.get(key)
        if value not in (None, "", False, 0):
            return True
    return False


def _vpn_runtime_state(payload: Mapping[str, object]) -> str | None:
    for key in ("state", "status", "connection_state", "vpn_state"):
        state = _normalise_state(payload.get(key))
        if state is not None:
            return state

    connected = payload.get("connected")
    if isinstance(connected, bool):
        return "connected" if connected else "disconnected"

    connection = payload.get("connection")
    if isinstance(connection, Mapping):
        return _vpn_runtime_state(connection)

    return None


def infer_vpn_functional_status(
    payload: Mapping[str, object],
    *,
    mode: VpnMode,
) -> VpnFunctionalStatus:
    """Normalise manager state without exposing OpenVPN implementation detail."""

    state = _vpn_runtime_state(payload)

    if state in {
        "connected",
        "up",
        "active",
        "online",
        "established",
    }:
        return VpnFunctionalStatus.CONNECTED

    if state in {
        "connecting",
        "authenticating",
        "starting",
        "activating",
        "reconnecting",
        "waiting",
        "waiting-for-credentials",
        "waiting-for-otp",
    }:
        return VpnFunctionalStatus.CONNECTING

    if state in {"disconnecting", "stopping", "deactivating"}:
        return VpnFunctionalStatus.DISCONNECTING

    if state in {
        "error",
        "failed",
        "failure",
        "auth-failed",
        "authentication-failed",
        "timeout",
    }:
        return VpnFunctionalStatus.ERROR

    if state in {
        "omitted",
        "skipped",
        "not-required",
        "notrequired",
        "bypassed",
    }:
        if mode is VpnMode.REQUIRED:
            return VpnFunctionalStatus.ERROR
        return VpnFunctionalStatus.NOT_REQUIRED

    if state in {
        "disconnected",
        "down",
        "idle",
        "stopped",
        "inactive",
        "not-connected",
    }:
        if _has_error(payload):
            return VpnFunctionalStatus.ERROR
        if mode is VpnMode.OPTIONAL:
            return VpnFunctionalStatus.NOT_REQUIRED
        return VpnFunctionalStatus.DISCONNECTED

    if _has_error(payload):
        return VpnFunctionalStatus.ERROR

    # Missing or unknown public state is a contract error from the Dock's
    # perspective; guessing "disconnected" would hide manager/API failures.
    return VpnFunctionalStatus.ERROR


@dataclass(frozen=True, slots=True)
class VpnIntegratedStateProvider:
    """Enrich generic VPN component state through ``xaac-vpn-manager``."""

    delegate: ComponentStateProvider
    client: VpnServiceClient

    def _integrate_vpn_state(self, base: ComponentState) -> ComponentState:
        try:
            mode = parse_vpn_mode(self.client.get_policy_state())
        except VpnIntegrationError:
            if not base.launchable:
                return base
            return replace(
                base,
                functional_status=VpnFunctionalStatus.ERROR.value,
                functional_error="vpn_policy_state_unavailable",
            )

        if mode is VpnMode.DISABLED:
            return ComponentState(
                component_id=ComponentId.VPN,
                enabled=False,
                available=False,
                running=False,
                status=ComponentStatus.DISABLED,
            )

        if not base.launchable:
            return base

        try:
            functional_status = infer_vpn_functional_status(
                self.client.get_state(),
                mode=mode,
            )
        except VpnIntegrationError:
            functional_status = VpnFunctionalStatus.ERROR
            functional_error = "vpn_state_unavailable"
        else:
            functional_error = (
                "vpn_state_error"
                if functional_status is VpnFunctionalStatus.ERROR
                else None
            )

        return replace(
            base,
            functional_status=functional_status.value,
            functional_error=functional_error,
        )

    def get_state(self, component_id: ComponentId | str) -> ComponentState:
        base = self.delegate.get_state(component_id)
        if base.component_id is not ComponentId.VPN:
            return base
        return self._integrate_vpn_state(base)

    def get_all_states(self) -> tuple[ComponentState, ...]:
        states = self.delegate.get_all_states()
        return tuple(
            self._integrate_vpn_state(state)
            if state.component_id is ComponentId.VPN
            else state
            for state in states
        )


@dataclass(frozen=True, slots=True)
class VpnPolicyAwareLauncher:
    """Block only VPN launches explicitly disabled by manager policy."""

    delegate: ApplicationLauncher
    client: VpnServiceClient

    def launch(self, component_id: ComponentId | str) -> LaunchResult:
        try:
            resolved_id = (
                component_id
                if isinstance(component_id, ComponentId)
                else ComponentId(component_id)
            )
        except (TypeError, ValueError):
            return self.delegate.launch(component_id)

        if resolved_id is ComponentId.VPN:
            try:
                mode = parse_vpn_mode(self.client.get_policy_state())
            except VpnIntegrationError:
                # Do not invent a disabled policy when the manager cannot be
                # reached.  The VPN GUI remains useful for diagnosis and still
                # owns its own policy enforcement.
                return self.delegate.launch(resolved_id)
            if mode is VpnMode.DISABLED:
                return LaunchResult(
                    component_id=ComponentId.VPN,
                    status=LaunchStatus.DISABLED,
                )

        return self.delegate.launch(resolved_id)


def create_default_vpn_integration(
    state_provider: ComponentStateProvider,
    launcher: ApplicationLauncher,
    *,
    client: VpnServiceClient | None = None,
) -> tuple[VpnIntegratedStateProvider, VpnPolicyAwareLauncher]:
    """Compose the standard Phase 5.2 VPN adapters around existing ports."""

    vpn_client = client or GioVpnManagerClient()
    return (
        VpnIntegratedStateProvider(state_provider, vpn_client),
        VpnPolicyAwareLauncher(launcher, vpn_client),
    )


__all__ = [
    "GioVpnManagerClient",
    "VPN_DBUS_INTERFACE",
    "VPN_DBUS_NAME",
    "VPN_DBUS_PATH",
    "VPN_DBUS_TIMEOUT_MS",
    "VpnContractError",
    "VpnFunctionalStatus",
    "VpnIntegratedStateProvider",
    "VpnIntegrationError",
    "VpnMode",
    "VpnPolicyAwareLauncher",
    "VpnServiceClient",
    "VpnServiceUnavailableError",
    "create_default_vpn_integration",
    "decode_vpn_json_reply",
    "infer_vpn_functional_status",
    "parse_vpn_mode",
]

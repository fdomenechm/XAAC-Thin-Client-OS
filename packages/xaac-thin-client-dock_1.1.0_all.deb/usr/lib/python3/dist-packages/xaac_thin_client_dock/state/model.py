"""Formal component state model for XAAC Thin Client Dock."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum

from xaac_thin_client_dock.components import AvailabilityReason, ComponentId


class ComponentStatus(StrEnum):
    """Normalised high-level state consumed by the Dock presentation layer."""

    DISABLED = "disabled"
    UNAVAILABLE = "unavailable"
    IDLE = "idle"
    RUNNING = "running"
    ERROR = "error"


@dataclass(frozen=True, slots=True)
class ComponentState:
    """Immutable externally visible state for one authorised component.

    The booleans are intentionally redundant with ``status``.  They provide a
    stable, simple contract for GUI decisions, while ``status`` gives the
    presentation layer one machine-readable summary value.
    """

    component_id: ComponentId
    enabled: bool
    available: bool
    running: bool
    status: ComponentStatus
    availability_reason: AvailabilityReason | None = None
    error: str | None = None
    functional_status: str | None = None
    functional_error: str | None = None
    navigation_block_reason: str | None = None

    @property
    def launchable(self) -> bool:
        """Return whether the Dock may safely open this component.

        Launchability is deliberately derived only from component policy and
        executable availability.  Functional problems in the service managed
        by the component (for example a disconnected network or a VPN
        authentication error) must not make the component itself inaccessible.
        """

        return self.enabled and self.available

    @property
    def navigable(self) -> bool:
        """Return whether the Dock may currently navigate to this component.

        This refines, but never redefines, component ``launchable`` semantics.
        Phase 5.4 uses it only for cross-component prerequisites that may block
        entry to an otherwise installed/enabled component.
        """

        return self.launchable and self.navigation_block_reason is None

    def __post_init__(self) -> None:
        if self.functional_status is not None and not self.functional_status.strip():
            raise ValueError("functional_status must not be empty")
        if self.functional_error is not None and not self.functional_error.strip():
            raise ValueError("functional_error must not be empty")
        if self.functional_error is not None and self.functional_status is None:
            raise ValueError("functional_error requires functional_status")
        if (
            self.navigation_block_reason is not None
            and not self.navigation_block_reason.strip()
        ):
            raise ValueError("navigation_block_reason must not be empty")
        if self.navigation_block_reason is not None and not (self.enabled and self.available):
            raise ValueError("navigation block requires a launchable component")

        if self.running and not self.available:
            raise ValueError("running component must be available")
        if self.running and not self.enabled:
            raise ValueError("running component must be enabled")
        if self.available and not self.enabled:
            raise ValueError("available component must be enabled")

        if self.status is ComponentStatus.DISABLED:
            if self.enabled or self.available or self.running:
                raise ValueError("disabled state cannot be enabled, available or running")
            if self.availability_reason is not None or self.error is not None:
                raise ValueError("disabled state cannot include discovery/error details")
            if self.functional_status is not None or self.functional_error is not None:
                raise ValueError("disabled state cannot include functional details")
            return

        if not self.enabled:
            raise ValueError("non-disabled state must be enabled")

        if self.status is ComponentStatus.UNAVAILABLE:
            if self.available or self.running:
                raise ValueError("unavailable state cannot be available or running")
            if self.availability_reason is not AvailabilityReason.EXECUTABLE_NOT_FOUND:
                raise ValueError(
                    "unavailable state must use reason=executable_not_found"
                )
            if self.error is not None:
                raise ValueError("unavailable state cannot include error")
            return

        if self.status is ComponentStatus.IDLE:
            if not self.available or self.running:
                raise ValueError("idle state must be available and not running")
            if self.availability_reason is not AvailabilityReason.AVAILABLE:
                raise ValueError("idle state must use reason=available")
            if self.error is not None:
                raise ValueError("idle state cannot include error")
            return

        if self.status is ComponentStatus.RUNNING:
            if not self.available or not self.running:
                raise ValueError("running state must be available and running")
            if self.availability_reason is not AvailabilityReason.AVAILABLE:
                raise ValueError("running state must use reason=available")
            if self.error is not None:
                raise ValueError("running state cannot include error")
            return

        if self.status is ComponentStatus.ERROR:
            if self.running:
                raise ValueError("error state cannot be marked running")
            if not self.error:
                raise ValueError("error state must include error")
            if self.available:
                if self.availability_reason is not AvailabilityReason.AVAILABLE:
                    raise ValueError(
                        "available error state must use reason=available"
                    )
            elif self.availability_reason is not AvailabilityReason.DETECTION_ERROR:
                raise ValueError(
                    "unavailable error state must use reason=detection_error"
                )

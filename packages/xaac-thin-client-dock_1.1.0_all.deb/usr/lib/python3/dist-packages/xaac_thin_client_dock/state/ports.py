"""Component state boundaries for XAAC Thin Client Dock."""

from __future__ import annotations

from typing import TYPE_CHECKING, Protocol, runtime_checkable

if TYPE_CHECKING:
    from xaac_thin_client_dock.components import ComponentId
    from xaac_thin_client_dock.state.model import ComponentState


@runtime_checkable
class ComponentEnablementProvider(Protocol):
    """Determine whether an authorised component is enabled for the Dock."""

    def is_enabled(self, component_id: ComponentId | str) -> bool:
        """Return whether the component is enabled by the current policy source."""


@runtime_checkable
class ComponentActivityProbe(Protocol):
    """Determine whether an available component currently has a live instance."""

    def is_running(self, component_id: ComponentId | str, executable: str) -> bool:
        """Return whether the component executable is running for this session."""


@runtime_checkable
class ComponentStateProvider(Protocol):
    """Read normalised state without exposing process/service internals."""

    def get_state(self, component_id: ComponentId | str) -> ComponentState:
        """Return the current externally visible state for one component."""

    def get_all_states(self) -> tuple[ComponentState, ...]:
        """Return states for all registered components in presentation order."""

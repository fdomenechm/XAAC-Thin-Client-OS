"""Runtime aggregation for the formal Dock component state contract."""

from __future__ import annotations

from xaac_thin_client_dock.components import (
    AvailabilityReason,
    ComponentDiscovery,
    ComponentId,
    ComponentRegistry,
)
from xaac_thin_client_dock.launching.process import (
    CurrentProcessIdentity,
    IdentityProvider,
    LinuxProcProcessInspector,
    ProcessInspector,
)
from xaac_thin_client_dock.state.model import ComponentState, ComponentStatus
from xaac_thin_client_dock.state.ports import (
    ComponentActivityProbe,
    ComponentEnablementProvider,
)


class AllComponentsEnabled:
    """Default enablement source until component policies are wired into the Dock."""

    def is_enabled(self, component_id: ComponentId | str) -> bool:
        return True


class CurrentUserProcessActivityProbe:
    """Determine running state using the same-user process rules from Phase 2.3."""

    __slots__ = ("_inspector", "_identity")

    def __init__(
        self,
        inspector: ProcessInspector | None = None,
        identity: IdentityProvider | None = None,
    ) -> None:
        self._inspector = inspector or LinuxProcProcessInspector()
        self._identity = identity or CurrentProcessIdentity()

    def is_running(self, component_id: ComponentId | str, executable: str) -> bool:
        return self._inspector.find(executable, self._identity.real_uid()) is not None


class RuntimeComponentStateProvider:
    """Aggregate policy, availability and process activity into GUI-safe state."""

    __slots__ = ("_registry", "_discovery", "_enablement", "_activity")

    def __init__(
        self,
        registry: ComponentRegistry,
        discovery: ComponentDiscovery,
        *,
        enablement: ComponentEnablementProvider | None = None,
        activity: ComponentActivityProbe | None = None,
    ) -> None:
        self._registry = registry
        self._discovery = discovery
        self._enablement = enablement or AllComponentsEnabled()
        self._activity = activity or CurrentUserProcessActivityProbe()

    def get_state(self, component_id: ComponentId | str) -> ComponentState:
        """Return one normalised state snapshot."""

        component = self._registry.get(component_id)

        if not self._enablement.is_enabled(component.component_id):
            return ComponentState(
                component_id=component.component_id,
                enabled=False,
                available=False,
                running=False,
                status=ComponentStatus.DISABLED,
            )

        availability = self._discovery.inspect(component.component_id)
        if not availability.available:
            if availability.reason is AvailabilityReason.DETECTION_ERROR:
                return ComponentState(
                    component_id=component.component_id,
                    enabled=True,
                    available=False,
                    running=False,
                    status=ComponentStatus.ERROR,
                    availability_reason=availability.reason,
                    error="availability_detection_error",
                )

            return ComponentState(
                component_id=component.component_id,
                enabled=True,
                available=False,
                running=False,
                status=ComponentStatus.UNAVAILABLE,
                availability_reason=availability.reason,
            )

        assert availability.resolved_path is not None
        try:
            running = self._activity.is_running(
                component.component_id,
                availability.resolved_path,
            )
        except OSError:
            return ComponentState(
                component_id=component.component_id,
                enabled=True,
                available=True,
                running=False,
                status=ComponentStatus.ERROR,
                availability_reason=AvailabilityReason.AVAILABLE,
                error="activity_detection_error",
            )

        return ComponentState(
            component_id=component.component_id,
            enabled=True,
            available=True,
            running=running,
            status=(ComponentStatus.RUNNING if running else ComponentStatus.IDLE),
            availability_reason=AvailabilityReason.AVAILABLE,
        )

    def get_all_states(self) -> tuple[ComponentState, ...]:
        """Return all component states in registry order."""

        return tuple(self.get_state(component.component_id) for component in self._registry)


def create_default_state_provider(
    registry: ComponentRegistry,
    discovery: ComponentDiscovery,
) -> RuntimeComponentStateProvider:
    """Create the standard Phase 2.4 runtime state provider."""

    return RuntimeComponentStateProvider(registry=registry, discovery=discovery)

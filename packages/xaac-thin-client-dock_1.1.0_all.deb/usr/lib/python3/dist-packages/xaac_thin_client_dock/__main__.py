"""Executable entry point for XAAC Thin Client Dock."""

from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
import os
import sys

from xaac_thin_client_dock import __version__
from xaac_thin_client_dock.presentation import DockView


ViewFactory = Callable[[], DockView]


DEVELOPMENT_MODE_ENV = "XAAC_DOCK_DEVELOPMENT"
DOCK_CONFIG_ENV = "XAAC_DOCK_CONFIG"
_TRUE_ENV_VALUES = frozenset({"1", "true", "yes", "on"})


class _DisabledDockView:
    """No-op view used when validated policy disables the Dock."""

    def run(self) -> int:
        return 0


def _development_mode_enabled(
    environ: Mapping[str, str] | None = None,
) -> bool:
    """Return whether the development-only non-unique GTK mode is enabled."""
    source = os.environ if environ is None else environ
    value = source.get(DEVELOPMENT_MODE_ENV, "")
    return value.strip().lower() in _TRUE_ENV_VALUES


def _load_runtime_policy(
    environ: Mapping[str, str] | None = None,
):
    """Load Dock policy from an explicitly supplied INI path, if configured.

    Phase 4.1 deliberately does not hard-code the future Debian `/etc` path.
    `XAAC_DOCK_CONFIG` is the composition hook until OS packaging owns that
    location.  With no path configured, the established `optional` default is
    preserved.
    """
    from xaac_thin_client_dock.configuration import (
        ConfigurationError,
        DockPolicy,
        IniConfigurationProvider,
        load_dock_policy,
    )

    source = os.environ if environ is None else environ
    raw_path = source.get(DOCK_CONFIG_ENV)
    if raw_path is None:
        return DockPolicy()
    path = raw_path.strip()
    if not path:
        raise ConfigurationError(f"{DOCK_CONFIG_ENV} must not be empty")
    return load_dock_policy(IniConfigurationProvider.from_path(path))


def _create_default_view() -> DockView:
    """Compose the default backend and concrete GTK presentation lazily."""
    from xaac_thin_client_dock.components import (
        create_default_discovery,
        create_default_registry,
    )
    from xaac_thin_client_dock.i18n import configure_language
    from xaac_thin_client_dock.integrations import (
        create_default_full_flow_integration,
    )
    from xaac_thin_client_dock.launching import create_default_launcher
    from xaac_thin_client_dock.state import create_default_state_provider
    from xaac_thin_client_dock.presentation import (
        DockNavigationController,
        build_navigation_items,
    )
    from xaac_thin_client_dock.presentation.localization import (
        build_localized_functional_status_labels,
        build_localized_navigation_labels,
        build_localized_power_action_labels,
        build_localized_status_labels,
    )
    from xaac_thin_client_dock.presentation.gtk_view import create_gtk_dock_view
    from xaac_thin_client_dock.system import (
        DockLifecycle,
        KioskKeyStroke,
        SessionBusInstancePresenter,
        create_default_kiosk_shortcut_policy,
        create_default_power_controller,
        create_default_recovery_coordinator,
    )

    configure_language()

    lifecycle = DockLifecycle.from_policy(_load_runtime_policy())
    if not lifecycle.enabled:
        return _DisabledDockView()

    registry = create_default_registry()
    discovery = create_default_discovery(registry)
    launcher = create_default_launcher(
        registry,
        discovery,
        presenter=SessionBusInstancePresenter(),
    )
    state_provider = create_default_state_provider(registry, discovery)
    recovery_coordinator = create_default_recovery_coordinator()
    state_provider, launcher, recovery_coordinator = (
        create_default_full_flow_integration(
            state_provider,
            launcher,
            recovery_coordinator,
        )
    )
    navigation = build_navigation_items(
        registry,
        labels=build_localized_navigation_labels(),
    )
    controller = DockNavigationController(launcher)
    kiosk_shortcut_policy = create_default_kiosk_shortcut_policy()
    development_mode = _development_mode_enabled()
    power_controller = (
        None if development_mode else create_default_power_controller()
    )

    def block_kiosk_shortcut(
        key: str,
        alt: bool,
        control: bool,
        shift: bool,
        super_pressed: bool,
    ) -> bool:
        return kiosk_shortcut_policy.blocks(
            KioskKeyStroke(
                key=key,
                alt=alt,
                control=control,
                shift=shift,
                super=super_pressed,
            )
        )

    return create_gtk_dock_view(
        navigation_items=navigation,
        activate_component=controller.activate,
        read_component_states=state_provider.get_all_states,
        non_unique=development_mode,
        development_mode=development_mode,
        persistent=lifecycle.persistent,
        kiosk_restricted=lifecycle.restricted_kiosk,
        kiosk_shortcut_blocker=(
            block_kiosk_shortcut if lifecycle.restricted_kiosk else None
        ),
        status_labels=build_localized_status_labels(),
        functional_status_labels=build_localized_functional_status_labels(),
        navigation_result_handler=recovery_coordinator.handle,
        power_off_action=(
            None if power_controller is None else power_controller.power_off
        ),
        power_labels=build_localized_power_action_labels(),
    )


def main(
    argv: Sequence[str] | None = None,
    *,
    view_factory: ViewFactory | None = None,
) -> int:
    """Run the Dock GUI or print version information."""
    args = list(sys.argv[1:] if argv is None else argv)

    if args == ["--version"]:
        print(f"XAAC Thin Client Dock {__version__}")
        return 0

    if args:
        print(
            "Usage: xaac-thin-client-dock [--version]",
            file=sys.stderr,
        )
        return 2

    factory = view_factory or _create_default_view
    return int(factory().run())


if __name__ == "__main__":
    raise SystemExit(main())

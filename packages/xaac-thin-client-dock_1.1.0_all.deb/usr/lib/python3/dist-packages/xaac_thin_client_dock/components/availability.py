"""Executable-based component availability for XAAC Thin Client Dock.

Phase 2.2 determines whether an authorised component can be addressed through
an executable visible to the current kiosk session.  It does not launch the
component and does not inspect process/runtime state.
"""

from __future__ import annotations

import shutil
from collections.abc import Iterable
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path
from typing import Protocol, runtime_checkable

from xaac_thin_client_dock.components.registry import (
    ComponentId,
    ComponentRegistry,
)


class AvailabilityReason(StrEnum):
    """Machine-readable reason for the current availability result."""

    AVAILABLE = "available"
    EXECUTABLE_NOT_FOUND = "executable_not_found"
    DETECTION_ERROR = "detection_error"


@dataclass(frozen=True, slots=True)
class ComponentExecutable:
    """Executable name associated with one authorised component.

    The value is deliberately a command name, not an arbitrary path.  The
    platform resolver decides where it is located, keeping discovery separate
    from launch policy and preventing the registry from accumulating OS paths.
    """

    component_id: ComponentId
    executable: str

    def __post_init__(self) -> None:
        executable = self.executable.strip()
        if not executable:
            raise ValueError("component executable must not be empty")
        if executable != self.executable:
            raise ValueError("component executable must not have surrounding whitespace")
        if Path(executable).name != executable:
            raise ValueError("component executable must be a command name, not a path")


@dataclass(frozen=True, slots=True)
class ComponentAvailability:
    """Snapshot of whether one component is currently addressable."""

    component_id: ComponentId
    executable: str
    available: bool
    reason: AvailabilityReason
    resolved_path: str | None = None

    def __post_init__(self) -> None:
        if self.available:
            if self.reason is not AvailabilityReason.AVAILABLE:
                raise ValueError("available component must use reason=available")
            if not self.resolved_path:
                raise ValueError("available component must include resolved_path")
        elif self.reason is AvailabilityReason.AVAILABLE:
            raise ValueError("unavailable component cannot use reason=available")
        elif self.resolved_path is not None:
            raise ValueError("unavailable component cannot include resolved_path")


@runtime_checkable
class ExecutableLocator(Protocol):
    """Resolve a command name without executing it."""

    def resolve(self, executable: str) -> str | None:
        """Return the executable path, or ``None`` when it cannot be found."""


class PathExecutableLocator:
    """Resolve executables using the current process ``PATH``."""

    def resolve(self, executable: str) -> str | None:
        return shutil.which(executable)


class DuplicateExecutableSpecError(ValueError):
    """Raised when two discovery specs target the same component."""


class MissingExecutableSpecError(LookupError):
    """Raised when an authorised component has no discovery specification."""


class ExecutableComponentDiscovery:
    """Discover authorised XAAC components through executable visibility."""

    __slots__ = ("_registry", "_executables", "_locator")

    def __init__(
        self,
        registry: ComponentRegistry,
        executables: Iterable[ComponentExecutable],
        locator: ExecutableLocator | None = None,
    ) -> None:
        by_id: dict[ComponentId, ComponentExecutable] = {}
        for spec in executables:
            if spec.component_id in by_id:
                raise DuplicateExecutableSpecError(
                    f"duplicate executable spec: {spec.component_id.value}"
                )
            by_id[spec.component_id] = spec

        self._registry = registry
        self._executables = by_id
        self._locator = locator or PathExecutableLocator()

    def inspect(self, component_id: ComponentId | str) -> ComponentAvailability:
        """Return an availability snapshot for one authorised component."""

        component = self._registry.get(component_id)
        try:
            spec = self._executables[component.component_id]
        except KeyError as exc:
            raise MissingExecutableSpecError(
                f"missing executable spec: {component.component_id.value}"
            ) from exc

        try:
            resolved = self._locator.resolve(spec.executable)
        except OSError:
            return ComponentAvailability(
                component_id=component.component_id,
                executable=spec.executable,
                available=False,
                reason=AvailabilityReason.DETECTION_ERROR,
            )

        if not resolved:
            return ComponentAvailability(
                component_id=component.component_id,
                executable=spec.executable,
                available=False,
                reason=AvailabilityReason.EXECUTABLE_NOT_FOUND,
            )

        return ComponentAvailability(
            component_id=component.component_id,
            executable=spec.executable,
            available=True,
            reason=AvailabilityReason.AVAILABLE,
            resolved_path=resolved,
        )

    def is_available(self, component_id: ComponentId | str) -> bool:
        """Return whether one authorised component is currently available."""

        return self.inspect(component_id).available

    def inspect_all(self) -> tuple[ComponentAvailability, ...]:
        """Inspect every registered component in registry order."""

        return tuple(self.inspect(component.component_id) for component in self._registry)


DEFAULT_COMPONENT_EXECUTABLES: tuple[ComponentExecutable, ...] = (
    ComponentExecutable(ComponentId.NETWORK, "xaac-thin-client-network"),
    ComponentExecutable(ComponentId.VPN, "xaac-thin-client-vpn"),
    ComponentExecutable(ComponentId.THIN_CLIENT, "xaac-thin-client-remote"),
)


def create_default_discovery(
    registry: ComponentRegistry,
    locator: ExecutableLocator | None = None,
) -> ExecutableComponentDiscovery:
    """Create executable discovery for the standard XAAC components."""

    return ExecutableComponentDiscovery(
        registry=registry,
        executables=DEFAULT_COMPONENT_EXECUTABLES,
        locator=locator,
    )

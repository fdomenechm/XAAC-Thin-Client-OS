"""Authorised component registry for XAAC Thin Client Dock.

Phase 2.1 defines the components known by the Dock and their stable metadata.
Availability, runtime state and launching remain separate responsibilities.
"""

from __future__ import annotations

from collections.abc import Iterable, Iterator
from dataclasses import dataclass
from enum import StrEnum


class ComponentId(StrEnum):
    """Stable identifiers for components shipped in XAAC Thin Client OS 1.1.0."""

    NETWORK = "network"
    VPN = "vpn"
    THIN_CLIENT = "thin_client"


@dataclass(frozen=True, slots=True)
class ComponentDefinition:
    """Static metadata describing one Dock component.

    ``label_key`` is an internationalisation key rather than user-facing text.
    Presentation translates it later, keeping the registry independent from
    the GUI and current locale.
    """

    component_id: ComponentId
    label_key: str
    order: int

    def __post_init__(self) -> None:
        if not self.label_key or not self.label_key.strip():
            raise ValueError("component label_key must not be empty")
        if self.order < 0:
            raise ValueError("component order must be zero or greater")


class UnknownComponentError(LookupError):
    """Raised when a requested component is not present in a registry."""


class DuplicateComponentError(ValueError):
    """Raised when a registry contains the same component identifier twice."""


class ComponentRegistry:
    """Immutable ordered registry of authorised Dock components."""

    __slots__ = ("_components", "_by_id")

    def __init__(self, components: Iterable[ComponentDefinition]) -> None:
        ordered = tuple(sorted(components, key=lambda component: component.order))
        by_id: dict[ComponentId, ComponentDefinition] = {}

        for component in ordered:
            if component.component_id in by_id:
                raise DuplicateComponentError(
                    f"duplicate component id: {component.component_id.value}"
                )
            by_id[component.component_id] = component

        self._components = ordered
        self._by_id = by_id

    def __iter__(self) -> Iterator[ComponentDefinition]:
        return iter(self._components)

    def __len__(self) -> int:
        return len(self._components)

    def __contains__(self, component_id: object) -> bool:
        try:
            parsed = _parse_component_id(component_id)
        except (TypeError, ValueError):
            return False
        return parsed in self._by_id

    @property
    def components(self) -> tuple[ComponentDefinition, ...]:
        """Return all registered components in presentation order."""

        return self._components

    def get(self, component_id: ComponentId | str) -> ComponentDefinition:
        """Return one registered component by its stable identifier."""

        try:
            parsed = _parse_component_id(component_id)
        except (TypeError, ValueError) as exc:
            raise UnknownComponentError(f"unknown component: {component_id!r}") from exc

        try:
            return self._by_id[parsed]
        except KeyError as exc:
            raise UnknownComponentError(
                f"unknown component: {parsed.value}"
            ) from exc


def _parse_component_id(component_id: object) -> ComponentId:
    if isinstance(component_id, ComponentId):
        return component_id
    if isinstance(component_id, str):
        return ComponentId(component_id)
    raise TypeError("component id must be ComponentId or str")


DEFAULT_COMPONENTS: tuple[ComponentDefinition, ...] = (
    ComponentDefinition(
        component_id=ComponentId.NETWORK,
        label_key="component.network",
        order=10,
    ),
    ComponentDefinition(
        component_id=ComponentId.VPN,
        label_key="component.vpn",
        order=20,
    ),
    ComponentDefinition(
        component_id=ComponentId.THIN_CLIENT,
        label_key="component.thin_client",
        order=30,
    ),
)


def create_default_registry() -> ComponentRegistry:
    """Create the standard Network/VPN/Thin Client registry."""

    return ComponentRegistry(DEFAULT_COMPONENTS)

"""Component discovery boundary for XAAC Thin Client Dock."""

from __future__ import annotations

from typing import TYPE_CHECKING, Protocol, runtime_checkable

if TYPE_CHECKING:
    from xaac_thin_client_dock.components.availability import ComponentAvailability
    from xaac_thin_client_dock.components.registry import ComponentId


@runtime_checkable
class ComponentDiscovery(Protocol):
    """Determine whether an authorised component is currently available."""

    def inspect(self, component_id: ComponentId | str) -> ComponentAvailability:
        """Return a structured availability snapshot for the component."""

    def is_available(self, component_id: ComponentId | str) -> bool:
        """Return whether the identified component is currently available."""

    def inspect_all(self) -> tuple[ComponentAvailability, ...]:
        """Return snapshots for all registered components in registry order."""

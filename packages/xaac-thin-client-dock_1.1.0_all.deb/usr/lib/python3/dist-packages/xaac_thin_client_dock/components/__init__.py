"""Component registry and discovery layer."""

from xaac_thin_client_dock.components.availability import (
    DEFAULT_COMPONENT_EXECUTABLES,
    AvailabilityReason,
    ComponentAvailability,
    ComponentExecutable,
    DuplicateExecutableSpecError,
    ExecutableComponentDiscovery,
    ExecutableLocator,
    MissingExecutableSpecError,
    PathExecutableLocator,
    create_default_discovery,
)
from xaac_thin_client_dock.components.ports import ComponentDiscovery
from xaac_thin_client_dock.components.registry import (
    DEFAULT_COMPONENTS,
    ComponentDefinition,
    ComponentId,
    ComponentRegistry,
    DuplicateComponentError,
    UnknownComponentError,
    create_default_registry,
)

__all__ = [
    "DEFAULT_COMPONENTS",
    "DEFAULT_COMPONENT_EXECUTABLES",
    "AvailabilityReason",
    "ComponentAvailability",
    "ComponentDefinition",
    "ComponentDiscovery",
    "ComponentExecutable",
    "ComponentId",
    "ComponentRegistry",
    "DuplicateComponentError",
    "DuplicateExecutableSpecError",
    "ExecutableComponentDiscovery",
    "ExecutableLocator",
    "MissingExecutableSpecError",
    "PathExecutableLocator",
    "UnknownComponentError",
    "create_default_discovery",
    "create_default_registry",
]

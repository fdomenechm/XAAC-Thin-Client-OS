"""Dock policy model and loader."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum

from xaac_thin_client_dock.configuration.ports import ConfigurationProvider


DOCK_POLICY_SECTION = "dock"
DOCK_MODE_KEY = "mode"


class DockMode(StrEnum):
    """Supported operating modes for the Dock."""

    DISABLED = "disabled"
    OPTIONAL = "optional"
    REQUIRED = "required"


class DockPolicyError(ValueError):
    """Base class for invalid Dock policy."""


class InvalidDockModeError(DockPolicyError):
    """Raised when ``[dock] mode`` contains an unsupported value."""


@dataclass(frozen=True, slots=True)
class DockPolicy:
    """Validated ``[dock]`` policy consumed by the application core."""

    mode: DockMode = DockMode.OPTIONAL

    @property
    def enabled(self) -> bool:
        """Whether the Dock is enabled and may be executed."""

        return self.mode is not DockMode.DISABLED

    @property
    def required(self) -> bool:
        """Whether the Dock must act as the persistent kiosk shell."""

        return self.mode is DockMode.REQUIRED

    @property
    def optional(self) -> bool:
        """Whether the Dock is available without being the mandatory shell."""

        return self.mode is DockMode.OPTIONAL


def parse_dock_mode(value: str) -> DockMode:
    """Validate and normalise a textual Dock mode."""

    normalised = value.strip().lower()
    try:
        return DockMode(normalised)
    except ValueError as exc:
        allowed = ", ".join(mode.value for mode in DockMode)
        raise InvalidDockModeError(
            f"Invalid [dock] mode {value!r}; expected one of: {allowed}"
        ) from exc


def load_dock_policy(configuration: ConfigurationProvider) -> DockPolicy:
    """Load and validate the ``[dock]`` policy from a configuration provider.

    A completely absent ``[dock] mode`` uses ``optional`` as the conservative
    default.  An explicitly present but empty/invalid value is rejected so
    configuration mistakes are never silently converted into another mode.
    """

    raw_mode = configuration.get(DOCK_POLICY_SECTION, DOCK_MODE_KEY)
    if raw_mode is None:
        return DockPolicy()

    return DockPolicy(mode=parse_dock_mode(raw_mode))

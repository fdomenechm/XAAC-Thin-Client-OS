"""Configuration boundary for XAAC Thin Client Dock."""

from __future__ import annotations

from typing import Protocol, runtime_checkable


@runtime_checkable
class ConfigurationProvider(Protocol):
    """Provide configuration values without exposing their storage mechanism."""

    def get(self, section: str, key: str) -> str | None:
        """Return a configuration value, or ``None`` when it is not defined."""

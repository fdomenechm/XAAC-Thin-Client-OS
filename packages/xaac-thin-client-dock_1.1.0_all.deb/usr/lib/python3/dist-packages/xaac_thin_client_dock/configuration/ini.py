"""INI-backed configuration provider for XAAC Thin Client Dock."""

from __future__ import annotations

from configparser import ConfigParser, Error as ConfigParserError
from dataclasses import dataclass
from os import PathLike
from pathlib import Path


class ConfigurationError(ValueError):
    """Raised when a configuration source cannot be read safely."""


@dataclass(frozen=True, slots=True)
class IniConfigurationProvider:
    """Expose values from an INI file through the configuration port.

    The provider deliberately contains no Dock policy semantics.  It only
    supplies string values; policy interpretation remains in ``policy.py``.
    This makes it replaceable later by another provider, such as configuration
    supplied by XAAC Thin Client Agent.
    """

    _parser: ConfigParser

    @classmethod
    def from_path(
        cls,
        path: str | PathLike[str],
    ) -> "IniConfigurationProvider":
        """Load configuration from *path*.

        Missing files and malformed INI input are explicit errors rather than
        silently producing an empty configuration.
        """

        config_path = Path(path)
        parser = ConfigParser(interpolation=None)

        try:
            with config_path.open("r", encoding="utf-8") as stream:
                parser.read_file(stream)
        except (OSError, UnicodeError) as exc:
            raise ConfigurationError(
                f"Unable to read configuration file: {config_path}"
            ) from exc
        except ConfigParserError as exc:
            raise ConfigurationError(
                f"Invalid INI configuration: {config_path}"
            ) from exc

        return cls(parser)

    @classmethod
    def from_string(cls, text: str) -> "IniConfigurationProvider":
        """Build an INI provider from text, primarily for composition/tests."""

        parser = ConfigParser(interpolation=None)
        try:
            parser.read_string(text)
        except ConfigParserError as exc:
            raise ConfigurationError("Invalid INI configuration text") from exc
        return cls(parser)

    def get(self, section: str, key: str) -> str | None:
        """Return a value or ``None`` when section/key is not defined."""

        if not self._parser.has_section(section):
            return None
        if not self._parser.has_option(section, key):
            return None
        return self._parser.get(section, key, raw=True)

# Debian packaging

XAAC Thin Client Dock provides a rootless POSIX `/bin/sh` package builder for
integration into XAAC Thin Client OS 1.1.0.

## Build

From the project root:

```sh
./scripts/build-deb.sh --clean
```

The build artifacts are written to:

```text
dist/xaac-thin-client-dock_1.1.0_all.deb
dist/xaac-thin-client-dock-1.1.0.evidence.json
```

A different output directory can be selected with:

```sh
./scripts/build-deb.sh --output-dir /tmp/xaac-packages
```

The builder reads the version from `pyproject.toml`, verifies that it matches
`xaac_thin_client_dock.__version__`, stages only runtime files and validates the
resulting package metadata with `dpkg-deb`. Root privileges are not required.

After validating the `.deb`, the builder also writes a JSON evidence manifest
next to it. The manifest records `package`, `version`, the `.deb` filename as
`artifact`, its SHA-256 digest, exact `size_bytes`, the UTC build timestamp in
ISO-8601 `Z` form and the local `builder` user. This gives XAAC Thin Client OS
a machine-readable integrity record for the exact package selected for
integration.

## Installed layout

The package installs:

```text
/usr/bin/xaac-thin-client-dock
/usr/lib/python3/dist-packages/xaac_thin_client_dock/
/etc/xaac-dock/xaac-thin-client-dock.ini
/usr/share/doc/xaac-thin-client-dock/
```

`/etc/xaac-dock/xaac-thin-client-dock.ini` is registered as a Debian `conffile`, so
administrator changes are preserved across package upgrades according to normal
`dpkg` semantics. Its initial policy is:

```ini
[dock]
mode = optional
```

The executable wrapper uses that file by default by exporting
`XAAC_DOCK_CONFIG=/etc/xaac-dock/xaac-thin-client-dock.ini`. An explicitly supplied
`XAAC_DOCK_CONFIG` environment value still takes precedence.

## Runtime dependencies

The Debian package declares:

- Python 3.13;
- `python3-gi`;
- `gir1.2-gtk-4.0`.

Network, VPN and Thin Client are intentionally not hard package dependencies.
The Dock is designed to remain functional when an authorised component is not
installed and to show that component as unavailable. XAAC Thin Client OS can
therefore own the installation order and policy for the complete appliance.

## Scope

The package does **not** install or modify the kiosk session, display manager,
systemd user units or window-manager configuration. Those are XAAC Thin Client
OS integration responsibilities and are validated later in the real kiosk
environment.

## Shutdown integration

The package includes the Dock's `LogindPowerController`. XAAC Thin Client OS must provide its normal systemd-logind system service and the policy required for the kiosk user to request `org.freedesktop.login1.Manager.PowerOff(true)`. No privilege-elevation helper is shipped by this package.

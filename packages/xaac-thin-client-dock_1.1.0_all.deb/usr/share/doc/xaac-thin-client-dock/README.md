# XAAC Thin Client Dock

**Version:** 1.1.0

XAAC Thin Client Dock is the shell/launcher component planned for XAAC Thin Client OS 1.1.0.

The repository currently contains:

- **Phase 1.1 — project skeleton**;
- **Phase 1.2 — internal architecture**;
- **Phase 1.3 — `[dock]` policy**;
- **Phase 2.1 — component registry**;
- **Phase 2.2 — component availability discovery**;
- **Phase 2.3 — controlled application launching**;
- **Phase 2.4 — formal component state contract**;
- **Phase 2.5 — backend validation and regression suite**;
- **Phase 3.1 — GTK 4 Dock window/base**;
- **Phase 3.2 — registry-driven main navigation**;
- **Phase 3.3 — backend-driven visual states**;
- **Phase 3.4 — busy-operation UX and double-click protection**;
- **Phase 3.5 — gettext internationalisation (Catalan, Spanish and English)**;
- **Phase 3.6 — final visual polish and XAAC visual consistency**;
- **Phase 3.7 — availability/functional-state interaction refinement**;
- **Phase 4.1 — persistent Dock lifecycle**;
- **Phase 4.2 — component window flow and return-to-Dock coordination**;
- **Phase 4.3 — application-side kiosk integration**;
- **Phase 4.4 — failure recovery and shell resilience**;
- **Phase 5.1 — functional integration with XAAC Thin Client Network**;
- **Phase 5.2 — functional integration with XAAC Thin Client VPN**;
- **Phase 5.3 — remote-session lifecycle integration with XAAC Thin Client Remote**;
- **Phase 5.4 — complete Network/VPN/Thin Client flow integration and session gating**;
- **Phase 6.1 — complete automated validation gate**;
- **Phase 6.2 — functional GUI validation gate and real-GTK manual scenario runner**;
- **global shutdown action — fixed right-side system control with authorized logind power-off**;
- **global appliance actions — clickable XAAC wordmark for «About» plus a Diagnostics button immediately to the left of Shutdown**.

Phase 6.3 kiosk validation and XAAC Thin Client OS integration remain in later roadmap work. The Debian package builder is already available for that integration.

In the 1.1.0 appliance layout, Dock owns the global actions of the local shell: clicking the **XAAC** wordmark opens the global About information, **Diagnostics** displays a sanitized component-state summary, and **Shut down** remains the authorized system power action. XAAC Thin Client Remote therefore does not need to duplicate these controls.

## Development requirements

- Python 3.13
- `requires-python = ">=3.13,<3.14"`
- GTK 4 runtime/development libraries required by PyGObject
- PyGObject 3.50 or newer, below 4.0
- POSIX `/bin/sh` compatible helper scripts whenever possible

## Project structure

```text
xaac-thin-client-dock/
├── config/
│   └── xaac-thin-client-dock.ini.example
├── docs/
│   ├── architecture.md
│   ├── automated-testing.md
│   ├── availability.md
│   ├── backend-testing.md
│   ├── components.md
│   ├── launching.md
│   ├── gui-window.md
│   ├── gui-navigation.md
│   ├── gui-operations.md
│   ├── gui-states.md
│   ├── gui-visual-polish.md
│   ├── gui-functional-validation.md
│   ├── internationalization.md
│   ├── kiosk-integration.md
│   ├── dock-persistence.md
│   ├── window-management.md
│   ├── failure-recovery.md
│   ├── policy.md
│   ├── network-integration.md
│   ├── vpn-integration.md
│   ├── thin-client-integration.md
│   ├── full-flow.md
│   ├── state.md
│   └── system-power.md
├── pyproject.toml
├── README.md
├── scripts/
│   ├── build-deb.sh
│   ├── dev.sh
│   ├── setup-dev.sh
│   ├── test-automated.sh
│   ├── test-backend.sh
│   ├── test-gui-functional.sh
│   ├── test.sh
│   └── validate-gui.sh
├── src/
│   └── xaac_thin_client_dock/
│       ├── architecture.py
│       ├── components/
│       │   ├── availability.py
│       │   ├── ports.py
│       │   └── registry.py
│       ├── configuration/
│       │   ├── ini.py
│       │   ├── policy.py
│       │   └── ports.py
│       ├── i18n/
│       │   ├── ca/LC_MESSAGES/
│       │   ├── es/LC_MESSAGES/
│       │   ├── en/LC_MESSAGES/
│       │   └── xaac-thin-client-dock.pot
│       ├── integrations/
│       │   ├── flow.py
│       │   ├── network.py
│       │   ├── vpn.py
│       │   └── thin_client.py
│       ├── launching/
│       ├── presentation/
│       ├── state/
│       └── system/
├── tools/
│   └── gui_validation.py
└── tests/
```

## Prepare the development environment

```sh
./scripts/setup-dev.sh
```

The script requires `python3.13` explicitly and creates `.venv`.

## Run in development mode

```sh
./scripts/dev.sh
```

`dev.sh` enables the development-only `XAAC_DOCK_DEVELOPMENT=1` mode. In this
mode the GTK application uses `Gio.ApplicationFlags.NON_UNIQUE`, so launching
the Dock from IDEs such as PyCharm does not depend on acquiring the production
single-instance D-Bus application ownership. The installed/production entry
point does **not** enable this flag and therefore keeps the normal singleton
behaviour.

`./scripts/test.sh` only runs the pytest suite and never starts the real GTK
application.

The executable starts the GTK 4 Dock shell with registry-driven navigation and
backend-derived visual states. Use `--version` to print the package version
without starting GTK.

## Run tests

For the normal fast regression suite:

```sh
./scripts/test.sh
```

For the **Phase 6.1** independent automated quality gate:

```sh
./scripts/test-automated.sh
```

The Phase 6.1 gate runs the complete suite with strict pytest checks, warnings
as errors, branch coverage and a **90% global coverage minimum**. It also
validates all project helper scripts with `/bin/sh -n`. The existing backend
quality gate remains available through `./scripts/test-backend.sh` with its
stricter **95% backend coverage minimum**. See
[`docs/automated-testing.md`](docs/automated-testing.md).

## Build Debian package

For integration into XAAC Thin Client OS 1.1.0:

```sh
./scripts/build-deb.sh --clean
```

The rootless builder creates
`dist/xaac-thin-client-dock_1.1.0_all.deb` together with `dist/xaac-thin-client-dock-1.1.0.evidence.json`, installs the Python runtime under
`/usr/lib/python3/dist-packages`, provides `/usr/bin/xaac-thin-client-dock`, and
installs `/etc/xaac-dock/xaac-thin-client-dock.ini` as a Debian conffile. See
[`docs/debian-packaging.md`](docs/debian-packaging.md).

For the **Phase 6.2** focused functional GUI gate:

```sh
./scripts/test-gui-functional.sh
```

For manual real-GTK inspection with deterministic component scenarios:

```sh
./scripts/validate-gui.sh --list
./scripts/validate-gui.sh baseline --language ca
./scripts/validate-gui.sh baseline --dock-mode required --language ca
```

See [`docs/gui-functional-validation.md`](docs/gui-functional-validation.md).

## Internal architecture — Phase 1.2

The Dock is split into six explicit boundaries:

- `configuration`: configuration/policy access;
- `components`: component availability/discovery;
- `state`: component state access;
- `launching`: controlled application launch/presentation;
- `presentation`: GUI boundary;
- `system`: kiosk/session/OS integration.

`src/xaac_thin_client_dock/architecture.py` aggregates those dependencies in
`DockPorts`. See [`docs/architecture.md`](docs/architecture.md) for the complete
rules and ownership boundaries.

XAAC Thin Client Dock does **not** manage NetworkManager, OpenVPN, RDP or SPICE
directly. It consumes controlled boundaries exposed by the appropriate XAAC
components.

## `[dock]` policy — Phase 1.3

The policy format is:

```ini
[dock]
mode = optional
```

Supported modes:

- `disabled`: the Dock is disabled and must not be executed;
- `optional`: the Dock is available as navigation but is not the mandatory
  persistent shell;
- `required`: the Dock is the intended persistent kiosk shell.

`DockPolicy` provides the validated semantic model. Missing `[dock] mode`
defaults to `optional`; explicit empty or unsupported values are rejected.

`IniConfigurationProvider` supplies local INI configuration through the generic
`ConfigurationProvider` port. The policy loader therefore remains independent
of the source and can later consume configuration delivered through XAAC Thin
Client Agent without changing policy semantics.

See [`docs/policy.md`](docs/policy.md) for the complete contract.

## Component registry — Phase 2.1

The Dock now has a formal registry for the three authorised initial components:

- `network` — XAAC Thin Client Network;
- `vpn` — XAAC Thin Client VPN;
- `thin_client` — XAAC Thin Client Remote.

`ComponentDefinition` contains only stable static metadata (`component_id`,
`label_key`, `order`). `ComponentRegistry` provides deterministic iteration and
lookup while rejecting duplicate or unknown IDs explicitly.

The registry itself deliberately does **not** detect installation/availability,
inspect runtime state or launch applications. Availability is implemented by a
separate Phase 2.2 adapter. See [`docs/components.md`](docs/components.md).

## Component availability — Phase 2.2

`ExecutableComponentDiscovery` determines whether each authorised component is
addressable through its expected executable without executing it. The standard
command names are:

- `network` → `xaac-thin-client-network`;
- `vpn` → `xaac-thin-client-vpn`;
- `thin_client` → `xaac-thin-client-remote`.

Discovery returns an immutable `ComponentAvailability` snapshot with the stable
component ID, executable, availability boolean, machine-readable reason and the
resolved executable path when present. `inspect_all()` preserves registry order.

The resolver is injected through `ExecutableLocator`, so tests and future OS
integration do not depend on the developer machine's `PATH`. The default
`PathExecutableLocator` uses executable lookup only and never starts a process.
See [`docs/availability.md`](docs/availability.md).


## Controlled launching — Phase 2.3

`ControlledApplicationLauncher` accepts only stable IDs from the authorised
component registry. It obtains the executable path from Phase 2.2 discovery and
never accepts an arbitrary command from the GUI.

For each request it:

1. validates the component through the registry;
2. refuses to launch while the Dock has effective UID 0;
3. refuses unavailable components;
4. looks in Linux `/proc` for a same-user native binary or interpreter-backed
   script instance of the resolved executable;
5. requests presentation of an existing instance instead of duplicating it;
6. otherwise starts the executable directly, without a shell or privilege
   elevation;
7. reports the outcome as an immutable `LaunchResult`.

Concurrent requests inside one Dock process are serialised to close the common
double-click race. The default window presenter is deliberately a no-op until
the kiosk/window-system layer supplies the concrete activation adapter; failure
to present never causes a duplicate process to be launched.

See [`docs/launching.md`](docs/launching.md).

## Component state contract — Phase 2.4

`ComponentState` is now the immutable, typed contract consumed by the future
presentation layer. Each Network/VPN/Thin Client snapshot exposes:

```text
enabled
available
running
status
```

The normalised `ComponentStatus` values are `disabled`, `unavailable`, `idle`,
`running` and `error`. `RuntimeComponentStateProvider` aggregates the component
registry, Phase 2.2 availability and a same-user activity probe without exposing
process details to the GUI. Diagnostic availability reason/error codes remain
machine-readable and stable.

`AllComponentsEnabled` is the neutral Phase 2.4 enablement source; the interface
is injectable so later local/Agent component policy can replace it without
changing the GUI contract. See [`docs/state.md`](docs/state.md).

## Backend validation — Phase 2.5

Phase 2.5 validates the backend as a complete chain rather than only as isolated
classes. Cross-boundary tests compose the real registry, discovery, state
provider and controlled launcher with deterministic system adapters.

The phase also adds a fail-closed regression rule: if existing-process
inspection fails, the launcher returns `failed/process_inspection_error` and
does not risk spawning a duplicate instance.

Run the dedicated backend quality gate with:

```sh
./scripts/test-backend.sh
```

It validates configuration, registry, availability, controlled launching and
state with a minimum combined backend coverage of 95%.

See [`docs/backend-testing.md`](docs/backend-testing.md).

## Dock window/base — Phase 3.1

The first concrete GUI layer is implemented with GTK 4/PyGObject, matching the
existing XAAC GUI stack. `GtkDockView` creates a compact undecorated 720 × 96
window with the XAAC brand area and an empty content slot reserved for Phase 3.2.

GTK is loaded lazily inside the concrete presentation adapter. Backend modules
and architecture ports therefore remain usable and testable without a graphical
session. Base CSS is shipped as package data and prefers Roboto.

Run the GUI in development mode with:

```sh
./scripts/dev.sh
```

The GUI block is visually complete through Phase 3.6. Phase 4.1 implements
policy-driven Dock persistence and Phase 4.2 adds authorised application
activation plus controlled return-to-Dock flow; final kiosk hardening and
compositor placement remain later Block 4 phases. See
[`docs/gui-window.md`](docs/gui-window.md) and
[`docs/gui-visual-polish.md`](docs/gui-visual-polish.md).

## Main navigation — Phase 3.2

The Dock uses an application-owned **light GTK palette** for its base surface and
navigation controls. Core colours and normal/hover/active/focus/disabled/backdrop
states are defined explicitly so the UI does not change appearance with the host
desktop GTK theme or focus state.


The Phase 3.1 content slot now renders registry-driven controls for Network, VPN
and Remote session (the technical XAAC Thin Client Remote component). The controls use the same GTK symbolic icon family as XAAC Thin
Client (`network-wired-symbolic`, `network-vpn-symbolic` and `computer-symbolic`),
with semantic colours applied by application CSS. Navigation order comes directly
from `ComponentRegistry`, and
button activation is delegated through `DockNavigationController` to the
existing controlled `ApplicationLauncher`; GTK never launches processes
itself.

Stable component identifiers and i18n keys remain independent from the visible
text. Phase 3.5 resolves the displayed labels through gettext according to the
XAAC Thin Client OS session locale. See
[`docs/gui-navigation.md`](docs/gui-navigation.md).

## Busy-operation UX — Phase 3.4

Navigation transitions now use an explicit busy lifecycle. On an accepted click the
Dock immediately:

1. marks the clicked control as busy;
2. disables all navigation controls to prevent overlapping/double-click actions;
3. changes the Dock cursor to `wait`;
4. runs the controlled launcher away from the GTK main thread in normal GUI
   execution;
5. marshals completion back to the GTK main loop;
6. clears the busy style/cursor and rebuilds sensitivity from the backend state
   snapshot.

The UI is restored whether the operation succeeds, raises an exception or cannot
be scheduled. A refresh performed while an operation is still in progress cannot
re-enable navigation prematurely.

`ImmediateOperationRunner` keeps non-GUI/unit tests deterministic, while real GTK
execution automatically uses `ThreadedOperationRunner` with `GLib.idle_add`.
GTK widgets are never mutated from the worker thread.

See [`docs/gui-operations.md`](docs/gui-operations.md).

## Scope completed so far

### Phase 1.1

- Python project/package layout;
- version 1.1.0;
- Python 3.13 requirement;
- development virtual environment scripts;
- basic test structure;
- console entry point;
- initial internationalisation directory layout.

### Phase 1.2

- internal subsystem separation;
- explicit ports/contracts for configuration, component discovery, state,
  launching, GUI and kiosk/system integration;
- dependency aggregation through `DockPorts`;
- documented architecture and ownership rules;
- architecture boundary regression test.

### Phase 1.3

- validated `DockMode` values: `disabled`, `optional`, `required`;
- immutable `DockPolicy` semantic model;
- `optional` default only when `[dock] mode` is absent;
- explicit rejection of invalid/empty modes;
- INI-backed configuration adapter;
- source-independent policy loading through `ConfigurationProvider`;
- example `[dock]` configuration;
- policy documentation and regression tests.

### Phase 2.1

- stable component identifiers for Network, VPN and Thin Client;
- immutable `ComponentDefinition` metadata;
- deterministic `ComponentRegistry`;
- explicit unknown/duplicate component errors;
- i18n label keys kept separate from user-facing translated text;
- registry documentation and regression tests;
- extensible registry consumption without hardcoded three-button assumptions.

### Phase 2.2

- executable-based availability discovery without launching applications;
- standard discovery specifications for Network, VPN and Thin Client;
- immutable structured availability snapshots;
- explicit reasons for available, missing executable and resolver errors;
- injectable executable locator for deterministic tests and OS integration;
- ordered bulk inspection through the existing component registry;
- explicit errors for unknown components, duplicate specs and missing specs.


### Phase 2.3

- immutable structured `LaunchResult` and `LaunchStatus`;
- authorised launch requests through the existing component registry;
- availability gating through Phase 2.2 discovery;
- explicit root-execution blocking;
- direct `subprocess` execution without shell or elevation helpers;
- same-user existing-process detection via Linux `/proc`;
- duplicate-launch prevention including concurrent Dock requests;
- presentation hook for existing instances;
- structured handling of process-inspection, presentation and spawn errors.

### Phase 2.4

- immutable typed `ComponentState` snapshots;
- normalised `disabled`, `unavailable`, `idle`, `running` and `error` states;
- stable `enabled`, `available`, `running`, `status` GUI contract;
- injectable component enablement and activity ports;
- same-user runtime activity probe;
- ordered bulk state through `get_all_states()`;
- normalised availability/activity detection errors;
- state model invariants and regression tests.

### Phase 2.5

- cross-boundary backend integration tests;
- full availability → state → launch → running-state regression flow;
- registry/discovery alignment tests for Network, VPN and Thin Client;
- expanded `ComponentState` and `LaunchResult` invariant coverage;
- Linux `/proc` adapter edge-case tests;
- direct subprocess invocation regression test;
- fail-closed process-inspection behaviour to preserve single-instance safety;
- dedicated `test-backend.sh` coverage gate with a 95% minimum.


## Global shutdown action

The Dock includes a global **Shut down** action that is not a component. It is
rendered outside the homogeneous component container, after a dedicated
separator, so it remains fixed at the far right while future components expand
through the centre/left area. The control is deliberately smaller than Network,
VPN and Remote session to communicate that it is an appliance action rather
than navigation.

Shutdown requires an explicit localized `Gtk.AlertDialog` confirmation with
**Accept** and **Cancel** actions. Debian 13 provides GTK 4.18, so the Dock uses
the GTK 4.10+ binding-friendly alert API rather than the deprecated
`Gtk.MessageDialog` path. In development (`dev.sh` and `validate-gui.sh`),
accepting closes only the Dock application; in production it proceeds to the
authorized system power request. Once confirmed, the Dock applies the same
guarded busy UX as other long operations: immediate wait cursor, control
disabling, duplicate-action protection and full restoration on failure.
The operating-system request uses systemd-logind `PowerOff(true)` over the
system D-Bus; authorization remains an XAAC Thin Client OS policy concern and
the Dock does not elevate privileges itself. See
[`docs/system-power.md`](docs/system-power.md).

## Dock persistence — Phase 4.1

Phase 4.1 connects the existing `[dock]` policy to the real GTK lifecycle.

- `required` keeps one Dock window alive as the persistent kiosk shell;
- normal window-manager close requests such as Alt+F4 are intercepted and the
  existing Dock window is re-presented;
- repeated application activation reuses the same top-level window rather than
  creating duplicates;
- the GTK application is held while a required Dock is active so losing the
  last normal window cannot silently terminate the shell;
- `optional` retains normal close behaviour;
- `disabled` exits without constructing GTK.

The installed configuration path is still intentionally not hard-coded. Until
the Debian/XAAC Thin Client OS integration phase owns that path, a policy file
may be supplied with `XAAC_DOCK_CONFIG=/path/to/dock.ini`. With no explicit
path, the established `optional` default remains unchanged.

For local validation of required mode:

```sh
cat > /tmp/xaac-dock-required.ini <<'EOF'
[dock]
mode = required
EOF
XAAC_DOCK_CONFIG=/tmp/xaac-dock-required.ini ./scripts/dev.sh
```

See [`docs/dock-persistence.md`](docs/dock-persistence.md).

## Window management — Phase 4.2

Phase 4.2 makes the Dock the navigation home across authorised application
transitions. Existing component instances are reactivated through the current
session's GApplication D-Bus identity instead of being duplicated. Successful
new/existing component processes are monitored by PID plus Linux process start
time; when they exit, the same Dock window is refreshed and presented again.
No `wmctrl`, `xdotool`, shell command or hard-coded component application ID is
required. See [`docs/window-management.md`](docs/window-management.md).

## Kiosk integration — Phase 4.3

In `required` mode the Dock now applies its application-side kiosk guard: it
consumes common desktop escape accelerators that reach the Dock, inhibits
logout/user-switch/suspend/idle session actions where supported, keeps the
Phase 4.1 persistent close guard, and exposes no arbitrary application launcher.
The shortcut policy is toolkit-independent and lives in `system/kiosk.py`.

Global compositor/kernel shortcuts cannot be reliably overridden by a GTK
window, so the dedicated XAAC Thin Client OS kiosk session remains responsible
for removing desktop, terminal, file-manager and VT escape bindings globally.
The Dock never mutates Zorin/GNOME settings to simulate that integration. See
[`docs/kiosk-integration.md`](docs/kiosk-integration.md).

## Automated validation — Phase 6.1

Phase 6.1 consolidates all automated tests from Blocks 1–5 into one independent
quality gate. `./scripts/test-automated.sh` validates POSIX shell syntax, exact
Python 3.13 use, strict pytest configuration, warnings-as-errors and complete
package branch coverage with a 90% minimum. The suite covers configuration,
policies, state/backend, launchers, errors/recovery, GUI behaviour,
internationalisation and all three functional integrations plus the complete
flow. See [`docs/automated-testing.md`](docs/automated-testing.md).

## Functional GUI validation — Phase 6.2

Phase 6.2 adds a focused `gui_functional` test gate plus a development-only
real-GTK scenario runner. The runner renders the real Dock presentation while
simulating only external component state and launch outcomes, so installed/missing
components, policy states, required Network/VPN gating, failures, busy/double-click
behaviour and repeated return can be inspected without live external services.
See [`docs/gui-functional-validation.md`](docs/gui-functional-validation.md).

## Explicitly deferred

The following remain intentionally **not** implemented yet:

- kiosk escape/focus/repetition validation — Phase 6.3;
- compositor placement/reserved screen geometry — OS integration;
- systemd/session startup and Debian packaging — later integration blocks;
- XAAC Thin Client Agent / Management Server remote policy transport — later
  integration work.

### Phase 3.1

- GTK 4/PyGObject concrete presentation adapter;
- compact undecorated Dock shell;
- pure immutable window specification;
- packaged base CSS with Roboto preference;
- lazy GTK loading to preserve backend independence;
- GUI entry point plus `--version`;
- presentation/architecture regression tests.

### Phase 3.2

- registry-driven Network/VPN/Remote session navigation (technical component is XAAC Thin Client Remote);
- immutable `DockNavigationItem` presentation model;
- deterministic navigation order inherited from `ComponentRegistry`;
- `DockNavigationController` delegation to the controlled launcher;
- GTK buttons with no process/system logic in the GUI adapter;
- default application composition wiring registry → discovery → launcher → view;
- presentation/navigation regression tests.


### Phase 3.3

- immutable backend-to-GUI `DockComponentVisualState` mapping;
- five deterministic visual states: disabled, unavailable, available/idle, running and error;
- state indicator and status label inside every navigation control;
- navigation sensitivity derives from `ComponentState.launchable` (`enabled and available`);
- disabled/unavailable controls remain blocked, while an available component in `error` remains activable for repair/diagnosis;
- initial state snapshot from `ComponentStateProvider`;
- immediate state refresh after navigation activation;
- missing/failed state reads rendered as non-interactive error;
- deterministic light-theme state CSS including backdrop rendering;
- stable `status.*` i18n keys consumed by the Phase 3.5 gettext layer.

## Visual states — Phase 3.3

The GTK surface now consumes `ComponentStateProvider` and renders the five
normalised backend states: `disabled`, `unavailable`, `idle`, `running` and
`error`. Each navigation control includes a compact state row and deterministic
state CSS. Interaction is not tied to a fixed status list: a control remains
interactive whenever the component application itself is enabled and available.
This allows an available Network/VPN component in `error` to be opened for
repair, while unknown or unavailable component availability still fails closed.

The state snapshot is read at window creation and refreshed after a navigation
action. GTK does not inspect processes, executable paths or availability.
Fallback state labels keep stable `status.*` keys consumed by the Phase 3.5 runtime
localisation. See [`docs/gui-states.md`](docs/gui-states.md).


### XAAC symbolic iconography

The Dock now uses the same GTK symbolic icon family and semantic colour language as
XAAC Thin Client. Network uses `network-wired-symbolic`, VPN uses
`network-vpn-symbolic`, and Remote session (XAAC Thin Client Remote) uses `computer-symbolic`. Icons render at
22 px, matching the principal selector icon size in XAAC Thin Client.

Colours communicate state rather than assigning an unrelated colour to each
application: available/contextual icons use XAAC blue (`#1d6695`), running/healthy
icons use XAAC green (`#2f8f46`), errors use XAAC red (`#bd3434`), and unavailable
or disabled states use neutral grey. This keeps icon shape, line weight and colour
semantics coherent across XAAC Thin Client OS.

### Phase 3.4

- immediate wait cursor on accepted navigation actions;
- temporary blocking of all navigation controls;
- explicit double-click/overlap guard;
- launcher execution outside the GTK main thread;
- completion marshalled through the GTK main loop;
- unconditional UI restoration after success/failure/scheduling error;
- refreshes cannot re-enable controls while an operation is busy;
- regression tests for the complete busy lifecycle.


## Internationalisation — Phase 3.5

The Dock now uses GNU gettext catalogues with the same localisation model used
by XAAC Thin Client. The supported GUI languages are Catalan (`ca`), Spanish
(`es`) and English (`en`).

At startup the composition root resolves the language from the graphical OS
session and configures gettext before building navigation or status labels.
`LC_ALL` takes precedence, followed by `LANGUAGE`, `LC_MESSAGES` and `LANG`.
Locale variants such as `ca_ES.UTF-8` are normalised to their supported language
code. Catalan is the safe fallback when no supported locale is available.

The translated surface currently covers component navigation and the five visual
states. Source `.po`, compiled `.mo` and the `.pot` template are included in the
Python package/wheel. Backend identifiers, component state and launching logic
remain locale-independent.

See [`docs/internationalization.md`](docs/internationalization.md).

## Final visual polish — Phase 3.6

Phase 3.6 closes the Dock GUI block. The surface now uses the same light
blue-grey/card palette, typography hierarchy, semantic blue/green/red language
and focus treatment as XAAC Thin Client. The transparent XAAC wordmark remains
the fixed brand element.

The navigation container is homogeneous, so Network, VPN and Remote session
keep equal widths in Catalan, Spanish and English. Normal, hover, pressed,
focus, backdrop, disabled, busy and backend-state styling are all application
owned and deterministic.

See [`docs/gui-visual-polish.md`](docs/gui-visual-polish.md).



## Phase 3.7 — Availability / functional-state separation

Dock navigation is now enabled from component launchability (`enabled and
available`) rather than from a fixed list of visual statuses.  A known available
component remains accessible even when it reports `error`, so Network/VPN can be
opened to repair their managed service.  `unavailable` remains reserved for the
component application itself being unavailable.  See
`docs/functional-state-separation.md`.

### Phase 4.1

- `DockLifecycle` mapping from `disabled/optional/required` policy;
- `required` GTK lifecycle with application hold and close-request interception;
- one reusable Dock top-level window across repeated activation;
- `optional` normal close behaviour;
- `disabled` no-GUI runtime path;
- runtime policy injection through `XAAC_DOCK_CONFIG` without fixing the future
  Debian `/etc` location;
- persistence and configuration regression tests.

### Phase 4.2

- same-PID GApplication reactivation over the user D-Bus session bus;
- no hard-coded component application IDs or X11 helper commands;
- process-lifetime tracking using PID plus `/proc` start time;
- duplicate watcher suppression;
- automatic GTK-main-loop return to the existing Dock window when a component exits;
- window-flow and architecture regression tests.

### Phase 4.3

- `required` mode activates application-side kiosk confinement;
- pure `KioskKeyStroke` / `KioskShortcutPolicy` system boundary;
- blocking of common desktop/window/session escape accelerators delivered to GTK;
- GTK session inhibition for logout, user switching, suspend and idle where supported;
- inhibition released on application shutdown;
- controlled component launcher remains the only application transition path;
- explicit OS contract for compositor/global shortcut hardening;
- no GNOME/Zorin mutation and no `gsettings`, `wmctrl`, `xdotool` or shell helpers.

## Failure recovery — Phase 4.4

The shell now contains an explicit `ComponentRecoveryCoordinator`. Launch
failures, unavailable/blocked component results, failed presentation of an
already-running instance, watcher-setup failures and component termination all
return to the existing Dock safely. Unexpected navigation exceptions also
clear busy UX and re-present the shell. The Dock does not automatically restart
failed component applications. See [`docs/failure-recovery.md`](docs/failure-recovery.md).

## Network functional integration — Phase 5.1

The Dock now consumes the public XAAC Thin Client Network **system D-Bus** API
(`org.xaac.ThinClient.Network1`) without accessing NetworkManager directly.
`GetPolicyState()` maps Network `disabled/optional/required` policy into Dock
access, while `GetState()` enriches the generic component state with Ethernet,
Wi-Fi, connected, connecting, disconnected, limited or error presentation.

Functional connectivity never replaces component launchability: a disconnected
or misconfigured Network remains openable so the user can repair it. A known
`disabled` Network policy blocks launch. Existing controlled launching,
duplicate prevention, window tracking and return-to-Dock recovery are reused.
State is refreshed when the Dock is shown, after navigation, on controlled
return from Network, and periodically so boot-time service races self-heal. See [`docs/network-integration.md`](docs/network-integration.md).
## VPN functional integration — Phase 5.2

The Dock now integrates XAAC Thin Client VPN through a dedicated system D-Bus
adapter for the `xaac-vpn-manager` boundary. The real 1.1.0
`GetCapabilities()` payload provides VPN `disabled/optional/required` policy,
while `GetStatus()` enriches the generic component state with not-required,
disconnected, connecting, connected, disconnecting or error presentation.

The Dock does not connect or disconnect OpenVPN itself and never handles VPN
credentials or OTP values. The existing `xaac-thin-client-vpn` GUI remains the
user interaction owner, while controlled launching, duplicate prevention,
window tracking, busy-state restoration and safe return to the Dock are reused
from Blocks 2–4. See [`docs/vpn-integration.md`](docs/vpn-integration.md).



## Thin Client functional integration — Phase 5.3

The Dock now integrates the remote-session lifecycle exposed by XAAC Thin
Client through a dedicated user-session D-Bus adapter. When the Thin Client GUI
is not running, executable availability is shown as **Session available**. Once
the GUI is running, `GetState()` enriches the Dock state with session available,
connecting, active or error.

A functional session watcher complements the existing process-exit watcher. It
starts only after the authorised Thin Client process is launched/presented and
returns focus to the Dock after a connection attempt has entered connecting or
active state and subsequently becomes available again or fails. This covers
normal disconnection, cancellation, connection failure and session closure even
when the Thin Client GUI itself remains alive. The Dock never controls the
remote protocol directly. See [`docs/thin-client-integration.md`](docs/thin-client-integration.md).

## Complete component flow — Phase 5.4

Network, VPN and Remote remain independently openable. Network/VPN policy and
runtime state are diagnostic context only: **they never disable or gate XAAC
Thin Client Remote**. This is required by the OS 1.1.0 recovery model: Remote
is shown even without connectivity and the persistent Dock lets the user open
Network or VPN to repair the condition. The controlled launcher still enforces
each component's own `disabled` policy and executable availability.


from __future__ import annotations

import hashlib
import io
import json
import os
import re
import stat
import subprocess
import tempfile
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Protocol, Sequence

from xaac_agent import __version__
from xaac_agent.thin_client_contract import ContractOperation, ThinClientIntegrationContract
from xaac_agent.thin_client_state import ThinClientStateReader
from xaac_agent.thin_client_systemd import ThinClientServiceAction, ThinClientSystemdController


class ThinClientDiagnosticError(ValueError):
    """Diagnòstic local de XAAC Thin Client no vàlid o insegur."""


_SECRET_RE = re.compile(
    r"(?i)(password|passwd|secret|token|api[_-]?key|authorization|client[_-]?secret|access[_-]?token)"
)


class DiagnosticLogBackend(Protocol):
    def run(self, argv: Sequence[str], *, timeout_seconds: int) -> subprocess.CompletedProcess[str]: ...


class SubprocessDiagnosticLogBackend:
    def run(self, argv: Sequence[str], *, timeout_seconds: int) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            list(argv), check=False, capture_output=True, text=True,
            timeout=timeout_seconds, stdin=subprocess.DEVNULL,
        )


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _canonical(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode("utf-8")


def _redact(value: Any, *, depth: int = 0) -> Any:
    if depth > 16:
        return "[TRUNCATED]"
    if isinstance(value, Mapping):
        result: dict[str, Any] = {}
        for key, child in value.items():
            text = str(key)
            result[text] = "[REDACTED]" if _SECRET_RE.search(text) else _redact(child, depth=depth + 1)
        return result
    if isinstance(value, list):
        return [_redact(child, depth=depth + 1) for child in value[:256]]
    if isinstance(value, str):
        text = value.replace("\x00", "")
        text = re.sub(r"(?i)(authorization\s*:\s*bearer)\s+\S+", r"\1 [REDACTED]", text)
        text = re.sub(r"(?i)((?:password|passwd|secret|token|api[_-]?key)\s*[=:]\s*)\S+", r"\1[REDACTED]", text)
        return text[:4096]
    if value is None or isinstance(value, (bool, int, float)):
        return value
    return str(value)[:512]


@dataclass(frozen=True, slots=True)
class ThinClientDiagnosticResult:
    state: str
    code: str
    package_path: str | None
    sha256: str | None
    bytes_written: int
    collected_at: str
    warnings: tuple[str, ...] = ()

    def to_payload(self) -> dict[str, object]:
        return {
            "format": "xaac-thin-client-diagnostic-result/v1",
            "state": self.state,
            "code": self.code,
            "package_path": self.package_path,
            "sha256": self.sha256,
            "bytes": self.bytes_written,
            "collected_at": self.collected_at,
            "warnings": list(self.warnings),
        }


@dataclass(slots=True)
class ThinClientDiagnosticCollector:
    contract: ThinClientIntegrationContract
    state_reader: ThinClientStateReader
    systemd_controller: ThinClientSystemdController
    output_directory: Path
    log_backend: DiagnosticLogBackend
    max_log_lines: int = 300
    max_log_bytes: int = 65536
    max_package_bytes: int = 1048576
    timeout_seconds: int = 15
    journalctl_path: str = "/usr/bin/journalctl"

    def __post_init__(self) -> None:
        self.output_directory = Path(self.output_directory)
        if not self.output_directory.is_absolute():
            raise ThinClientDiagnosticError("diagnostic_output_directory_must_be_absolute")
        if not 1 <= self.max_log_lines <= 5000:
            raise ThinClientDiagnosticError("diagnostic_max_log_lines_out_of_range")
        if not 1024 <= self.max_log_bytes <= 4 * 1024 * 1024:
            raise ThinClientDiagnosticError("diagnostic_max_log_bytes_out_of_range")
        if not 4096 <= self.max_package_bytes <= 16 * 1024 * 1024:
            raise ThinClientDiagnosticError("diagnostic_max_package_bytes_out_of_range")
        if not 1 <= self.timeout_seconds <= 120:
            raise ThinClientDiagnosticError("diagnostic_timeout_out_of_range")
        if not self.journalctl_path.startswith("/"):
            raise ThinClientDiagnosticError("journalctl_path_must_be_absolute")

    def collect(self, *, diagnostic_id: str) -> ThinClientDiagnosticResult:
        if not self.contract.is_operation_allowed(ContractOperation.COLLECT_DIAGNOSTICS):
            raise ThinClientDiagnosticError("collect_diagnostics_not_authorized")
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,63}", diagnostic_id):
            raise ThinClientDiagnosticError("invalid_diagnostic_id")
        self._ensure_output_directory()
        warnings: list[str] = []
        collected_at = _utc_now()

        try:
            state = self.state_reader.read().to_payload()
        except Exception as error:  # diagnòstic de millor esforç
            state = {"format": "xaac-agent-thin-client-state/v1", "unavailable": True}
            warnings.append(f"state:{type(error).__name__}")

        try:
            service = self.systemd_controller.execute(ThinClientServiceAction.STATUS).to_payload()
        except Exception as error:
            service = {"format": "xaac-thin-client-service-result/v1", "unavailable": True}
            warnings.append(f"service:{type(error).__name__}")

        configuration = self._read_effective_configuration(warnings)
        logs = self._collect_logs(warnings)
        versions = {
            "format": "xaac-thin-client-versions/v1",
            "agent": {"name": "xaac-agent", "version": __version__},
            "thin_client": {"version": state.get("version") if isinstance(state, Mapping) else None},
        }
        manifest = {
            "format": "xaac-thin-client-diagnostic/v1",
            "diagnostic_id": diagnostic_id,
            "collected_at": collected_at,
            "redaction": "basic-v1",
            "entries": ["state.json", "service.json", "configuration.json", "versions.json", "logs.txt"],
            "warnings": warnings,
        }
        package = self._build_package(manifest, state, service, configuration, versions, logs)
        if len(package) > self.max_package_bytes:
            raise ThinClientDiagnosticError("diagnostic_package_too_large")
        destination = self.output_directory / f"{diagnostic_id}.zip"
        self._atomic_write(destination, package)
        digest = hashlib.sha256(package).hexdigest()
        return ThinClientDiagnosticResult(
            state="succeeded", code="thin_client_diagnostic_collected",
            package_path=str(destination), sha256=digest, bytes_written=len(package),
            collected_at=collected_at, warnings=tuple(warnings),
        )

    def _read_effective_configuration(self, warnings: list[str]) -> dict[str, Any]:
        path = self.contract.config_root / "active-configuration.json"
        if path.is_symlink():
            warnings.append("configuration:symlink")
            return {"format": "xaac-configuration/v1", "unavailable": True}
        if not path.exists():
            return {"format": "xaac-configuration/v1", "present": False}
        try:
            info = path.stat(follow_symlinks=False)
            if not stat.S_ISREG(info.st_mode) or info.st_size > 4 * 1024 * 1024:
                raise OSError("unsafe configuration")
            raw = path.read_bytes()
            document = json.loads(raw.decode("utf-8"))
            if not isinstance(document, Mapping):
                raise ValueError("invalid document")
            return _redact(document)
        except (OSError, UnicodeDecodeError, json.JSONDecodeError, ValueError):
            warnings.append("configuration:unreadable")
            return {"format": "xaac-configuration/v1", "unavailable": True}

    def _collect_logs(self, warnings: list[str]) -> str:
        argv = (
            self.journalctl_path, "--unit", self.systemd_controller.unit,
            "--lines", str(self.max_log_lines), "--no-pager", "--output=short-iso",
        )
        try:
            completed = self.log_backend.run(argv, timeout_seconds=self.timeout_seconds)
        except (OSError, subprocess.TimeoutExpired):
            warnings.append("logs:unavailable")
            return ""
        if completed.returncode != 0:
            warnings.append("logs:failed")
        text = str(_redact(completed.stdout or completed.stderr or ""))
        encoded = text.encode("utf-8")[: self.max_log_bytes]
        return encoded.decode("utf-8", errors="ignore")

    def _build_package(self, manifest: object, state: object, service: object, configuration: object, versions: object, logs: str) -> bytes:
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for name, payload in (
                ("manifest.json", manifest), ("state.json", state), ("service.json", service),
                ("configuration.json", configuration), ("versions.json", versions),
            ):
                archive.writestr(name, _canonical(payload))
            archive.writestr("logs.txt", logs.encode("utf-8"))
        return buffer.getvalue()

    def _ensure_output_directory(self) -> None:
        path = self.output_directory
        if path.is_symlink():
            raise ThinClientDiagnosticError("diagnostic_output_directory_symlink")
        try:
            path.mkdir(mode=0o700, parents=True, exist_ok=True)
            os.chmod(path, 0o700, follow_symlinks=False)
            mode = path.stat(follow_symlinks=False).st_mode
        except OSError as error:
            raise ThinClientDiagnosticError("diagnostic_output_directory_unavailable") from error
        if not stat.S_ISDIR(mode):
            raise ThinClientDiagnosticError("diagnostic_output_not_directory")

    def _atomic_write(self, destination: Path, payload: bytes) -> None:
        if destination.is_symlink():
            raise ThinClientDiagnosticError("diagnostic_destination_symlink")
        descriptor, temporary_name = tempfile.mkstemp(prefix=".diagnostic-", dir=self.output_directory)
        temporary = Path(temporary_name)
        try:
            os.fchmod(descriptor, 0o600)
            with os.fdopen(descriptor, "wb", closefd=True) as stream:
                stream.write(payload)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, destination)
            os.chmod(destination, 0o600, follow_symlinks=False)
            directory_fd = os.open(self.output_directory, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
        except OSError as error:
            raise ThinClientDiagnosticError("diagnostic_write_failed") from error
        finally:
            temporary.unlink(missing_ok=True)

from __future__ import annotations

import json
import os
import re
import stat
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from xaac_agent.thin_client_contract import ContractOperation, ThinClientIntegrationContract


class ThinClientRuntimeError(ValueError):
    """Intercanvi efímer local no vàlid o insegur."""


_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$")


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _format_time(value: datetime) -> str:
    if value.tzinfo is None or value.utcoffset() is None:
        raise ThinClientRuntimeError("runtime_timestamp_requires_timezone")
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _parse_time(value: object) -> datetime:
    if not isinstance(value, str):
        raise ThinClientRuntimeError("invalid_runtime_timestamp")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as error:
        raise ThinClientRuntimeError("invalid_runtime_timestamp") from error
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ThinClientRuntimeError("runtime_timestamp_requires_timezone")
    return parsed.astimezone(timezone.utc)


def _safe_directory(path: Path, *, create: bool = False) -> None:
    if path.is_symlink():
        raise ThinClientRuntimeError("runtime_path_symlink")
    if create:
        try:
            path.mkdir(parents=True, mode=0o750, exist_ok=True)
            os.chmod(path, 0o750, follow_symlinks=False)
        except OSError as error:
            raise ThinClientRuntimeError("runtime_directory_create_failed") from error
    if not path.exists():
        raise ThinClientRuntimeError("runtime_directory_missing")
    mode = path.stat(follow_symlinks=False).st_mode
    if not stat.S_ISDIR(mode):
        raise ThinClientRuntimeError("runtime_path_not_directory")
    if mode & (stat.S_IROTH | stat.S_IWOTH):
        raise ThinClientRuntimeError("runtime_path_world_accessible")


def _atomic_write_json(path: Path, payload: dict[str, Any]) -> None:
    _safe_directory(path.parent, create=True)
    if path.is_symlink():
        raise ThinClientRuntimeError("runtime_file_symlink")
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    try:
        fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
        try:
            os.fchmod(fd, 0o640)
            with os.fdopen(fd, "wb", closefd=True) as handle:
                handle.write(raw)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temp_name, path)
            directory_fd = os.open(path.parent, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
        except Exception:
            try:
                os.unlink(temp_name)
            except OSError:
                pass
            raise
    except ThinClientRuntimeError:
        raise
    except OSError as error:
        raise ThinClientRuntimeError("runtime_atomic_write_failed") from error


def _read_json(path: Path, *, max_bytes: int) -> dict[str, Any]:
    if path.is_symlink():
        raise ThinClientRuntimeError("runtime_file_symlink")
    try:
        mode = path.stat(follow_symlinks=False).st_mode
    except FileNotFoundError as error:
        raise ThinClientRuntimeError("runtime_file_missing") from error
    if not stat.S_ISREG(mode):
        raise ThinClientRuntimeError("runtime_file_not_regular")
    if path.stat(follow_symlinks=False).st_size > max_bytes:
        raise ThinClientRuntimeError("runtime_file_too_large")
    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
    try:
        fd = os.open(path, flags)
        with os.fdopen(fd, "rb", closefd=True) as handle:
            raw = handle.read(max_bytes + 1)
    except OSError as error:
        raise ThinClientRuntimeError("runtime_file_read_failed") from error
    if len(raw) > max_bytes:
        raise ThinClientRuntimeError("runtime_file_too_large")
    try:
        value = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ThinClientRuntimeError("runtime_json_invalid") from error
    if not isinstance(value, dict):
        raise ThinClientRuntimeError("runtime_document_not_object")
    return value


@dataclass(frozen=True, slots=True)
class LocalHeartbeat:
    component: str
    instance_id: str
    boot_id: str
    sequence: int
    timestamp: datetime
    status: str = "healthy"

    def to_payload(self) -> dict[str, Any]:
        return {
            "format": "xaac-local-heartbeat/v1",
            "component": self.component,
            "instance_id": self.instance_id,
            "boot_id": self.boot_id,
            "sequence": self.sequence,
            "timestamp": _format_time(self.timestamp),
            "status": self.status,
        }

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "LocalHeartbeat":
        allowed = {"format", "component", "instance_id", "boot_id", "sequence", "timestamp", "status"}
        if set(payload) - allowed or payload.get("format") != "xaac-local-heartbeat/v1":
            raise ThinClientRuntimeError("invalid_heartbeat_format")
        component = payload.get("component")
        instance_id = payload.get("instance_id")
        boot_id = payload.get("boot_id")
        sequence = payload.get("sequence")
        status = payload.get("status")
        if component not in {"agent", "thin-client"}:
            raise ThinClientRuntimeError("invalid_heartbeat_component")
        if not isinstance(instance_id, str) or not _ID_RE.fullmatch(instance_id):
            raise ThinClientRuntimeError("invalid_heartbeat_instance_id")
        if not isinstance(boot_id, str) or not _ID_RE.fullmatch(boot_id):
            raise ThinClientRuntimeError("invalid_heartbeat_boot_id")
        if not isinstance(sequence, int) or isinstance(sequence, bool) or sequence < 0:
            raise ThinClientRuntimeError("invalid_heartbeat_sequence")
        if status not in {"healthy", "degraded", "stopping"}:
            raise ThinClientRuntimeError("invalid_heartbeat_status")
        return cls(component, instance_id, boot_id, sequence, _parse_time(payload.get("timestamp")), status)


@dataclass(frozen=True, slots=True)
class LocalEvent:
    event_id: str
    source: str
    event_type: str
    timestamp: datetime
    severity: str
    data: dict[str, Any]

    def to_payload(self) -> dict[str, Any]:
        return {
            "format": "xaac-local-event/v1",
            "event_id": self.event_id,
            "source": self.source,
            "event_type": self.event_type,
            "timestamp": _format_time(self.timestamp),
            "severity": self.severity,
            "data": self.data,
        }

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "LocalEvent":
        allowed = {"format", "event_id", "source", "event_type", "timestamp", "severity", "data"}
        if set(payload) - allowed or payload.get("format") != "xaac-local-event/v1":
            raise ThinClientRuntimeError("invalid_event_format")
        event_id, source, event_type = payload.get("event_id"), payload.get("source"), payload.get("event_type")
        if any(not isinstance(v, str) or not _ID_RE.fullmatch(v) for v in (event_id, source, event_type)):
            raise ThinClientRuntimeError("invalid_event_identity")
        severity = payload.get("severity")
        if severity not in {"debug", "info", "warning", "error", "critical"}:
            raise ThinClientRuntimeError("invalid_event_severity")
        data = payload.get("data")
        if not isinstance(data, dict):
            raise ThinClientRuntimeError("invalid_event_data")
        raw = json.dumps(data, ensure_ascii=False, allow_nan=False).encode("utf-8")
        if len(raw) > 16384:
            raise ThinClientRuntimeError("event_data_too_large")
        return cls(event_id, source, event_type, _parse_time(payload.get("timestamp")), severity, data)


class ThinClientRuntimeExchange:
    def __init__(
        self,
        *,
        contract: ThinClientIntegrationContract,
        boot_id_provider: Callable[[], str],
        max_file_bytes: int = 65536,
        max_events: int = 128,
    ) -> None:
        if not 1024 <= max_file_bytes <= 1024 * 1024:
            raise ThinClientRuntimeError("runtime_max_file_bytes_out_of_range")
        if not 1 <= max_events <= 4096:
            raise ThinClientRuntimeError("runtime_max_events_out_of_range")
        self.contract = contract
        self.boot_id_provider = boot_id_provider
        self.max_file_bytes = max_file_bytes
        self.max_events = max_events

    @property
    def heartbeat_directory(self) -> Path:
        return self.contract.runtime_root / "heartbeats"

    @property
    def event_directory(self) -> Path:
        return self.contract.runtime_root / "events"

    def initialize(self) -> None:
        self.contract.validate_layout(require_existing=False)
        _safe_directory(self.contract.runtime_root, create=True)
        _safe_directory(self.heartbeat_directory, create=True)
        _safe_directory(self.event_directory, create=True)
        self.cleanup_stale_boot_files()

    def publish_heartbeat(self, heartbeat: LocalHeartbeat) -> Path:
        operation = ContractOperation.PUBLISH_HEARTBEAT
        if not self.contract.is_operation_allowed(operation):
            raise ThinClientRuntimeError("runtime_operation_denied")
        if heartbeat.boot_id != self.boot_id_provider():
            raise ThinClientRuntimeError("heartbeat_boot_id_mismatch")
        path = self.heartbeat_directory / f"{heartbeat.component}.json"
        _atomic_write_json(path, heartbeat.to_payload())
        return path

    def read_heartbeat(self, component: str, *, max_age_seconds: int, now: datetime | None = None) -> tuple[LocalHeartbeat, bool]:
        if not self.contract.is_operation_allowed(ContractOperation.READ_HEARTBEAT):
            raise ThinClientRuntimeError("runtime_operation_denied")
        if component not in {"agent", "thin-client"} or not 1 <= max_age_seconds <= 86400:
            raise ThinClientRuntimeError("invalid_heartbeat_query")
        heartbeat = LocalHeartbeat.from_payload(_read_json(self.heartbeat_directory / f"{component}.json", max_bytes=self.max_file_bytes))
        current = now or _utc_now()
        stale = heartbeat.boot_id != self.boot_id_provider() or (current - heartbeat.timestamp).total_seconds() > max_age_seconds
        return heartbeat, stale

    def publish_event(self, event: LocalEvent) -> Path:
        if not self.contract.is_operation_allowed(ContractOperation.PUBLISH_EVENT):
            raise ThinClientRuntimeError("runtime_operation_denied")
        path = self.event_directory / f"{event.timestamp.strftime('%Y%m%dT%H%M%S%fZ')}-{event.event_id}.json"
        _atomic_write_json(path, event.to_payload())
        self._prune_events()
        return path

    def read_events(self, *, limit: int | None = None, remove: bool = False) -> tuple[LocalEvent, ...]:
        if not self.contract.is_operation_allowed(ContractOperation.READ_EVENTS):
            raise ThinClientRuntimeError("runtime_operation_denied")
        effective_limit = min(32, self.max_events) if limit is None else limit
        if not 1 <= effective_limit <= self.max_events:
            raise ThinClientRuntimeError("invalid_event_limit")
        _safe_directory(self.event_directory, create=True)
        result: list[LocalEvent] = []
        for path in sorted(self.event_directory.iterdir()):
            if len(result) >= effective_limit:
                break
            if path.is_symlink():
                raise ThinClientRuntimeError("runtime_file_symlink")
            event = LocalEvent.from_payload(_read_json(path, max_bytes=self.max_file_bytes))
            result.append(event)
            if remove:
                path.unlink()
        return tuple(result)

    def cleanup_stale_boot_files(self) -> int:
        current_boot = self.boot_id_provider()
        removed = 0
        for directory in (self.heartbeat_directory, self.event_directory):
            if not directory.exists():
                continue
            _safe_directory(directory)
            for path in directory.iterdir():
                if path.is_symlink():
                    raise ThinClientRuntimeError("runtime_file_symlink")
                if not path.is_file():
                    continue
                try:
                    payload = _read_json(path, max_bytes=self.max_file_bytes)
                    boot_id = payload.get("boot_id")
                    if directory == self.heartbeat_directory and boot_id == current_boot:
                        continue
                except ThinClientRuntimeError:
                    pass
                path.unlink()
                removed += 1
        return removed

    def _prune_events(self) -> None:
        paths = sorted(path for path in self.event_directory.iterdir() if path.is_file() and not path.is_symlink())
        for path in paths[:-self.max_events]:
            path.unlink()

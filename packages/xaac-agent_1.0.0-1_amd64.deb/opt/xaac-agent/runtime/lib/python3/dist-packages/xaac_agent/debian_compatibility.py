from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any


class DebianCompatibilityMatrixError(ValueError):
    """Raised when the production compatibility matrix is incomplete or unsafe."""


@dataclass(frozen=True, slots=True)
class DebianCompatibilityMatrix:
    package: str
    version: str
    matrix_document: Path
    installed_directory: Path
    production_os: tuple[str, ...]
    development_os: tuple[str, ...]
    architectures: tuple[str, ...]
    private_python: str
    system_python_dependency: bool
    required_init: str
    hardware_profiles: tuple[str, ...]
    support_levels: tuple[str, ...]

    @classmethod
    def load(cls, path: Path) -> "DebianCompatibilityMatrix":
        try:
            raw: Any = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise DebianCompatibilityMatrixError("compatibility_matrix_invalid") from exc
        if not isinstance(raw, dict) or raw.get("schema_version") != 1:
            raise DebianCompatibilityMatrixError("compatibility_matrix_schema_invalid")
        platforms = raw.get("platforms")
        runtime = raw.get("runtime")
        if not isinstance(platforms, dict) or not isinstance(runtime, dict):
            raise DebianCompatibilityMatrixError("compatibility_matrix_sections_invalid")
        return cls(
            package=str(raw.get("package", "")),
            version=str(raw.get("version", "")),
            matrix_document=Path(str(raw.get("matrix_document", ""))),
            installed_directory=Path(str(raw.get("installed_directory", ""))),
            production_os=tuple(str(item) for item in platforms.get("production", [])),
            development_os=tuple(str(item) for item in platforms.get("development", [])),
            architectures=tuple(str(item) for item in platforms.get("architectures", [])),
            private_python=str(runtime.get("private_python", "")),
            system_python_dependency=runtime.get("system_python_dependency") is True,
            required_init=str(raw.get("required_init", "")),
            hardware_profiles=tuple(str(item) for item in raw.get("hardware_profiles", [])),
            support_levels=tuple(str(item) for item in raw.get("support_levels", [])),
        )

    def validate(self, project_root: Path) -> None:
        if self.package != "xaac-agent" or self.version != "0.14.9":
            raise DebianCompatibilityMatrixError("compatibility_matrix_identity_invalid")
        if self.matrix_document.is_absolute() or ".." in self.matrix_document.parts:
            raise DebianCompatibilityMatrixError("compatibility_matrix_path_unsafe")
        document = project_root / self.matrix_document
        if not document.is_file():
            raise DebianCompatibilityMatrixError("compatibility_matrix_document_missing")
        if self.installed_directory != Path("/usr/share/doc/xaac-agent"):
            raise DebianCompatibilityMatrixError("compatibility_matrix_install_path_invalid")
        if self.production_os != ("Debian 13",):
            raise DebianCompatibilityMatrixError("compatibility_matrix_production_os_invalid")
        if set(self.development_os) != {"Zorin OS 17", "Zorin OS 18"}:
            raise DebianCompatibilityMatrixError("compatibility_matrix_development_os_invalid")
        if self.architectures != ("amd64",):
            raise DebianCompatibilityMatrixError("compatibility_matrix_architecture_invalid")
        if self.private_python != "3.13.x" or self.system_python_dependency:
            raise DebianCompatibilityMatrixError("compatibility_matrix_runtime_invalid")
        if self.required_init != "systemd":
            raise DebianCompatibilityMatrixError("compatibility_matrix_init_invalid")
        if set(self.hardware_profiles) != {"generic-amd64", "dell-wyse-3040"}:
            raise DebianCompatibilityMatrixError("compatibility_matrix_hardware_invalid")
        if set(self.support_levels) != {"supported", "development-only", "unsupported"}:
            raise DebianCompatibilityMatrixError("compatibility_matrix_support_levels_invalid")
        text = document.read_text(encoding="utf-8")
        for required in (
            "Debian 13", "Zorin OS 17", "Zorin OS 18", "Dell Wyse 3040", "amd64",
            "Python 3.13", "/opt/xaac-agent/runtime", "/usr/bin/python3", "systemd",
            "supported", "development-only", "unsupported",
        ):
            if required not in text:
                raise DebianCompatibilityMatrixError("compatibility_matrix_content_incomplete")

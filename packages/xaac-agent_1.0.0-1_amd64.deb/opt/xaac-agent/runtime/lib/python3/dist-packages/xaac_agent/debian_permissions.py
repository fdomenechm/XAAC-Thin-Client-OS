from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any


class DebianPermissionsError(ValueError):
    """Raised when the Debian account or permission policy is unsafe."""


_NAME_RE = re.compile(r"^[a-z_][a-z0-9_-]{0,30}$")
_MODE_RE = re.compile(r"^0[0-7]{3}$")


@dataclass(frozen=True, slots=True)
class ManagedPathPermission:
    path: Path
    owner: str
    group: str
    mode: str
    writable_by_service: bool
    optional: bool = False


@dataclass(frozen=True, slots=True)
class DebianPermissionsPolicy:
    service_user: str
    primary_group: str
    supplementary_groups: tuple[str, ...]
    home: Path
    shell: Path
    managed_paths: tuple[ManagedPathPermission, ...]

    @classmethod
    def load(cls, path: Path) -> "DebianPermissionsPolicy":
        try:
            raw: Any = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise DebianPermissionsError("debian_permissions_invalid") from exc
        if not isinstance(raw, dict) or raw.get("schema_version") != 1:
            raise DebianPermissionsError("debian_permissions_schema_invalid")
        service = raw.get("service")
        paths = raw.get("paths")
        if not isinstance(service, dict) or not isinstance(paths, list) or not paths:
            raise DebianPermissionsError("debian_permissions_sections_invalid")
        user = service.get("user")
        group = service.get("primary_group")
        supplementary = service.get("supplementary_groups")
        if not isinstance(user, str) or not isinstance(group, str):
            raise DebianPermissionsError("debian_permissions_identity_invalid")
        if not isinstance(supplementary, list) or any(not isinstance(item, str) for item in supplementary):
            raise DebianPermissionsError("debian_permissions_groups_invalid")
        if service.get("dynamic") is not False:
            raise DebianPermissionsError("debian_permissions_dynamic_user_forbidden")
        managed: list[ManagedPathPermission] = []
        seen: set[Path] = set()
        for item in paths:
            if not isinstance(item, dict):
                raise DebianPermissionsError("debian_permissions_path_invalid")
            item_path = Path(str(item.get("path", "")))
            owner = item.get("owner")
            item_group = item.get("group")
            mode = item.get("mode")
            writable = item.get("writable_by_service")
            if item_path in seen or not item_path.is_absolute() or ".." in item_path.parts:
                raise DebianPermissionsError("debian_permissions_path_unsafe")
            if not isinstance(owner, str) or not isinstance(item_group, str) or not isinstance(mode, str):
                raise DebianPermissionsError("debian_permissions_path_fields_invalid")
            if not _MODE_RE.fullmatch(mode) or not isinstance(writable, bool):
                raise DebianPermissionsError("debian_permissions_mode_invalid")
            seen.add(item_path)
            managed.append(
                ManagedPathPermission(
                    path=item_path,
                    owner=owner,
                    group=item_group,
                    mode=mode,
                    writable_by_service=writable,
                    optional=item.get("optional") is True,
                )
            )
        return cls(
            service_user=user,
            primary_group=group,
            supplementary_groups=tuple(supplementary),
            home=Path(str(service.get("home", ""))),
            shell=Path(str(service.get("shell", ""))),
            managed_paths=tuple(managed),
        )

    def validate(self) -> None:
        names = (self.service_user, self.primary_group, *self.supplementary_groups)
        if any(not _NAME_RE.fullmatch(name) for name in names):
            raise DebianPermissionsError("debian_permissions_name_invalid")
        if self.service_user != "xaac-agent" or self.primary_group != "xaac-agent":
            raise DebianPermissionsError("debian_permissions_service_identity_invalid")
        if self.supplementary_groups != ("xaac-command",):
            raise DebianPermissionsError("debian_permissions_supplementary_groups_invalid")
        if self.home != Path("/var/lib/xaac-agent") or self.shell != Path("/usr/sbin/nologin"):
            raise DebianPermissionsError("debian_permissions_account_profile_invalid")
        by_path = {item.path: item for item in self.managed_paths}
        required_writable = {
            Path("/var/lib/xaac-agent"),
            Path("/var/cache/xaac-agent"),
            Path("/var/log/xaac-agent"),
            Path("/run/xaac-agent"),
        }
        for path in required_writable:
            item = by_path.get(path)
            if item is None or not item.writable_by_service or item.owner != self.service_user:
                raise DebianPermissionsError("debian_permissions_writable_path_invalid")
        for protected in (Path("/opt/xaac-agent"), Path("/etc/xaac-agent")):
            item = by_path.get(protected)
            if item is None or item.owner != "root" or item.writable_by_service:
                raise DebianPermissionsError("debian_permissions_protected_path_invalid")
        socket = by_path.get(Path("/run/xaac-agent/privileged.sock"))
        if socket is None or socket.owner != "root" or socket.group != "xaac-command" or socket.mode != "0660":
            raise DebianPermissionsError("debian_permissions_socket_invalid")
        for item in self.managed_paths:
            numeric_mode = int(item.mode, 8)
            if item.path.as_posix().startswith("/etc/") and numeric_mode & 0o002:
                raise DebianPermissionsError("debian_permissions_config_world_writable")
            if item.path.as_posix().startswith("/opt/") and numeric_mode & 0o022:
                raise DebianPermissionsError("debian_permissions_runtime_writable")

#!/bin/sh
set -eu

VPN_APP=${XAAC_VPN_APP:-/usr/bin/xaac-thin-client-vpn}
THIN_CLIENT=${XAAC_THIN_CLIENT_APP:-/usr/bin/xaac-thin-client}
POLICY=${XAAC_VPN_POLICY:-optional}

case "$POLICY" in
    disabled)
        exec "$THIN_CLIENT"
        ;;
    optional|required)
        ;;
    *)
        echo "ERROR: política VPN desconeguda: $POLICY" >&2
        exit 2
        ;;
esac

# The GUI exit contract for Phase 4 OS integration:
#   0 = VPN connected / continue
#   10 = user skipped optional VPN
# other = failure/cancel
if "$VPN_APP"; then
    VPN_RC=0
else
    VPN_RC=$?
fi

case "$VPN_RC" in
    0)
        exec "$THIN_CLIENT"
        ;;
    10)
        if [ "$POLICY" = "optional" ]; then
            exec "$THIN_CLIENT"
        fi
        echo "ERROR: la VPN és obligatòria i no es pot ometre." >&2
        exit 10
        ;;
    *)
        echo "ERROR: XAAC Thin Client VPN ha finalitzat amb codi $VPN_RC." >&2
        exit "$VPN_RC"
        ;;
esac
